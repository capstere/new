﻿# RuleBank Configuration Guide

## Filhierarki
- 01_ResultCallPatterns.csv: Tolkar "Test Result" → Call (POS/NEG/ERROR)
- 02_SampleExpectationRules.csv: Förväntat call baserat på Sample ID
- 03_ErrorCodes.csv: Felkodsmappning (inkl. intervall)
- 04_MissingSamplesConfig.csv: Konfig för saknade samples (template)
- 05_SampleIdMarkers.csv: Markers/tokenindex för Sample ID
- 06_ParityCheckConfig.csv: Parity/suffix-logik per assay
- 07_SampleNumberRules.csv: Sample-nummerregler (regex, min/max, padding)

## Lägga till nytt assay (checklista)
1. Lägg till patterns i 01_ResultCallPatterns.csv
2. Lägg till expectations i 02_SampleExpectationRules.csv
3. Lägg till markers i 05_SampleIdMarkers.csv (om behövs)
4. Lägg till parity-config i 06_ParityCheckConfig.csv (om behövs)
5. Lägg till sample-number-regler i 07_SampleNumberRules.csv

## Viktiga körregler (kodbaserade) som påverkar RuleBank
- **Status != Done ger alltid ObservedCall=ERROR** innan 01_ResultCallPatterns utvärderas.
  - Det betyder att patterns i **01_ResultCallPatterns.csv** endast är relevanta när Status är **Done** och Error-kolumnen är tom.
- **06_ParityCheckConfig.csv** matchas med **första träff (priority-sorterad DESC)**. En wildcard-rad (`AssayPattern=*`) bör därför vara **disabled** om den bara är en mall.
- **05_SampleIdMarkers.csv**: kolumnen `SampleTokenIndex` ingår i filschemat men används inte av `Get-MarkerValue` (RuleEngine läser endast `Marker`).

## Ändringar i denna version
- 01_ResultCallPatterns.csv: fixade en rad med saknad Enabled/Priority ("Aborted").
- 06_ParityCheckConfig.csv: inaktiverade wildcard-template-raden (`*`).
- 05_SampleIdMarkers.csv: inaktiverade `DelaminationSeparator` eftersom den är dokumentation/mall och inte används av RuleEngine.

