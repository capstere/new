﻿#requires -Version 5.1
<#
  Build-RuleBank.ps1
  Creates RuleBank.compiled.psd1 from RuleBank CSV files.
  - Fail-fast: validates required CSV files and required columns.
  - Output is a pure PowerShell data file (constants only) compatible with Import-PowerShellDataFile.
  - Intended to be run by developers / maintainers when RuleBank CSV is updated.

  Usage:
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Build-RuleBank.ps1
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-ThisDir {
    $p = $PSScriptRoot
    if (-not $p) { $p = Split-Path -Parent $MyInvocation.MyCommand.Path }
    return $p
}

function Assert-FileExists {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        throw "RuleBank build: Fil saknas: $Path"
    }
}

function Import-RuleCsv {
    param([Parameter(Mandatory)][string]$Path)

    Assert-FileExists -Path $Path

    # delimiter detect (comma vs semicolon)
    $sample = (Get-Content -LiteralPath $Path -TotalCount 1)
    $delim = ','
    if ($sample -and ($sample -match ';') -and ($sample -notmatch ',')) { $delim = ';' }

    return @(Import-Csv -LiteralPath $Path -Delimiter $delim)
}

function Get-CsvHeaders {
    param([Parameter(Mandatory)][string]$Path)

    $sample = (Get-Content -LiteralPath $Path -TotalCount 1)
    $delim = ','
    if ($sample -and ($sample -match ';') -and ($sample -notmatch ',')) { $delim = ';' }

    $hdrLine = (Get-Content -LiteralPath $Path -TotalCount 1)
    if (-not $hdrLine) { return @() }
    return @($hdrLine.Split($delim) | ForEach-Object { ($_ + '').Trim().Trim('"') })
}

function Assert-HasColumns {
    param(
        [Parameter(Mandatory)][string]$CsvPath,
        [Parameter(Mandatory)][string[]]$RequiredColumns
    )
    $hdr = Get-CsvHeaders -Path $CsvPath
    if (-not $hdr -or $hdr.Count -eq 0) { throw "RuleBank build: Kan inte läsa header: $CsvPath" }

    foreach ($c in $RequiredColumns) {
        if (-not ($hdr -contains $c)) {
            throw ("RuleBank build: Saknar kolumn '" + $c + "' i " + (Split-Path -Leaf $CsvPath))
        }
    }
}

function ConvertTo-Psd1Literal {
    <#
      Serializes ONLY:
        - hashtables
        - arrays
        - strings, numbers, booleans, $null
      Output is safe for Import-PowerShellDataFile (no expressions).
    #>
    param(
        [Parameter(Mandatory)]$Value,
        [int]$Indent = 0
    )

    $sp = (' ' * $Indent)

    if ($null -eq $Value) { return '$null' }

    if ($Value -is [bool]) { return ($(if ($Value) { '$true' } else { '$false' })) }

    if ($Value -is [int] -or $Value -is [long] -or $Value -is [double] -or $Value -is [decimal]) {
        return ([string]$Value)
    }

    if ($Value -is [string]) {
        $s = $Value.Replace("'", "''")
        return ("'" + $s + "'")
    }

    if ($Value -is [System.Collections.IDictionary]) {
        if ($Value.Count -eq 0) { return '@{}' }
        $lines = New-Object System.Collections.Generic.List[string]
        $lines.Add('@{')
        foreach ($k in $Value.Keys) {
            $key = [string]$k
            if ($key -match '^[A-Za-z_][A-Za-z0-9_]*$') { $kLit = $key }
            else { $kLit = ("'" + $key.Replace("'", "''") + "'") }

            $vLit = ConvertTo-Psd1Literal -Value $Value[$k] -Indent ($Indent + 4)
            $lines.Add((' ' * ($Indent + 4)) + $kLit + ' = ' + $vLit)
        }
        $lines.Add($sp + '}')
        return ($lines -join "`r`n")
    }

    if ($Value -is [System.Collections.IEnumerable] -and ($Value -isnot [string])) {
        $arr = @($Value)
        if ($arr.Count -eq 0) { return '@()' }
        $lines = New-Object System.Collections.Generic.List[string]
        $lines.Add('@(')
        foreach ($item in $arr) {
            $lines.Add((' ' * ($Indent + 4)) + (ConvertTo-Psd1Literal -Value $item -Indent ($Indent + 4)))
        }
        $lines.Add($sp + ')')
        return ($lines -join "`r`n")
    }

    # Fallback as string
    $s2 = ([string]$Value).Replace("'", "''")
    return ("'" + $s2 + "'")
}

function To-PlainRow {
    param([Parameter(Mandatory)][object]$Row)
    $h = @{}
    foreach ($p in $Row.PSObject.Properties) {
        $h[$p.Name] = $p.Value
    }
    return $h
}

# ---------------- Main ----------------
$ruleBankDir = Get-ThisDir

$files = @{
    ResultCallPatterns     = '01_ResultCallPatterns.csv'
    SampleExpectationRules = '02_SampleExpectationRules.csv'
    ErrorCodes             = '03_ErrorCodes.csv'
    SampleIdMarkers        = '05_SampleIdMarkers.csv'
    ParityCheckConfig      = '06_ParityCheckConfig.csv'
    SampleNumberRules      = '07_SampleNumberRules.csv'
    TestTypePolicy         = '08_TestTypePolicy.csv'
}

# Column validation (fail fast)
$req = @{
    ResultCallPatterns     = @('Assay','MatchType','Pattern','Call','Priority')
    SampleExpectationRules = @('Assay','SampleIdMatchType','SampleIdPattern','Expected','Priority')
    ErrorCodes             = @('ErrorCode','Name','GeneratesRetest')
    SampleIdMarkers        = @('AssayPattern','MarkerType','Marker','SampleTokenIndex','Enabled')
    ParityCheckConfig      = @('AssayPattern','Enabled','Priority')
    SampleNumberRules      = @('AssayPattern','Enabled','Priority')
    TestTypePolicy         = @('AssayPattern','AllowedTestTypes','Enabled','Priority')
}

foreach ($k in $files.Keys) {
    $p = Join-Path $ruleBankDir $files[$k]
    Assert-FileExists -Path $p
    if ($req[$k] -and $req[$k].Count -gt 0) {
        Assert-HasColumns -CsvPath $p -RequiredColumns $req[$k]
    }
}

# Import all CSV
$rb = @{}
foreach ($k in $files.Keys) {
    $p = Join-Path $ruleBankDir $files[$k]
    $rb[$k] = @(Import-RuleCsv -Path $p)
}

# Output payload (pure data)
$out = @{
    Meta = @{
        GeneratedOn = (Get-Date).ToString('s')
        Counts = @{
            ResultCallPatterns     = @($rb.ResultCallPatterns).Count
            SampleExpectationRules = @($rb.SampleExpectationRules).Count
            ErrorCodes             = @($rb.ErrorCodes).Count
            SampleIdMarkers        = @($rb.SampleIdMarkers).Count
            ParityCheckConfig      = @($rb.ParityCheckConfig).Count
            SampleNumberRules      = @($rb.SampleNumberRules).Count
            TestTypePolicy         = @($rb.TestTypePolicy).Count
        }
    }

    ResultCallPatterns     = @($rb.ResultCallPatterns | ForEach-Object { To-PlainRow $_ })
    SampleExpectationRules = @($rb.SampleExpectationRules | ForEach-Object { To-PlainRow $_ })
    ErrorCodes             = @($rb.ErrorCodes | ForEach-Object { To-PlainRow $_ })
    SampleIdMarkers        = @($rb.SampleIdMarkers | ForEach-Object { To-PlainRow $_ })
    ParityCheckConfig      = @($rb.ParityCheckConfig | ForEach-Object { To-PlainRow $_ })
    SampleNumberRules      = @($rb.SampleNumberRules | ForEach-Object { To-PlainRow $_ })
    TestTypePolicy         = @($rb.TestTypePolicy | ForEach-Object { To-PlainRow $_ })
}

$psd1 = ConvertTo-Psd1Literal -Value $out -Indent 0
$dest = Join-Path $ruleBankDir 'RuleBank.compiled.psd1'
[System.IO.File]::WriteAllText($dest, $psd1, [System.Text.Encoding]::UTF8)

Write-Host "✅ Skapade: $dest"
