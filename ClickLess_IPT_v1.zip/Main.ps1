﻿
#requires -version 5.1
Set-StrictMode -Version 2

$ErrorActionPreference = 'Stop'

$script:Root = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $script:Root 'Modules\Init.ps1')
Import-ClickLessModules -Root $script:Root

# Load config
$configPath = Join-Path $script:Root 'config.psd1'
if (-not (Test-Path $configPath)) { throw "Missing config.psd1" }
$config = Import-PowerShellDataFile -Path $configPath

# Logging
Initialize-Logging -LogFolder (Join-Path $script:Root $config.LogFolder) -Level $config.LogLevel
Write-Info "App starting. Root=$script:Root"

# Load EPPlus
try {
    Load-EPPlus -LibPath (Join-Path $script:Root 'Lib\EPPlus.dll')
    Write-Info "EPPlus loaded."
} catch {
    Write-ErrorLog ("Failed to load EPPlus: {0}" -f (Format-Exception $_.Exception))
    [System.Windows.Forms.MessageBox]::Show("EPPlus.dll is missing. Copy EPPlus 4.5.3.3 to .\Lib\EPPlus.dll`n`nSee README.txt", "Dependency missing", 'OK', 'Error') | Out-Null
    throw
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing


function Get-ChildFoldersMaxDepth {
    param(
        [Parameter(Mandatory=$true)][string]$RootPath,
        [Parameter(Mandatory=$true)][int]$MaxDepth
    )
    $out = New-Object System.Collections.Generic.List[System.IO.DirectoryInfo]
    $q = New-Object System.Collections.Generic.Queue[object]
    $q.Enqueue(@($RootPath, 0))
    while ($q.Count -gt 0) {
        $item = $q.Dequeue()
        $path = [string]$item[0]
        $depth = [int]$item[1]

        if ($depth -ge $MaxDepth) { continue }

        $subs = @()
        try {
            $subs = Get-ChildItem -Path $path -Directory -ErrorAction SilentlyContinue
        } catch { $subs = @() }

        foreach ($s in $subs) {
            $out.Add($s) | Out-Null
            $q.Enqueue(@($s.FullName, $depth + 1))
        }
    }
    return $out
}

function Find-BatchFolder {
    param([string]$LSP, [string]$RootPath)
    if ([string]::IsNullOrWhiteSpace($LSP)) { return $null }
    if (-not (Test-Path $RootPath)) { return $null }

    # 1) Shallow search
    $folders = Get-ChildItem -Path $RootPath -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match [Regex]::Escape($LSP) }
    if ($folders.Count -gt 0) { return $folders[0].FullName }

    # 2) Bounded-depth search (depth 2)
    $all = Get-ChildFoldersMaxDepth -RootPath $RootPath -MaxDepth 2
    $hit = $all | Where-Object { $_.Name -match [Regex]::Escape($LSP) } | Select-Object -First 1
    if ($hit) { return $hit.FullName }

    return $null
}
if (-not (Test-Path $RootPath)) { return $null }

    # Common: batch folder contains LSP in its name
    $folders = Get-ChildItem -Path $RootPath -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match [Regex]::Escape($LSP) }
    if ($folders.Count -gt 0) { return $folders[0].FullName }

    # Deep search (limited)
    $folders2 = Get-ChildItem -Path $RootPath -Directory -Recurse -Depth 2 -ErrorAction SilentlyContinue | Where-Object { $_.Name -match [Regex]::Escape($LSP) }
    if ($folders2.Count -gt 0) { return $folders2[0].FullName }

    return $null
}

function Get-CandidateFiles {
    param([string]$BatchFolder)
    if (-not (Test-Path $BatchFolder)) { return @{} }

    $files = Get-ChildItem -Path $BatchFolder -File -Recurse -ErrorAction SilentlyContinue

    $csv = $files | Where-Object { $_.Extension -ieq '.csv' -and $_.Name -match '(?i)tests\s*summary' } | Select-Object -First 25
    $neg = $files | Where-Object { $_.Extension -ieq '.xlsx' -and $_.Name -match '(?i)seal\s*test' -and $_.Name -match '(?i)neg' } | Select-Object -First 25
    $pos = $files | Where-Object { $_.Extension -ieq '.xlsx' -and $_.Name -match '(?i)seal\s*test' -and $_.Name -match '(?i)pos' } | Select-Object -First 25
    $ws  = $files | Where-Object { $_.Extension -ieq '.xlsx' -and $_.Name -match '^(?i)D\d{5,}' } | Select-Object -First 25

    return @{
        TestsSummary = $csv
        SealNeg = $neg
        SealPos = $pos
        Worksheet = $ws
    }
}

function Copy-ToLocalTempIfNeeded {
    param([string]$Path, [string]$WorkDir)
    if (-not (Test-Path $Path)) { throw "Missing input: $Path" }
    if (-not (Test-Path $WorkDir)) { New-Item -ItemType Directory -Path $WorkDir | Out-Null }

    $dest = Join-Path $WorkDir ([IO.Path]::GetFileName($Path))
    Copy-Item -Path $Path -Destination $dest -Force
    return $dest
}

# GUI
$form = New-Object System.Windows.Forms.Form
$form.Text = "Click Less / IPT Compiling (v1)"
$form.Size = New-Object System.Drawing.Size(860, 420)
$form.StartPosition = 'CenterScreen'

$lblLsp = New-Object System.Windows.Forms.Label
$lblLsp.Text = "LSP:"
$lblLsp.Location = New-Object System.Drawing.Point(20,20)
$lblLsp.AutoSize = $true
$form.Controls.Add($lblLsp)

$txtLsp = New-Object System.Windows.Forms.TextBox
$txtLsp.Location = New-Object System.Drawing.Point(70,18)
$txtLsp.Size = New-Object System.Drawing.Size(160, 24)
$form.Controls.Add($txtLsp)

$btnSearch = New-Object System.Windows.Forms.Button
$btnSearch.Text = "Search"
$btnSearch.Location = New-Object System.Drawing.Point(250, 16)
$btnSearch.Size = New-Object System.Drawing.Size(90, 28)
$form.Controls.Add($btnSearch)

$lblBatch = New-Object System.Windows.Forms.Label
$lblBatch.Text = "Batch folder:"
$lblBatch.Location = New-Object System.Drawing.Point(20,55)
$lblBatch.AutoSize = $true
$form.Controls.Add($lblBatch)

$txtBatch = New-Object System.Windows.Forms.TextBox
$txtBatch.Location = New-Object System.Drawing.Point(110,52)
$txtBatch.Size = New-Object System.Drawing.Size(700, 24)
$txtBatch.ReadOnly = $true
$form.Controls.Add($txtBatch)

function Add-FilePickerRow([string]$label,[int]$top,[ref]$combo,[ref]$browseBtn) {
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = $label
    $lbl.Location = New-Object System.Drawing.Point(20,$top)
    $lbl.AutoSize = $true
    $form.Controls.Add($lbl)

    $cb = New-Object System.Windows.Forms.ComboBox
    $cb.Location = New-Object System.Drawing.Point(170,$top-3)
    $cb.Size = New-Object System.Drawing.Size(560, 24)
    $cb.DropDownStyle = 'DropDownList'
    $form.Controls.Add($cb)

    $btn = New-Object System.Windows.Forms.Button
    $btn.Text = "Browse..."
    $btn.Location = New-Object System.Drawing.Point(740,$top-5)
    $btn.Size = New-Object System.Drawing.Size(80, 28)
    $form.Controls.Add($btn)

    $combo.Value = $cb
    $browseBtn.Value = $btn
}

$cbCsv=$null;$btnCsv=$null
$cbNeg=$null;$btnNeg=$null
$cbPos=$null;$btnPos=$null
$cbWs =$null;$btnWs =$null

Add-FilePickerRow -label "1) Tests Summary (CSV)" -top 95  -combo ([ref]$cbCsv) -browseBtn ([ref]$btnCsv)
Add-FilePickerRow -label "2) Seal Test NEG (XLSX)" -top 135 -combo ([ref]$cbNeg) -browseBtn ([ref]$btnNeg)
Add-FilePickerRow -label "3) Seal Test POS (XLSX)" -top 175 -combo ([ref]$cbPos) -browseBtn ([ref]$btnPos)
Add-FilePickerRow -label "4) Worksheet (XLSX)" -top 215 -combo ([ref]$cbWs)  -browseBtn ([ref]$btnWs)

$btnCreate = New-Object System.Windows.Forms.Button
$btnCreate.Text = "Create Report"
$btnCreate.Location = New-Object System.Drawing.Point(20, 270)
$btnCreate.Size = New-Object System.Drawing.Size(160, 35)
$form.Controls.Add($btnCreate)

$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.Text = "Ready."
$lblStatus.Location = New-Object System.Drawing.Point(200, 278)
$lblStatus.Size = New-Object System.Drawing.Size(620, 30)
$form.Controls.Add($lblStatus)

$ofd = New-Object System.Windows.Forms.OpenFileDialog
$ofd.InitialDirectory = $script:Root
$ofd.Multiselect = $false

function Set-Status([string]$msg) {
    $lblStatus.Text = $msg
    $form.Refresh()
    Write-Info $msg
}

function Populate-Combos([hashtable]$cand) {
    $cbCsv.Items.Clear(); $cbNeg.Items.Clear(); $cbPos.Items.Clear(); $cbWs.Items.Clear()

    foreach ($f in $cand.TestsSummary) { [void]$cbCsv.Items.Add($f.FullName) }
    foreach ($f in $cand.SealNeg)     { [void]$cbNeg.Items.Add($f.FullName) }
    foreach ($f in $cand.SealPos)     { [void]$cbPos.Items.Add($f.FullName) }
    foreach ($f in $cand.Worksheet)   { [void]$cbWs.Items.Add($f.FullName) }

    if ($cbCsv.Items.Count -gt 0) { $cbCsv.SelectedIndex = 0 }
    if ($cbNeg.Items.Count -gt 0) { $cbNeg.SelectedIndex = 0 }
    if ($cbPos.Items.Count -gt 0) { $cbPos.SelectedIndex = 0 }
    if ($cbWs.Items.Count -gt 0)  { $cbWs.SelectedIndex  = 0 }
}

function Browse-File([string]$filter,[ref]$combo) {
    $ofd.Filter = $filter
    if ($ofd.ShowDialog() -eq 'OK') {
        $path = $ofd.FileName
        if (-not ($combo.Value.Items -contains $path)) { [void]$combo.Value.Items.Add($path) }
        $combo.Value.SelectedItem = $path
    }
}

$btnCsv.Add_Click({ Browse-File -filter "CSV files (*.csv)|*.csv" -combo ([ref]$cbCsv) })
$btnNeg.Add_Click({ Browse-File -filter "Excel files (*.xlsx)|*.xlsx" -combo ([ref]$cbNeg) })
$btnPos.Add_Click({ Browse-File -filter "Excel files (*.xlsx)|*.xlsx" -combo ([ref]$cbPos) })
$btnWs.Add_Click({ Browse-File -filter "Excel files (*.xlsx)|*.xlsx" -combo ([ref]$cbWs) })

function Do-Search {
    $lsp = $txtLsp.Text.Trim()
    Set-Status ("Searching for LSP {0}..." -f $lsp)

    $batch = Find-BatchFolder -LSP $lsp -RootPath $config.BatchRootPath
    if ($null -eq $batch) {
        Set-Status ("No batch folder found under {0} for LSP {1}" -f $config.BatchRootPath, $lsp)
        $txtBatch.Text = ''
        return
    }
    $txtBatch.Text = $batch
    Write-Info ("Batch folder: {0}" -f $batch)

    $cand = Get-CandidateFiles -BatchFolder $batch
    Populate-Combos -cand $cand
    Set-Status "Select files and click Create Report."
}

$btnSearch.Add_Click({ Do-Search })
$txtLsp.Add_KeyDown({
    if ($_.KeyCode -eq 'Enter') { Do-Search }
})

function Validate-Inputs {
    $errs = New-Object System.Collections.Generic.List[string]
    $csv = [string]$cbCsv.SelectedItem
    $neg = [string]$cbNeg.SelectedItem
    $pos = [string]$cbPos.SelectedItem
    $ws  = [string]$cbWs.SelectedItem

    if ([string]::IsNullOrWhiteSpace($csv)) { $errs.Add("Tests Summary CSV not selected.") | Out-Null }
    elseif ([IO.Path]::GetExtension($csv) -ine '.csv') { $errs.Add("Tests Summary must be CSV (live input constraint).") | Out-Null }

    if ([string]::IsNullOrWhiteSpace($neg)) { $errs.Add("Seal Test NEG not selected.") | Out-Null }
    if ([string]::IsNullOrWhiteSpace($pos)) { $errs.Add("Seal Test POS not selected.") | Out-Null }
    if ([string]::IsNullOrWhiteSpace($ws))  { $errs.Add("Worksheet not selected.") | Out-Null }

    return @{
        Ok = ($errs.Count -eq 0)
        Errors = $errs
        Csv=$csv; Neg=$neg; Pos=$pos; Worksheet=$ws
    }
}

$btnCreate.Add_Click({
    try {
        $val = Validate-Inputs
        if (-not $val.Ok) {
            [System.Windows.Forms.MessageBox]::Show(($val.Errors -join "`r`n"), "Missing inputs", 'OK', 'Warning') | Out-Null
            return
        }

        $lsp = $txtLsp.Text.Trim()
        $batchFolder = $txtBatch.Text.Trim()
        if ([string]::IsNullOrWhiteSpace($batchFolder)) {
            [System.Windows.Forms.MessageBox]::Show("No batch folder. Search first.", "Workflow", 'OK', 'Warning') | Out-Null
            return
        }

        $workDir = $batchFolder
        $localWork = $null
        if ($config.UseLocalTempWorkDir) {
            $localWork = Join-Path $config.TempRoot ("{0}_{1}" -f $lsp,(Get-Date).ToString('yyyyMMdd_HHmmss'))
            New-Item -ItemType Directory -Path $localWork -Force | Out-Null
            Set-Status "Copying inputs to local temp..."
        }

        $csvPath = $val.Csv
        $negPath = $val.Neg
        $posPath = $val.Pos
        $wsPath  = $val.Worksheet

        if ($localWork) {
            $csvPath = Copy-ToLocalTempIfNeeded -Path $csvPath -WorkDir $localWork
            $negPath = Copy-ToLocalTempIfNeeded -Path $negPath -WorkDir $localWork
            $posPath = Copy-ToLocalTempIfNeeded -Path $posPath -WorkDir $localWork
            $wsPath  = Copy-ToLocalTempIfNeeded -Path $wsPath  -WorkDir $localWork
        }

        Start-Timer 'TOTAL'

        Set-Status "Importing Seal tests..."
        Start-Timer 'SEAL'
        $sealNeg = Import-SealTest -Path $negPath -Label 'NEG'
        $sealPos = Import-SealTest -Path $posPath -Label 'POS'
        $sealInfo = @{ Neg=$sealNeg; Pos=$sealPos }
        Write-Info ("Seal import ms: {0}" -f (Stop-Timer 'SEAL'))

        Set-Status "Importing Worksheet..."
        Start-Timer 'WS'
        $worksheetInfo = Import-WorksheetXlsx -Path $wsPath
        Write-Info ("Worksheet import ms: {0}" -f (Stop-Timer 'WS'))

        Set-Status "Importing Tests Summary CSV..."
        Start-Timer 'CSV'
        $csvBundle = Import-TestsSummaryCsv -Path $csvPath -Config $config
        Write-Info ("CSV import rows={0} ms={1}" -f $csvBundle.Rows.Count, (Stop-Timer 'CSV'))

        Set-Status "Compiling + validating..."
        Start-Timer 'ENGINE'
        $engineOut = Invoke-RuleEngine -Rows $csvBundle.Rows -SealInfo $sealInfo -WorksheetInfo $worksheetInfo -AssayNameHint $null
        Write-Info ("Engine ms: {0}" -f (Stop-Timer 'ENGINE'))

        $template = Resolve-Path -Path (Join-Path $script:Root $config.TemplatePath) -ErrorAction Stop
        $outFolder = Join-Path $batchFolder $config.OutputSubFolderName
        $outName = "{0}_ClickLess_Report_{1}.xlsx" -f $lsp,(Get-Date).ToString('yyyyMMdd_HHmmss')
        $outPath = Join-Path $outFolder $outName

        Set-Status "Writing report..."
        Start-Timer 'WRITE'
        $meta = @{
            LSP = $lsp
            TestsSummaryCsv = $val.Csv
            SealNeg = $val.Neg
            SealPos = $val.Pos
            Worksheet = $val.Worksheet
            BatchFolder = $batchFolder
            LogPath = (Get-LogPath)
        }
        Write-Report -TemplatePath $template.Path -OutputPath $outPath -Meta $meta -SealInfo $sealInfo -WorksheetInfo $worksheetInfo -Findings $engineOut.Findings -Stats $engineOut.Stats -RawRows $csvBundle.RawRows
        Write-Info ("Write ms: {0}" -f (Stop-Timer 'WRITE'))

        $msTotal = Stop-Timer 'TOTAL'
        Set-Status ("DONE. Report: {0} (Total {1} ms)" -f $outPath, $msTotal)
        [System.Windows.Forms.MessageBox]::Show("Report created:`r`n$outPath`r`n`r`nLog:`r`n$(Get-LogPath)", "Done", 'OK', 'Information') | Out-Null

    } catch {
        $msg = Format-Exception $_.Exception
        Write-ErrorLog $msg
        [System.Windows.Forms.MessageBox]::Show("Error:`r`n$msg`r`n`r`nSee log: $(Get-LogPath)", "Error", 'OK', 'Error') | Out-Null
    }
})

# Template check warning early (fail hard only at write time per spec; but warn here)
if (-not (Test-Path (Join-Path $script:Root $config.TemplatePath))) {
    Write-Warn "Template missing at startup: $($config.TemplatePath)"
}

[void]$form.ShowDialog()
