﻿
Set-StrictMode -Version 2

# Pure data (no heavy logic)

$Global:ErrorBank = @{
    MinorFunctionalCodes = @(
        2008,2009,
        2125,
        2096,2097,
        2037,
        5006,5007,5008,5009,5017,5018,5019,
        5001,5002,5003,5004,5005,5015,5016,
        5011
    )
    MajorFunctionalCodes = @(
        # Placeholder for assay-specific major codes if ever needed
    )
}

# Assay profiles (extend as you add assays)
$Global:AssayProfiles = @{
    'GXMTB/RIF Ultra' = @{
        Name = 'GXMTB/RIF Ultra'
        TestTypePolicy = @{
            Mode = 'SpecimenOnly'  # SpecimenOnly | ControlsBySampleType
            ExpectedTestType = 'Specimen'
            SampleTypeToTestType = @{}  # only used if ControlsBySampleType
        }
        ExpectedResultRegex = @{
            # Per TestType -> regex (string)
            'Specimen' = '^(MTB DETECTED( - (LOW|MEDIUM|HIGH|VERY LOW))?|MTB NOT DETECTED|INVALID|ERROR|NO RESULT)(;.*)?$'
            'Control'  = '.*' # placeholder
        }
    }
    'Generic' = @{
        Name = 'Generic'
        TestTypePolicy = @{
            Mode = 'None'
        }
        ExpectedResultRegex = @{}
    }
}

function Get-AssayProfile {
    param([string]$AssayName)
    if ([string]::IsNullOrWhiteSpace($AssayName)) { return $Global:AssayProfiles['Generic'] }
    if ($Global:AssayProfiles.ContainsKey($AssayName)) { return $Global:AssayProfiles[$AssayName] }
    return $Global:AssayProfiles['Generic']
}
