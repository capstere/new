﻿
Set-StrictMode -Version 2

$script:LogPath = $null
$script:LogLevel = 'Info'
$script:Timers = @{}

function Initialize-Logging {
    param(
        [Parameter(Mandatory=$true)][string]$LogFolder,
        [Parameter(Mandatory=$false)][string]$Level = 'Info'
    )
    if (-not (Test-Path $LogFolder)) { New-Item -ItemType Directory -Path $LogFolder | Out-Null }

    $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
    $script:LogPath = Join-Path $LogFolder ("ClickLess_{0}.log" -f $stamp)
    $script:LogLevel = $Level

    "=== ClickLess/IPT log started {0} ===" -f (Get-Date) | Out-File -FilePath $script:LogPath -Encoding UTF8
}

function Get-LogPath { $script:LogPath }

function Write-Log {
    param(
        [Parameter(Mandatory=$true)][ValidateSet('Debug','Info','Warn','Error')][string]$Level,
        [Parameter(Mandatory=$true)][string]$Message
    )

    $order = @{ Debug=0; Info=1; Warn=2; Error=3 }
    if ($order[$Level] -lt $order[$script:LogLevel]) { return }

    $line = "[{0}] [{1}] {2}" -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'), $Level.ToUpper(), $Message
    if ($script:LogPath) { $line | Out-File -FilePath $script:LogPath -Append -Encoding UTF8 }
    Write-Host $line
}

function Write-Info  { param([string]$Message) Write-Log -Level Info  -Message $Message }
function Write-Warn  { param([string]$Message) Write-Log -Level Warn  -Message $Message }
function Write-ErrorLog { param([string]$Message) Write-Log -Level Error -Message $Message }
function Write-DebugLog { param([string]$Message) Write-Log -Level Debug -Message $Message }

function Start-Timer {
    param([Parameter(Mandatory=$true)][string]$Name)
    $script:Timers[$Name] = [Diagnostics.Stopwatch]::StartNew()
}

function Stop-Timer {
    param([Parameter(Mandatory=$true)][string]$Name)
    if (-not $script:Timers.ContainsKey($Name)) { return $null }
    $sw = $script:Timers[$Name]
    $sw.Stop()
    $ms = [int]$sw.ElapsedMilliseconds
    $script:Timers.Remove($Name) | Out-Null
    return $ms
}

function Format-Exception {
    param([Parameter(Mandatory=$true)][System.Exception]$Exception)
    $msg = $Exception.ToString()
    return $msg
}
