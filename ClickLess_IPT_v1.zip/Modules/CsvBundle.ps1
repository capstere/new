﻿
Set-StrictMode -Version 2

function Get-CsvDelimiter {
    param([Parameter(Mandatory=$true)][string]$Line)
    # Heuristic: choose delimiter with most splits
    $candidates = @(',', ';', "`t")
    $best = ','
    $bestCount = 0
    foreach ($d in $candidates) {
        $count = ($Line -split [Regex]::Escape($d)).Count
        if ($count -gt $bestCount) { $bestCount = $count; $best = $d }
    }
    return $best
}

function Split-CsvLine {
    param(
        [Parameter(Mandatory=$true)][string]$Line,
        [Parameter(Mandatory=$true)][string]$Delimiter
    )
    # Minimal RFC4180-ish splitter (supports quoted fields, escaped quotes)
    $fields = New-Object System.Collections.Generic.List[string]
    $sb = New-Object System.Text.StringBuilder
    $inQuotes = $false
    for ($i=0; $i -lt $Line.Length; $i++) {
        $ch = $Line[$i]
        if ($ch -eq '"') {
            if ($inQuotes -and ($i+1 -lt $Line.Length) -and $Line[$i+1] -eq '"') {
                [void]$sb.Append('"'); $i++
            } else {
                $inQuotes = -not $inQuotes
            }
            continue
        }
        if (-not $inQuotes -and $ch -eq $Delimiter) {
            $fields.Add($sb.ToString())
            $sb.Length = 0
            continue
        }
        [void]$sb.Append($ch)
    }
    $fields.Add($sb.ToString())
    return ,$fields.ToArray()
}

function Normalize-TestResult {
    param([string]$Value)
    if ($null -eq $Value) { return $null }
    $v = $Value.Trim()
    $v = [Regex]::Replace($v, '\s+', ' ')
    $v = [Regex]::Replace($v, ';\s*', '; ')
    return $v
}

function Parse-ErrorCode {
    param([string]$ErrorRaw)
    if ([string]::IsNullOrWhiteSpace($ErrorRaw)) { return $null }
    $m = [Regex]::Match($ErrorRaw, '(\d{3,6})')
    if ($m.Success) { return [int]$m.Groups[1].Value }
    return $null
}

function Find-HeaderRow {
    param(
        [Parameter(Mandatory=$true)][string[]]$Lines,
        [Parameter(Mandatory=$true)][string[]]$RequiredHeaders,
        [Parameter(Mandatory=$true)][int]$MaxLinesToScan
    )
    $scan = [Math]::Min($Lines.Count, $MaxLinesToScan)
    for ($i=0; $i -lt $scan; $i++) {
        $line = $Lines[$i]
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        $delim = Get-CsvDelimiter -Line $line
        $cols = Split-CsvLine -Line $line -Delimiter $delim
        $hit = 0
        foreach ($h in $RequiredHeaders) {
            foreach ($c in $cols) {
                if ($c.Trim().ToLowerInvariant() -eq $h.ToLowerInvariant()) { $hit++; break }
            }
        }
        if ($hit -ge [Math]::Min($RequiredHeaders.Count, 6)) {
            return @{
                HeaderLineIndex0 = $i
                Delimiter = $delim
                HeaderColumns = $cols
            }
        }
    }
    return $null
}

function Import-TestsSummaryCsv {
    <#
    Returns:
      @{
         HeaderMap = hashtable (normalized header -> index)
         Rows      = [System.Collections.Generic.List[pscustomobject]]
         RawRows   = list of hashtables for Raw sheet (same order as Rows)
         Meta      = @{ HeaderLineNo=..; DataStartLineNo=..; Delimiter=.. }
      }
    #>
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][hashtable]$Config
    )
    if (-not (Test-Path $Path)) { throw "CSV not found: $Path" }

    $required = @(
        'Sample ID','Cartridge S/N','Test Result','Status','Test Type','Reagent Lot ID',
        'Assay','Assay Version','Instrument S/N','Module S/N','Start Time'
    )

    # Preview read for header detect
    $preview = New-Object System.Collections.Generic.List[string]
    $sr = New-Object System.IO.StreamReader($Path, [System.Text.Encoding]::UTF8, $true)
    try {
        for ($i=0; $i -lt [int]$Config.CsvMaxPreviewLinesForHeaderDetect; $i++) {
            if ($sr.EndOfStream) { break }
            $preview.Add($sr.ReadLine())
        }
    } finally { $sr.Close() }

    $hdr = Find-HeaderRow -Lines $preview.ToArray() -RequiredHeaders $required -MaxLinesToScan ([int]$Config.CsvMaxPreviewLinesForHeaderDetect)
    if ($null -eq $hdr) { throw "Could not detect CSV header row (required headers missing)." }

    $headerLine0 = [int]$hdr.HeaderLineIndex0
    $delimiter = [string]$hdr.Delimiter
    $headers = $hdr.HeaderColumns

    # map headers
    $map = @{}
    for ($i=0; $i -lt $headers.Count; $i++) {
        $key = $headers[$i].Trim()
        if (-not [string]::IsNullOrWhiteSpace($key)) {
            $map[$key] = $i
        }
    }

    foreach ($h in $required) {
        if (-not $map.ContainsKey($h)) { throw "Missing required CSV header: '$h'" }
    }

    # Identify optional headers
    $optError = $map.ContainsKey('Error')
    $optPressure = $map.ContainsKey('Max Pressure (PSI)') -or $map.ContainsKey('Max Pressure PSI')
    $pressureHeader = $null
    if ($map.ContainsKey('Max Pressure (PSI)')) { $pressureHeader = 'Max Pressure (PSI)' }
    elseif ($map.ContainsKey('Max Pressure PSI')) { $pressureHeader = 'Max Pressure PSI' }

    # Analyte columns: collect anything that looks like 'SPC Ct' etc.
    $analyteHeaders = @()
    foreach ($k in $map.Keys) {
        if ($k -match 'Ct' -or $k -match 'SPC') { $analyteHeaders += $k }
    }

    $rows = New-Object System.Collections.Generic.List[pscustomobject]
    $rawRows = New-Object System.Collections.Generic.List[hashtable]

    # Stream read full file single pass
    $lineNo = 0
    $sr2 = New-Object System.IO.StreamReader($Path, [System.Text.Encoding]::UTF8, $true)
    try {
        while (-not $sr2.EndOfStream) {
            $line = $sr2.ReadLine()
            $lineNo++

            if ($lineNo -le ($headerLine0 + 1)) { continue } # skip until header line inclusive (1-based lineNo)
            # Skip empty
            if ([string]::IsNullOrWhiteSpace($line)) { continue }

            $cols = Split-CsvLine -Line $line -Delimiter $delimiter
            # if row shorter than required indexes, pad
            if ($cols.Count -lt ($headers.Count)) {
                $tmp = New-Object string[] ($headers.Count)
                for ($i=0; $i -lt $tmp.Length; $i++) { $tmp[$i] = $null }
                for ($i=0; $i -lt $cols.Count; $i++) { $tmp[$i] = $cols[$i] }
                $cols = $tmp
            }

            $get = {
                param([string]$name)
                $idx = $map[$name]
                if ($idx -ge 0 -and $idx -lt $cols.Count) { return $cols[$idx] } else { return $null }
            }

            $errorRaw = $null
            if ($optError) { $errorRaw = & $get 'Error' }

            $maxP = $null
            if ($optPressure -and $pressureHeader) {
                $p = & $get $pressureHeader
                if (-not [string]::IsNullOrWhiteSpace($p)) {
                    $p2 = $p.Trim()
                    [double]$dp = 0
                    if ([double]::TryParse($p2, [ref]$dp)) { $maxP = $dp }
                }
            }

            $analytes = $null
            if ($analyteHeaders.Count -gt 0) {
                $analytes = @{}
                foreach ($ah in $analyteHeaders) {
                    $idx = $map[$ah]
                    if ($idx -ge 0 -and $idx -lt $cols.Count) {
                        $val = $cols[$idx]
                        if (-not [string]::IsNullOrWhiteSpace($val)) { $analytes[$ah] = $val.Trim() }
                    }
                }
                if ($analytes.Count -eq 0) { $analytes = $null }
            }

            $obj = [pscustomobject]@{
                RowIndex     = $lineNo
                Assay        = (& $get 'Assay')
                AssayVersion = (& $get 'Assay Version')
                ReagentLotId = (& $get 'Reagent Lot ID')
                SampleId     = (& $get 'Sample ID')
                CartridgeSN  = (& $get 'Cartridge S/N')
                TestType     = (& $get 'Test Type')
                InstrumentSN = (& $get 'Instrument S/N')
                ModuleSN     = (& $get 'Module S/N')
                StartTime    = (& $get 'Start Time')
                Status       = (& $get 'Status')
                TestResult   = (Normalize-TestResult -Value (& $get 'Test Result'))
                MaxPressurePSI = $maxP
                ErrorRaw     = $errorRaw
                ErrorCode    = (Parse-ErrorCode -ErrorRaw $errorRaw)
                Analytes     = $analytes
            }
            $rows.Add($obj)

            $rawRows.Add(@{
                Line        = $lineNo
                SampleId    = $obj.SampleId
                CartridgeSN = $obj.CartridgeSN
                TestType    = $obj.TestType
                Status      = $obj.Status
                TestResult  = $obj.TestResult
                ErrorRaw    = $obj.ErrorRaw
                ErrorCode   = $obj.ErrorCode
                MaxPressurePSI = $obj.MaxPressurePSI
                Assay       = $obj.Assay
                AssayVersion= $obj.AssayVersion
                InstrumentSN= $obj.InstrumentSN
                ModuleSN    = $obj.ModuleSN
                StartTime   = $obj.StartTime
            })
        }
    } finally { $sr2.Close() }

    return @{
        HeaderMap = $map
        Rows      = $rows
        RawRows   = $rawRows
        Meta      = @{
            HeaderLineNo = ($headerLine0 + 1)
            DataStartLineNo = ($headerLine0 + 2)
            Delimiter = $delimiter
            Path = $Path
        }
    }
}
