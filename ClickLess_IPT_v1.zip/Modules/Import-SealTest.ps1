﻿
Set-StrictMode -Version 2

function Import-SealTest {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$Label
    )
    if (-not (Test-Path $Path)) { throw "Seal Test file not found: $Path" }

    $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object System.IO.FileInfo($Path))
    try {
        $ws = $pkg.Workbook.Worksheets[1]
        if ($null -eq $ws) { throw "No worksheet in Seal Test file: $Path" }

        # Very defensive: scan for PASS/FAIL keywords
        $text = ""
        $maxRow = [Math]::Min($ws.Dimension.End.Row, 60)
        $maxCol = [Math]::Min($ws.Dimension.End.Column, 12)
        for ($r=1; $r -le $maxRow; $r++) {
            for ($c=1; $c -le $maxCol; $c++) {
                $v = $ws.Cells[$r,$c].Text
                if ($v) { $text += " " + $v }
            }
        }
        $pass = $false
        $fail = $false
        if ($text -match '(?i)\bPASS\b') { $pass = $true }
        if ($text -match '(?i)\bFAIL\b') { $fail = $true }

        $status = 'Unknown'
        if ($pass -and -not $fail) { $status = 'PASS' }
        elseif ($fail) { $status = 'FAIL' }

        return @{
            Label = $Label
            Path  = $Path
            Status = $status
            Deviations = @() # placeholder: extend with assay-specific cell extraction
        }
    } finally {
        $pkg.Dispose()
    }
}
