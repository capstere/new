﻿
Set-StrictMode -Version 2

function Set-Cell {
    param($ws, [int]$Row, [int]$Col, $Value)
    $ws.Cells[$Row,$Col].Value = $Value
}

function Ensure-Worksheet {
    param($wb, [string]$Name)
    $ws = $wb.Worksheets[$Name]
    if ($null -eq $ws) { $ws = $wb.Worksheets.Add($Name) }
    return $ws
}

function Write-InformationSheet {
    param($ws, [hashtable]$Meta)
    $ws.Cells.Clear()
    Set-Cell $ws 1 1 'ClickLess / IPT Report'
    Set-Cell $ws 2 1 'Generated'
    Set-Cell $ws 2 2 (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    Set-Cell $ws 4 1 'LSP'
    Set-Cell $ws 4 2 $Meta.LSP
    Set-Cell $ws 6 1 'Inputs'
    $r=7
    foreach ($k in @('TestsSummaryCsv','SealNeg','SealPos','Worksheet')) {
        Set-Cell $ws $r 1 $k
        Set-Cell $ws $r 2 $Meta[$k]
        $r++
    }
    $ws.Cells[$ws.Dimension.Address].AutoFitColumns()
}

function Write-SealTestInfoSheet {
    param($ws, [hashtable]$SealInfo)
    $ws.Cells.Clear()
    Set-Cell $ws 1 1 'Seal Test Summary'
    Set-Cell $ws 3 1 'NEG'
    Set-Cell $ws 3 2 $SealInfo.Neg.Status
    Set-Cell $ws 4 1 'POS'
    Set-Cell $ws 4 2 $SealInfo.Pos.Status
    Set-Cell $ws 6 1 'Files'
    Set-Cell $ws 7 1 'NEG'
    Set-Cell $ws 7 2 $SealInfo.Neg.Path
    Set-Cell $ws 8 1 'POS'
    Set-Cell $ws 8 2 $SealInfo.Pos.Path
    $ws.Cells[$ws.Dimension.Address].AutoFitColumns()
}

function Write-STFSumSheet {
    param($ws, [hashtable]$WorksheetInfo)
    $ws.Cells.Clear()
    Set-Cell $ws 1 1 'Worksheet Summary'
    Set-Cell $ws 3 1 'File'
    Set-Cell $ws 3 2 $WorksheetInfo.Path

    $r=5
    Set-Cell $ws $r 1 'Key'
    Set-Cell $ws $r 2 'Value'
    $r++
    foreach ($k in ($WorksheetInfo.Summary.Keys | Sort-Object)) {
        Set-Cell $ws $r 1 $k
        Set-Cell $ws $r 2 $WorksheetInfo.Summary[$k]
        $r++
    }

    $r += 2
    Set-Cell $ws $r 1 'Equipment (heuristic)'
    $r++
    foreach ($e in $WorksheetInfo.Equipment) {
        Set-Cell $ws $r 1 $e
        $r++
    }

    $ws.Cells[$ws.Dimension.Address].AutoFitColumns()
}

function Write-RawSheet {
    param($ws, [System.Collections.Generic.List[hashtable]]$RawRows)
    $ws.Cells.Clear()
    $headers = @('Line','SampleId','CartridgeSN','TestType','Status','TestResult','ErrorCode','ErrorRaw','MaxPressurePSI','Assay','AssayVersion','InstrumentSN','ModuleSN','StartTime')
    for ($c=0; $c -lt $headers.Count; $c++) { $ws.Cells[1,$c+1].Value = $headers[$c] }
    $ws.Cells[1,1,1,$headers.Count].Style.Font.Bold = $true

    $r=2
    foreach ($row in $RawRows) {
        for ($c=0; $c -lt $headers.Count; $c++) {
            $h = $headers[$c]
            $ws.Cells[$r,$c+1].Value = $row[$h]
        }
        $r++
    }
    $ws.View.FreezePanes(2,1)
    $ws.Cells[$ws.Dimension.Address].AutoFitColumns()
}

function Write-Information2Sheet {
    param(
        $ws,
        [System.Collections.Generic.List[pscustomobject]]$Findings,
        [hashtable]$Stats
    )
    $ws.Cells.Clear()

    # Summary
    Set-Cell $ws 1 1 'Findings Summary'
    $ws.Cells[1,1].Style.Font.Bold = $true
    Set-Cell $ws 2 1 'Bucket'
    Set-Cell $ws 2 2 'Count'
    $ws.Cells[2,1,2,2].Style.Font.Bold = $true

    $r=3
    foreach ($k in ($Stats.Keys | Sort-Object)) {
        Set-Cell $ws $r 1 $k
        Set-Cell $ws $r 2 $Stats[$k]
        $r++
    }

    $tableTop = $r + 2
    Set-Cell $ws $tableTop 1 'Bucket'
    Set-Cell $ws $tableTop 2 'Code'
    Set-Cell $ws $tableTop 3 'Message'
    Set-Cell $ws $tableTop 4 'Sample ID'
    Set-Cell $ws $tableTop 5 'Cartridge S/N'
    Set-Cell $ws $tableTop 6 'Test Type'
    Set-Cell $ws $tableTop 7 'Instrument S/N'
    Set-Cell $ws $tableTop 8 'Module S/N'
    Set-Cell $ws $tableTop 9 'Start Time'
    Set-Cell $ws $tableTop 10 'Status'
    Set-Cell $ws $tableTop 11 'Test Result'
    Set-Cell $ws $tableTop 12 'Max Pressure'
    Set-Cell $ws $tableTop 13 'Error Code'
    Set-Cell $ws $tableTop 14 'Error Details'
    Set-Cell $ws $tableTop 15 'Line'
    $ws.Cells[$tableTop,1,$tableTop,15].Style.Font.Bold = $true

    $dataStart = $tableTop + 1
    $row = $dataStart
    foreach ($f in $Findings) {
        $ws.Cells[$row,1].Value = $f.Bucket
        $ws.Cells[$row,2].Value = $f.Code
        $ws.Cells[$row,3].Value = $f.Message
        $ws.Cells[$row,4].Value = $f.SampleId
        $ws.Cells[$row,5].Value = $f.CartridgeSN
        $ws.Cells[$row,6].Value = $f.TestType
        $ws.Cells[$row,7].Value = $f.InstrumentSN
        $ws.Cells[$row,8].Value = $f.ModuleSN
        $ws.Cells[$row,9].Value = $f.StartTime
        $ws.Cells[$row,10].Value = $f.Status
        $ws.Cells[$row,11].Value = $f.TestResult
        $ws.Cells[$row,12].Value = $f.MaxPressurePSI
        $ws.Cells[$row,13].Value = $f.ErrorCode
        $ws.Cells[$row,14].Value = $f.ErrorRaw
        $ws.Cells[$row,15].Value = $f.Line

        # Hyperlink Line -> Raw sheet
        if ($null -ne $f.Line -and $f.Line -ne '') {
            $ws.Cells[$row,15].Hyperlink = New-Object OfficeOpenXml.ExcelHyperLink ("Raw!A{0}" -f ([int]$row + 0))
            # Note: actual Raw row mapping handled by caller by keeping Raw in same order as CSV lines; see below.
        }
        $row++
    }

    # Freeze panes at table header
    $ws.View.FreezePanes($dataStart,1)
    # Autofilter
    $ws.Cells[$tableTop,1,$row-1,15].AutoFilter = $true
    $ws.Cells[$ws.Dimension.Address].AutoFitColumns()
}

function Write-Report {
    param(
        [Parameter(Mandatory=$true)][string]$TemplatePath,
        [Parameter(Mandatory=$true)][string]$OutputPath,
        [Parameter(Mandatory=$true)][hashtable]$Meta,
        [Parameter(Mandatory=$true)][hashtable]$SealInfo,
        [Parameter(Mandatory=$true)][hashtable]$WorksheetInfo,
        [Parameter(Mandatory=$true)][System.Collections.Generic.List[pscustomobject]]$Findings,
        [Parameter(Mandatory=$true)][hashtable]$Stats,
        [Parameter(Mandatory=$true)][System.Collections.Generic.List[hashtable]]$RawRows
    )
    if (-not (Test-Path $TemplatePath)) { throw "Template missing: $TemplatePath" }

    $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object System.IO.FileInfo($TemplatePath))
    try {
        $wb = $pkg.Workbook

        $wsInfo  = Ensure-Worksheet -wb $wb -Name 'Information'
        $wsInfo2 = Ensure-Worksheet -wb $wb -Name 'Information2'
        $wsSeal  = Ensure-Worksheet -wb $wb -Name 'Seal Test Info'
        $wsStf   = Ensure-Worksheet -wb $wb -Name 'STF Sum'
        $wsRaw   = Ensure-Worksheet -wb $wb -Name 'Raw'

        Write-InformationSheet -ws $wsInfo -Meta $Meta
        Write-SealTestInfoSheet -ws $wsSeal -SealInfo $SealInfo
        Write-STFSumSheet -ws $wsStf -WorksheetInfo $WorksheetInfo
        Write-RawSheet -ws $wsRaw -RawRows $RawRows
        Write-Information2Sheet -ws $wsInfo2 -Findings $Findings -Stats $Stats

        # Fix hyperlinks in Information2 to actual Raw line
        # Raw sheet has header row, so Raw line = f.Line (CSV line) maps to row? We wrote RawRows sequentially.
        # We'll create a map from CSV line -> Raw sheet row number.
        $lineToRow = @{}
        $rawRowNum = 2
        foreach ($rr in $RawRows) {
            if ($rr.ContainsKey('Line')) {
                $lineToRow[[string]$rr.Line] = $rawRowNum
            }
            $rawRowNum++
        }

        # walk Findings Line cells and set hyperlink target precisely
        # Table starts after summary, but we don't know exact; search for header "Bucket" then use below.
        $headerRow = $null
        for ($r=1; $r -le [Math]::Min($wsInfo2.Dimension.End.Row, 200); $r++) {
            if ($wsInfo2.Cells[$r,1].Text -eq 'Bucket' -and $wsInfo2.Cells[$r,2].Text -eq 'Code') {
                $headerRow = $r
                break
            }
        }
        if ($null -ne $headerRow) {
            $start = $headerRow + 1
            for ($r=$start; $r -le $wsInfo2.Dimension.End.Row; $r++) {
                $lineText = $wsInfo2.Cells[$r,15].Text
                if ([string]::IsNullOrWhiteSpace($lineText)) { continue }
                if ($lineToRow.ContainsKey($lineText)) {
                    $target = "Raw!A{0}" -f $lineToRow[$lineText]
                    $wsInfo2.Cells[$r,15].Hyperlink = New-Object OfficeOpenXml.ExcelHyperLink($target)
                }
            }
        }

        $outInfo = New-Object System.IO.FileInfo($OutputPath)
        if (-not (Test-Path $outInfo.DirectoryName)) { New-Item -ItemType Directory -Path $outInfo.DirectoryName | Out-Null }
        $pkg.SaveAs($outInfo)
    } finally {
        $pkg.Dispose()
    }
}
