﻿
Set-StrictMode -Version 2

function Import-WorksheetXlsx {
    param([Parameter(Mandatory=$true)][string]$Path)
    if (-not (Test-Path $Path)) { throw "Worksheet file not found: $Path" }

    $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object System.IO.FileInfo($Path))
    try {
        # Best-effort extract: looks for a sheet with 'Summary' else first
        $ws = $null
        foreach ($w in $pkg.Workbook.Worksheets) {
            if ($w.Name -match '(?i)summary') { $ws = $w; break }
        }
        if ($null -eq $ws) { $ws = $pkg.Workbook.Worksheets[1] }

        $kv = @{}
        $equip = New-Object System.Collections.Generic.List[string]

        $maxRow = [Math]::Min($ws.Dimension.End.Row, 120)
        $maxCol = [Math]::Min($ws.Dimension.End.Column, 12)
        for ($r=1; $r -le $maxRow; $r++) {
            $left = $ws.Cells[$r,1].Text
            $right = $ws.Cells[$r,2].Text
            if ($left -and $right -and -not $kv.ContainsKey($left)) { $kv[$left] = $right }

            # Equipment list heuristic
            for ($c=1; $c -le $maxCol; $c++) {
                $t = $ws.Cells[$r,$c].Text
                if ($t -match '(?i)\bGX\b|\bGeneXpert\b|\bModule\b|\bInstrument\b') {
                    $equip.Add($t) | Out-Null
                }
            }
        }

        return @{
            Path = $Path
            Summary = $kv
            Equipment = ($equip | Select-Object -Unique)
        }
    } finally {
        $pkg.Dispose()
    }
}
