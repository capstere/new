﻿
Set-StrictMode -Version 2

function New-Finding {
    param(
        [Parameter(Mandatory=$true)][string]$Bucket,
        [Parameter(Mandatory=$true)][string]$Code,
        [Parameter(Mandatory=$true)][string]$Message,
        [Parameter(Mandatory=$true)][int]$Line,
        [Parameter(Mandatory=$true)][pscustomobject]$Row
    )
    return [pscustomobject]@{
        Bucket      = $Bucket
        Code        = $Code
        Message     = $Message
        Line        = $Line
        SampleId    = $Row.SampleId
        CartridgeSN = $Row.CartridgeSN
        TestType    = $Row.TestType
        InstrumentSN= $Row.InstrumentSN
        ModuleSN    = $Row.ModuleSN
        StartTime   = $Row.StartTime
        Status      = $Row.Status
        TestResult  = $Row.TestResult
        MaxPressurePSI = $Row.MaxPressurePSI
        ErrorCode   = $Row.ErrorCode
        ErrorRaw    = $Row.ErrorRaw
    }
}

function Test-IsTerminationOutcome {
    param([pscustomobject]$Row)
    $status = [string]$Row.Status
    $tr = [string]$Row.TestResult
    if ($status -notin @('Aborted','Done')) { return $false }
    if ($tr -match '^(ERROR|NO RESULT|INVALID)$') { return $true }
    return $false
}

function Get-SPCCtValue {
    param([pscustomobject]$Row)
    if ($null -eq $Row.Analytes) { return $null }
    foreach ($k in $Row.Analytes.Keys) {
        if ($k -match 'SPC' -and $k -match 'Ct') {
            $v = $Row.Analytes[$k]
            [double]$d = 0
            if ([double]::TryParse($v, [ref]$d)) { return $d }
        }
    }
    return $null
}

function Get-MatrixKey {
    # Attempts to extract bag and sample number for missing-sample matrix.
    # Returns @{ Bag=00; Sample=01 } or $null if cannot parse.
    param([string]$SampleId)
    if ([string]::IsNullOrWhiteSpace($SampleId)) { return $null }

    # Common patterns: *_00_*_01* or ..._01_..._20
    $m = [Regex]::Match($SampleId, '_(\d{2})_.*?_(\d{2})')
    if ($m.Success) {
        return @{
            Bag    = [int]$m.Groups[1].Value
            Sample = [int]$m.Groups[2].Value
        }
    }
    return $null
}

function Invoke-RuleEngine {
    <#
      Inputs:
        Rows: list of normalized row objects
        AssayNameHint: if provided, use profile; else infer from first row Assay
      Output:
        @{ Findings = list; Stats = hashtable }
    #>
    param(
        [Parameter(Mandatory=$true)][System.Collections.Generic.List[pscustomobject]]$Rows,
        [Parameter(Mandatory=$true)][hashtable]$SealInfo,
        [Parameter(Mandatory=$true)][hashtable]$WorksheetInfo,
        [Parameter(Mandatory=$false)][string]$AssayNameHint = $null
    )

    $findings = New-Object System.Collections.Generic.List[pscustomobject]

    $assayName = $AssayNameHint
    if ([string]::IsNullOrWhiteSpace($assayName) -and $Rows.Count -gt 0) { $assayName = $Rows[0].Assay }
    $profile = Get-AssayProfile -AssayName $assayName

    # Duplicate detection
    $bySample = @{}
    $byCart = @{}

    foreach ($r in $Rows) {
        $sid = [string]$r.SampleId
        $csn = [string]$r.CartridgeSN

        if (-not [string]::IsNullOrWhiteSpace($sid)) {
            if ($bySample.ContainsKey($sid)) { $bySample[$sid] += 1 } else { $bySample[$sid] = 1 }
        }
        if (-not [string]::IsNullOrWhiteSpace($csn)) {
            if ($byCart.ContainsKey($csn)) { $byCart[$csn] += 1 } else { $byCart[$csn] = 1 }
        }
    }

    foreach ($r in $Rows) {
        if (-not [string]::IsNullOrWhiteSpace($r.SampleId) -and $bySample[$r.SampleId] -gt 1) {
            $findings.Add((New-Finding -Bucket 'DuplicateSampleId' -Code 'DupSampleId' -Message 'Duplicate Sample ID detected' -Line $r.RowIndex -Row $r))
        }
        if (-not [string]::IsNullOrWhiteSpace($r.CartridgeSN) -and $byCart[$r.CartridgeSN] -gt 1) {
            $findings.Add((New-Finding -Bucket 'DuplicateCartridgeSN' -Code 'DupCartridgeSN' -Message 'Duplicate Cartridge S/N detected' -Line $r.RowIndex -Row $r))
        }

        # Naming deviations (flags only)
        if ($r.SampleId -match '(^|[^A-Z])A{1,3}($|[^A-Z])') {
            $findings.Add((New-Finding -Bucket 'Replacement' -Code 'AFlag' -Message 'Replacement flag (contains A/AA/AAA token)' -Line $r.RowIndex -Row $r))
        }
        if ($r.SampleId -match '_D\d{1,2}[A-Z]?' -or $r.SampleId -match '(?i)delam') {
            $findings.Add((New-Finding -Bucket 'Observation' -Code 'Delam' -Message 'Delamination flag in Sample ID' -Line $r.RowIndex -Row $r))
        }

        # Expected test type (if SpecimenOnly)
        if ($profile.TestTypePolicy.Mode -eq 'SpecimenOnly') {
            $exp = [string]$profile.TestTypePolicy.ExpectedTestType
            if (-not [string]::IsNullOrWhiteSpace($exp) -and -not [string]::IsNullOrWhiteSpace($r.TestType)) {
                if ($r.TestType.Trim() -ne $exp) {
                    $findings.Add((New-Finding -Bucket 'WrongTestType' -Code 'WrongTT' -Message ("Test Type '{0}' not allowed for assay (expected '{1}')" -f $r.TestType,$exp) -Line $r.RowIndex -Row $r))
                }
            }
        }

        # Major functional: expected TestResult regex mismatch (if provided)
        if ($profile.ExpectedResultRegex.ContainsKey($r.TestType)) {
            $rx = [string]$profile.ExpectedResultRegex[$r.TestType]
            if (-not [string]::IsNullOrWhiteSpace($rx) -and -not [string]::IsNullOrWhiteSpace($r.TestResult)) {
                if (-not ([Regex]::IsMatch($r.TestResult, $rx))) {
                    $findings.Add((New-Finding -Bucket 'MajorFunctional' -Code 'ExpMismatch' -Message 'Observed Test Result does not match expected pattern' -Line $r.RowIndex -Row $r))
                }
            }
        }

        # Error classification (global)
        if (Test-IsTerminationOutcome -Row $r) {
            $ec = $r.ErrorCode
            $spc = Get-SPCCtValue -Row $r

            if ($null -ne $r.MaxPressurePSI -and [double]$r.MaxPressurePSI -gt 90) {
                $findings.Add((New-Finding -Bucket 'MinorFunctional' -Code 'HighPressure' -Message 'Max Pressure > 90 PSI' -Line $r.RowIndex -Row $r))
            }

            if ($null -ne $ec) {
                if ($Global:ErrorBank.MinorFunctionalCodes -contains [int]$ec) {
                    $findings.Add((New-Finding -Bucket 'MinorFunctional' -Code ([string]$ec) -Message 'Known minor functional error code' -Line $r.RowIndex -Row $r))
                } else {
                    $findings.Add((New-Finding -Bucket 'InstrumentError' -Code ([string]$ec) -Message 'Numeric error code not in minor bank → instrument error (re-test)' -Line $r.RowIndex -Row $r))
                }
            } else {
                # Unknown/missing numeric code: if SPC Ct=0 then Minor Functional (non-HPV rule simplified)
                if ($null -ne $spc -and [double]$spc -eq 0) {
                    $findings.Add((New-Finding -Bucket 'MinorFunctional' -Code 'SPC0' -Message 'Invalid with SPC Ct=0 → minor functional (global)' -Line $r.RowIndex -Row $r))
                } else {
                    $findings.Add((New-Finding -Bucket 'Observation' -Code 'UnknownErr' -Message 'Termination outcome without parsable numeric error code' -Line $r.RowIndex -Row $r))
                }
            }
        }
    }

    # Missing samples matrix (best-effort; only enabled if we can parse at least one key)
    $seen = @{}
    $parsedAny = $false
    foreach ($r in $Rows) {
        $k = Get-MatrixKey -SampleId $r.SampleId
        if ($null -ne $k) {
            $parsedAny = $true
            $key = "{0:D2}-{1:D2}" -f $k.Bag,$k.Sample
            $seen[$key] = $true
        }
    }

    if ($parsedAny) {
        # Determine expected for bag 00: 01–10; bags 01–10: 01–20
        for ($bag=0; $bag -le 10; $bag++) {
            $max = 20
            if ($bag -eq 0) { $max = 10 }
            for ($s=1; $s -le $max; $s++) {
                $key = "{0:D2}-{1:D2}" -f $bag,$s
                if (-not $seen.ContainsKey($key)) {
                    $findings.Add([pscustomobject]@{
                        Bucket='MissingSample'
                        Code='MissingSample'
                        Message=("Expected sample missing (bag {0:D2} sample {1:D2})" -f $bag,$s)
                        Line=$null
                        SampleId=("Bag {0:D2} Sample {1:D2}" -f $bag,$s)
                        CartridgeSN=$null
                        TestType=$null
                        InstrumentSN=$null
                        ModuleSN=$null
                        StartTime=$null
                        Status=$null
                        TestResult=$null
                        MaxPressurePSI=$null
                        ErrorCode=$null
                        ErrorRaw=$null
                    })
                }
            }
        }
    }

    # Stats
    $stats = @{}
    foreach ($f in $findings) {
        if ($stats.ContainsKey($f.Bucket)) { $stats[$f.Bucket] += 1 } else { $stats[$f.Bucket] = 1 }
    }

    return @{
        Findings = $findings
        Stats = $stats
        AssayProfile = $profile
    }
}
