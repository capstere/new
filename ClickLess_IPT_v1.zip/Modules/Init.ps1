﻿
Set-StrictMode -Version 2

function Import-ClickLessModules {
    param([Parameter(Mandatory=$true)][string]$Root)

    . (Join-Path $Root 'Modules\Logging.ps1')
    . (Join-Path $Root 'Modules\CsvBundle.ps1')
    . (Join-Path $Root 'Modules\RuleBank.ps1')
    . (Join-Path $Root 'Modules\RuleEngine.ps1')
    . (Join-Path $Root 'Modules\Import-SealTest.ps1')
    . (Join-Path $Root 'Modules\Import-Worksheet.ps1')
    . (Join-Path $Root 'Modules\Writers\Write-Report.ps1')
}

function Load-EPPlus {
    param([Parameter(Mandatory=$true)][string]$LibPath)
    if (-not (Test-Path $LibPath)) { throw "EPPlus.dll not found: $LibPath" }
    Add-Type -Path $LibPath | Out-Null
    # Avoid EPPlus license prompt (v4 does not require explicit license context)
}
