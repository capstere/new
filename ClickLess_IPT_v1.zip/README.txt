﻿
Click Less / IPT Compiling — v1 (from scratch)

Requirements
- Windows PowerShell 5.1
- EPPlus 4.5.3.3 (EPPlus.dll) in .\Lib\
  (This repo ships with an empty Lib folder; copy EPPlus.dll there.)

Workflow (unchanged)
1) Run Main.ps1
2) Enter LSP and press Enter
3) Select 4 inputs
4) Click Create Report

Outputs
- Excel report based on output_template-v4.xlsx
- Adds an extra sheet "Raw" and hyperlinks from Information2 -> Raw row

Notes
- Tests Summary input MUST be CSV.
- All scripts are UTF-8 with BOM + CRLF.
