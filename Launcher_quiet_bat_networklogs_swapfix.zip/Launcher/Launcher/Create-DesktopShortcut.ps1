param(
    [Parameter(Mandatory=$true)][string]$ShortcutName,
    [Parameter(Mandatory=$true)][string]$LauncherPs1,
    [Parameter(Mandatory=$false)][string]$WorkingDir
)

# Desktop starter generator
# Creates a quiet .bat on the desktop.
# - No console spam (suppresses stdout/stderr)
# - Avoids working directory locks inside the cache by cd:ing to %TEMP%

$desktop = [Environment]::GetFolderPath('Desktop')
$batPath = Join-Path $desktop ("{0}.bat" -f $ShortcutName)

# Clean up legacy shortcut if it exists (older installs used .lnk)
try {
    $legacyLnk = Join-Path $desktop ("{0}.lnk" -f $ShortcutName)
    if (Test-Path -LiteralPath $legacyLnk) { Remove-Item -LiteralPath $legacyLnk -Force -ErrorAction SilentlyContinue }
} catch {}

$resolved = $LauncherPs1
try { $resolved = (Resolve-Path -LiteralPath $LauncherPs1 -ErrorAction Stop).Path } catch {}

# Escape quotes for cmd.exe
$resolvedEsc = $resolved.Replace('"','""')

$bat = @(
    '@echo off',
    'setlocal',
    'cd /d "%TEMP%"',
    ('start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" 1>nul 2>nul' -f $resolvedEsc),
    'exit /b 0'
) -join [Environment]::NewLine

try {
    Set-Content -LiteralPath $batPath -Value $bat -Encoding ASCII -Force
    Write-Host ("Created desktop starter: {0}" -f $batPath)
} catch {
    Write-Host ("Failed to create desktop starter: {0}" -f $_.Exception.Message)
}
