﻿﻿# RuleEngine.ps1 (Windows PowerShell 5.1)
# Shadow-mode RuleEngine + RuleBank (CSV-driven)
# - Does NOT change legacy report logic unless explicitly wired
# - Produces per-row: ObservedCall, ExpectedCall, Deviation, ErrorCode/RetestPolicy
# - Writes RuleEngine_Debug worksheet (shadow)

function Import-RuleCsv {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return @() }

    $delim = ','
    try { $delim = Get-CsvDelimiter -Path $Path } catch {}

    try {
        $lines = Get-Content -LiteralPath $Path -ErrorAction Stop
        if (-not $lines -or $lines.Count -lt 1) { return @() }
        return @(ConvertFrom-Csv -InputObject ($lines -join "`n") -Delimiter $delim)
    } catch {
        try { return @(Import-Csv -LiteralPath $Path -Delimiter $delim) } catch { return @() }
    }
}

function Load-RuleBank {
    param([Parameter(Mandatory)][string]$RuleBankDir)

    $rb = [ordered]@{
        Dir = $RuleBankDir
        ResultCallPatterns = @()
        SampleExpectationRules = @()
        ErrorCodes = @()
        MissingSamplesConfig = @()
        SampleIdMarkers = @()
        ParityCheckConfig = @()
        SampleNumberRules = @()
    }

    if (-not (Test-Path -LiteralPath $RuleBankDir)) { return [pscustomobject]$rb }

    $map = @{
        ResultCallPatterns      = '01_ResultCallPatterns.csv'
        SampleExpectationRules  = '02_SampleExpectationRules.csv'
        ErrorCodes              = '03_ErrorCodes.csv'
        MissingSamplesConfig    = '04_MissingSamplesConfig.csv'
        SampleIdMarkers         = '05_SampleIdMarkers.csv'
        ParityCheckConfig       = '06_ParityCheckConfig.csv'
        SampleNumberRules       = '07_SampleNumberRules.csv'
    }

    foreach ($k in $map.Keys) {
        $p = Join-Path $RuleBankDir $map[$k]
        $rb[$k] = Import-RuleCsv -Path $p
    }

    # Priority sort where applicable
    try { $rb.ResultCallPatterns = @($rb.ResultCallPatterns | Sort-Object { [int]($_.Priority) } -Descending) } catch {}
    try { $rb.SampleExpectationRules = @($rb.SampleExpectationRules | Sort-Object { [int]($_.Priority) } -Descending) } catch {}
    try { $rb.SampleNumberRules = @($rb.SampleNumberRules | Sort-Object { [int]($_.Priority) } -Descending) } catch {}

    return [pscustomobject]$rb
}

function Get-RowField {
    param(
        [Parameter(Mandatory)][object]$Row,
        [Parameter(Mandatory)][string]$FieldName
    )
    try {
        $p = $Row.PSObject.Properties[$FieldName]
        if ($p -and $null -ne $p.Value) { return $p.Value }
    } catch {}
    return ''
}

function Test-RuleEnabled {
    param([Parameter(Mandatory)][object]$Rule)
    $en = (Get-RowField -Row $Rule -FieldName 'Enabled')
    if ($en -eq $null) { return $true }
    $s = ($en + '').Trim().ToUpperInvariant()
    if (-not $s) { return $true }
    return ($s -in @('TRUE','1','YES','Y'))
}

function Test-AssayMatch {
    param(
        [Parameter(Mandatory)][string]$RuleAssay,
        [Parameter(Mandatory)][string]$RowAssay
    )
    $ra = ($RuleAssay + '').Trim()
    if (-not $ra -or $ra -eq '*') { return $true }
    return ($ra -ieq ($RowAssay + '').Trim())
}

function Match-Text {
    param(
        [Parameter(Mandatory)][string]$Text,
        [Parameter(Mandatory)][string]$Pattern,
        [Parameter(Mandatory)][string]$MatchType
    )

    $t = ($Text + '')
    $p = ($Pattern + '')
    $m = ($MatchType + '').Trim().ToUpperInvariant()
    if (-not $m) { $m = 'CONTAINS' }

    try {
        switch ($m) {
            'REGEX'  { return [regex]::IsMatch($t, $p, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase) }
            'EQUALS' { return (($t.Trim()).ToUpperInvariant() -eq ($p.Trim()).ToUpperInvariant()) }
            'PREFIX' {
                $tt = ($t.Trim()).ToUpperInvariant()
                $pp = ($p.Trim()).ToUpperInvariant()
                if (-not $pp) { return $true }
                return ($tt.Length -ge $pp.Length -and $tt.Substring(0, $pp.Length) -eq $pp)
            }
            'SUFFIX' {
                $tt = ($t.Trim()).ToUpperInvariant()
                $pp = ($p.Trim()).ToUpperInvariant()
                if (-not $pp) { return $true }
                return ($tt.Length -ge $pp.Length -and $tt.Substring($tt.Length - $pp.Length) -eq $pp)
            }
            default {
                return (($t.ToUpperInvariant()).Contains($p.ToUpperInvariant()))
            }
        }
    } catch {
        return $false
    }
}

function Get-ObservedCallDetailed {
    param(
        [Parameter(Mandatory)][object]$Row,
        [Parameter(Mandatory)][object[]]$Patterns
    )

    $status = (Get-RowField -Row $Row -FieldName 'Status')
    $errTxt = (Get-RowField -Row $Row -FieldName 'Error')
    $testResult = (Get-RowField -Row $Row -FieldName 'Test Result')
    $assay = (Get-RowField -Row $Row -FieldName 'Assay')

        # Global hard overrides:
    # - Non-Done status or explicit Error => treat as run failure (ERR), not a biological INDET call.
    #   (MTB-family "INDETERMINATE" in Test Result is handled as a minor-functional flag, not as ObservedCall=INDET.)
    if (($errTxt + '').Trim()) {
        return [pscustomobject]@{ Call='ERR'; Reason='Error column populated' }
    }
    $st = ($status + '').Trim()
    if ($st -and ($st -ine 'Done')) {
        return [pscustomobject]@{ Call='ERR'; Reason=("Status=" + $st) }
    }

    $tr = ($testResult + '').Trim()
    if (-not $tr) { return [pscustomobject]@{ Call='UNK'; Reason='Blank Test Result' } }

    # MTB-family override: treat MTB DETECTED/TRACE DETECTED as POS even if RIF contains NOT DETECTED/INDETERMINATE.
    # This prevents classic false INDET/NEG due to substring collisions.
    $ass = ($assay + '')
    if ($ass -match 'MTB') {
        if ($tr -match '(?i)\bMTB\s+TRACE\s+DETECTED\b') {
            return [pscustomobject]@{ Call='POS'; Reason='MTB Trace detected (override)' }
        }
        if ($tr -match '(?i)\bMTB\s+DETECTED\b') {
            return [pscustomobject]@{ Call='POS'; Reason='MTB detected (override)' }
        }
        if ($tr -match '(?i)\bMTB\s+NOT\s+DETECTED\b') {
            return [pscustomobject]@{ Call='NEG'; Reason='MTB not detected (override)' }
        }
    }

    foreach ($r in $Patterns) {
        if (-not (Test-RuleEnabled $r)) { continue }
        $ruleAssay = (Get-RowField -Row $r -FieldName 'Assay')
        if (-not (Test-AssayMatch -RuleAssay $ruleAssay -RowAssay $assay)) { continue }

        $pat  = (Get-RowField -Row $r -FieldName 'Pattern')
        if (-not ($pat + '').Trim()) { continue }
        $mt   = (Get-RowField -Row $r -FieldName 'MatchType')

        if (Match-Text -Text $tr -Pattern $pat -MatchType $mt) {
            $call = ((Get-RowField -Row $r -FieldName 'Call') + '').Trim().ToUpperInvariant()
            if ($call) {
                $note = (Get-RowField -Row $r -FieldName 'Note')
                $why = if (($note + '').Trim()) { $note } else { ("Matched " + $mt + ": " + $pat) }
                return [pscustomobject]@{ Call=$call; Reason=$why }
            }
        }
    }

    return [pscustomobject]@{ Call='UNK'; Reason='No pattern matched' }
}

function Test-MtbResistanceIndeterminate {
    param(
        [Parameter(Mandatory=$false)][string]$Assay,
        [Parameter(Mandatory=$false)][string]$TestResult
    )
    $a = ($Assay + '').ToUpperInvariant()
    if (-not $a -or ($a -notmatch 'MTB')) { return $false }
    $tr = ($TestResult + '').ToUpperInvariant()
    if (-not $tr) { return $false }
    return ($tr -match 'INDETERMINATE')
}

function Get-DelaminationCodeFromToken {
    param(
        [Parameter(Mandatory=$false)][string]$SampleTokenRaw,
        [Parameter(Mandatory=$false)][string]$DelamRegex
    )
    $t = ($SampleTokenRaw + '')
    $rx = ($DelamRegex + '').Trim()
    if (-not $t -or -not $rx) { return '' }
    try {
        $m = [regex]::Match($t, $rx, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
        if ($m.Success) { return ($m.Groups[0].Value + '').Trim() }
    } catch {}
    return ''
}


function Get-ExpectedCallDetailed {
    param(
        [Parameter(Mandatory)][object]$Row,
        [Parameter(Mandatory)][object[]]$Rules
    )

    $sampleId = (Get-RowField -Row $Row -FieldName 'Sample ID')
    $assay    = (Get-RowField -Row $Row -FieldName 'Assay')
    $sid = ($sampleId + '').Trim()
    if (-not $sid) { return [pscustomobject]@{ Call=''; Reason='Blank Sample ID' } }

    foreach ($r in $Rules) {
        if (-not (Test-RuleEnabled $r)) { continue }
        $ruleAssay = (Get-RowField -Row $r -FieldName 'Assay')
        if (-not (Test-AssayMatch -RuleAssay $ruleAssay -RowAssay $assay)) { continue }

        $mtype = (Get-RowField -Row $r -FieldName 'SampleIdMatchType')
        $pat   = (Get-RowField -Row $r -FieldName 'SampleIdPattern')
        if (-not ($pat + '').Trim()) { continue }

        if (Match-Text -Text $sid -Pattern $pat -MatchType $mtype) {
            $call = ((Get-RowField -Row $r -FieldName 'Expected') + '').Trim().ToUpperInvariant()
            if ($call) {
                $note = (Get-RowField -Row $r -FieldName 'Note')
                $why = if (($note + '').Trim()) { $note } else { ("Matched " + $mtype + ": " + $pat) }
                return [pscustomobject]@{ Call=$call; Reason=$why }
            }
        }
    }

    return [pscustomobject]@{ Call=''; Reason='No expectation rule matched' }
}

function Get-ExpectedTestTypeDerived {
    param([Parameter(Mandatory)][string]$SampleId)

    $parts = $SampleId.Split('_')
    if ($parts.Count -ge 3) {
        $tc = $parts[2]
        switch -Regex ($tc) {
            '^0$' { return 'Negative Control 1' }
            '^1$' { return 'Positive Control 1' }
            '^2$' { return 'Positive Control 2' }
            '^3$' { return 'Positive Control 3' }
            '^4$' { return 'Positive Control 4' }
            '^5$' { return 'Positive Control 5' }
            default { }
        }
    }
    return 'Specimen'
}

function Build-ErrorCodeLookup {
    param([Parameter(Mandatory)][object[]]$ErrorCodes)

    $lut = @{
        Codes = @{}
        Default = $null
    }

    foreach ($r in $ErrorCodes) {
        $code = ((Get-RowField -Row $r -FieldName 'ErrorCode') + '').Trim()
        $name = (Get-RowField -Row $r -FieldName 'Name')
        $ret  = (Get-RowField -Row $r -FieldName 'GeneratesRetest')

        if ($code -eq '####') {
            $lut.Default = [pscustomobject]@{ ErrorCode='####'; Name=$name; GeneratesRetest=$ret }
            continue
        }
        if ($code -match '^\d{4,5}$') {
            $lut.Codes[$code] = [pscustomobject]@{ ErrorCode=$code; Name=$name; GeneratesRetest=$ret }
        }
    }

    return $lut
}

function Get-ErrorInfo {
    param(
        [Parameter(Mandatory)][object]$Row,
        [Parameter(Mandatory)][hashtable]$ErrorLut
    )

    $errTxt = (Get-RowField -Row $Row -FieldName 'Error')
    $mpTxt  = (Get-RowField -Row $Row -FieldName 'Max Pressure (PSI)')

    $code = ''
    $hasErr = (($errTxt + '').Trim().Length -gt 0)

    if ($hasErr) {
        if (($errTxt + '') -match '(\d{4,5})') { $code = $Matches[1] }
    }

    $name = ''
    $retest = ''

    # Apply #### default ONLY if Error text exists
    if ($hasErr) {
        if ($code -and $ErrorLut.Codes.ContainsKey($code)) {
            $name   = $ErrorLut.Codes[$code].Name
            $retest = $ErrorLut.Codes[$code].GeneratesRetest
        } elseif ($ErrorLut.Default) {
            $name   = $ErrorLut.Default.Name
            $retest = $ErrorLut.Default.GeneratesRetest
        }
    }

    $pressure = $null
    try {
        if (($mpTxt + '').Trim()) { $pressure = [double]($mpTxt + '') }
    } catch {}

    $pressureFlag = $false
    if ($pressure -ne $null -and $pressure -gt 90) { $pressureFlag = $true }

    return [pscustomobject]@{
        ErrorCode       = $code
        ErrorName       = $name
        GeneratesRetest = $retest
        MaxPressure     = $pressure
        PressureFlag    = $pressureFlag
    }
}

function Classify-Deviation {
    param(
        [AllowEmptyString()][string]$Expected,
        [AllowEmptyString()][string]$Observed
    )
    $e = ($Expected + '').Trim().ToUpperInvariant()
    $o = ($Observed + '').Trim().ToUpperInvariant()

    if (-not $e) { return 'UNK' }
    if ($o -eq 'ERR') { return 'ERR' }
    if ($o -eq 'INDET') { return 'INDET' }
    if ($o -eq 'UNK' -or -not $o) { return 'UNK' }
    if ($e -eq $o) { return 'OK' }
    if ($e -eq 'POS' -and $o -eq 'NEG') { return 'FN' }
    if ($e -eq 'NEG' -and $o -eq 'POS') { return 'FP' }
    return 'MISMATCH'
}

function Split-CsvLineQuoted {
    param(
        [Parameter(Mandatory)][string]$Line,
        [Parameter(Mandatory)][string]$Delimiter
    )
    $d = [regex]::Escape($Delimiter)
    $rx = $d + '(?=(?:(?:[^"]*"){2})*[^"]*$)'
    return [regex]::Split($Line, $rx)
}

function Get-HeaderFromTestSummaryFile {
    param([Parameter(Mandatory)][string]$CsvPath)

    if (-not (Test-Path -LiteralPath $CsvPath)) { return @() }

    $delim = ','
    try { $delim = Get-CsvDelimiter -Path $CsvPath } catch {}

    $lines = @()
    try { $lines = Get-Content -LiteralPath $CsvPath -ErrorAction Stop } catch { return @() }

    # Test Summary: header is line 8 (index 7)
    if (-not $lines -or $lines.Count -lt 8) { return @() }
    $hdrLine = $lines[7]
    if (-not $hdrLine) { return @() }

    $headers = Split-CsvLineQuoted -Line $hdrLine -Delimiter $delim
    $headers = @($headers | ForEach-Object { (($_ + '') -replace '^"|"$','').Trim() })
    return $headers
}

function Convert-FieldRowsToObjects {
    param(
        [Parameter(Mandatory)][object[]]$FieldRows,
        [Parameter(Mandatory)][string[]]$Headers
    )

    $out = New-Object System.Collections.Generic.List[object]

    foreach ($r in $FieldRows) {
        if ($null -eq $r) { continue }
        $arr = $r
        if ($arr -isnot [object[]]) { continue }

        $o = [ordered]@{}
        $max = [Math]::Min($Headers.Count, $arr.Count)
        for ($i=0; $i -lt $max; $i++) {
            $h = $Headers[$i]
            if (-not $h) { continue }
            $o[$h] = $arr[$i]
        }
        $out.Add([pscustomobject]$o)
    }

    return $out.ToArray()
}

function Get-DelaminationRegexFromRuleBank {
    param([Parameter(Mandatory)][pscustomobject]$RuleBank)

    # Expected columns in 05_SampleIdMarkers.csv: Key,Value
    foreach ($r in $RuleBank.SampleIdMarkers) {
        if (-not (Test-RuleEnabled $r)) { continue }
        $k = ((Get-RowField -Row $r -FieldName 'Key') + '').Trim()
        if ($k -and ($k -ieq 'DelaminationCodeRegex')) {
            $v = ((Get-RowField -Row $r -FieldName 'Value') + '').Trim()
            if ($v) { return $v }
        }
    }
    # Safe fallback
    return 'D\d{2}[A-Z]?|D2B'
}

function Get-ParityConfig {
    param([Parameter(Mandatory)][pscustomobject]$RuleBank)

    $cfg = [ordered]@{
        TokenIndex = 3
        XChar = 'X'
        PlusChar = '+'
        NumericRatioThreshold = 0.60
    }

    foreach ($r in $RuleBank.ParityCheckConfig) {
        if (-not (Test-RuleEnabled $r)) { continue }
        $k = ((Get-RowField -Row $r -FieldName 'Key') + '').Trim()
        $v = ((Get-RowField -Row $r -FieldName 'Value') + '').Trim()
        if (-not $k) { continue }

        switch ($k.ToUpperInvariant()) {
            'SAMPLETOKENINDEX' { try { $cfg.TokenIndex = [int]$v } catch {} }
            'XCHAR' { if ($v) { $cfg.XChar = $v.Substring(0,1).ToUpperInvariant() } }
            'PLUSCHAR' { if ($v) { $cfg.PlusChar = $v.Substring(0,1) } }
            'NUMERICRATIOTHRESHOLD' { try { $cfg.NumericRatioThreshold = [double]$v } catch {} }
            default { }
        }
    }

    return [pscustomobject]$cfg
}

function Get-ControlCodeFromRow {
    param([Parameter(Mandatory)][object]$Row)

    $sid = (Get-RowField -Row $Row -FieldName 'Sample ID')
    if (($sid + '').Trim()) {
        $parts = ($sid + '').Split('_')
        if ($parts.Count -ge 3) {
            $cc = ($parts[2] + '').Trim()
            if ($cc -match '^\d+$') { return $cc }
        }
    }

    $tt = (Get-RowField -Row $Row -FieldName 'Test Type')
    if (($tt + '') -match '(?i)Negative\s+Control') { return '0' }
    if (($tt + '') -match '(?i)Positive\s+Control\s+(\d+)') { return $Matches[1] }

    return ''
}

function Get-SampleTokenAndBase {
    param(
        [Parameter(Mandatory)][string]$SampleId,
        [Parameter(Mandatory)][int]$TokenIndex,
        [Parameter(Mandatory)][string]$DelamPattern
    )

    $tok = ''
    $base = ''

    $parts = $SampleId.Split('_')
    if ($parts.Count -gt $TokenIndex) {
        $tok = ($parts[$TokenIndex] + '').Trim()
    }

    if (-not $tok) { return [pscustomobject]@{ SampleToken=''; BaseToken=''; ActualSuffix=''; SampleNum=''; SampleNumRaw=''; } }

    # strip trailing delamination code: e.g. 11X_D2B -> base 11X
    $rx = "([_-]?(?:" + $DelamPattern + "))$"
    try {
        $base = [regex]::Replace($tok, $rx, '', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    } catch {
        $base = $tok
    }

    $base = ($base + '').Trim()

    $act = ''
    if ($base.Length -ge 1) {
        $last = $base.Substring($base.Length - 1, 1).ToUpperInvariant()
        if ($last -eq 'X' -or $last -eq '+') { $act = $last }
    }

    $numRaw = ''
    $num = ''
    if ($base -match '^(\d{1,3})') {
        $numRaw = $Matches[1]
        $num = $numRaw
    }

    return [pscustomobject]@{ SampleToken=$tok; BaseToken=$base; ActualSuffix=$act; SampleNum=$num; SampleNumRaw=$numRaw }
}

function Get-SampleNumberRuleForRow {
    param(
        [Parameter(Mandatory)][object]$Row,
        [Parameter(Mandatory)][object[]]$Rules,
        [Parameter(Mandatory=$false)][string]$SampleTypeCode,
        [Parameter(Mandatory=$false)][string]$ControlCode
    )

    $assay = (Get-RowField -Row $Row -FieldName 'Assay')

    # Sort by Priority if present (descending), else keep order
    $sorted = $Rules
    try {
        $sorted = @($Rules | Sort-Object { [int]((Get-RowField -Row $_ -FieldName 'Priority') + '') } -Descending)
    } catch {}

    foreach ($r in $sorted) {
        if (-not (Test-RuleEnabled $r)) { continue }

        # Assay match: prefer AssayPattern (contains/regex), fallback to Assay exact/*.
        $ap = ((Get-RowField -Row $r -FieldName 'AssayPattern') + '').Trim()
        if (-not $ap) { $ap = ((Get-RowField -Row $r -FieldName 'Assay') + '').Trim() }

        if ($ap -and $ap -ne '*') {
            $ok = $false
            try {
                # If pattern looks like a regex, try regex match; otherwise use case-insensitive contains.
                if ($ap -match '[\^\$\.\*\+\?\(\)\[\]\{\}\|\\]') {
                    $ok = [regex]::IsMatch(($assay + ''), $ap, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
                } else {
                    $ok = (($assay + '').ToUpperInvariant().Contains($ap.ToUpperInvariant()))
                }
            } catch {
                $ok = (($assay + '').ToUpperInvariant().Contains($ap.ToUpperInvariant()))
            }
            if (-not $ok) { continue }
        }

        # Prefer SampleTypeCode matching if present
        $rtc = ((Get-RowField -Row $r -FieldName 'SampleTypeCode') + '').Trim()
        if ($rtc -and $SampleTypeCode) {
            if ($rtc -ne $SampleTypeCode) { continue }
            return $r
        }

        # Fallback: ControlCode matching (legacy)
        $cc = ((Get-RowField -Row $r -FieldName 'ControlCode') + '').Trim()
        if ($cc) {
            if (-not $cc -or $cc -eq '*') { return $r }
            if ($ControlCode -and ($cc -eq $ControlCode)) { return $r }
            continue
        }

        # If rule has neither SampleTypeCode nor ControlCode, treat as wildcard
        return $r
    }

    return $null
}

function Invoke-RuleEngine {
    param(
        [Parameter(Mandatory=$true)][AllowEmptyCollection()][object[]]$CsvObjects,
        [Parameter(Mandatory)][pscustomobject]$RuleBank,
        [Parameter(Mandatory=$false)][string]$CsvPath
    )

    if (-not $CsvObjects -or $CsvObjects.Count -eq 0) {
        return [pscustomobject]@{ Rows=@(); Summary=[pscustomobject]@{ Total=0; ObservedCounts=@{}; DeviationCounts=@{}; RetestYes=0 }; TopDeviations=@() }
    }

    # Convert field-arrays (from Import-CsvRows) to objects using header from file
    $needsConvert = $false
    try {
        if ($CsvObjects[0] -is [object[]]) { $needsConvert = $true }
        else {
            $p1 = $CsvObjects[0].PSObject.Properties.Match('Sample ID')
            if ($p1.Count -eq 0) { $needsConvert = $true }
        }
    } catch { $needsConvert = $true }

    if ($needsConvert) {
        if (-not $CsvPath) { throw 'RuleEngine: CsvPath is required to convert field-array rows to objects.' }
        $hdr = Get-HeaderFromTestSummaryFile -CsvPath $CsvPath
        if (-not $hdr -or $hdr.Count -lt 5) { throw 'RuleEngine: Could not read CSV header (line 8).' }
        $CsvObjects = Convert-FieldRowsToObjects -FieldRows $CsvObjects -Headers $hdr
        if (-not $CsvObjects -or $CsvObjects.Count -eq 0) {
            return [pscustomobject]@{ Rows=@(); Summary=[pscustomobject]@{ Total=0; ObservedCounts=@{}; DeviationCounts=@{}; RetestYes=0 }; TopDeviations=@() }
        }
    }

    $parCfg = Get-ParityConfig -RuleBank $RuleBank
    $delamPattern = Get-DelaminationRegexFromRuleBank -RuleBank $RuleBank

    # Pre-scan for parity + majority suffix
    $numeric = New-Object System.Collections.Generic.List[long]
    $suffixCounts = @{ 'X' = 0; '+' = 0 }

    foreach ($row in $CsvObjects) {
        $sn = (Get-RowField -Row $row -FieldName 'Cartridge S/N')
        if (($sn + '').Trim() -match '^\d+$') {
            try { $numeric.Add([long]($sn + '')) } catch {}
        }

        $sid = (Get-RowField -Row $row -FieldName 'Sample ID')
        if (($sid + '').Trim()) {
            $t = Get-SampleTokenAndBase -SampleId ($sid + '') -TokenIndex $parCfg.TokenIndex -DelamPattern $delamPattern
            if ($t.ActualSuffix -and $suffixCounts.ContainsKey($t.ActualSuffix)) { $suffixCounts[$t.ActualSuffix]++ }
        }
    }

    $numRatio = 0.0
    try { $numRatio = [double]$numeric.Count / [double]$CsvObjects.Count } catch {}

    $useParity = ($numeric.Count -gt 0 -and $numRatio -ge $parCfg.NumericRatioThreshold)

    $minSn = $null
    $parityForX = $null
    if ($useParity) {
        try {
            $minSn = ($numeric | Measure-Object -Minimum).Minimum
            $parityForX = [int]($minSn % 2)
        } catch {
            $useParity = $false
        }
    }

    $majSuffix = ''
    if (-not $useParity) {
        if ($suffixCounts['X'] -gt $suffixCounts['+']) { $majSuffix = 'X' }
        elseif ($suffixCounts['+'] -gt $suffixCounts['X']) { $majSuffix = '+' }
    }

    $results = New-Object System.Collections.Generic.List[object]
    $errLut = Build-ErrorCodeLookup -ErrorCodes $RuleBank.ErrorCodes

    foreach ($row in $CsvObjects) {
        try {
            $obsD = Get-ObservedCallDetailed -Row $row -Patterns $RuleBank.ResultCallPatterns
            $expD = Get-ExpectedCallDetailed -Row $row -Rules $RuleBank.SampleExpectationRules

            $sid = (Get-RowField -Row $row -FieldName 'Sample ID')
            $assay = (Get-RowField -Row $row -FieldName 'Assay')

            $expTT = ''
            if (($sid + '').Trim()) { $expTT = Get-ExpectedTestTypeDerived -SampleId ($sid + '') }

            # ExpectedCall fallback: derive from Test Type / control code when no explicit rule matched
            $expCall = ($expD.Call + '').Trim().ToUpperInvariant()
            $expSrc = 'RULE'
            if (-not $expCall) {
                $tt = (Get-RowField -Row $row -FieldName 'Test Type')
                $tt2 = ($tt + '')
                if ($tt2 -match '(?i)Negative\s+Control') { $expCall = 'NEG'; $expSrc = 'TESTTYPE' }
                elseif ($tt2 -match '(?i)Positive\s+Control') { $expCall = 'POS'; $expSrc = 'TESTTYPE' }
                else {
                    $cc2 = Get-ControlCodeFromRow -Row $row
                    if ($cc2 -match '^\d+$') {
                        if ([int]$cc2 -eq 0) { $expCall = 'NEG'; $expSrc = 'CONTROL_CODE' }
                        elseif ([int]$cc2 -ge 1) { $expCall = 'POS'; $expSrc = 'CONTROL_CODE' }
                    }
                }
            }

            $errInfo = Get-ErrorInfo -Row $row -ErrorLut $errLut
            $dev = Classify-Deviation -Expected $expCall -Observed $obsD.Call

            # Suffix / parity validation (naming robustness)
            $tokInfo = [pscustomobject]@{ SampleToken=''; BaseToken=''; ActualSuffix=''; SampleNum=''; SampleNumRaw='' }
            if (($sid + '').Trim()) {
                $tokInfo = Get-SampleTokenAndBase -SampleId ($sid + '') -TokenIndex $parCfg.TokenIndex -DelamPattern $delamPattern
            }


            # --- Run outcome / error classification / MTB indeterminate (minor functional) ---
            $mtbIndet = Test-MtbResistanceIndeterminate -Assay (Get-RowField -Row $row -FieldName 'Assay') -TestResult (Get-RowField -Row $row -FieldName 'Test Result')

            $runOutcome = 'OK'
            if ($obsD.Call -eq 'ERR') { $runOutcome = 'ERROR' }

            $errClass = ''
            $rt2 = (($errInfo.GeneratesRetest + '').Trim().ToUpperInvariant())
            if (($errInfo.ErrorCode + '').Trim()) {
                if ($rt2 -in @('YES','Y','TRUE','1')) { $errClass = 'Instrument Error' }
                else { $errClass = 'Minor Functional Error' }
            }
            if ($mtbIndet) {
                if ($errClass) { $errClass = $errClass + '; MTB Indeterminate' } else { $errClass = 'MTB Indeterminate' }
            }

            # Delamination handling (only affects classification, not suffix logic)
            $delamCode = Get-DelaminationCodeFromToken -SampleTokenRaw $tokInfo.SampleToken -DelamRegex $delamPattern
            $delamHandling = ''
            if (($delamCode + '').Trim()) {
                if (($errInfo.ErrorCode + '').Trim()) {
                    if ($rt2 -in @('YES','Y','TRUE','1')) { $delamHandling = 'Replace (Instrument Error)' }
                    else { $delamHandling = 'Delamination Error' }
                } else {
                    $delamHandling = 'Delamination Observation'
                }
            }
            $expectedSuffix = ''
            $suffixSource = ''
            $suffixCheck = ''

            $snVal = (Get-RowField -Row $row -FieldName 'Cartridge S/N')
            $snNum = $null
            if (($snVal + '').Trim() -match '^\d+$') { try { $snNum = [long]($snVal + '') } catch {} }

            if ($tokInfo.ActualSuffix) {
                if ($useParity -and $snNum -ne $null -and $parityForX -ne $null) {
                    $expS = if (([int]($snNum % 2)) -eq $parityForX) { 'X' } else { '+' }
                    $expectedSuffix = $expS
                    $suffixSource = 'PARITY'
                } elseif ($majSuffix) {
                    $expectedSuffix = $majSuffix
                    $suffixSource = 'MAJORITY'
                }

                if ($expectedSuffix) {
                    $suffixCheck = if ($tokInfo.ActualSuffix -eq $expectedSuffix) { 'OK' } else { 'BAD' }
                }
            }

            # Sample number validation (config-driven)
            $sampleNum = $tokInfo.SampleNum
            $sampleNumOk = ''
            $sampleNumWhy = ''
            $cc = Get-ControlCodeFromRow -Row $row

            $rule = $null
            try { $rule = Get-SampleNumberRuleForRow -Row $row -Rules $RuleBank.SampleNumberRules -ControlCode $cc } catch {}
            if ($rule -and $sampleNum) {
                $min = 0; $max = 0; $width = 0; $idx = $parCfg.TokenIndex
                # Read numeric constraints (support both legacy and spec-style column names)
            $min = 0; $max = 0; $width = 0
            foreach ($fn in @('Min','SampleNumberMin','SampleNumMin')) {
                if ($min -ne 0) { break }
                try { $min = [int](((Get-RowField -Row $rule -FieldName $fn) + '').Trim()) } catch {}
            }
            foreach ($fn in @('Max','SampleNumberMax','SampleNumMax')) {
                if ($max -ne 0) { break }
                try { $max = [int](((Get-RowField -Row $rule -FieldName $fn) + '').Trim()) } catch {}
            }
            foreach ($fn in @('Width','SampleNumberPad','SampleNumWidth')) {
                if ($width -ne 0) { break }
                try { $width = [int](((Get-RowField -Row $rule -FieldName $fn) + '').Trim()) } catch {}
            }

                $numInt = 0
                try { $numInt = [int]$sampleNum } catch { $numInt = 0 }

                $wOk = $true
                if ($width -gt 0) {
                    if (($tokInfo.SampleNumRaw + '').Length -ne $width) { $wOk = $false }
                }

                if ($wOk -and $min -gt 0 -and $max -gt 0 -and $numInt -ge $min -and $numInt -le $max) {
                    $sampleNumOk = 'YES'
                } else {
                    $sampleNumOk = 'NO'
                    $sampleNumWhy = 'Out of range/width'
                }
            } elseif ($rule -and -not $sampleNum) {
                $sampleNumOk = 'NO'
                $sampleNumWhy = 'No sample number'
            }

            $results.Add([pscustomobject]@{
                SampleId         = $sid
                CartridgeSN      = (Get-RowField -Row $row -FieldName 'Cartridge S/N')
                Assay            = $assay
                AssayVersion     = (Get-RowField -Row $row -FieldName 'Assay Version')
                ReagentLotId     = (Get-RowField -Row $row -FieldName 'Reagent Lot ID')
                TestType         = (Get-RowField -Row $row -FieldName 'Test Type')
                ExpectedTestType = $expTT
                ControlCode      = $cc
                SampleToken      = $tokInfo.SampleToken
                BaseToken        = $tokInfo.BaseToken
                ActualSuffix     = $tokInfo.ActualSuffix
                ExpectedSuffix   = $expectedSuffix
                SuffixCheck      = $suffixCheck
                SuffixSource     = $suffixSource
                SampleNum        = $sampleNum
                SampleNumOK      = $sampleNumOk
                SampleNumWhy     = $sampleNumWhy
                Status           = (Get-RowField -Row $row -FieldName 'Status')
                TestResult       = (Get-RowField -Row $row -FieldName 'Test Result')
                ErrorText        = (Get-RowField -Row $row -FieldName 'Error')
                RunOutcome       = $runOutcome
                ErrorClass       = $errClass
                MtbIndeterminate = $(if ($mtbIndet) { 'YES' } else { '' })
                DelamCode        = $delamCode
                DelamHandling    = $delamHandling
                MaxPressure      = $errInfo.MaxPressure
                PressureFlag     = $errInfo.PressureFlag
                ErrorCode        = $errInfo.ErrorCode
                ErrorName        = $errInfo.ErrorName
                GeneratesRetest  = $errInfo.GeneratesRetest
                ObservedCall     = $obsD.Call
                ObservedWhy      = $obsD.Reason
                ExpectedCall     = $expCall
                ExpectedWhy      = $expD.Reason
                ExpectedSource   = $expSrc
                Deviation        = $dev
            })

        } catch {
            $sid2 = ''
            try { $sid2 = (Get-RowField -Row $row -FieldName 'Sample ID') } catch {}
            throw ("RuleEngine row-fel (Sample ID=" + $sid2 + "): " + $_.Exception.Message)
        }
    }

    $summary = [pscustomobject]@{
        Total = $results.Count
        ObservedCounts = @{}
        DeviationCounts = @{}
        RetestYes = 0
    }

    foreach ($r in $results) {
        if (-not $summary.ObservedCounts.ContainsKey($r.ObservedCall)) { $summary.ObservedCounts[$r.ObservedCall] = 0 }
        $summary.ObservedCounts[$r.ObservedCall]++

        if (-not $summary.DeviationCounts.ContainsKey($r.Deviation)) { $summary.DeviationCounts[$r.Deviation] = 0 }
        $summary.DeviationCounts[$r.Deviation]++

        $rt = ($r.GeneratesRetest + '').Trim().ToUpperInvariant()
        if ($rt -in @('YES','Y','TRUE','1')) { $summary.RetestYes++ }
    }

    $top = @($results | Where-Object { $_.Deviation -in @('FP','FN','INDET','MISMATCH') } | Select-Object -First 50)

    return [pscustomobject]@{ Rows = $results.ToArray(); Summary = $summary; TopDeviations = $top }
}

function Write-RuleEngineDebugSheet {
    param(
        [Parameter(Mandatory)][object]$Pkg,
        [Parameter(Mandatory)][pscustomobject]$RuleEngineResult
    )

    try {
        $old = $Pkg.Workbook.Worksheets['RuleEngine_Debug']
        if ($old) { $Pkg.Workbook.Worksheets.Delete($old) }
    } catch {}

    $ws = $Pkg.Workbook.Worksheets.Add('RuleEngine_Debug')

    $headers = @(
        '#','Sample ID','Cartridge S/N','Test Type','Expected Test Type','Expected Call','Observed Call','Deviation','Status','RunOutcome','ErrorClass','MTB Indeterminate','DelamCode','DelamHandling','ErrorCode','ErrorName','Retest','Max Pressure','PressureFlag','ObservedWhy','ExpectedWhy','Test Result','Error','BaseSampleToken','SampleSuffix','ExpectedSuffix','ActualSuffix','SuffixCheck','SuffixSource','SampleNum','SampleNumOK','SampleNumRule','SampleNumRuleNote'
    )
    for ($c = 1; $c -le $headers.Count; $c++) {
        $ws.Cells[1,$c].Value = $headers[$c-1]
        $ws.Cells[1,$c].Style.Font.Bold = $true
    }

    $rows = $RuleEngineResult.Rows
    $rOut = 2
    $idx = 1

    foreach ($r in $rows) {
        $ws.Cells[$rOut,1].Value  = $idx
        $ws.Cells[$rOut,2].Value  = ($r.SampleId + '')
        $ws.Cells[$rOut,3].Value  = ($r.CartridgeSN + '')
        $ws.Cells[$rOut,4].Value  = ($r.TestType + '')
        $ws.Cells[$rOut,5].Value  = ($r.ExpectedTestType + '')
        $ws.Cells[$rOut,6].Value  = ($r.ControlCode + '')

        $ws.Cells[$rOut,7].Value  = ($r.SampleToken + '')
        $ws.Cells[$rOut,8].Value  = ($r.BaseToken + '')
        $ws.Cells[$rOut,9].Value  = ($r.ActualSuffix + '')
        $ws.Cells[$rOut,10].Value = ($r.ExpectedSuffix + '')
        $ws.Cells[$rOut,11].Value = ($r.SuffixCheck + '')
        $ws.Cells[$rOut,12].Value = ($r.SuffixSource + '')

        $ws.Cells[$rOut,13].Value = ($r.SampleNum + '')
        $ws.Cells[$rOut,14].Value = ($r.SampleNumOK + '')
        $ws.Cells[$rOut,15].Value = ($r.SampleNumWhy + '')

        $ws.Cells[$rOut,16].Value = ($r.ExpectedCall + '')
        $ws.Cells[$rOut,17].Value = ($r.ExpectedSource + '')
        $ws.Cells[$rOut,18].Value = ($r.ObservedCall + '')
        $ws.Cells[$rOut,19].Value = ($r.ObservedWhy + '')
        $ws.Cells[$rOut,20].Value = ($r.Deviation + '')

        $ws.Cells[$rOut,21].Value = ($r.Status + '')
        $ws.Cells[$rOut,22].Value = ($r.ErrorCode + '')
        $ws.Cells[$rOut,23].Value = ($r.ErrorName + '')
        $ws.Cells[$rOut,24].Value = ($r.GeneratesRetest + '')
        $ws.Cells[$rOut,25].Value = $(if ($null -ne $r.MaxPressure) { $r.MaxPressure } else { '' })
        $ws.Cells[$rOut,26].Value = $(if ($r.PressureFlag) { 'YES' } else { '' })

        $ws.Cells[$rOut,27].Value = ($r.TestResult + '')
        $ws.Cells[$rOut,28].Value = ($r.ErrorText + '')

        $rOut++; $idx++
    }

    try { if ($ws.Dimension) { $ws.Cells[$ws.Dimension.Address].AutoFitColumns() } } catch {}
    return $ws
}
