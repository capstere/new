# Rules and Assays

This project is driven by Rules/RuleBank.psd1. Add new assay profiles or rule checks
there, then use the existing rule engine to emit Information2 rows.

Add a new rule
1) Open Rules/RuleBank.psd1 and add a new entry under RuleDefinitions.
2) Provide at least:
   - Section: must match one of Defaults.SectionOrder.
   - Severity: Fail, Warn, or Info.
   - Tags: tag(s) that map to a section via Defaults.SectionTagMap.
   - When: a hashtable with the matching conditions.
   - RowLabel or RowLabelFrom (ErrorCode or ErrorCodeOrBlank).
   - Optional: Reason and SuggestedAction for extra columns.
3) Add the rule id to an assay profile's EnabledRules list (or leave it empty to
   enable all rules).

Supported When conditions
- TestTypeLike
- SamplePrefixLike
- ExcludeSamplePrefixLike
- ResultContains
- ResultNotContains
- ErrorCodeIn
- SpcCtEquals
- SampleIdHasReplacement
- SampleIdObsLike
- ExcludeReplacement
- StatusIn
- ErrorEmpty

Add a new assay profile
1) Add a new object to AssayProfiles in Rules/RuleBank.psd1.
2) Set MatchNames to all assay name variants (case-insensitive matching).
3) Provide EnabledRules if the profile uses a subset of rules.
4) Override Settings as needed (SampleIdPattern, ExpectedTestTypeByPrefix, ranges).

Implementation notes
- Sample IDs are parsed once per row via Parse-SampleIdDerived (Services/Canonical.ps1).
- The rule engine emits rows with WorstSeverity and Tags; the writer maps tags to
  sections using Defaults.SectionTagMap.
- Keep scripts UTF-8 with BOM and CRLF. Use Tools/Verify-Encoding.ps1 to check.
