﻿param(
    [string]$Root = $PSScriptRoot
)

# Fixes encoding and line endings for PowerShell script and data files.
# Ensures each .ps1/.psm1/.psd1 file is saved as UTF-8 with BOM and
# uses CRLF line endings.  This script scans recursively under the
# specified root.  Base64 or certificate here-strings are not
# modified beyond normalizing line endings; the literal base64 bytes
# remain intact.

$files = Get-ChildItem -LiteralPath $Root -Recurse -Force |
    Where-Object {
        ($_.Extension -in '.ps1','.psm1','.psd1') -and -not $_.PSIsContainer
    }
foreach ($file in $files) {
    try {
        # Read text content preserving original encoding
        $content = Get-Content -LiteralPath $file.FullName -Raw -ErrorAction Stop
        # Normalize all line endings to LF first
        $contentLf = $content -replace "`r`n", "`n" -replace "`r", "`n"
        # Convert LF back to CRLF
        $contentCrLf = $contentLf -replace "`n", "`r`n"
        # Write out with UTF-8 BOM and CRLF
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($contentCrLf)
        $preamble = [System.Text.Encoding]::UTF8.GetPreamble()
        [System.IO.File]::WriteAllBytes($file.FullName, $preamble + $bytes)
    } catch {
        Write-Host ("Failed to fix encoding for {0}: {1}" -f $file.FullName, $_.Exception.Message) -ForegroundColor Red
    }
}
