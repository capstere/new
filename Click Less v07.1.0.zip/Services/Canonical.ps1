﻿function Normalize-HeaderName {

    param([string]$s)

    if ([string]::IsNullOrWhiteSpace($s)) { return '' }

    $t = $s.Trim().ToLowerInvariant()

    $t = $t.Replace('_',' ')

    $t = ($t -replace '[\(\)]',' ')

    $t = ($t -replace '\s+',' ').Trim()

    return $t

}



function Normalize-AssayName {

    param([string]$Name)

    if ([string]::IsNullOrWhiteSpace($Name)) { return '' }

    $x = $Name.Trim().ToLowerInvariant()

    $x = $x -replace '[_]+',' '

    $x = $x -replace '[^a-z0-9]+',' '

    $x = ($x -replace '\s+',' ').Trim()

    return $x

}



function Get-HeaderIndexValue {

    param(

        [object]$HeaderIndex,

        [string[]]$Keys

    )

    if (-not $HeaderIndex) { return -1 }



    foreach ($k in ($Keys | Where-Object { $_ })) {

        $n = Normalize-HeaderName $k

        if ($HeaderIndex.ContainsKey($n)) { return [int]$HeaderIndex[$n] }

        if ($HeaderIndex.ContainsKey($k)) { return [int]$HeaderIndex[$k] }

    }

    return -1

}



function Convert-SampleIdDerivedToParts {

    param([pscustomobject]$Derived)

    if (-not $Derived) {
        return [pscustomobject]@{
            Prefix  = ''
            Bag     = ''
            Rep     = ''
            Sample  = ''
            Suffix  = ''
            Obs     = ''
            Success = $false
        }
    }

    return [pscustomobject]@{
        Prefix  = $Derived.Prefix
        Bag     = $Derived.Bag
        Rep     = $Derived.Replicate
        Sample  = $Derived.Sample
        Suffix  = $Derived.Suffix
        Obs     = $Derived.Obs
        Success = [bool]$Derived.Success
    }

}



function Parse-SampleIdDerived {

    param(

        [string]$SampleId,

        [string]$Pattern

    )



    $raw = if ($SampleId) { $SampleId.Trim() } else { '' }
    $default = [pscustomobject]@{
        SampleId              = $raw
        Prefix                = ''
        Bag                   = ''
        Replicate             = ''
        Sample                = ''
        Suffix                = ''
        Obs                   = ''
        BagNumber             = $null
        ReplicateNumber       = $null
        SampleIndex           = $null
        IsReplacement         = $false
        HasDelaminationMarker = $false
        HasObservation        = $false
        Success               = $false
    }

    if ([string]::IsNullOrWhiteSpace($raw)) { return $default }

    $usePattern = if ($Pattern) { $Pattern } else { '^(?<prefix>[^_]+)_(?<bag>\d{2})_(?<rep>\d)_(?<sample>\d{2})(?<suffix>[A-Z0-9+]*)(?:_(?<obs>.+))?$' }

    try {
        $m = [regex]::Match($raw, $usePattern)
        if ($m.Success) {
            $default.Prefix    = if ($m.Groups['prefix']) { $m.Groups['prefix'].Value } else { '' }
            $default.Bag       = if ($m.Groups['bag'])    { $m.Groups['bag'].Value }    else { '' }
            $default.Replicate = if ($m.Groups['rep'])    { $m.Groups['rep'].Value }    else { '' }
            $default.Sample    = if ($m.Groups['sample']) { $m.Groups['sample'].Value } else { '' }
            $default.Suffix    = if ($m.Groups['suffix']) { $m.Groups['suffix'].Value } else { '' }
            $default.Obs       = if ($m.Groups['obs'])    { $m.Groups['obs'].Value }    else { '' }
            $default.Success   = $true
        } else {
            $prefixMatch = [regex]::Match($raw, '^(?<prefix>[^_]+)')
            if ($prefixMatch.Success) { $default.Prefix = $prefixMatch.Groups['prefix'].Value }
            $fallbackMatch = [regex]::Match($raw, '^[^_]+_(?<bag>\\d{1,2})_(?<rep>\\d{1,2})_(?<sample>\\d{1,2})')
            if ($fallbackMatch.Success) {
                $default.Bag       = $fallbackMatch.Groups['bag'].Value
                $default.Replicate = $fallbackMatch.Groups['rep'].Value
                $default.Sample    = $fallbackMatch.Groups['sample'].Value
            }
        }
    } catch {
        return $default
    }

    $num = $null
    if ($default.Bag -and [int]::TryParse($default.Bag, [ref]$num)) { $default.BagNumber = $num }
    $num = $null
    if ($default.Replicate -and [int]::TryParse($default.Replicate, [ref]$num)) { $default.ReplicateNumber = $num }
    $num = $null
    if ($default.Sample -and [int]::TryParse($default.Sample, [ref]$num)) { $default.SampleIndex = $num }

    if ($default.Obs) { $default.HasObservation = $true }

    if ($default.Suffix -match '(?i)a') {
        $default.IsReplacement = $true
    } elseif ($raw -match '(?i)\\d{2}a') {
        $default.IsReplacement = $true
    }

    $obsText = $default.Obs
    if (-not $obsText) {
        $obsMatch = [regex]::Match($raw, '(?i)(?:^|_)(D\\d{2}|D)(?:_|$)')
        if ($obsMatch.Success) { $obsText = $obsMatch.Groups[1].Value }
    }
    if ($obsText -and $obsText -match '(?i)^D') { $default.HasDelaminationMarker = $true }

    return $default

}



function Parse-SampleIdParts {

    param(

        [string]$SampleId,

        [string]$Pattern

    )



    $derived = Parse-SampleIdDerived -SampleId $SampleId -Pattern $Pattern
    return Convert-SampleIdDerivedToParts -Derived $derived

}

