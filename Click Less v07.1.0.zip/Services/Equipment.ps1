﻿function Get-OptionalEquipmentInfo {

    param(

        [OfficeOpenXml.ExcelPackage]$Pkg,

        [bool]$Enabled = $true

    )



    if (-not $Enabled) { return $null }
    if (-not $Pkg) { return $null }

    try {
        return Get-TestSummaryEquipment -Pkg $Pkg
    } catch {
        Gui-Log ("Get-TestSummaryEquipment: " + $_.Exception.Message) 'Warn'
        return $null
    }

}
