﻿function Write-UiLog {

    param([string]$Msg, [string]$Level = 'Info')

    if (Get-Command Gui-Log -ErrorAction SilentlyContinue) {

        try { Gui-Log $Msg $Level } catch { Write-Host "[$Level] $Msg" }

    } else {

        $prefix = switch ($Level) { 'Error' { '[ERROR]' } 'Warn' { '[WARN]' } default { '[INFO]' } }

        Write-Host "$prefix $Msg"

    }

}



function Ensure-EPPlus {

    [CmdletBinding()]

    param(

        [string]$Version = '4.5.3.3',

        [string]$SourceDllPath = 'N:\QC\QC-1\IPT\Skiftspecifika dokument\PQC analyst\JESPER\Scripts\Modules\EPPlus\EPPlus.4.5.3.3\lib\net40\EPPlus.dll',

        [string]$HintPath = $null,

        [string]$CacheRoot = "$env:ProgramData\EPPlus\$Version"

    )



    $candidatePaths = New-Object System.Collections.Generic.List[string]



    if (-not [string]::IsNullOrWhiteSpace($HintPath)) { $candidatePaths.Add([string]$HintPath) }

    if (-not [string]::IsNullOrWhiteSpace($SourceDllPath)) { $candidatePaths.Add([string]$SourceDllPath) }



    $net35 = 'N:\QC\QC-1\IPT\Skiftspecifika dokument\PQC analyst\JESPER\Scripts\Modules\EPPlus\EPPlus.4.5.3.3\.5.3.3\lib\net35\EPPlus.dll'

    if (-not [string]::IsNullOrWhiteSpace($net35)) { $candidatePaths.Add($net35) }



    try {

        if ($PSScriptRoot) {

            $candidatePaths.Add((Join-Path $PSScriptRoot 'EPPlus.dll'))

        }

    } catch {}



    try {

        $userModRoot = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'WindowsPowerShell\Modules'

        if (Test-Path $userModRoot) {

            Get-ChildItem -Path (Join-Path $userModRoot 'EPPlus') -Directory -ErrorAction SilentlyContinue | ForEach-Object {

                $candidatePaths.Add((Join-Path $_.FullName 'lib\net45\EPPlus.dll'))

                $candidatePaths.Add((Join-Path $_.FullName 'lib\net40\EPPlus.dll'))

            }

        }



        $pf64 = [Environment]::GetFolderPath('ProgramFiles')

        $pf86 = [Environment]::GetFolderPath('ProgramFilesX86')

        foreach ($pf in @($pf64, $pf86)) {

            if ([string]::IsNullOrWhiteSpace($pf)) { continue }

            $systemModRoot = Join-Path $pf 'WindowsPowerShell\Modules'

            if (Test-Path $systemModRoot) {

                Get-ChildItem -Path (Join-Path $systemModRoot 'EPPlus') -Directory -ErrorAction SilentlyContinue | ForEach-Object {

                    $candidatePaths.Add((Join-Path $_.FullName 'lib\net45\EPPlus.dll'))

                    $candidatePaths.Add((Join-Path $_.FullName 'lib\net40\EPPlus.dll'))

                }

            }

        }

    } catch {}



    $cacheDll = $null

    try {

        if (-not [string]::IsNullOrWhiteSpace($CacheRoot)) {

            $cacheDll = Join-Path $CacheRoot 'EPPlus.dll'

            $candidatePaths.Add($cacheDll)

        }

    } catch {}



    foreach ($cand in $candidatePaths) {

        try {

            if (-not [string]::IsNullOrWhiteSpace($cand) -and (Test-Path -LiteralPath $cand)) {

                return $cand

            }

        } catch {}

    }



    try {

        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}



        $nugetUrl = "https://www.nuget.org/api/v2/package/EPPlus/$Version"

        $guid     = [Guid]::NewGuid().ToString()

        $tempDir  = Join-Path $env:TEMP "EPPlus_$guid"

        New-Item -ItemType Directory -Path $tempDir -Force | Out-Null

        $nupkgPath = Join-Path $tempDir "EPPlus.$Version.nupkg"



        Write-UiLog "Hämtar EPPlus $Version från NuGet (fallback)…" 'Info'

        Invoke-WebRequest -Uri $nugetUrl -OutFile $nupkgPath -UseBasicParsing -Headers @{ 'User-Agent' = 'DocMerge/1.0' } -ErrorAction Stop | Out-Null



        $extractDir = Join-Path $tempDir 'extracted'

        Expand-Archive -Path $nupkgPath -DestinationPath $extractDir -Force



        $dllCandidates = @(

            Join-Path $extractDir 'lib\net45\EPPlus.dll',

            Join-Path $extractDir 'lib\net40\EPPlus.dll'

        ) | Where-Object { Test-Path $_ }



        if (-not $dllCandidates -or $dllCandidates.Count -eq 0) {

            throw "Kunde inte hitta EPPlus.dll i nupkg (lib\\net45/net40)."

        }



        if (-not [string]::IsNullOrWhiteSpace($CacheRoot)) {

            New-Item -ItemType Directory -Path $CacheRoot -Force | Out-Null

            Copy-Item -Path $dllCandidates[0] -Destination $cacheDll -Force

            try { Unblock-File -Path $cacheDll } catch {}

            Write-UiLog "EPPlus kopierad till cache: $cacheDll" 'Info'

            return $cacheDll

        }



        return $dllCandidates[0]



    } catch {

        Write-UiLog "⚠️ EPPlus: Kunde inte hämta EPPlus ($Version): $($_.Exception.Message)" 'Warn'

    }



    return $null

}



function Load-EPPlus {

    [CmdletBinding()]

    param(

        [string]$HintPath = $null,

        [string]$Version  = '4.5.3.3'

    )



    try {

        if ([System.AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.GetName().Name -eq 'EPPlus' -or $_.GetName().Name -eq 'OfficeOpenXml' }) {

            return $true

        }

    } catch {}



    $dllPath = Ensure-EPPlus -Version $Version -HintPath $HintPath

    if (-not $dllPath) {

        return $false

    }



    try {

        try { Unblock-File -Path $dllPath -ErrorAction SilentlyContinue } catch {}

        $bytes = [System.IO.File]::ReadAllBytes($dllPath)

        [System.Reflection.Assembly]::Load($bytes) | Out-Null



        try {

            $pkg = New-Object OfficeOpenXml.ExcelPackage

            $pkg.Dispose()

        } catch {}



        return $true

    } catch {

        Write-UiLog "❌ EPPlus-fel: $($_.Exception.Message)" 'Error'

        return $false

    }

}



function Initialize-EPPlus {

    [CmdletBinding()]

    param(

        [string]$HintPath = $null,

        [string]$Version  = '4.5.3.3'

    )



    if (Load-EPPlus -HintPath $HintPath -Version $Version) {

        return $true

    }



    $attempts = @(

        $HintPath,

        'N:\\QC\\QC-1\\IPT\\Skiftspecifika dokument\\PQC analyst\\JESPER\\Scripts\\Modules\\EPPlus\\EPPlus.4.5.3.3\\lib\\net40\\EPPlus.dll',

        'N:\\QC\\QC-1\\IPT\\Skiftspecifika dokument\\PQC analyst\\JESPER\\Scripts\\Modules\\EPPlus\\EPPlus.4.5.3.3\\.5.3.3\\lib\\net35\\EPPlus.dll'

    ) | Where-Object { $_ -and ($_ + '').Trim() } | Select-Object -Unique



    $msg = @()

    $msg += 'EPPlus.dll could not be loaded.'

    $msg += 'Attempted (top):'

    $msg += ($attempts | ForEach-Object { " - $_" })

    $msg += ''

    $msg += 'Fix options:'

    $msg += ' - Verify the N:\\...\\EPPlus.dll path exists (net40/net35), or'

    $msg += ' - Put EPPlus.dll in .\\EPPlus.dll (project root), or'

    $msg += ' - Set Config.EpplusDllPath to the full path of EPPlus.dll.'



    throw ($msg -join "`r`n")

}



function Safe-AutoFitColumns {

    param(

        [Parameter(Mandatory)][OfficeOpenXml.ExcelWorksheet]$Worksheet,

        [int]$MaxRows = 2000

    )

    try {

        if ($Worksheet -and $Worksheet.Dimension) {

            $startRow = $Worksheet.Dimension.Start.Row

            $startCol = $Worksheet.Dimension.Start.Column

            $endRow   = [Math]::Min($Worksheet.Dimension.End.Row, $MaxRows)

            $endCol   = $Worksheet.Dimension.End.Column

            $Worksheet.Cells[$startRow,$startCol,$endRow,$endCol].AutoFitColumns() | Out-Null

        }

    } catch {

        # ignore AutoFit errors

    }

}



function Set-RangeFromArray {

    param(

        [Parameter(Mandatory)][OfficeOpenXml.ExcelWorksheet]$Worksheet,

        [Parameter(Mandatory)][int]$StartRow,

        [Parameter(Mandatory)][int]$StartCol,

        [Parameter(Mandatory)][object[,]]$Values

    )

    $rowCount = $Values.GetLength(0)

    $colCount = $Values.GetLength(1)

    if ($rowCount -le 0 -or $colCount -le 0) { return }

    $Worksheet.Cells[$StartRow,$StartCol,$StartRow + $rowCount - 1,$StartCol + $colCount - 1].Value = $Values

}

