﻿# RuleEngine.ps1 (PowerShell 5.1)
# Safe drop-in: does nothing unless $Config.EnableRuleEngine = $true

function Import-RuleCsv {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    $delim = ','
    try { $delim = Get-CsvDelimiter -Path $Path } catch {}
    try {
        $lines = Get-Content -LiteralPath $Path -ErrorAction Stop
        if (-not $lines -or $lines.Count -lt 1) { return @() }
        return ,@(ConvertFrom-Csv -InputObject ($lines -join "`n") -Delimiter $delim)
    } catch {
        try { return ,@(Import-Csv -LiteralPath $Path -Delimiter $delim) } catch { return @() }
    }
}

function Load-RuleBank {
    param([Parameter(Mandatory)][string]$RuleBankDir)
    $rb = [ordered]@{
        Dir = $RuleBankDir
        ResultCallPatterns = @()
        SampleExpectationRules = @()
        ErrorCodes = @()
        MissingSamplesConfig = @()
        SampleIdMarkers = @()
        ParityCheckConfig = @()
    }

    if (-not (Test-Path -LiteralPath $RuleBankDir)) { return [pscustomobject]$rb }

    $map = @{
        ResultCallPatterns      = '01_ResultCallPatterns.csv'
        SampleExpectationRules  = '02_SampleExpectationRules.csv'
        ErrorCodes              = '03_ErrorCodes.csv'
        MissingSamplesConfig    = '04_MissingSamplesConfig.csv'
        SampleIdMarkers         = '05_SampleIdMarkers.csv'
        ParityCheckConfig       = '06_ParityCheckConfig.csv'
    }

    foreach ($k in $map.Keys) {
        $p = Join-Path $RuleBankDir $map[$k]
        $rb[$k] = Import-RuleCsv -Path $p
    }

    # Priority sort where applicable
    try {
        $rb.ResultCallPatterns = @($rb.ResultCallPatterns | Sort-Object { [int]($_.Priority) } -Descending)
    } catch {}

    return [pscustomobject]$rb
}

function Get-ObservedCall {
    param(
        [Parameter(Mandatory)][string]$TestResult,
        [Parameter(Mandatory)][object[]]$Patterns
    )
    $tr = ($TestResult + '').Trim()
    if (-not $tr) { return 'UNK' }

    foreach ($r in $Patterns) {
        $pat = ($r.Pattern + '').Trim()
        if (-not $pat) { continue }
        $mode = (($r.MatchType + '')).Trim().ToUpperInvariant()
        if (-not $mode) { $mode = 'CONTAINS' }
        $isMatch = $false
        try {
            switch ($mode) {
                'REGEX'   { $isMatch = [regex]::IsMatch($tr, $pat, [Text.RegularExpressions.RegexOptions]::IgnoreCase) }
                'EQUALS'  { $isMatch = ($tr -ieq $pat) }
                default   { $isMatch = ($tr.ToUpperInvariant().Contains($pat.ToUpperInvariant())) }
            }
        } catch { $isMatch = $false }

        if ($isMatch) {
            $call = (($r.Call + '')).Trim().ToUpperInvariant()
            if ($call) { return $call }
        }
    }

    return 'UNK'
}

function Get-RowField {
    param(
        [Parameter(Mandatory)][object]$Row,
        [Parameter(Mandatory)][string]$FieldName
    )
    try {
        $p = $Row.PSObject.Properties[$FieldName]
        if ($p -and $null -ne $p.Value) { return $p.Value }
    } catch {}
    return ''
}

function Invoke-RuleEngine {
    param(
        [Parameter(Mandatory)][object[]]$CsvObjects,
        [Parameter(Mandatory)][pscustomobject]$RuleBank
    )

    $results = New-Object System.Collections.Generic.List[object]

    foreach ($row in $CsvObjects) {
        $tr = ''
        try { $tr = $row.'Test Result' } catch {}
        $obs = Get-ObservedCall -TestResult $tr -Patterns $RuleBank.ResultCallPatterns

        $results.Add([pscustomobject]@{
	        SampleId      = (Get-RowField -Row $row -FieldName 'Sample ID')
	        CartridgeSN   = (Get-RowField -Row $row -FieldName 'Cartridge S/N')
	        TestType      = (Get-RowField -Row $row -FieldName 'Test Type')
	        Status        = (Get-RowField -Row $row -FieldName 'Status')
            TestResult    = $tr
            ObservedCall  = $obs
            ExpectedCall  = ''   # filled later when we wire 02_SampleExpectationRules
            Deviation     = ''
        })
    }

    $summary = [pscustomobject]@{
        Total = $results.Count
        ObservedCounts = @{}
    }
    foreach ($r in $results) {
        if (-not $summary.ObservedCounts.ContainsKey($r.ObservedCall)) { $summary.ObservedCounts[$r.ObservedCall] = 0 }
        $summary.ObservedCounts[$r.ObservedCall]++
    }

    return [pscustomobject]@{ Rows = $results; Summary = $summary }
}
