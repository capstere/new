# Changelog

## v07.1.1
- Remove Dashboard sheet from report output.
- Disable Worksheet equipment extraction (config flag) and keep Infinity/GX from static list.
- Simplify GUI by moving output/sharepoint choices to Config defaults.
- Cache input files per run and consolidate opens/parses for CSV/XLSX.
- Use bulk Excel writes and drop AutoFitColumns calls for faster output.
- Clean package contents to ship only output_template-v5.xlsx.
