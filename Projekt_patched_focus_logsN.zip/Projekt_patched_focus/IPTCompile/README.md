# IPTCompile – kort användarguide

## Vad verktyget gör
IPTCompile sammanställer ett IPT/PQC-test till en rapport (.xlsx) genom att:
- hitta rätt LSP-mapp,
- låta dig välja rätt filer (Seal Test NEG/POS, CSV, Worksheet),
- kontrollera avvikelser och kompletterande information,
- skapa en färdig rapport.

## Starta (kort)
1. **Första gången:** Gå till nätmappen `...\zz_IPTCompile\` och kör `Install_Launcher.bat`.
2. **Därefter:** Starta via skrivbordsgenvägen **"IPTCompile (Local)"**.
3. **Alternativt:** Kör `IPTCompile_Launcher.bat` från nätmappen om du inte har genvägen.

## Steg för steg
1. **Skriv in LSP‑numret** och klicka **Sök filer**.
2. **Välj filer** (minst **Seal Test NEG** och **Seal Test POS**).
3. **Klicka Skapa rapport**.
4. **Klar** – du får en rad som säger **"Rapport sparad"** med sökväg.

## Var hamnar rapporten?
- Rapporten sparas normalt i en temporär sökväg (TEMP).
- Den exakta sökvägen visas alltid i slutraden **"✅ Rapport sparad: …"**.

## Vanliga fel och vad du gör
- **"Ingen LSP-mapp hittad"**
  Kontrollera LSP‑numret och att mappen finns i IPT‑strukturen.
- **"Kontrollprovsfil saknas"**
  Kontrollera att nätmappen är åtkomlig. Kontakta PQC/IT om filen saknas.
- **"Filen är låst/kan inte spara"**
  Stäng filen i Excel och försök igen.
- **"SharePoint ej tillgängligt"**
  Testa igen senare eller kör utan SharePoint Info.
- **"Sökning/rapport pågår"**
  Vänta tills körningen är klar och klicka igen.

## Var loggar finns
- **GUI‑logg:** i programfönstret (kort, för användare).
- **Tekniska loggar (lokalt):** `C:\IPTCompile\Loggar\`.
- **Tekniska loggar (nät):** `...\zz_IPTCompile\Loggar\` (speglas från lokalt efter körning).
- **Audit‑logg:** `...\zz_IPTCompile\audit\`.
- **Launcher‑loggar:** `C:\IPTCompileLauncher\_LocalLauncherAudit\` och `...\zz_IPTCompile\_LauncherAudit\`.

## Viktig regel (måste följas)
**Kontrollprovsfilen "KONTROLLPROVSFIL - Version 2.5.xlsm" hämtas alltid direkt från nätet.**
Den får inte kopieras, cachas eller användas lokalt.

## Kontakt vid problem
Kontakta **PQC/IT** eller Jesper. Bifoga gärna loggsökvägen vid felanmälan.
