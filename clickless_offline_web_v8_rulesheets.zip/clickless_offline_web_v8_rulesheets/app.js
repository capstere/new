/* ClickLess Offline Analyzer v8
   - ES5-ish (no const/let/arrow/template/module/async)
   - CSV validation + Rule Sheets (CSV)
   - Optional: ZIP input using JSZip (if loaded)
   - Shows results on the page (no downloads).
*/
(function () {
  'use strict';

  // ----------------------------
  // DOM helpers
  // ----------------------------
  function $(id) { return document.getElementById(id); }

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    if (attrs) {
      for (var k in attrs) {
        if (!attrs.hasOwnProperty(k)) continue;
        if (k === 'text') node.textContent = String(attrs[k]);
        else if (k === 'html') node.innerHTML = String(attrs[k]);
        else if (k === 'class') node.className = String(attrs[k]);
        else if (k === 'style') node.setAttribute('style', String(attrs[k]));
        else node.setAttribute(k, String(attrs[k]));
      }
    }
    if (children && children.length) {
      for (var i = 0; i < children.length; i++) node.appendChild(children[i]);
    }
    return node;
  }

  function clearNode(node) { while (node && node.firstChild) node.removeChild(node.firstChild); }

  function pill(text, kind) {
    var cls = 'pill';
    if (kind === 'ok') cls += ' ok';
    else if (kind === 'bad') cls += ' bad';
    else if (kind === 'warn') cls += ' warn';
    return el('span', { 'class': cls, text: text });
  }

  function setStatus(msg, isError) {
    var s = $('status');
    s.textContent = msg || '';
    s.className = 'small ' + (isError ? 'err' : 'muted');
  }

  function esc(s) {
    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  // ----------------------------
  // File registry + detection
  // ----------------------------
  var TYPE_OPTIONS = [
    { key: 'auto', label: 'Auto' },
    { key: 'testSummary', label: 'Test Summary (csv)' },
    { key: 'ruleSheet', label: 'Rule Sheet (csv)' }
  ];

  var files = []; // {file, typeKey, detectedKey}

  function detectTypeByName(name) {
    var n = (name || '').toLowerCase();
    if (n.indexOf('test summary') >= 0 || n.indexOf('tests summary') >= 0) return 'testSummary';
    if (n.indexOf('rulesheet') >= 0 || n.indexOf('rule sheet') >= 0 || n.indexOf('rule_') >= 0) return 'ruleSheet';
    if (n.indexOf('rule') >= 0 && n.slice(-4) === '.csv') return 'ruleSheet';
    if (n.slice(-4) === '.csv') return 'ruleSheet';
    return 'auto';
  }

  function typeLabel(key) {
    for (var i = 0; i < TYPE_OPTIONS.length; i++) if (TYPE_OPTIONS[i].key === key) return TYPE_OPTIONS[i].label;
    return key;
  }

  // ----------------------------
  // ZIP support
  // ----------------------------
  function isZipFile(file) {
    if (!file) return false;
    var n = (file.name || '').toLowerCase();
    if (n.slice(-4) === '.zip') return true;
    var t = (file.type || '').toLowerCase();
    if (t.indexOf('zip') >= 0) return true;
    return false;
  }

  function makeFileLike(data, name, mime) {
    var opts = mime ? { type: mime } : {};
    try { return new File([data], name, opts); }
    catch (e) { var b = new Blob([data], opts); b.name = name; return b; }
  }

  function extractFilesFromZip(zipFile) {
    if (typeof JSZip === 'undefined') return Promise.reject(new Error('JSZip not loaded'));
    return zipFile.arrayBuffer().then(function (buf) {
      return JSZip.loadAsync(buf);
    }).then(function (zip) {
      var out = [];
      var promises = [];
      zip.forEach(function (relPath, entry) {
        if (!entry || entry.dir) return;
        if (relPath.indexOf('__MACOSX/') === 0) return;
        var base = relPath.split('/').pop();
        if (!base) return;
        if (base.indexOf('._') === 0) return;
        // only allow csv / zip-with-csv for v8
        if (base.toLowerCase().slice(-4) !== '.csv') return;
        promises.push(entry.async('arraybuffer').then(function (ab) {
          out.push(makeFileLike(ab, base, 'text/csv'));
        }));
      });
      return Promise.all(promises).then(function () { return out; });
    });
  }

  // ----------------------------
  // UI: list + validation
  // ----------------------------
  function refreshFileList() {
    var list = $('fileList');
    clearNode(list);

    if (!files.length) {
      list.appendChild(el('div', { 'class': 'small muted', text: 'Inga filer valda.' }));
      $('runBtn').disabled = true;
      return;
    }

    var tbl = el('table');
    var thead = el('thead');
    var trh = el('tr');
    trh.appendChild(el('th', { text: 'Fil' }));
    trh.appendChild(el('th', { text: 'Detekterad typ' }));
    trh.appendChild(el('th', { text: 'Använd som' }));
    trh.appendChild(el('th', { text: '' }));
    thead.appendChild(trh);
    tbl.appendChild(thead);

    var tbody = el('tbody');
    for (var i = 0; i < files.length; i++) {
      (function (idx) {
        var f = files[idx];
        var tr = el('tr');

        tr.appendChild(el('td', { 'class': 'mono', text: f.file.name || '(namnlös fil)' }));
        tr.appendChild(el('td', { text: typeLabel(f.detectedKey) }));

        var sel = el('select');
        for (var j = 0; j < TYPE_OPTIONS.length; j++) {
          var opt = el('option', { value: TYPE_OPTIONS[j].key, text: TYPE_OPTIONS[j].label });
          if (TYPE_OPTIONS[j].key === f.typeKey) opt.selected = true;
          sel.appendChild(opt);
        }
        sel.addEventListener('change', function () { files[idx].typeKey = sel.value; validateReady(); });
        tr.appendChild(el('td', null, [sel]));

        var rm = el('button', { 'class': 'btn2', type: 'button', text: 'Ta bort' });
        rm.addEventListener('click', function () { files.splice(idx, 1); refreshFileList(); validateReady(); });
        tr.appendChild(el('td', null, [rm]));

        tbody.appendChild(tr);
      })(i);
    }
    tbl.appendChild(tbody);
    list.appendChild(tbl);

    validateReady();
  }

  function pickByType(key) {
    for (var i = 0; i < files.length; i++) {
      var tk = files[i].typeKey;
      if (tk === 'auto') tk = files[i].detectedKey;
      if (tk === key) return files[i].file;
    }
    return null;
  }

  function pickAllByType(key) {
    var out = [];
    for (var i = 0; i < files.length; i++) {
      var tk = files[i].typeKey;
      if (tk === 'auto') tk = files[i].detectedKey;
      if (tk === key) out.push(files[i].file);
    }
    return out;
  }

  function validateReady() {
    var hasCsv = !!pickByType('testSummary');
    $('runBtn').disabled = !hasCsv;
    if (!hasCsv) setStatus('Välj minst 1 Test Summary CSV.', false);
    else setStatus('Redo. Klicka "Kör analys".', false);
  }

  // ----------------------------
  // File reading
  // ----------------------------
  function readFileAsText(file) {
    return new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onload = function () { resolve(fr.result); };
      fr.onerror = function () { reject(new Error('FileReader error: ' + (file && file.name ? file.name : 'unknown'))); };
      fr.readAsText(file);
    });
  }

  // ----------------------------
  // CSV parsing (robust, no hard-coded header row)
  // ----------------------------
  function countChar(s, ch) {
    var c = 0;
    for (var i = 0; i < s.length; i++) if (s.charAt(i) === ch) c++;
    return c;
  }

  function splitCsvLine(line, delim) {
    // Handles quotes and escaped quotes.
    var out = [];
    var cur = '';
    var inQ = false;
    for (var i = 0; i < line.length; i++) {
      var ch = line.charAt(i);
      if (ch === '"') {
        if (inQ && i + 1 < line.length && line.charAt(i + 1) === '"') { cur += '"'; i++; }
        else inQ = !inQ;
      } else if (ch === delim && !inQ) {
        out.push(cur);
        cur = '';
      } else {
        cur += ch;
      }
    }
    out.push(cur);
    return out;
  }

  function normHeader(h) {
    return String(h || '').replace(/\uFEFF/g, '').trim();
  }

  function findHeaderIndex(lines) {
    // Find first line that looks like a Test Summary header.
    for (var i = 0; i < lines.length && i < 80; i++) {
      var l = lines[i];
      if (!l) continue;
      var low = l.toLowerCase();
      if (low.indexOf('assay') >= 0 && low.indexOf('sample id') >= 0 && (low.indexOf('cartridge') >= 0 || low.indexOf('s/n') >= 0)) return i;
    }
    return -1;
  }

  function detectDelimiter(lines) {
    var delim = ';';
    for (var i = 0; i < lines.length && i < 50; i++) {
      var l = lines[i];
      if (!l || !l.length) continue;
      var cSemi = countChar(l, ';');
      var cComma = countChar(l, ',');
      delim = (cSemi >= cComma) ? ';' : ',';
      break;
    }
    return delim;
  }

  function parseCsvToObjects(text) {
    text = text || '';
    if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);

    var lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
    var delim = detectDelimiter(lines);
    var headerIdx = findHeaderIndex(lines);
    if (headerIdx < 0) return { ok: false, error: 'Kunde inte hitta header-rad i CSV.', headerIdx: -1, rows: [], headers: [], delim: delim };

    var headersRaw = splitCsvLine(lines[headerIdx], delim);
    var headers = [];
    for (var h = 0; h < headersRaw.length; h++) headers.push(normHeader(headersRaw[h]));

    var rows = [];
    for (var i = headerIdx + 1; i < lines.length; i++) {
      var line = lines[i];
      if (!line) continue;
      if (/^(\s*;)+\s*$/.test(line) || /^(\s*,)+\s*$/.test(line)) continue;

      var cols = splitCsvLine(line, delim);
      if (cols.length < 4) continue;

      var obj = {};
      var max = headers.length;
      for (var j = 0; j < max; j++) obj[headers[j]] = (cols[j] != null ? cols[j] : '');
      // quick skip: if no assay, likely not a row
      if (!String(obj['Assay'] || '').trim()) continue;

      rows.push(obj);
    }

    return { ok: true, headerIdx: headerIdx + 1, delim: delim, headers: headers, rows: rows };
  }

  function getField(row, names) {
    for (var i = 0; i < names.length; i++) {
      var k = names[i];
      if (row.hasOwnProperty(k)) return row[k];
    }
    return '';
  }

  // ----------------------------
  // Rule engine (from rule sheets)
  // ----------------------------
  function toBool(v) {
    if (v == null) return true;
    var s = String(v).trim().toLowerCase();
    if (s === '') return true;
    if (s === 'true' || s === '1' || s === 'yes' || s === 'y') return true;
    if (s === 'false' || s === '0' || s === 'no' || s === 'n') return false;
    return true;
  }

  function toInt(v, def) {
    var n = parseInt(String(v || ''), 10);
    if (isNaN(n)) return def;
    return n;
  }

  function parseRuleSheet(text, fileName) {
    // Generic CSV -> objects; header row: first row that has "Assay" + ("Call" or "Expected")
    text = text || '';
    if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
    var lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
    var delim = detectDelimiter(lines);

    var headerIdx = -1;
    for (var i = 0; i < lines.length && i < 120; i++) {
      var l = lines[i];
      if (!l) continue;
      var low = l.toLowerCase();
      if (low.indexOf('assay') >= 0 && (low.indexOf('call') >= 0 || low.indexOf('expected') >= 0)) { headerIdx = i; break; }
    }
    if (headerIdx < 0) return { ok: false, error: 'Rule sheet: kunde inte hitta header (behöver Assay + Call/Expected).', type: 'unknown', rows: [] };

    var headersRaw = splitCsvLine(lines[headerIdx], delim);
    var headers = [];
    for (var h = 0; h < headersRaw.length; h++) headers.push(normHeader(headersRaw[h]));

    var objs = [];
    for (i = headerIdx + 1; i < lines.length; i++) {
      var line = lines[i];
      if (!line) continue;
      if (/^(\s*;)+\s*$/.test(line) || /^(\s*,)+\s*$/.test(line)) continue;
      var cols = splitCsvLine(line, delim);
      if (cols.length < 2) continue;
      var obj = {};
      for (var j = 0; j < headers.length; j++) obj[headers[j]] = (cols[j] != null ? cols[j] : '');
      if (!String(obj['Assay'] || '').trim()) continue;
      objs.push(obj);
    }

    // detect type
    var type = 'unknown';
    for (var k = 0; k < headers.length; k++) {
      if (headers[k].toLowerCase() === 'call') type = 'call';
      if (headers[k].toLowerCase() === 'expected') type = 'expect';
    }
    return { ok: true, type: type, rows: objs, name: (fileName || '') };
  }

  function matchAssay(ruleAssay, assay) {
    var ra = String(ruleAssay || '').trim();
    if (ra === '' || ra === '*') return true;
    if (ra.charAt(0) === '/' && ra.lastIndexOf('/') > 0) {
      var last = ra.lastIndexOf('/');
      var pat = ra.slice(1, last);
      var flags = ra.slice(last + 1);
      try {
        var rx = new RegExp(pat, flags || 'i');
        return rx.test(String(assay || ''));
      } catch (e) { return false; }
    }
    return String(assay || '') === ra;
  }

  function matchText(matchType, pattern, text) {
    var mt = String(matchType || '').trim().toLowerCase();
    var p = String(pattern || '');
    var t = String(text || '');
    if (mt === 'regex') {
      try { return (new RegExp(p, 'i')).test(t); } catch (e) { return false; }
    }
    // default contains
    return t.toLowerCase().indexOf(p.toLowerCase()) >= 0;
  }

  function matchSampleId(matchType, pattern, sampleId) {
    var mt = String(matchType || '').trim().toLowerCase();
    var p = String(pattern || '');
    var s = String(sampleId || '');
    if (mt === 'regex') { try { return (new RegExp(p, 'i')).test(s); } catch (e) { return false; } }
    if (mt === 'suffix') return s.slice(-p.length) === p;
    if (mt === 'prefix') return s.indexOf(p) === 0;
    if (mt === 'contains') return s.indexOf(p) >= 0;
    // default: contains
    return s.indexOf(p) >= 0;
  }

  function buildRuleEngine(parsedRuleSheets) {
    var engine = { callRules: [], expectRules: [], sheetNames: [] };

    for (var i = 0; i < parsedRuleSheets.length; i++) {
      var sh = parsedRuleSheets[i];
      if (!sh || !sh.ok) continue;
      engine.sheetNames.push(sh.name || ('rulesheet_' + i));

      if (sh.type === 'call') {
        for (var r = 0; r < sh.rows.length; r++) {
          var row = sh.rows[r];
          engine.callRules.push({
            assay: row['Assay'],
            call: String(row['Call'] || '').trim().toUpperCase(),
            matchType: row['MatchType'] || 'contains',
            pattern: row['Pattern'] || '',
            priority: toInt(row['Priority'], 0),
            enabled: toBool(row['Enabled']),
            note: row['Note'] || ''
          });
        }
      } else if (sh.type === 'expect') {
        for (r = 0; r < sh.rows.length; r++) {
          row = sh.rows[r];
          engine.expectRules.push({
            assay: row['Assay'],
            expected: String(row['Expected'] || '').trim().toUpperCase(),
            matchType: row['SampleIdMatchType'] || 'suffix',
            pattern: row['SampleIdPattern'] || '',
            priority: toInt(row['Priority'], 0),
            enabled: toBool(row['Enabled']),
            note: row['Note'] || ''
          });
        }
      }
    }

    engine.callRules.sort(function (a, b) { return b.priority - a.priority; });
    engine.expectRules.sort(function (a, b) { return b.priority - a.priority; });

    return engine;
  }

  function defaultExpected(sampleId) {
    var s = String(sampleId || '');
    if (s.indexOf('NEG_') === 0) return 'NEG';
    if (s.indexOf('POS_') === 0) return 'POS';
    if (s.indexOf('_0_') >= 0) return 'NEG';
    var last = s.slice(-1);
    if (last === '+') return 'POS';
    if (last === 'X') return 'NEG';
    return '';
  }

  function defaultCallFromResult(testResult) {
    var t = String(testResult || '').toUpperCase();
    if (t.indexOf('INDETERMINATE') >= 0) return 'INDET';
    if (t.indexOf('INVALID') >= 0) return 'INDET';
    if (t.indexOf('ERROR') >= 0) return 'INDET';
    if (t.indexOf('NO RESULT') >= 0) return 'INDET';
    if (t.indexOf('NOT DETECTED') >= 0) return 'NEG';
    // Important: check DETECTED after NOT DETECTED
    if (t.indexOf('DETECTED') >= 0) return 'POS';
    return '';
  }

  function resolveExpected(engine, assay, sampleId) {
    for (var i = 0; i < engine.expectRules.length; i++) {
      var r = engine.expectRules[i];
      if (!r.enabled) continue;
      if (!matchAssay(r.assay, assay)) continue;
      if (!matchSampleId(r.matchType, r.pattern, sampleId)) continue;
      return { value: r.expected, note: r.note, via: 'rule', rule: r };
    }
    var d = defaultExpected(sampleId);
    return { value: d, note: 'default', via: 'default', rule: null };
  }

  function resolveCall(engine, assay, testResult) {
    for (var i = 0; i < engine.callRules.length; i++) {
      var r = engine.callRules[i];
      if (!r.enabled) continue;
      if (!matchAssay(r.assay, assay)) continue;
      if (!matchText(r.matchType, r.pattern, testResult)) continue;
      return { value: r.call, note: r.note, via: 'rule', rule: r };
    }
    var d = defaultCallFromResult(testResult);
    return { value: d, note: 'default', via: 'default', rule: null };
  }

  // ----------------------------
  // Analysis (CSV)
  // ----------------------------
  function summarizeCsv(parsed) {
    var rows = parsed.rows || [];
    if (!rows.length) return { assay: '', assayVer: '', lot: '', count: 0 };

    var assay = String(rows[0]['Assay'] || '');
    var assayVer = String(getField(rows[0], ['Assay Version', 'Assay version']) || '');
    var lot = String(getField(rows[0], ['Reagent Lot ID', 'Reagent lot ID', 'Reagent Lot']) || '');

    return { assay: assay, assayVer: assayVer, lot: lot, count: rows.length };
  }

  function computeDuplicates(rows, key) {
    var map = {};
    var dups = [];
    for (var i = 0; i < rows.length; i++) {
      var v = String(rows[i][key] || '').trim();
      if (!v) continue;
      map[v] = (map[v] || 0) + 1;
    }
    for (var k in map) if (map.hasOwnProperty(k) && map[k] > 1) dups.push({ value: k, count: map[k] });
    dups.sort(function (a, b) { return b.count - a.count; });
    return dups;
  }

  function buildFunctionalDeviations(rows, engine) {
    var out = [];
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      var assay = String(r['Assay'] || '');
      var sampleId = String(getField(r, ['Sample ID', 'Sample Id', 'SampleID']) || '');
      var cart = String(getField(r, ['Cartridge S/N', 'Cartridge SN', 'Cartridge S/N ']) || '');
      var testResult = String(getField(r, ['Test Result', 'Test result', 'Result']) || '');

      var exp = resolveExpected(engine, assay, sampleId);
      var call = resolveCall(engine, assay, testResult);

      var expected = exp.value;
      var actual = call.value;

      var cls = 'OK';
      var kind = 'ok';
      if (!expected || !actual) { cls = 'UNKNOWN'; kind = 'warn'; }
      else if (actual === 'INDET') { cls = 'INDETERMINATE'; kind = 'warn'; }
      else if (expected === 'NEG' && actual === 'POS') { cls = 'FALSE POSITIVE'; kind = 'bad'; }
      else if (expected === 'POS' && actual === 'NEG') { cls = 'FALSE NEGATIVE'; kind = 'bad'; }

      if (cls !== 'OK') {
        out.push({
          assay: assay,
          sampleId: sampleId,
          cart: cart,
          expected: expected || '(?)',
          call: actual || '(?)',
          classification: cls,
          kind: kind,
          evidence: (call.via === 'rule' ? ('rule: ' + (call.rule && call.rule.pattern ? call.rule.pattern : '')) : 'default'),
          testResult: testResult
        });
      }
    }
    return out;
  }

  function renderFunctionalTable(items) {
    var tbl = el('table');
    var thead = el('thead');
    var trh = el('tr');
    trh.appendChild(el('th', { text: 'Klass' }));
    trh.appendChild(el('th', { text: 'Sample ID' }));
    trh.appendChild(el('th', { text: 'Cartridge S/N' }));
    trh.appendChild(el('th', { text: 'Expected' }));
    trh.appendChild(el('th', { text: 'Call' }));
    trh.appendChild(el('th', { text: 'Evidence' }));
    trh.appendChild(el('th', { text: 'Test Result (utdrag)' }));
    thead.appendChild(trh);
    tbl.appendChild(thead);

    var tbody = el('tbody');
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      var tr = el('tr');
      if (it.kind === 'bad') tr.className = 'row-bad';
      else if (it.kind === 'warn') tr.className = 'row-warn';

      var p = pill(it.classification, it.kind);
      tr.appendChild(el('td', null, [p]));
      tr.appendChild(el('td', { 'class': 'mono', text: it.sampleId }));
      tr.appendChild(el('td', { 'class': 'mono', text: it.cart }));
      tr.appendChild(el('td', null, [pill(it.expected, it.expected === 'POS' ? 'ok' : (it.expected === 'NEG' ? 'ok' : 'warn'))]));
      tr.appendChild(el('td', null, [pill(it.call, it.call === 'INDET' ? 'warn' : (it.call ? 'ok' : 'warn'))]));
      tr.appendChild(el('td', { 'class': 'small muted', text: it.evidence }));
      tr.appendChild(el('td', { 'class': 'small', text: (it.testResult || '').slice(0, 120) }));
      tbody.appendChild(tr);
    }
    tbl.appendChild(tbody);
    return tbl;
  }

  function renderKeyValueTable(pairs) {
    var tbl = el('table');
    var tbody = el('tbody');
    for (var i = 0; i < pairs.length; i++) {
      var tr = el('tr');
      tr.appendChild(el('td', { 'class': 'muted', text: pairs[i][0] }));
      tr.appendChild(el('td', { 'class': 'mono', text: pairs[i][1] }));
      tbody.appendChild(tr);
    }
    tbl.appendChild(tbody);
    return tbl;
  }

  function runAnalysis() {
    $('runBtn').disabled = true;
    clearNode($('output'));
    setStatus('Analyserar...', false);

    var fCsv = pickByType('testSummary');
    if (!fCsv) {
      setStatus('Ingen Test Summary vald.', true);
      $('runBtn').disabled = false;
      return;
    }

    var ruleFiles = pickAllByType('ruleSheet');

    // Read CSV + rule sheets (if any)
    readFileAsText(fCsv).then(function (csvText) {
      var parsed = parseCsvToObjects(csvText);
      if (!parsed.ok) throw new Error(parsed.error || 'CSV parse error');

      var summary = summarizeCsv(parsed);

      var ruleReads = [];
      for (var i = 0; i < ruleFiles.length; i++) {
        (function (rf) {
          ruleReads.push(readFileAsText(rf).then(function (t) { return parseRuleSheet(t, rf.name || 'rulesheet.csv'); }));
        })(ruleFiles[i]);
      }

      return Promise.all(ruleReads).then(function (parsedSheets) {
        var engine = buildRuleEngine(parsedSheets || []);

        // Build output
        var out = $('output');
        clearNode(out);

        // Summary
        out.appendChild(el('div', { html: '<b>Test Summary CSV</b> ' + esc(fCsv.name || '') }));
        out.appendChild(renderKeyValueTable([
          ['Assay', summary.assay || '(?)'],
          ['Assay Version', summary.assayVer || '(?)'],
          ['Reagent Lot ID', summary.lot || '(?)'],
          ['Rows', String(summary.count)],
          ['Header row', String(parsed.headerIdx)]
        ]));

        // Rules info
        out.appendChild(el('div', { html: '<div style="margin-top:10px"><b>Rule sheets</b></div>' }));
        out.appendChild(el('div', { 'class': 'small muted', text:
          (ruleFiles.length ? ('Laddade: ' + ruleFiles.length + ' (' + engine.sheetNames.join(', ') + ')') : 'Inga rule sheets valda – kör med defaults.')
        }));
        out.appendChild(el('div', { 'class': 'small muted', text:
          ('Call rules: ' + engine.callRules.length + ' • Expectation rules: ' + engine.expectRules.length)
        }));

        // Functional deviations
        out.appendChild(el('div', { html: '<div style="margin-top:12px"><b>Functional deviations (FP / FN / INDET)</b></div>' }));
        var deviations = buildFunctionalDeviations(parsed.rows, engine);

        // Summary pills
        var cFP = 0, cFN = 0, cIN = 0, cUN = 0;
        for (var di = 0; di < deviations.length; di++) {
          var cc = deviations[di].classification;
          if (cc === 'FALSE POSITIVE') cFP++;
          else if (cc === 'FALSE NEGATIVE') cFN++;
          else if (cc === 'INDETERMINATE') cIN++;
          else if (cc === 'UNKNOWN') cUN++;
        }
        if (deviations.length) {
          var sumLine = el('div', { 'class': 'small', style: 'margin:6px 0 8px 0' });
          sumLine.appendChild(pill('FP ' + cFP, cFP ? 'bad' : 'ok'));
          sumLine.appendChild(el('span', { text: ' ' }));
          sumLine.appendChild(pill('FN ' + cFN, cFN ? 'bad' : 'ok'));
          sumLine.appendChild(el('span', { text: ' ' }));
          sumLine.appendChild(pill('INDET ' + cIN, cIN ? 'warn' : 'ok'));
          if (cUN) { sumLine.appendChild(el('span', { text: ' ' })); sumLine.appendChild(pill('UNKNOWN ' + cUN, 'warn')); }
          out.appendChild(sumLine);
        }

        if (!deviations.length) {
          out.appendChild(el('div', null, [pill('Inga avvikelser hittades', 'ok')]));
        } else {
          out.appendChild(el('div', { 'class': 'small muted', text: 'Hittade ' + deviations.length + ' avvikelse(r).' }));
          out.appendChild(renderFunctionalTable(deviations));
        }

        // Duplicates
        out.appendChild(el('div', { html: '<div style="margin-top:12px"><b>Dubletter</b></div>' }));
        var dupSample = computeDuplicates(parsed.rows, 'Sample ID');
        var dupCart = computeDuplicates(parsed.rows, 'Cartridge S/N');

        if (!dupSample.length) out.appendChild(el('div', null, [pill('Sample ID: inga dubletter', 'ok')]));
        else {
          out.appendChild(el('div', null, [pill('Sample ID: ' + dupSample.length + ' dublett-nyckel(ar)', 'warn')]));
          out.appendChild(renderKeyValueTable(dupSample.slice(0, 20).map(function (d) { return [d.value, String(d.count)]; })));
        }

        if (!dupCart.length) out.appendChild(el('div', null, [pill('Cartridge S/N: inga dubletter', 'ok')]));
        else {
          out.appendChild(el('div', null, [pill('Cartridge S/N: ' + dupCart.length + ' dublett-nyckel(ar)', 'warn')]));
          out.appendChild(renderKeyValueTable(dupCart.slice(0, 20).map(function (d) { return [d.value, String(d.count)]; })));
        }

        setStatus('OK – Analys klar.', false);
        $('runBtn').disabled = false;
      });
    }).catch(function (e) {
      var msg = (e && e.message) ? e.message : String(e);
      setStatus('Fel: ' + msg, true);
      var out = $('output');
      clearNode(out);
      out.appendChild(el('div', null, [pill('Error', 'bad'), el('span', { text: ' ' + msg })]));
      $('runBtn').disabled = false;
    });
  }

  // ----------------------------
  // Add files (input + drop)
  // ----------------------------
  function addFiles(fileList) {
    if (!fileList || !fileList.length) return Promise.resolve();

    var incoming = [];
    var zipPromises = [];

    for (var i = 0; i < fileList.length; i++) {
      var f = fileList[i];
      if (!f) continue;

      if (isZipFile(f)) {
        setStatus('Läser ZIP: ' + (f.name || 'bundle.zip') + ' ...', false);
        zipPromises.push(extractFilesFromZip(f).then(function (extracted) {
          if (extracted && extracted.length) {
            for (var j = 0; j < extracted.length; j++) incoming.push(extracted[j]);
          }
        }).catch(function (e) {
          setStatus('Kunde inte läsa ZIP (' + (f && f.name ? f.name : '') + '): ' + (e && e.message ? e.message : String(e)), true);
        }));
      } else {
        incoming.push(f);
      }
    }

    return Promise.all(zipPromises).then(function () {
      for (var k = 0; k < incoming.length; k++) {
        var ff = incoming[k];
        var detected = detectTypeByName(ff.name || '');
        files.push({ file: ff, typeKey: 'auto', detectedKey: detected });
      }
      refreshFileList();
      setStatus('', false);
    });
  }

  // ----------------------------
  // Init
  // ----------------------------
  function init() {
    var inp = $('fileInput');
    var dz = $('dropZone');

    inp.addEventListener('change', function () {
      addFiles(inp.files).then(function () { /* done */ });
      inp.value = '';
    });

    $('clearBtn').addEventListener('click', function () {
      files = [];
      refreshFileList();
      clearNode($('output'));
      setStatus('Rensat.', false);
    });

    $('runBtn').addEventListener('click', function () {
      runAnalysis();
    });

    function prevent(e) { e.preventDefault(); e.stopPropagation(); }

    dz.addEventListener('dragenter', prevent);
    dz.addEventListener('dragover', prevent);
    dz.addEventListener('drop', function (e) {
      prevent(e);
      var dt = e.dataTransfer;
      if (dt && dt.files) addFiles(dt.files).then(function () { /* done */ });
    });

    refreshFileList();
    setStatus('Välj Test Summary CSV + ev. rule sheets.', false);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

})();