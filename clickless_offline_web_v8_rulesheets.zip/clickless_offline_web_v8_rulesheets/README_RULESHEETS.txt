ClickLess Offline Web v8 (CSV + Rule Sheets) – Templates

Du kan lägga in 1 Test Summary (CSV) + 0..N rule sheets (CSV).
Sidan läser rule sheets och använder dem för att klassificera "Functional deviations":
- False Positive (FP): Expected NEG men Call POS
- False Negative (FN): Expected POS men Call NEG
- Indeterminate: Call INDET eller okänd Call/Expected

📄 Rule sheet 1: 01_ResultCallPatterns.csv
Kolumner:
- Assay: exakt assay-namn (från Test Summary), eller * för "alla".
- Call: POS / NEG / INDET
- MatchType: contains | regex
- Pattern: substring eller regex (om MatchType=regex)
- Priority: högre vinner (t.ex. 900 före 50)
- Enabled: TRUE/FALSE (tom = TRUE)
- Note: valfritt

📄 Rule sheet 2: 02_SampleExpectationRules.csv
Kolumner:
- Assay: exakt assay-namn, eller *
- Expected: POS / NEG
- SampleIdMatchType: suffix | prefix | contains | regex
- SampleIdPattern: t.ex. '+' eller 'NEG_' eller regex
- Priority: högre vinner
- Enabled: TRUE/FALSE
- Note: valfritt

Tips:
- Börja med *-rader som basregler.
- Lägg sedan assay-specifika rader med högre Priority för specialfall.
- Om både assay-specifik och * matchar, vinner högst Priority.

✅ Snabb test:
- Lägg Test Summary CSV + templates i samma filval
- Kör analys → se att FP/FN/INDET dyker upp om något avviker
