#region Imports & Config
if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
    $exe = Join-Path $PSHome 'powershell.exe'
    $scriptPath = if ($PSCommandPath) { $PSCommandPath } else { $MyInvocation.MyCommand.Path }
    Start-Process -FilePath $exe -ArgumentList "-NoProfile -STA -ExecutionPolicy Bypass -File `"$scriptPath`""
    exit
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.ComponentModel
try {
    Add-Type -AssemblyName 'Microsoft.VisualBasic' -ErrorAction SilentlyContinue
} catch {}

$ScriptRootPath = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $PSScriptRoot) { $PSScriptRoot = $ScriptRootPath }
$modulesRoot = Join-Path $ScriptRootPath 'Modules'

. (Join-Path $modulesRoot 'Bootstrap/Loader.ps1')

# Ladda EPPlus tidigt så att typer + Excel-hjälpfunktioner alltid finns innan övriga moduler läses in.
try {
    Initialize-EPPlus -HintPath $Config.EpplusDllPath | Out-Null
} catch {
    Gui-Log ("⚠️ EPPlus kunde inte laddas vid start: {0}" -f $_.Exception.Message) 'Warn'
}

$global:StartupReady = $true
$configStatus = $null

try {

    $configStatus = Test-Config
    if ($configStatus) {
        foreach ($err in $configStatus.Errors) { Gui-Log "❌ Konfig-fel: $err" 'Error' }
        foreach ($warn in $configStatus.Warnings) { Gui-Log "⚠️ Konfig-varning: $warn" 'Warn' }
        if (-not $configStatus.Ok) {
            $global:StartupReady = $false
            try { [System.Windows.Forms.MessageBox]::Show("Startkontroll misslyckades. Se logg för detaljer.","Startkontroll") | Out-Null } catch {}
        }
    }
} catch { Gui-Log "❌ Test-Config misslyckades: $($_.Exception.Message)" 'Error'; $global:StartupReady = $false }

$Host.UI.RawUI.WindowTitle = "Startar…"
Show-Splash "Laddar PnP.PowerShell…"
$global:SpConnected = $false
$global:SpError     = $null

try {
    $null = Get-PackageProvider -Name "NuGet" -ForceBootstrap -ErrorAction SilentlyContinue
} catch {}

try { Initialize-EPPlus -HintPath $Config.EpplusDllPath | Out-Null } catch { Gui-Log "⚠️ EPPlus-förkontroll misslyckades: $($_.Exception.Message)" 'Warn' }

try {
    $null = Initialize-SharePointService -SiteUrl $global:SP_SiteUrl `
                                         -Tenant $global:SP_Tenant `
                                         -ClientId $global:SP_ClientId `
                                         -CertificateBase64 $global:SP_CertBase64 `
                                         -UseSplash
} catch {
    $global:SpError = "SharePoint-init misslyckades: $($_.Exception.Message)"
}

#endregion Imports & Config

Start-ClickLessApp
