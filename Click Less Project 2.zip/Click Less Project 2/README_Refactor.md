Refactor Overview

Core
- Core helpers and parsing live under `Modules/Core/`.
- Rule engine logic is in `Modules/Core/RuleEngine.Core.ps1`, with supporting helpers in `Modules/Core/RuleEngine.Helpers.ps1`.

GUI
- WinForms build + event wiring is in `Modules/GUI/Forms.ps1`.
- UI styling is in `Modules/GUI/UiStyling.ps1`.
- Splash screen helpers are in `Modules/GUI/Splash.ps1`.

IO
- File dialogs are in `Modules/IO/FilePicker.ps1`.
- Output path helpers and file-lock checks are in `Modules/IO/PathHelpers.ps1`.

Writers
- Information2 writer lives in `Modules/Writers/Information2Writer.ps1`.
- Excel styling helpers and AutoFit gating are in `Modules/Writers/ExcelStyling.ps1`.
- SharePoint sheet writer lives in `Modules/Writers/SharePointInfoWriter.ps1`.

Rules
- Rule data, display maps, and alias maps are in `Modules/Rules/RuleBank.ps1`.

Services
- Logging and GUI log hooks are in `Modules/Services/Logging.ps1`.
- EPPlus loader is in `Modules/Services/EpplusLoader.ps1`.
- SharePoint connection and query helpers are in `Modules/Services/SharePointService.ps1`.

Loader Order
- `Modules/Bootstrap/Loader.ps1` dot-sources modules in this order:
  MapHelpers -> Severity -> Normalize -> CsvParsing -> Types -> Logging -> Services -> RuleBank -> RuleEngine.Core -> Writers -> IO -> GUI.
- `Main.ps1` only dot-sources the loader and then calls `Start-ClickLessApp`.

Performance Toggles (Config)
- Located under `Config.Performance` in `Modules/Config.ps1`.
- Defaults:
  - FastMode = true
  - AutoFitColumns = false
  - AutoFitMaxRows = 300
  - EnableConditionalFormatting = true
- Writers respect these toggles; AutoFit and conditional formatting are gated by the config.

Compatibility Checklist
- GUI opens.
- Search LSP works.
- File selection works.
- Report builds.
- Report saves to TEMP.
- Report opens automatically.
- SharePoint failure does not stop report generation.
- No BOM/encoding issues (UTF-8 without BOM for .ps1).
