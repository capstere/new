. (Join-Path $PSScriptRoot 'GUI/Splash.ps1')
