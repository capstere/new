. (Join-Path $PSScriptRoot 'Rules/RuleBank.ps1')
