function Test-FileLocked {
    param([Parameter(Mandatory=$true)][string]$Path)
    try { $fs = [IO.File]::Open($Path,'Open','ReadWrite','None'); $fs.Close(); return $false } catch { return $true }
}

function New-ReportOutputPath {
    param(
        [Parameter(Mandatory=$true)][string]$Lsp,
        [Parameter(Mandatory=$true)][string]$SaveDir
    )
    $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $baseName = "${env:USERNAME}_output_${Lsp}_$stamp.xlsx"
    return [pscustomobject]@{
        Timestamp = $stamp
        FileName  = $baseName
        Directory = $SaveDir
        Path      = (Join-Path $SaveDir $baseName)
    }
}
