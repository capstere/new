function Select-OpenFile {
    param(
        [string]$Title = 'Välj fil',
        [string]$Filter = 'Alla filer|*.*'
    )
    try {
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Filter = $Filter
        $dlg.Title  = $Title
        if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            return (Get-Item -LiteralPath $dlg.FileName)
        }
    } catch {
        Gui-Log ("⚠️ Filval misslyckades: " + $_.Exception.Message) 'Warn'
    }
    return $null
}

function Select-ExcelFile {
    param([string]$Title = 'Välj Excel-fil')
    return (Select-OpenFile -Title $Title -Filter 'Excel|*.xlsx;*.xlsm|Alla filer|*.*')
}

function Select-CsvFile {
    param([string]$Title = 'Välj CSV-fil')
    return (Select-OpenFile -Title $Title -Filter 'CSV|*.csv|Alla filer|*.*')
}
