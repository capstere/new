function Initialize-SharePointService {
    param(
        [string]$SiteUrl,
        [string]$Tenant,
        [string]$ClientId,
        [string]$CertificateBase64,
        [switch]$UseSplash
    )

    $global:SpConnected = $false
    $global:SpError = $null

    try {
        if ($UseSplash -and (Get-Command Update-Splash -ErrorAction SilentlyContinue)) {
            Update-Splash "Laddar..."
        }

        Import-Module PnP.PowerShell -ErrorAction Stop
    } catch {
        try {
            Gui-Log "ℹ️ PowerShell-modulen saknas, installerar modulen..." 'Info'
            Install-Module PnP.PowerShell -MaximumVersion 1.12.0 -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
            if ($UseSplash -and (Get-Command Update-Splash -ErrorAction SilentlyContinue)) {
                Update-Splash "Laddar..."
            }
            Import-Module PnP.PowerShell -ErrorAction Stop
        } catch {
            $global:SpError = "PnP-install/import misslyckades: $($_.Exception.Message)"
            return $false
        }
    }

    $env:PNPPOWERSHELL_UPDATECHECK = "Off"

    try {
        if ($UseSplash -and (Get-Command Update-Splash -ErrorAction SilentlyContinue)) {
            Update-Splash "Ansluter till SharePoint"
        }
        Connect-PnPOnline -Url $SiteUrl `
                          -Tenant $Tenant `
                          -ClientId $ClientId `
                          -CertificateBase64Encoded $CertificateBase64 `
                          -ErrorAction Stop
        $global:SpConnected = $true
        return $true
    } catch {
        $msg = "Connect-PnPOnline misslyckades: $($_.Exception.Message)"
        if ($UseSplash -and (Get-Command Update-Splash -ErrorAction SilentlyContinue)) {
            Update-Splash $msg
        }
        $global:SpError = $msg
        return $false
    }
}

function Test-SharePointAvailable {
    if ($global:SpConnected) { return $true }
    if (Get-Command Get-PnPConnection -ErrorAction SilentlyContinue) {
        try { $null = Get-PnPConnection; return $true } catch { return $false }
    }
    return $false
}

function Get-SharePointBatchRows {
    param(
        [Parameter(Mandatory=$true)][string]$Batch,
        [string[]]$Fields
    )

    if (-not (Test-SharePointAvailable)) { return @() }

    try {
        $items = Get-PnPListItem -List "Cepheid | Production orders" -Fields $Fields -PageSize 2000 -ErrorAction Stop
        $match = $items | Where-Object {
            $v1 = $_['Batch_x0023_']; $v2 = $_['SAP_x0020_Batch_x0023__x0020_2']
            $s1 = if ($null -ne $v1) { ([string]$v1).Trim() } else { '' }
            $s2 = if ($null -ne $v2) { ([string]$v2).Trim() } else { '' }
            $s1 -eq $Batch -or $s2 -eq $Batch
        } | Select-Object -First 1

        if ($match) { return @($match) }
    } catch {
        Gui-Log "⚠️ SP: Get-PnPListItem misslyckades: $($_.Exception.Message)" 'Warn'
    }
    return @()
}

function Get-SharePointInfoRows {
    param([Parameter(Mandatory=$true)][string]$Batch)

    $result = [pscustomobject]@{ Rows = @(); MatchFound = $false }
    if (-not $Batch) { return $result }

    $fields = @(
        'Work_x0020_Center','Title','Batch_x0023_','SAP_x0020_Batch_x0023__x0020_2',
        'LSP','Material','BBD_x002f_SLED','Actual_x0020_startdate_x002f__x0',
        'PAL_x0020__x002d__x0020_Sample_x','Sample_x0020_Reagent_x0020_P_x00',
        'Order_x0020_quantity','Total_x0020_good','ITP_x0020_Test_x0020_results',
        'IPT_x0020__x002d__x0020_Testing_0','MES_x0020__x002d__x0020_Order_x0'
    )

    $renameMap = @{
        'Work Center'            = 'Work Center'
        'Title'                  = 'Order#'
        'Batch#'                 = 'SAP Batch#'
        'SAP Batch# 2'           = 'SAP Batch# 2'
        'LSP'                    = 'LSP'
        'Material'               = 'Material'
        'BBD/SLED'               = 'BBD/SLED'
        'Actual startdate/_x0'   = 'ROBAL - Actual start date/time'
        'PAL - Sample_x'         = 'Sample Reagent use'
        'Sample Reagent P'       = 'Sample Reagent P/N'
        'Order quantity'         = 'Order quantity'
        'Total good'             = 'ROBAL - Till Packning'
        'IPT Test results'       = 'IPT Test results'
        'IPT - Testing_0'        = 'IPT - Testing Finalized'
        'MES - Order_x0'         = 'MES Order'
    }

    $desiredOrder = @(
        'Work Center','Order#','SAP Batch#','SAP Batch# 2','LSP','Material','BBD/SLED',
        'ROBAL - Actual start date/time','Sample Reagent use','Sample Reagent P/N',
        'Order quantity','ROBAL - Till Packning','IPT Test results',
        'IPT - Testing Finalized','MES Order'
    )

    $dateFields      = @('BBD/SLED','ROBAL - Actual start date/time','IPT - Testing Finalized')
    $shortDateFields = @('BBD/SLED')

    $rows = @()
    $items = Get-SharePointBatchRows -Batch $Batch -Fields $fields
    if ($items.Count -gt 0) {
        $match = $items[0]
        foreach ($f in $fields) {
            $val = $match[$f]
            $label = $f -replace '_x0020_', ' ' `
                         -replace '_x002d_', '-' `
                         -replace '_x0023_', '#' `
                         -replace '_x002f_', '/' `
                         -replace '_x2013_', '–' `
                         -replace '_x00',''
            $label = $label.Trim()
            if ($renameMap.ContainsKey($label)) { $label = $renameMap[$label] }
            if ($null -ne $val -and $val -ne '') {
                if ($val -eq $true) { $val = 'JA' }
                elseif ($val -eq $false) { $val = 'NEJ' }

                $dt = $null
                if ($val -is [datetime]) { $dt = [datetime]$val }
                else { try { $dt = [datetime]::Parse($val) } catch { $dt = $null } }
                if ($dt -ne $null -and ($dateFields -contains $label)) {
                    $fmt = if ($shortDateFields -contains $label) { 'yyyy-MM-dd' } else { 'yyyy-MM-dd HH:mm' }
                    $val = $dt.ToString($fmt)
                }
                $rows += [pscustomobject]@{ Rubrik = $label; 'Värde' = $val }
            }
        }

        if ($rows.Count -gt 0) {
            $ordered = @()
            foreach ($label in $desiredOrder) {
                $hit = $rows | Where-Object { $_.Rubrik -eq $label } | Select-Object -First 1
                if ($hit) { $ordered += $hit }
            }
            if ($ordered.Count -gt 0) { $rows = $ordered }
        }
        $result.Rows = $rows
        $result.MatchFound = $true
    }

    return $result
}
