function Write-Information2Sheet {
    param(
        [object]$Worksheet,
        [pscustomobject]$Context,
        [pscustomobject]$Evaluation,
        [string]$CsvPath,
        [string]$ScriptVersion
    )

    if (-not $Worksheet) { return }

    try {
        if (-not $Evaluation) {
            $Evaluation = [pscustomobject]@{
                OverallStatus          = 'FAIL'
                OverallSeverity        = 'Error'
                Findings               = @()
                AffectedTests          = @()
                AffectedTestsTruncated = 0
                ErrorSummary           = @()
                PressureStats          = [ordered]@{ Max=$null; OverWarn=0; OverFail=0; WarnThreshold=$null; FailThreshold=$null }
                DuplicatesTable        = @()
                Debug                  = @()
                UniqueErrorCodes       = 0
                IdentityFlags          = [ordered]@{}
                SeverityCounts         = @{ Error=0; Warn=0; Info=0 }
                BaselineExpected       = 0
                BaselineDelta          = 0
                ErrorRowCount          = 0
            }
        }
        if (-not $Context) {
            $Context = [pscustomobject]@{
                TotalTests           = 0
                StatusCounts         = @{}
                AssayRaw             = ''
                AssayCanonical       = ''
                AssayDisplayName     = ''
                AssayVersion         = ''
                ReagentLotIds        = @()
                ReagentLotDisplay    = ''
                WorkCenters          = @()
                WorkCentersDisplay   = ''
                MaxPressureMax       = $null
                UniqueSampleIds      = 0
                UniqueCartridgeSN    = 0
                DuplicateCounts      = [ordered]@{ SampleId=0; CartridgeSN=0 }
                AssayCanonicalSource = ''
                ParseErrors          = @()
            }
        }

        try { $Worksheet.Cells.Clear() } catch {}
        try { $Worksheet.ConditionalFormatting.Clear() } catch {}
        try { $Worksheet.DataValidations.Clear() } catch {}
        try { $Worksheet.Tables.Clear() } catch {}

        $perf = $null
        $fastMode = $true
        $autoFit = $false
        $autoFitMax = 300
        $enableCF = $true
        try {
            if ($Config -and $Config.Performance) { $perf = $Config.Performance }
        } catch {}
        if ($perf) {
            if ($perf.FastMode -ne $null) { $fastMode = [bool]$perf.FastMode }
            if ($perf.AutoFitColumns -ne $null) { $autoFit = [bool]$perf.AutoFitColumns }
            if ($perf.AutoFitMaxRows -ne $null) { $autoFitMax = [int]$perf.AutoFitMaxRows }
            if ($perf.EnableConditionalFormatting -ne $null) { $enableCF = [bool]$perf.EnableConditionalFormatting }
        }
        if (-not $autoFitMax -or $autoFitMax -lt 1) { $autoFitMax = 300 }

        function Get-DisplayLabel {
            param([string]$Key, [string]$Fallback)
            try {
                if ($global:RuleBank -and $global:RuleBank.ColumnDisplayNames) {
                    if (Test-MapHasKey $global:RuleBank.ColumnDisplayNames $Key) {
                        $val = Get-MapValue $global:RuleBank.ColumnDisplayNames $Key $null
                        if ($val) { return $val }
                    }
                }
            } catch {}
            return $Fallback
        }

        $cells = $Worksheet.Cells
        $ps = if ($Evaluation.PressureStats) { $Evaluation.PressureStats } else { [ordered]@{ Max=$null; OverWarn=0; OverFail=0; WarnThreshold=$null; FailThreshold=$null } }
        $sevCounts = if ($Evaluation.SeverityCounts) { $Evaluation.SeverityCounts } else { @{ Error=0; Warn=0; Info=0 } }

        $statusCounts = @{ Done=0; Error=0; Invalid=0; Aborted=0; Incomplete=0; Other=0 }
        foreach ($k in @($statusCounts.Keys)) {
            try { if ($Context.StatusCounts -and (Test-MapHasKey $Context.StatusCounts $k)) { $statusCounts[$k] = [int]$Context.StatusCounts[$k] } } catch {}
        }

        $assayDisplay = if ($Context.AssayDisplayName) { $Context.AssayDisplayName } elseif ($Context.AssayCanonical) { $Context.AssayCanonical } else { $Context.AssayRaw }
        $reagentDisplay = if ($Context.ReagentLotDisplay) { $Context.ReagentLotDisplay } else { ($Context.ReagentLotIds -join ', ') }
        if (-not $reagentDisplay) { $reagentDisplay = '—' }
        $workCenterDisplay = if ($Context.WorkCentersDisplay) { $Context.WorkCentersDisplay } else { ($Context.WorkCenters -join ', ') }
        if (-not $workCenterDisplay) { $workCenterDisplay = '—' }

        $r = 1
        $cells["A$r"].Value = "Information2 – QC Summary"
        $cells["A$r:M$r"].Merge = $true
        $cells["A$r"].Style.Font.Bold = $true
        $cells["A$r"].Style.Font.Size = 16
        $r++

        $cells["A$r"].Value = "CSV"
        $cells["A$r"].Style.Font.Bold = $true
        $cells["B$r"].Value = $(if ($CsvPath) { Split-Path $CsvPath -Leaf } else { '—' })
        $cells["D$r"].Value = "Generated"
        $cells["D$r"].Style.Font.Bold = $true
        $cells["E$r"].Value = (Get-Date).ToString('yyyy-MM-dd HH:mm')
        if ($ScriptVersion) {
            $cells["G$r"].Value = "Version"
            $cells["G$r"].Style.Font.Bold = $true
            $cells["H$r"].Value = $ScriptVersion
        }
        $r += 2

        $cells["A$r"].Value = "At-a-glance"
        $cells["A$r:B$r"].Merge = $true
        $cells["A$r"].Style.Font.Bold = $true
        $cells["A$r"].Style.Font.Size = 12
        $r++

        $glanceStart = $r
        $cells["A$r"].Value = Get-DisplayLabel 'OverallStatus' 'Overall Status'
        $cells["B$r"].Value = $Evaluation.OverallStatus
        $cells["B$r"].Style.Font.Bold = $true
        $statusColor = switch ($Evaluation.OverallStatus) {
            'FAIL' { '#ffc7ce' }
            'WARN' { '#ffe699' }
            default { '#c6efce' }
        }
        $cells["B$r"].Style.Fill.PatternType = 'Solid'
        $cells["B$r"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml($statusColor))
        $r++

        $cells["A$r"].Value = Get-DisplayLabel 'OverallSeverity' 'Worst Severity'
        $cells["B$r"].Value = $Evaluation.OverallSeverity
        $r++

        $cells["A$r"].Value = Get-DisplayLabel 'AffectedRows' 'Affected Rows'
        $cells["B$r"].Value = [int]$Evaluation.ErrorRowCount
        $r++

        $cells["A$r"].Value = Get-DisplayLabel 'DistinctErrorCodes' 'Distinct Error Codes'
        $cells["B$r"].Value = [int]$Evaluation.UniqueErrorCodes
        $r++

        $cells["A$r"].Value = Get-DisplayLabel 'AssayDisplayName' 'Assay'
        $cells["B$r"].Value = $assayDisplay
        $r++

        $cells["A$r"].Value = Get-DisplayLabel 'AssayVersion' 'Assay Version'
        $cells["B$r"].Value = $Context.AssayVersion
        $r++

        $cells["A$r"].Value = Get-DisplayLabel 'ReagentLotDisplay' 'Reagent Lots'
        $cells["B$r"].Value = $reagentDisplay
        $r++

        $cells["A$r"].Value = Get-DisplayLabel 'WorkCentersDisplay' 'Work Centers'
        $cells["B$r"].Value = $workCenterDisplay
        $r++

        $cells["A$r"].Value = Get-DisplayLabel 'MatchSource' 'Match Source'
        $cells["B$r"].Value = $Context.AssayCanonicalSource
        $r++

        $glanceEnd = $r - 1
        $cells["A$glanceStart:A$glanceEnd"].Style.Font.Bold = $true
        $cells["A$glanceStart:A$glanceEnd"].Style.Fill.PatternType = 'Solid'
        $cells["A$glanceStart:A$glanceEnd"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#f2f2f2'))
        if (-not $fastMode) { $cells["B$glanceStart:B$glanceEnd"].Style.WrapText = $true }

        $r++
        $cells["A$r"].Value = "Summary Metrics"
        $cells["A$r:B$r"].Merge = $true
        $cells["A$r"].Style.Font.Bold = $true
        $cells["A$r"].Style.Font.Size = 12
        $r++

        $summaryStart = $r
        $cells["A$r"].Value = Get-DisplayLabel 'TotalTests' 'Row Count'
        $cells["B$r"].Value = [int]$Context.TotalTests
        $r++
        $cells["A$r"].Value = Get-DisplayLabel 'UniqueSampleIds' 'Unique Sample ID'
        $cells["B$r"].Value = [int]$Context.UniqueSampleIds
        $r++
        $cells["A$r"].Value = Get-DisplayLabel 'UniqueCartridgeSN' 'Unique Cartridge S/N'
        $cells["B$r"].Value = [int]$Context.UniqueCartridgeSN
        $r++
        $cells["A$r"].Value = Get-DisplayLabel 'FindingsCounts' 'Findings: ERROR / WARN / INFO'
        $cells["B$r"].Value = ("{0} / {1} / {2}" -f $sevCounts.Error, $sevCounts.Warn, $sevCounts.Info)
        $r++
        $cells["A$r"].Value = Get-DisplayLabel 'Baseline' 'Baseline (expected/actual/delta)'
        $cells["B$r"].Value = ("{0} / {1} / {2}" -f $Evaluation.BaselineExpected, $Context.TotalTests, $Evaluation.BaselineDelta)
        $r++
        $cells["A$r"].Value = Get-DisplayLabel 'MaxPressure' 'Max Pressure (max)'
        $cells["B$r"].Value = if ($ps.Max -ne $null) { [Math]::Round([double]$ps.Max,2) } else { '—' }
        $r++
        $cells["A$r"].Value = Get-DisplayLabel 'MaxPressureThresholds' 'Max Pressure >= Warn / Fail'
        $cells["B$r"].Value = ("{0} / {1}" -f [int]$ps.OverWarn, [int]$ps.OverFail)
        $r++
        $cells["A$r"].Value = Get-DisplayLabel 'StatusCounts' 'Status counts (Done/Error/Invalid/Aborted/Incomplete)'
        $cells["B$r"].Value = ("{0}/{1}/{2}/{3}/{4}" -f $statusCounts.Done, $statusCounts.Error, $statusCounts.Invalid, $statusCounts.Aborted, $statusCounts.Incomplete)
        $r++
        $summaryEnd = $r - 1
        $cells["A$summaryStart:A$summaryEnd"].Style.Font.Bold = $true
        $cells["A$summaryStart:A$summaryEnd"].Style.Fill.PatternType = 'Solid'
        $cells["A$summaryStart:A$summaryEnd"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#f2f2f2'))
        if (-not $fastMode) { $cells["B$summaryStart:B$summaryEnd"].Style.WrapText = $true }

        $r += 1
        $cells["A$r"].Value = "Findings"
        $cells["A$r"].Style.Font.Bold = $true
        $cells["A$r"].Style.Font.Size = 12
        $r++

        $cells["A$r"].Value = Get-DisplayLabel 'Findings.Severity' 'Severity'
        $cells["B$r"].Value = Get-DisplayLabel 'Findings.RuleId' 'Rule Id'
        $cells["C$r"].Value = Get-DisplayLabel 'Findings.Title' 'Title'
        $cells["D$r"].Value = Get-DisplayLabel 'Findings.Message' 'Message'
        $cells["E$r"].Value = Get-DisplayLabel 'Findings.Count' 'Count'
        $cells["F$r"].Value = Get-DisplayLabel 'Findings.Example' 'Example'
        $cells["G$r"].Value = Get-DisplayLabel 'Findings.Evidence' 'Evidence'
        $cells["A$r:G$r"].Style.Font.Bold = $true
        $cells["A$r:G$r"].Style.WrapText = $true
        $r++

        $findStart = $r
        $findAll = @($Evaluation.Findings)
        $findRows = @($findAll | Select-Object -First 50)
        foreach ($f in $findRows) {
            $cells["A$r"].Value = $f.Severity
            $cells["B$r"].Value = $f.RuleId
            $cells["C$r"].Value = $f.Title
            $cells["D$r"].Value = $f.Message
            $cells["E$r"].Value = [int]$f.Count
            $cells["F$r"].Value = $f.Example
            $cells["G$r"].Value = $f.Evidence
            $r++
        }
        $findEnd = $r - 1
        if ($findEnd -ge $findStart) {
            if (-not $fastMode) {
                $cells["C$findStart:G$findEnd"].Style.WrapText = $true
            }
            if ($enableCF) {
                $addr = "A$findStart:A$findEnd"
                $cfErr = $Worksheet.ConditionalFormatting.AddExpression($addr)
                $cfErr.Formula = 'ISNUMBER(SEARCH("Error",A1))'
                $cfErr.Style.Fill.PatternType = 'Solid'
                $cfErr.Style.Fill.BackgroundColor.Color = [System.Drawing.ColorTranslator]::FromHtml('#ffc7ce')

                $cfWarn = $Worksheet.ConditionalFormatting.AddExpression($addr)
                $cfWarn.Formula = 'ISNUMBER(SEARCH("Warn",A1))'
                $cfWarn.Style.Fill.PatternType = 'Solid'
                $cfWarn.Style.Fill.BackgroundColor.Color = [System.Drawing.ColorTranslator]::FromHtml('#ffe699')
            }
        }
        if ($findAll.Count -gt $findRows.Count) {
            $cells["A$r"].Value = ("Findings truncated: {0} row(s) not shown" -f ($findAll.Count - $findRows.Count))
            $cells["A$r:G$r"].Merge = $true
            $cells["A$r"].Style.Font.Italic = $true
            $r++
        }
        $r += 1

        $cells["A$r"].Value = "Error Codes Summary"
        $cells["A$r"].Style.Font.Bold = $true
        $cells["A$r"].Style.Font.Size = 12
        $r++

        $cells["A$r"].Value = Get-DisplayLabel 'ErrorSummary.Code' 'Code'
        $cells["B$r"].Value = Get-DisplayLabel 'ErrorSummary.Name' 'Name'
        $cells["C$r"].Value = Get-DisplayLabel 'ErrorSummary.Classification' 'Classification'
        $cells["D$r"].Value = Get-DisplayLabel 'ErrorSummary.Count' 'Count'
        $cells["E$r"].Value = Get-DisplayLabel 'ErrorSummary.Example' 'Example Sample ID'
        $cells["A$r:E$r"].Style.Font.Bold = $true
        $cells["A$r:E$r"].Style.WrapText = $true
        $r++

        $errStart = $r
        $errAll = @($Evaluation.ErrorSummary)
        $errRows = @($errAll | Select-Object -First 60)
        foreach ($err in $errRows) {
            $cells["A$r"].Value = $err.ErrorCode
            $cells["B$r"].Value = $err.Name
            $cells["C$r"].Value = if ($err.Classification) { $err.Classification } else { $err.Group }
            $cells["D$r"].Value = [int]$err.Count
            $cells["E$r"].Value = $err.ExampleSampleID
            $r++
        }
        $errEnd = $r - 1
        if ($errEnd -ge $errStart) {
            if (-not $fastMode) {
                $cells["A$errStart:E$errEnd"].Style.WrapText = $true
            }
        }
        if ($errAll.Count -gt $errRows.Count) {
            $cells["A$r"].Value = ("Error codes truncated: {0} row(s) not shown" -f ($errAll.Count - $errRows.Count))
            $cells["A$r:E$r"].Merge = $true
            $cells["A$r"].Style.Font.Italic = $true
            $r++
        }
        $r += 1

        $cells["A$r"].Value = "Affected Tests (Warn/Error)"
        $cells["A$r"].Style.Font.Bold = $true
        $cells["A$r"].Style.Font.Size = 12
        $r++

        $cells["A$r"].Value = Get-DisplayLabel 'AffectedTests.Severity' 'Severity'
        $cells["B$r"].Value = Get-DisplayLabel 'AffectedTests.RuleId' 'Rule Id'
        $cells["C$r"].Value = Get-DisplayLabel 'AffectedTests.SampleId' 'Sample ID'
        $cells["D$r"].Value = Get-DisplayLabel 'AffectedTests.CartridgeSN' 'Cartridge S/N'
        $cells["E$r"].Value = Get-DisplayLabel 'AffectedTests.ModuleSN' 'Module S/N'
        $cells["F$r"].Value = Get-DisplayLabel 'AffectedTests.TestType' 'Test Type'
        $cells["G$r"].Value = Get-DisplayLabel 'AffectedTests.Status' 'Status'
        $cells["H$r"].Value = Get-DisplayLabel 'AffectedTests.TestResult' 'Test Result'
        $cells["I$r"].Value = Get-DisplayLabel 'AffectedTests.MaxPressure' 'Max Pressure (PSI)'
        $cells["J$r"].Value = Get-DisplayLabel 'AffectedTests.Error' 'Error'
        $cells["K$r"].Value = Get-DisplayLabel 'AffectedTests.ErrorCode' 'Error Code'
        $cells["L$r"].Value = Get-DisplayLabel 'AffectedTests.WorkCenter' 'Work Center'
        $cells["M$r"].Value = Get-DisplayLabel 'AffectedTests.RowIndex' 'Row#'
        $cells["A$r:M$r"].Style.Font.Bold = $true
        $cells["A$r:M$r"].Style.WrapText = $true

        $affStart = ++$r
        $affAll = @($Evaluation.AffectedTests)
        $affRows = @($affAll | Select-Object -First 250)
        foreach ($row in $affRows) {
            $cells["A$r"].Value = $row.Severity
            $cells["B$r"].Value = $row.PrimaryRule
            $cells["C$r"].Value = $row.SampleID
            $cells["D$r"].Value = $row.CartridgeSN
            $cells["E$r"].Value = $row.ModuleSN
            $cells["F$r"].Value = $row.TestType
            $cells["G$r"].Value = $row.Status
            $cells["H$r"].Value = $row.TestResult
            $cells["I$r"].Value = if ($row.MaxPressure -ne $null) { [Math]::Round([double]$row.MaxPressure,2) } else { $null }
            $cells["J$r"].Value = $row.ErrorRaw
            $cells["K$r"].Value = $row.ErrorCode
            $cells["L$r"].Value = $row.WorkCenter
            $cells["M$r"].Value = [int]$row.RowIndex
            $r++
        }
        $affEnd = $r - 1
        if ($affEnd -ge $affStart) {
            try { $Worksheet.View.FreezePanes($affStart, 1) } catch {}
            if (-not $fastMode) {
                $cells["A$affStart:M$affEnd"].Style.WrapText = $true
            }
            if ($enableCF) {
                $addrA = "A$affStart:A$affEnd"
                $addrG = "G$affStart:G$affEnd"
                $addrI = "I$affStart:I$affEnd"

                $cfAffErr = $Worksheet.ConditionalFormatting.AddExpression($addrA)
                $cfAffErr.Formula = 'ISNUMBER(SEARCH("Error",A1))'
                $cfAffErr.Style.Fill.PatternType = 'Solid'
                $cfAffErr.Style.Fill.BackgroundColor.Color = [System.Drawing.ColorTranslator]::FromHtml('#ffc7ce')

                $cfAffWarn = $Worksheet.ConditionalFormatting.AddExpression($addrA)
                $cfAffWarn.Formula = 'ISNUMBER(SEARCH("Warn",A1))'
                $cfAffWarn.Style.Fill.PatternType = 'Solid'
                $cfAffWarn.Style.Fill.BackgroundColor.Color = [System.Drawing.ColorTranslator]::FromHtml('#ffe699')

                $cfDone = $Worksheet.ConditionalFormatting.AddExpression($addrG)
                $cfDone.Formula = 'ISNUMBER(SEARCH("Done",G1))'
                $cfDone.Style.Fill.PatternType = 'Solid'
                $cfDone.Style.Fill.BackgroundColor.Color = [System.Drawing.ColorTranslator]::FromHtml('#c6efce')

                try {
                    if ($ps.FailThreshold -ne $null) {
                        $thrFail = ([double]$ps.FailThreshold).ToString([System.Globalization.CultureInfo]::InvariantCulture)
                        $cfMpFail = $Worksheet.ConditionalFormatting.AddExpression($addrI)
                        $cfMpFail.Formula = "I1>=$thrFail"
                        $cfMpFail.Style.Fill.PatternType = 'Solid'
                        $cfMpFail.Style.Fill.BackgroundColor.Color = [System.Drawing.ColorTranslator]::FromHtml('#ffc7ce')
                    }
                    if ($ps.WarnThreshold -ne $null) {
                        $thrWarn = ([double]$ps.WarnThreshold).ToString([System.Globalization.CultureInfo]::InvariantCulture)
                        $cfMpWarn = $Worksheet.ConditionalFormatting.AddExpression($addrI)
                        $cfMpWarn.Formula = "I1>=$thrWarn"
                        $cfMpWarn.Style.Fill.PatternType = 'Solid'
                        $cfMpWarn.Style.Fill.BackgroundColor.Color = [System.Drawing.ColorTranslator]::FromHtml('#ffe699')
                    }
                } catch {}
            }
        }
        if ($affAll.Count -gt $affRows.Count) {
            $cells["A$r"].Value = ("Affected tests truncated: {0} row(s) not shown" -f ($affAll.Count - $affRows.Count))
            $cells["A$r:M$r"].Merge = $true
            $cells["A$r"].Style.Font.Italic = $true
            $r++
        }

        $Worksheet.Cells.Style.Font.Name = 'Arial'
        $Worksheet.Cells.Style.Font.Size = 10

        try {
            if ($autoFit -and $Worksheet.Dimension) {
                $endRow = $Worksheet.Dimension.End.Row
                if ($autoFitMax -and $autoFitMax -gt 0) { $endRow = [Math]::Min($endRow, $autoFitMax) }
                $Worksheet.Cells[$Worksheet.Dimension.Start.Row,$Worksheet.Dimension.Start.Column,$endRow,$Worksheet.Dimension.End.Column].AutoFitColumns() | Out-Null
            }
        } catch {}

    } catch {
        if (Get-Command Log-Exception -ErrorAction SilentlyContinue) {
            Log-Exception -Message "Information2 misslyckades att byggas" -ErrorRecord $_ -Severity 'Warn'
        } else {
            Gui-Log "⚠️ Information2 misslyckades att byggas: $($_.Exception.Message)" 'Warn'
        }
        try {
            $Worksheet.Cells.Clear()
            $Worksheet.Cells["A1"].Value = "Information2 failed"
            $Worksheet.Cells["A1"].Style.Font.Bold = $true
            $Worksheet.Cells["A2"].Value = $_.Exception.Message
            $Worksheet.Cells["A2"].Style.WrapText = $true
        } catch {}
    }
}
