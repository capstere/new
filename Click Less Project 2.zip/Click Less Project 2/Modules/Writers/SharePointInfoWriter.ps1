function Write-SPSheet-Safe {
    param(
        [OfficeOpenXml.ExcelPackage]$Pkg,
        [object]$Rows,
        [string[]]$DesiredOrder,
        [string]$Batch
    )
    if (-not $Pkg) { return $false }
    $Rows = @($Rows)
    $name = "SharePoint Info"
    $wsOld = $Pkg.Workbook.Worksheets[$name]
    if ($wsOld) { $Pkg.Workbook.Worksheets.Delete($wsOld) }
    $ws = $Pkg.Workbook.Worksheets.Add($name)
    if ($Rows.Count -eq 0 -or $Rows[0] -eq $null) {
        $ws.Cells[1,1].Value = "No rows found (Batch=$Batch)"
        return $true
    }
    $isKV = ($Rows[0].psobject.Properties.Name -contains 'Rubrik') -and `
            ($Rows[0].psobject.Properties.Name -contains 'Värde')
    if ($isKV) {
        $ws.Cells[1,1].Value = "SharePoint Information"
        $ws.Cells[1,2].Value = ""
        $ws.Cells["A1:B1"].Merge = $true
        $ws.Cells["A1"].Style.Font.Bold = $true
        $ws.Cells["A1"].Style.Font.Size = 12
        $ws.Cells["A1"].Style.Font.Color.SetColor([System.Drawing.Color]::White)
        $ws.Cells["A1"].Style.Fill.PatternType = "Solid"
        $ws.Cells["A1"].Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::DarkBlue)
        $ws.Cells["A1"].Style.HorizontalAlignment = "Center"
        $ws.Cells["A1"].Style.VerticalAlignment   = "Center"

        $r = 2
        foreach ($row in $Rows) {
            $ws.Cells[$r,1].Value = $row.Rubrik
            $ws.Cells[$r,2].Value = $row.'Värde'
            $r++
        }
        $lastRow = $r-1
        $ws.Cells["A2:A$lastRow"].Style.Font.Bold = $true
        $ws.Cells["A2:A$lastRow"].Style.Fill.PatternType = "Solid"
        $ws.Cells["A2:A$lastRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::Gainsboro)
        $ws.Cells["B2:B$lastRow"].Style.Fill.PatternType = "Solid"
        $ws.Cells["B2:B$lastRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::WhiteSmoke)

        $rng = $ws.Cells["A1:B$lastRow"]
        $rng.Style.Font.Name = "Arial"
        $rng.Style.Font.Size = 10
        $rng.Style.HorizontalAlignment = "Left"
        $rng.Style.VerticalAlignment   = "Center"
        $rng.Style.Border.Top.Style    = "Thin"
        $rng.Style.Border.Bottom.Style = "Thin"
        $rng.Style.Border.Left.Style   = "Thin"
        $rng.Style.Border.Right.Style  = "Thin"
        $rng.Style.Border.BorderAround("Medium")
        Invoke-AutoFitColumns -Worksheet $ws -Address "A1:B$lastRow"
    }
    else {
        $cols = @()
        if ($DesiredOrder) { $cols += $DesiredOrder }
        foreach ($k in $Rows[0].psobject.Properties.Name) {
            if ($cols -notcontains $k) { $cols += $k }
        }

        for ($c=0; $c -lt $cols.Count; $c++) {
            $ws.Cells[1,$c+1].Value = $cols[$c]
            $ws.Cells[1,$c+1].Style.Font.Bold = $true
        }
        $r = 2
        foreach ($row in $Rows) {
            for ($c=0; $c -lt $cols.Count; $c++) {
                $ws.Cells[$r,$c+1].Value = $row.$($cols[$c])
            }
            $r++
        }
        try {
            if ($ws.Dimension) {
                $maxR = [Math]::Min($ws.Dimension.End.Row, 2000)
                Invoke-AutoFitColumns -Worksheet $ws -MaxRows $maxR
            }
        } catch {}
    }
    return $true
}
