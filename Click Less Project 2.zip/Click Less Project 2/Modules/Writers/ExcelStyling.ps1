function Set-RowBorder {
    param ($ws, [int] $row, [int] $firstRow, [int] $lastRow)
    foreach ($col in 'B','C','D','E','F','G','H') {
        $ws.Cells["$col$row"].Style.Border.Left.Style   = "None"
        $ws.Cells["$col$row"].Style.Border.Right.Style  = "None"
        $ws.Cells["$col$row"].Style.Border.Top.Style    = "None"
        $ws.Cells["$col$row"].Style.Border.Bottom.Style = "None"
    }
    $ws.Cells["B$row"].Style.Border.Left.Style  = "Medium"
    $ws.Cells["H$row"].Style.Border.Right.Style = "Medium"
    foreach ($col in 'B','C','D','E','F','G') { $ws.Cells["$col$row"].Style.Border.Right.Style = "Thin" }
    $topStyle = if ($row -eq $firstRow) { "Medium" } else { "Thin" }
    $bottomStyle = if ($row -eq $lastRow)  { "Medium" } else { "Thin" }
    foreach ($col in 'B','C','D','E','F','G','H') {
        $ws.Cells["$col$row"].Style.Border.Top.Style    = $topStyle
        $ws.Cells["$col$row"].Style.Border.Bottom.Style = $bottomStyle
    }
}

function Style-Cell {
    param($cell,$bold,$bg,$border,$fontColor)
    if ($bold) { $cell.Style.Font.Bold = $true }
    if ($bg)   { $cell.Style.Fill.PatternType = "Solid"; $cell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#$bg")) }
    if ($fontColor) { $cell.Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml("#$fontColor")) }
    if ($border) { $cell.Style.Border.Top.Style=$border; $cell.Style.Border.Bottom.Style=$border; $cell.Style.Border.Left.Style=$border; $cell.Style.Border.Right.Style=$border }
}

function Invoke-AutoFitColumns {
    param(
        [OfficeOpenXml.ExcelWorksheet]$Worksheet,
        [int]$MaxRows,
        [string]$Address
    )
    if (-not $Worksheet) { return }

    $autoFit = $false
    $max = $MaxRows
    try {
        if ($Config -and $Config.Performance) {
            if ($Config.Performance.AutoFitColumns -ne $null) { $autoFit = [bool]$Config.Performance.AutoFitColumns }
            if (-not $max -and $Config.Performance.AutoFitMaxRows -ne $null) { $max = [int]$Config.Performance.AutoFitMaxRows }
        }
    } catch {}

    if (-not $autoFit) { return }

    try {
        if ($Address) {
            $Worksheet.Cells[$Address].AutoFitColumns() | Out-Null
            return
        }
        if ($Worksheet.Dimension) {
            $endRow = $Worksheet.Dimension.End.Row
            if ($max -and $max -gt 0) { $endRow = [Math]::Min($endRow, $max) }
            $Worksheet.Cells[$Worksheet.Dimension.Start.Row,$Worksheet.Dimension.Start.Column,$endRow,$Worksheet.Dimension.End.Column].AutoFitColumns() | Out-Null
        }
    } catch {}
}
