if ($script:ClickLessLoaderLoaded) { return }
$script:ClickLessLoaderLoaded = $true

$loaderPath = $MyInvocation.MyCommand.Path
$bootstrapRoot = Split-Path -Parent $loaderPath
$modulesRoot = Split-Path -Parent $bootstrapRoot
$projectRoot = Split-Path -Parent $modulesRoot

if (-not $PSScriptRoot) { $PSScriptRoot = $projectRoot }

. (Join-Path $modulesRoot 'Config.ps1') -ScriptRoot $projectRoot

. (Join-Path $modulesRoot 'Core/MapHelpers.ps1')
. (Join-Path $modulesRoot 'Core/Severity.ps1')
. (Join-Path $modulesRoot 'Core/Normalize.ps1')
. (Join-Path $modulesRoot 'Core/CsvParsing.ps1')
. (Join-Path $modulesRoot 'Core/Types.ps1')
. (Join-Path $modulesRoot 'Core/RuleEngine.Helpers.ps1')

. (Join-Path $modulesRoot 'Services/Logging.ps1')
. (Join-Path $modulesRoot 'Services/EpplusLoader.ps1')
. (Join-Path $modulesRoot 'Services/SharePointService.ps1')

. (Join-Path $modulesRoot 'Rules/RuleBank.ps1')
. (Join-Path $modulesRoot 'Core/RuleEngine.Core.ps1')

. (Join-Path $modulesRoot 'Writers/ExcelStyling.ps1')
. (Join-Path $modulesRoot 'Writers/Information2Writer.ps1')
. (Join-Path $modulesRoot 'Writers/SharePointInfoWriter.ps1')

. (Join-Path $modulesRoot 'IO/PathHelpers.ps1')
. (Join-Path $modulesRoot 'IO/FilePicker.ps1')

. (Join-Path $modulesRoot 'GUI/UiStyling.ps1')
. (Join-Path $modulesRoot 'GUI/Splash.ps1')
. (Join-Path $modulesRoot 'GUI/SignatureHelpers.ps1')
. (Join-Path $modulesRoot 'GUI/Forms.ps1')
