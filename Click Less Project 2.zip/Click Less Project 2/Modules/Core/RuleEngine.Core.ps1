#requires -Version 5.1

function New-AssayRuleContext {
    param(
        [pscustomobject]$Bundle,
        $AssayMap,
        [pscustomobject]$RuleBank
    )

    $ctx = [ordered]@{
        CsvPath             = if ($Bundle) { $Bundle.Path } else { '' }
        Bundle              = $Bundle
        Delimiter           = if ($Bundle -and $Bundle.Delimiter) { $Bundle.Delimiter } else { ',' }
        HeaderRowIndex      = if ($Bundle) { [int]$Bundle.HeaderRowIndex } else { 0 }
        DataStartRowIndex   = if ($Bundle) { [int]$Bundle.DataStartRowIndex } else { 0 }
        Headers             = if ($Bundle) { $Bundle.Headers } else { @() }
        HeaderIndex         = if ($Bundle) { $Bundle.HeaderIndex } else { @{} }
        Indices             = [ordered]@{}
        AssayRaw            = $null
        AssayVersion        = $null
        WorkCenters         = @()
        ReagentLotIds       = @()
        AssayNormalized     = $null
        AssayCanonical      = $null
        AssayDisplayName    = $null
        MatchSource         = $null
        ProfileMatched      = $null
        ProfileMode         = $null
        Profile             = $null
        StatusCounts        = @{}
        ErrorCodeCounts     = @{}         # Hashtable
        DataRows            = @()
        TotalTests          = 0
        MaxPressureMax      = $null
        MaxPressureCount    = 0
        ColumnMissing       = @()
        Debug               = @()
        ParseErrors         = New-Object System.Collections.Generic.List[string]
        DuplicateCounts     = [ordered]@{}
        UniqueSampleIds     = 0
        UniqueCartridgeSN   = 0
        AssayCanonicalSource= $null
        ReagentLotDisplay   = ''
        WorkCentersDisplay  = ''
        TestTypeCounts      = @{}
    }

    if (-not $Bundle -or -not $Bundle.Lines) {
        $ctx.Debug = @([pscustomobject]@{ Name='Context'; Value='Bundle or Lines missing' })
        return [pscustomobject]$ctx
    }

    # Index lookup
    $idxAssay       = Get-HeaderIndexValue -HeaderIndex $ctx.HeaderIndex -Keys @('assay')
    $idxAssayVer    = Get-HeaderIndexValue -HeaderIndex $ctx.HeaderIndex -Keys @('assay version')
    $idxReagentLot  = Get-HeaderIndexValue -HeaderIndex $ctx.HeaderIndex -Keys @('reagent lot id','reagent lot')
    $idxSample      = Get-HeaderIndexValue -HeaderIndex $ctx.HeaderIndex -Keys @('sample id','sampleid')
    $idxCartridge   = Get-HeaderIndexValue -HeaderIndex $ctx.HeaderIndex -Keys @('cartridge s/n','cartridge sn','cartridge serial')
    $idxModule      = Get-HeaderIndexValue -HeaderIndex $ctx.HeaderIndex -Keys @('module sn','module s/n','module serial','module')
    $idxTestType    = Get-HeaderIndexValue -HeaderIndex $ctx.HeaderIndex -Keys @('test type','testtype')
    $idxStatus      = Get-HeaderIndexValue -HeaderIndex $ctx.HeaderIndex -Keys @('status')
    $idxTestResult  = Get-HeaderIndexValue -HeaderIndex $ctx.HeaderIndex -Keys @('test result','result')
    $idxError       = Get-HeaderIndexValue -HeaderIndex $ctx.HeaderIndex -Keys @('error','error code','error codes')
    $idxMaxPressure = Get-HeaderIndexValue -HeaderIndex $ctx.HeaderIndex -Keys @('max pressure (psi)','max pressure psi','max pressure')
    $idxWorkCenter  = Get-HeaderIndexValue -HeaderIndex $ctx.HeaderIndex -Keys @('work center','workcenter')

    $ctx.Indices = [ordered]@{
        Assay       = $idxAssay
        AssayVer    = $idxAssayVer
        ReagentLot  = $idxReagentLot
        SampleId    = $idxSample
        CartridgeSn = $idxCartridge
        ModuleSn    = $idxModule
        TestType    = $idxTestType
        Status      = $idxStatus
        TestResult  = $idxTestResult
        Error       = $idxError
        MaxPressure = $idxMaxPressure
        WorkCenter  = $idxWorkCenter
    }

    foreach ($kv in $ctx.Indices.GetEnumerator()) {
        if ($kv.Value -lt 0) { $ctx.ColumnMissing += $kv.Name }
    }

    # Parser selection
    $parse = $null
    if (Get-Command Parse-CsvLine -ErrorAction SilentlyContinue) {
        $parse = { param($ln,$delim) (Parse-CsvLine -line $ln -delim $delim) }
    } elseif (Get-Command ConvertTo-CsvFields -ErrorAction SilentlyContinue) {
        $parse = { param($ln,$delim) (ConvertTo-CsvFields $ln) }
    } else {
        # Fallback: delimiter med citattecken
        $parse = { param($ln,$delim) ([regex]::Split($ln, [regex]::Escape($delim) + '(?=(?:[^"]*"[^"]*")*[^"]*$)')) }
    }

    $lines    = $Bundle.Lines
    $startRow = $ctx.DataStartRowIndex
    if ($startRow -lt 0) { $startRow = [int]$ctx.HeaderRowIndex + 1 }
    if ($startRow -lt 0) { $startRow = 0 }

    $reagentSet    = New-Object 'System.Collections.Generic.HashSet[string]'
    $workCenterSet = New-Object 'System.Collections.Generic.HashSet[string]'
    $sampleCounts  = @{}
    $cartridgeCounts = @{}
    $testTypeCounts = @{}

    $statusCounts = @{
        'Done'        = 0
        'Error'       = 0
        'Invalid'     = 0
        'Aborted'     = 0
        'Incomplete'  = 0
        'In Progress' = 0
        'Other'       = 0
    }

    $errorCounts = @{}  # Hashtable
    $rows = New-Object 'System.Collections.Generic.List[object]'
    $maxPressureMax = $null
    $maxPressureCount = 0

    for ($r = $startRow; $r -lt $lines.Count; $r++) {
        $ln = $lines[$r]
        if (-not $ln) { continue }

        $cols = $null
        try {
            $cols = & $parse $ln $ctx.Delimiter
        } catch {
            [void]$ctx.ParseErrors.Add(("Row {0}: Parse failed: {1}" -f ($r+1), $_.Exception.Message))
            continue
        }

        if (-not $cols -or ($cols -join '').Trim().Length -eq 0) { continue }

        try {
            $rowObj = [ordered]@{
                RowIndex     = ($r + 1)
                DataIndex    = ($r - $startRow + 1)
                Assay        = if ($idxAssay -ge 0 -and $cols.Count -gt $idxAssay) { ($cols[$idxAssay] + '').Trim() } else { '' }
                AssayVersion = if ($idxAssayVer -ge 0 -and $cols.Count -gt $idxAssayVer) { ($cols[$idxAssayVer] + '').Trim() } else { '' }
                ReagentLotId = if ($idxReagentLot -ge 0 -and $cols.Count -gt $idxReagentLot) { ($cols[$idxReagentLot] + '').Trim() } else { '' }
                SampleID     = if ($idxSample -ge 0 -and $cols.Count -gt $idxSample) { ($cols[$idxSample] + '').Trim() } else { '' }
                CartridgeSN  = if ($idxCartridge -ge 0 -and $cols.Count -gt $idxCartridge) { ($cols[$idxCartridge] + '').Trim() } else { '' }
                ModuleSN     = if ($idxModule -ge 0 -and $cols.Count -gt $idxModule) { ($cols[$idxModule] + '').Trim() } else { '' }
                TestType     = if ($idxTestType -ge 0 -and $cols.Count -gt $idxTestType) { ($cols[$idxTestType] + '').Trim() } else { '' }
                Status       = if ($idxStatus -ge 0 -and $cols.Count -gt $idxStatus) { ($cols[$idxStatus] + '').Trim() } else { '' }
                TestResult   = if ($idxTestResult -ge 0 -and $cols.Count -gt $idxTestResult) { ($cols[$idxTestResult] + '').Trim() } else { '' }
                ErrorRaw     = if ($idxError -ge 0 -and $cols.Count -gt $idxError) { ($cols[$idxError] + '').Trim() } else { '' }
                ErrorCode    = $null
                MaxPressure  = $null
                WorkCenter   = if ($idxWorkCenter -ge 0 -and $cols.Count -gt $idxWorkCenter) { ($cols[$idxWorkCenter] + '').Trim() } else { '' }
                FailureTags  = New-Object System.Collections.Generic.List[string]
                Notes        = ''
                Severity     = 'Info'
                ParsedRole   = ''
                ParsedId     = ''
                ParsedIdx    = ''
                PrimaryRule  = ''
            }

            if ($rowObj.ReagentLotId) {
                $m = [regex]::Match($rowObj.ReagentLotId, '(?<!\d)(\d{5})(?!\d)')
                if ($m.Success) { $rowObj.ReagentLotId = $m.Groups[1].Value }
                [void]$reagentSet.Add($rowObj.ReagentLotId)
            }
            if ($rowObj.WorkCenter) { [void]$workCenterSet.Add($rowObj.WorkCenter) }

            if ($idxError -ge 0) {
                $code = Parse-ErrorCode -Text $rowObj.ErrorRaw -RuleBank $RuleBank
                if ($code) {
                    $rowObj.ErrorCode = $code
                    Add-MapCount -Map $errorCounts -Key $code -Delta 1
                }
            }

            if ($idxMaxPressure -ge 0 -and $cols.Count -gt $idxMaxPressure) {
                $mp = Convert-ToDoubleOrNull (($cols[$idxMaxPressure] + '').Trim())
                if ($mp -ne $null) {
                    $rowObj.MaxPressure = [double]$mp
                    if ($maxPressureMax -eq $null -or $mp -gt $maxPressureMax) { $maxPressureMax = [double]$mp }
                    $maxPressureCount++
                }
            }

            # Derived: SampleId parts
            try {
                $parsed = Parse-SampleIdParts -SampleId $rowObj.SampleID -RuleBank $RuleBank
                if ($parsed -and $parsed.Success) {
                    $rowObj.ParsedRole = $parsed.Role
                    $rowObj.ParsedId   = $parsed.Id
                    $rowObj.ParsedIdx  = $parsed.Idx
                }
            } catch {}

            # Counting
            if ($rowObj.SampleID) {
                if (-not $sampleCounts.ContainsKey($rowObj.SampleID)) { $sampleCounts[$rowObj.SampleID] = 0 }
                $sampleCounts[$rowObj.SampleID]++
            }
            if ($rowObj.CartridgeSN) {
                if (-not $cartridgeCounts.ContainsKey($rowObj.CartridgeSN)) { $cartridgeCounts[$rowObj.CartridgeSN] = 0 }
                $cartridgeCounts[$rowObj.CartridgeSN]++
            }
            if ($rowObj.TestType) {
                if (-not $testTypeCounts.ContainsKey($rowObj.TestType)) { $testTypeCounts[$rowObj.TestType] = 0 }
                $testTypeCounts[$rowObj.TestType]++
            }

            # Status counts
            $statusKey = if ($rowObj.Status) { $rowObj.Status } else { 'Other' }
            if ($statusCounts.ContainsKey($statusKey)) { $statusCounts[$statusKey]++ } else { $statusCounts['Other']++ }

            [void]$rows.Add([pscustomobject]$rowObj)
        } catch {
            [void]$ctx.ParseErrors.Add(("Row {0}: Parse/convert failed: {1}" -f ($r+1), $_.Exception.Message))
        }
    }

    $ctx.DataRows        = $rows.ToArray()
    $ctx.TotalTests      = $ctx.DataRows.Count
    $ctx.StatusCounts    = $statusCounts
    $ctx.ErrorCodeCounts = $errorCounts

    # HashSet -> string[]
    if ($reagentSet -is [System.Collections.IEnumerable]) {
        $reagentArray = New-Object string[] $reagentSet.Count
        try { $reagentSet.CopyTo($reagentArray) } catch { $reagentArray = foreach ($id in $reagentSet) { [string]$id } }
        $ctx.ReagentLotIds = $reagentArray
    } else { $ctx.ReagentLotIds = @() }

    if ($workCenterSet -is [System.Collections.IEnumerable]) {
        $workCenterArray = New-Object string[] $workCenterSet.Count
        try { $workCenterSet.CopyTo($workCenterArray) } catch { $workCenterArray = foreach ($wc in $workCenterSet) { [string]$wc } }
        $ctx.WorkCenters = $workCenterArray
    } else { $ctx.WorkCenters = @() }

    $ctx.UniqueSampleIds   = ($sampleCounts.Keys | Measure-Object).Count
    $ctx.UniqueCartridgeSN = ($cartridgeCounts.Keys | Measure-Object).Count

    $dupSample = @($sampleCounts.Keys | Where-Object { $sampleCounts[$_] -gt 1 })
    $dupCart   = @($cartridgeCounts.Keys | Where-Object { $cartridgeCounts[$_] -gt 1 })
    $ctx.DuplicateCounts = [ordered]@{
        SampleId    = $dupSample.Count
        CartridgeSN = $dupCart.Count
    }

    $ctx.MaxPressureMax   = $maxPressureMax
    $ctx.MaxPressureCount = $maxPressureCount
    $ctx.TestTypeCounts   = $testTypeCounts

    # Sätt AssayRaw/AssayVersion till vanligaste förekomsten
    try {
        $assayGroups = $ctx.DataRows | Where-Object { $_.Assay } | Group-Object -Property Assay | Sort-Object -Property Count -Descending
        if ($assayGroups -and $assayGroups.Count -gt 0) { $ctx.AssayRaw = ($assayGroups[0].Name + '') }

        $verGroups = $ctx.DataRows | Where-Object { $_.AssayVersion } | Group-Object -Property AssayVersion | Sort-Object -Property Count -Descending
        if ($verGroups -and $verGroups.Count -gt 0) { $ctx.AssayVersion = ($verGroups[0].Name + '') }
    } catch {}

    # Canonical name resolution
    $resolved = Resolve-AssayCanonicalName -RawAssay $ctx.AssayRaw -AssayMap $AssayMap -RuleBank $RuleBank
    $ctx.AssayNormalized      = $resolved.Normalized
    $ctx.AssayCanonical       = $resolved.Canonical
    $ctx.MatchSource          = $resolved.MatchSource
    $ctx.AssayCanonicalSource = $resolved.MatchSource

    $displayName = $null
    try {
        if ($RuleBank -and $RuleBank.AssayDisplayNames) {
            if (Test-MapHasKey $RuleBank.AssayDisplayNames $ctx.AssayCanonical) {
                $displayName = $RuleBank.AssayDisplayNames[$ctx.AssayCanonical]
            } elseif ($ctx.AssayCanonical) {
                $canonNorm = Normalize-AssayName $ctx.AssayCanonical
                foreach ($k in $RuleBank.AssayDisplayNames.Keys) {
                    if ($canonNorm -eq (Normalize-AssayName ($k + ''))) {
                        $displayName = $RuleBank.AssayDisplayNames[$k]
                        break
                    }
                }
            }
        }
    } catch {}
    if (-not $displayName) { $displayName = $ctx.AssayCanonical }
    $ctx.AssayDisplayName = $displayName

    $ctx.ReagentLotDisplay = if ($ctx.ReagentLotIds -and $ctx.ReagentLotIds.Count -gt 0) {
        ($ctx.ReagentLotIds | Where-Object { $_ } | Sort-Object -Unique | ForEach-Object { "LSP $($_)" }) -join ', '
    } else { '—' }

    $ctx.WorkCentersDisplay = if ($ctx.WorkCenters -and $ctx.WorkCenters.Count -gt 0) {
        ($ctx.WorkCenters | Where-Object { $_ } | Sort-Object -Unique) -join ', '
    } else { '—' }

    # Rule profile
    $profileResolved = Get-AssayRuleProfile -Canonical $ctx.AssayCanonical -RuleBank $RuleBank
    if ($profileResolved) {
        $ctx.Profile        = $profileResolved.Profile
        $ctx.ProfileMatched = $profileResolved.Key
        $ctx.ProfileMode    = $profileResolved.Mode
    }

    # Debug info (ingen Avg längre)
    $ctx.Debug = @(
        [pscustomobject]@{ Name='CsvPath';          Value=$ctx.CsvPath },
        [pscustomobject]@{ Name='Delimiter';        Value=$ctx.Delimiter },
        [pscustomobject]@{ Name='HeaderRowIndex';   Value=$ctx.HeaderRowIndex },
        [pscustomobject]@{ Name='DataStartRow';     Value=$ctx.DataStartRowIndex },
        [pscustomobject]@{ Name='RowCount';         Value=$ctx.TotalTests },
        [pscustomobject]@{ Name='ParseErrors';      Value=$ctx.ParseErrors.Count },
        [pscustomobject]@{ Name='AssayRaw';         Value=$ctx.AssayRaw },
        [pscustomobject]@{ Name='AssayDisplayName'; Value=$ctx.AssayDisplayName },
        [pscustomobject]@{ Name='AssayCanonical';   Value=$ctx.AssayCanonical },
        [pscustomobject]@{ Name='MatchSource';      Value=$ctx.MatchSource },
        [pscustomobject]@{ Name='AssayVersion';     Value=$ctx.AssayVersion },
        [pscustomobject]@{ Name='ReagentLotIds';    Value=($ctx.ReagentLotIds -join ', ') },
        [pscustomobject]@{ Name='ReagentLotDisplay';Value=$ctx.ReagentLotDisplay },
        [pscustomobject]@{ Name='WorkCenters';      Value=($ctx.WorkCenters -join ', ') },
        [pscustomobject]@{ Name='WorkCentersDisplay';Value=$ctx.WorkCentersDisplay },
        [pscustomobject]@{ Name='MaxPressureMax';   Value=$ctx.MaxPressureMax }
    )

    return [pscustomobject]$ctx
}


# -----------------------------
# Engine
# -----------------------------

function Invoke-AssayRuleEngine {
    param(
        [pscustomobject]$Context,
        [pscustomobject]$RuleBank
    )

    $result = [pscustomobject]@{
        Findings               = @()
        AffectedTests          = @()
        AffectedTestsTruncated = 0
        ErrorSummary           = @()
        ErrorCodesTable        = @()
        PressureStats          = [pscustomobject]@{ Max=$null; OverWarn=0; OverFail=0; WarnThreshold=$null; FailThreshold=$null }
        DuplicatesTable        = @()
        Debug                  = @()
        OverallSeverity        = 'Info'
        OverallStatus          = 'PASS'
        StatusCounts           = @{}
        TotalTests             = 0
        UniqueErrorCodes       = 0
        IdentityFlags          = @{}
        SeverityCounts         = @{ Error=0; Warn=0; Info=0 }  # Hashtable
        Exception              = $null
        BaselineExpected       = 0
        BaselineDelta          = 0
        ErrorRowCount          = 0
    }

    $findings = New-Object System.Collections.Generic.List[object]

    function New-Finding {
        param(
            [string]$Severity,
            [string]$RuleId,
            [string]$Message,
            [object[]]$Rows,
            [string]$Classification = '',
            [bool]$GeneratesRetest = $false,
            [string]$Evidence = $null
        )
        $affCount = if ($Rows) { [int]$Rows.Count } else { 0 }
        $example = ''
        if ($Rows -and $Rows.Count -gt 0) {
            $sample = ($Rows | Where-Object { $_.SampleID } | Select-Object -First 1 -ExpandProperty SampleID)
            if ($sample) { $example = $sample }
            elseif ($Rows[0].RowIndex) { $example = "Row $($Rows[0].RowIndex)" }
        }
        return [pscustomobject]@{
            Severity        = $Severity
            RuleId          = $RuleId
            Message         = $Message
            Count           = $affCount
            AffectedCount   = $affCount
            Title           = $Message
            Example         = $example
            Evidence        = ($Evidence + '')
            Classification  = $Classification
            GeneratesRetest = [bool]$GeneratesRetest
        }
    }

    if (-not $Context) {
        [void]$findings.Add((New-Finding -Severity 'Error' -RuleId 'ENGINE_EXCEPTION' -Message 'Context missing' -Rows $null -Evidence 'Context object is null'))
        $result.Findings = $findings.ToArray()
        $result.OverallSeverity = 'Error'
        $result.OverallStatus = 'FAIL'
        return [pscustomobject]$result
    }

    try {
        $rows = $Context.DataRows
        $result.TotalTests    = [int]$Context.TotalTests
        $result.StatusCounts  = $Context.StatusCounts
        $result.Debug         = $Context.Debug

        # Parse warnings som INFO
        try {
            if ($Context.ParseErrors -and $Context.ParseErrors.Count -gt 0) {
                $msg = ("CSV parse warnings: {0}" -f [int]$Context.ParseErrors.Count)
                $ev  = ($Context.ParseErrors | Select-Object -First 3) -join ' | '
                [void]$findings.Add((New-Finding -Severity 'Info' -RuleId 'CSV_PARSE_WARNINGS' -Message $msg -Rows $null -Evidence $ev))
            }
        } catch {}

        # Pressure thresholds
        $warnThreshold = 85
        $failThreshold = 90
        try {
            if ($RuleBank -and $RuleBank.Global -and $RuleBank.Global.MaxPressure) {
                if ($RuleBank.Global.MaxPressure.WarnThreshold -ne $null) { $warnThreshold = [double]$RuleBank.Global.MaxPressure.WarnThreshold }
                if ($RuleBank.Global.MaxPressure.FailThreshold -ne $null) { $failThreshold = [double]$RuleBank.Global.MaxPressure.FailThreshold }
            }
        } catch {}

        # Sätt Max/Trösklar
        $result.PressureStats.Max = $Context.MaxPressureMax
        $result.PressureStats.WarnThreshold = $warnThreshold
        $result.PressureStats.FailThreshold = $failThreshold

        # OverWarn/OverFail (antal rader >= tröskel)
        try {
            $overWarn = @($rows | Where-Object { $_.MaxPressure -ne $null -and $_.MaxPressure -ge [double]$warnThreshold }).Count
            $overFail = @($rows | Where-Object { $_.MaxPressure -ne $null -and $_.MaxPressure -ge [double]$failThreshold }).Count
            $result.PressureStats.OverWarn = [int]$overWarn
            $result.PressureStats.OverFail = [int]$overFail
        } catch {}

        # Baseline policy
        $expected = 0
        $allowedMissing = 0
        $allowedExtra   = 0
        $baselineSeverity = 'Error'
        $baselineRuleId   = 'BASELINE_SAMPLE_SIZE'
        try {
            if ($RuleBank -and $RuleBank.Baseline -and $RuleBank.Baseline.SampleSizePolicy) {
                $policy = $RuleBank.Baseline.SampleSizePolicy
                if ($policy.Expected -ne $null)       { $expected = [int]$policy.Expected }
                if ($policy.AllowedMissing -ne $null) { $allowedMissing = [int]$policy.AllowedMissing }
                if ($policy.AllowedExtra -ne $null)   { $allowedExtra = [int]$policy.AllowedExtra }
                if ($policy.Severity)                 { $baselineSeverity = $policy.Severity }
                if ($policy.RuleId)                   { $baselineRuleId = $policy.RuleId }
            }
        } catch {}

        $diff = $result.TotalTests - $expected
        $result.BaselineExpected = $expected
        $result.BaselineDelta    = $diff

        if ($expected -gt 0) {
            if ($diff -lt 0 -and [Math]::Abs($diff) -gt $allowedMissing) {
                [void]$findings.Add((New-Finding -Severity $baselineSeverity -RuleId $baselineRuleId -Message ("{0} tests missing (expected {1}, got {2})" -f ([Math]::Abs($diff)), $expected, $result.TotalTests) -Rows $null -Evidence ("AllowedMissing=$allowedMissing; AllowedExtra=$allowedExtra")))
            } elseif ($diff -gt 0 -and $diff -gt $allowedExtra) {
                [void]$findings.Add((New-Finding -Severity $baselineSeverity -RuleId $baselineRuleId -Message ("{0} extra tests (expected {1}, got {2})" -f $diff, $expected, $result.TotalTests) -Rows $null -Evidence ("AllowedMissing=$allowedMissing; AllowedExtra=$allowedExtra")))
            }
        }

        foreach ($col in ($Context.ColumnMissing | Sort-Object)) {
            [void]$findings.Add((New-Finding -Severity 'Info' -RuleId ('COLUMN_MISSING_' + $col.ToUpper()) -Message ("Column missing: {0}" -f $col) -Rows $null))
        }

        # Identity checks (oförändrad)
        $identityDefs = @()
        try {
            if ($RuleBank -and $RuleBank.Global -and $RuleBank.Global.Identity -and $RuleBank.Global.Identity.Fields) {
                $identityDefs = @($RuleBank.Global.Identity.Fields.GetEnumerator() | ForEach-Object {
                    [pscustomobject]@{ Name=$_.Key; Config=$_.Value }
                })
            }
        } catch {}
        if ($identityDefs.Count -eq 0) {
            $identityDefs = @(
                [pscustomobject]@{ Name='Assay';        Config=[ordered]@{ RuleId='IDENTITY_ASSAY'; Severity='Error' } },
                [pscustomobject]@{ Name='AssayVersion'; Config=[ordered]@{ RuleId='IDENTITY_ASSAY_VERSION'; Severity='Error' } },
                [pscustomobject]@{ Name='ReagentLotId'; Config=[ordered]@{ RuleId='IDENTITY_REAGENT_LOT_ID'; Severity='Error' } }
            )
        }

        $result.IdentityFlags = [ordered]@{}
        foreach ($idDef in $identityDefs) {
            $propName = $idDef.Name
            $ruleId   = if ($idDef.Config.RuleId) { $idDef.Config.RuleId } else { 'IDENTITY_' + ($propName -replace '\W','_').ToUpper() }
            $sevId    = if ($idDef.Config.Severity) { $idDef.Config.Severity } else { 'Error' }

            $vals = @($rows | ForEach-Object { $_.$propName } | Where-Object { $_ }) | Select-Object -Unique
            if ($vals.Count -gt 1) {
                $baselineVal = $vals[0]
                $affected = @($rows | Where-Object { $_.$propName -and $_.$propName -ne $baselineVal })
                foreach ($r in $affected) { Add-FailureTag -Row $r -RuleId $ruleId -Severity $sevId }
                $result.IdentityFlags[$propName] = 'Mismatch'
                [void]$findings.Add((New-Finding -Severity $sevId -RuleId $ruleId -Message ("{0} mismatch (expected '{1}')" -f $propName, $baselineVal) -Rows $affected))
            } elseif ($vals.Count -eq 1) {
                $result.IdentityFlags[$propName] = 'Ok'
            } else {
                $result.IdentityFlags[$propName] = 'Missing'
            }
        }

        # Duplicate counts
        if ($Context.DuplicateCounts) {
            foreach ($k in $Context.DuplicateCounts.Keys) {
                if ($Context.DuplicateCounts[$k] -gt 0) {
                    [void]$findings.Add((New-Finding -Severity 'Warn' -RuleId ("DUPLICATE_" + $k.ToUpper()) -Message ("Duplicate {0} detected" -f $k) -Rows $null -Evidence ("Count={0}" -f $Context.DuplicateCounts[$k])))
                }
            }
        }

        # RuleBank rules (oförändrad)
        if ($RuleBank -and $RuleBank.Rules) {
            foreach ($rule in $RuleBank.Rules) {
                if (-not $rule) { continue }
                try {
                    $rid = $rule.RuleId
                    $sev = if ($rule.Severity) { $rule.Severity } else { 'Warn' }
                    $msg = $rule.Message
                    $class = if ($rule.Classification) { $rule.Classification } else { '' }
                    $generates = $false
                    try { if ($rule.GeneratesRetest -ne $null) { $generates = [bool]$rule.GeneratesRetest } } catch {}

                    $affRows = @()
                    if ($rule.Filter) {
                        $affRows = @($rows | Where-Object $rule.Filter)
                    } elseif ($rule.FilterScript) {
                        $affRows = @($rows | Where-Object $rule.FilterScript)
                    }

                    if ($affRows.Count -gt 0) {
                        foreach ($r in $affRows) { Add-FailureTag -Row $r -RuleId $rid -Severity $sev }
                        [void]$findings.Add((New-Finding -Severity $sev -RuleId $rid -Message $msg -Rows $affRows -Classification $class -GeneratesRetest $generates))
                    }
                } catch {}
            }
        }

        # Error code breakdown
        $errorCodeCounts = $Context.ErrorCodeCounts
        $knownCodes = @()
        try { if ($RuleBank -and $RuleBank.ErrorBank -and $RuleBank.ErrorBank.Codes) { $knownCodes = $RuleBank.ErrorBank.Codes.Keys } } catch {}
        if ($errorCodeCounts -and $errorCodeCounts.Count -gt 0) {
            $errDetails = New-Object System.Collections.Generic.List[object]
            foreach ($code in ($errorCodeCounts.Keys | Sort-Object)) {
                $defKey = $code
                $def = $null
                if ($defKey) {
                    try { $def = $RuleBank.ErrorBank.Codes[$defKey] } catch {}
                }
                $exampleRow = ($rows | Where-Object { $_.ErrorCode -eq $code } | Select-Object -First 1)
                [void]$errDetails.Add([pscustomobject]@{
                    ErrorCode       = $code
                    Name            = if ($def -and $def.Name) { $def.Name } else { '' }
                    Group           = if ($def -and $def.Group) { $def.Group } else { '' }
                    Classification  = if ($def -and $def.Classification) { $def.Classification } else { '' }
                    GeneratesRetest = if ($def -and $def.GeneratesRetest -ne $null) { [bool]$def.GeneratesRetest } else { $false }
                    Count           = [int]$errorCodeCounts[$code]
                    ExampleSampleID = if ($exampleRow) { $exampleRow.SampleID } else { '' }
                })
            }
            if ($errDetails.Count -gt 0) {
                $result.ErrorSummary = @(
                    $errDetails | Sort-Object `
                        @{ Expression = 'Count';     Descending = $true }, `
                        @{ Expression = 'ErrorCode'; Descending = $false }
                )
                $result.ErrorCodesTable = $result.ErrorSummary
                $result.UniqueErrorCodes = [int]$errDetails.Count
            }
        }

        # Unknown error codes warning (oförändrad)
        if ($knownCodes.Count -gt 0) {
            $rowsUnknownErr = @($rows | Where-Object { $_.ErrorCode -and ($knownCodes -notcontains $_.ErrorCode) })
            if ($rowsUnknownErr.Count -gt 0) {
                foreach ($r in $rowsUnknownErr) { Add-FailureTag -Row $r -RuleId 'UNKNOWN_ERROR_CODE' -Severity 'Warn' }
                $unknownCodesTxt = (($rowsUnknownErr | Select-Object -ExpandProperty ErrorCode) | Select-Object -Unique) -join ', '
                [void]$findings.Add((New-Finding -Severity 'Warn' -RuleId 'UNKNOWN_ERROR_CODE' -Message 'Error code not in known list.' -Rows $rowsUnknownErr -Evidence ("Unknown codes: {0}" -f $unknownCodesTxt)))
            }
        }

        # Affected tests – stabil sortering
        $affected = @($rows | Where-Object { $_.FailureTags -and $_.FailureTags.Count -gt 0 -and (Get-SeverityRank $_.Severity) -ge (Get-SeverityRank 'Warn') })
        $affected = @(
            $affected | Sort-Object `
                @{ Expression = { Get-SeverityRank $_.Severity }; Descending = $true }, `
                @{ Expression = { $_.ErrorCode } }, `
                @{ Expression = { $_.SampleID } }, `
                @{ Expression = { $_.RowIndex } }
        )
        $result.AffectedTests = $affected
        $result.ErrorRowCount = $affected.Count

        if ($findings.Count -eq 0) {
            [void]$findings.Add((New-Finding -Severity 'Info' -RuleId 'NO_FINDINGS' -Message 'No rule findings detected.' -Rows $null))
        }

        $sortedFindings = @(
            $findings | Sort-Object `
                @{ Expression = { Get-SeverityRank $_.Severity }; Descending = $true }, `
                @{ Expression = { $_.Count }; Descending = $true }
        )
        $result.Findings = $sortedFindings

        foreach ($f in $sortedFindings) {
            if ($result.SeverityCounts.ContainsKey($f.Severity)) { $result.SeverityCounts[$f.Severity] = [int]$result.SeverityCounts[$f.Severity] + 1 }
        }

        $worst = 'Info'
        foreach ($f in $sortedFindings) {
            if ((Get-SeverityRank $f.Severity) -gt (Get-SeverityRank $worst)) { $worst = $f.Severity }
        }
        $result.OverallSeverity = $worst
        switch ($worst) {
            'Error' { $result.OverallStatus = 'FAIL' }
            'Warn'  { $result.OverallStatus = 'WARN' }
            default { $result.OverallStatus = 'PASS' }
        }

    } catch {
        $ev = $null
        try { $ev = $_.Exception.ToString() } catch { $ev = $_.Exception.Message }

        [void]$findings.Add([pscustomobject]@{
            Severity        = 'Error'
            RuleId          = 'ENGINE_EXCEPTION'
            Message         = 'RuleEngine exception'
            Count           = 0
            Evidence        = $ev
            Classification  = 'Engine'
            GeneratesRetest = $false
            Example         = ''
        })
        $result.Findings = $findings.ToArray()
        $result.OverallSeverity = 'Error'
        $result.OverallStatus = 'FAIL'
        $result.Exception = $_.Exception
    }

    return [pscustomobject]$result
}
