function Test-MapHasKey {
    param([object]$Map, [object]$Key)
    if ($null -eq $Map -or $null -eq $Key) { return $false }

    try {
        if ($Map -is [hashtable]) { return $Map.ContainsKey($Key) }
        if ($Map -is [System.Collections.Specialized.OrderedDictionary]) { return $Map.Contains($Key) }
        if ($Map -is [System.Collections.IDictionary]) { return $Map.Contains($Key) }

        if ($Map.PSObject -and $Map.PSObject.Methods['ContainsKey']) { return [bool]$Map.ContainsKey($Key) }
        if ($Map.PSObject -and $Map.PSObject.Methods['Contains'])    { return [bool]$Map.Contains($Key) }
    } catch {}
    return $false
}

function Get-MapValue {
    param([object]$Map, [object]$Key, [object]$Default = $null)
    try {
        if (Test-MapHasKey -Map $Map -Key $Key) { return $Map[$Key] }
    } catch {}
    return $Default
}

function Set-MapValue {
    param([object]$Map, [object]$Key, [object]$Value)
    if ($null -eq $Map -or $null -eq $Key) { return $false }
    try { $Map[$Key] = $Value; return $true } catch { return $false }
}

function Add-MapCount {
    param([object]$Map, [object]$Key, [int]$Delta = 1)
    if ($null -eq $Map -or $null -eq $Key) { return }
    try {
        if (-not (Test-MapHasKey $Map $Key)) { $Map[$Key] = 0 }
        $Map[$Key] = [int]$Map[$Key] + [int]$Delta
    } catch {}
}
