function Normalize-HeaderName {
    param([string]$s)
    if ([string]::IsNullOrWhiteSpace($s)) { return '' }
    $t = $s.Trim().ToLowerInvariant()
    $t = $t.Replace('_',' ')
    $t = ($t -replace '[\(\)]',' ')
    $t = ($t -replace '\s+',' ').Trim()
    return $t
}

function Normalize-AssayName {
    param([string]$Name)
    if ([string]::IsNullOrWhiteSpace($Name)) { return '' }
    $x = $Name.Trim().ToLowerInvariant()
    $x = $x -replace '[_]+',' '
    $x = $x -replace '[^a-z0-9]+',' '
    $x = ($x -replace '\s+',' ').Trim()
    return $x
}

function Normalize-Assay {
    param([string]$s)
    if ([string]::IsNullOrWhiteSpace($s)) { return $null }
    return (Normalize-AssayName $s)
}

function Normalize-Id {
    param([string]$Value, [ValidateSet('Batch','Part','Cartridge')] [string]$Type)
    if ([string]::IsNullOrWhiteSpace($Value)) { return $null }
    $v = $Value.Trim()
    switch ($Type) {
        'Batch'     { return ($v -replace '[^\d]', '') }
        'Part'      { return (($v -replace '[^0-9A-Za-z\-]', '')).ToUpper() }
        'Cartridge' { return ($v -replace '[^\d]', '') }
        default     { return $v }
    }
}

function Normalize-HeaderText {
    param([string]$s)
    if ([string]::IsNullOrEmpty($s)) { return '' }
    $s = $s -replace "[\uFEFF\u200B]", ""
    $s = $s -replace "_x000D_", " "
    $s = $s -replace "[\u00A0\u2007\u202F]", " "
    $s = $s -replace "[\u2013\u2014\u2212]", "-"
    $s = ($s -replace "\s+", " ").Trim()
    return $s
}
