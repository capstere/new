function Get-HeaderIndexValue {
    param(
        [object]$HeaderIndex,
        [string[]]$Keys
    )
    if (-not $HeaderIndex) { return -1 }

    foreach ($k in ($Keys | Where-Object { $_ })) {
        $n = Normalize-HeaderName $k

        if (Test-MapHasKey $HeaderIndex $n) { return [int](Get-MapValue $HeaderIndex $n -1) }
        if (Test-MapHasKey $HeaderIndex $k) { return [int](Get-MapValue $HeaderIndex $k -1) }
    }
    return -1
}

function Resolve-AssayCanonicalName {
    param(
        [string]$RawAssay,
        $AssayMap,
        [pscustomobject]$RuleBank
    )

    $norm = Normalize-AssayName $RawAssay
    $canon = $null
    $source = 'Fallback'
    $matched = $null

    try {
        if (-not [string]::IsNullOrWhiteSpace($norm) -and $RuleBank -and $RuleBank.AssayProfiles) {
            foreach ($k in $RuleBank.AssayProfiles.Keys) {
                if ($norm -eq (Normalize-AssayName ($k + ''))) {
                    $canon = $k; $source = 'Profiles'; $matched = $k
                    break
                }
            }
        }
    } catch {}

    try {
        if (-not $canon -and $RuleBank -and $RuleBank.AssayAliases) {
            foreach ($k in $RuleBank.AssayAliases.Keys) {
                if ($norm -eq (Normalize-AssayName ($k + ''))) {
                    $canon = $RuleBank.AssayAliases[$k]
                    $source = 'RuleBankAlias'
                    $matched = $k
                    break
                }
            }
        }
    } catch {}

    if (-not $canon -and $AssayMap) {
        try {
            if ($AssayMap -is [hashtable]) {
                foreach ($k in $AssayMap.Keys) {
                    if ($norm -eq (Normalize-AssayName ($k + ''))) {
                        $canon = $AssayMap[$k]
                        $source = 'ConfigAssayMap'
                        $matched = $k
                        break
                    }
                }
            } else {
                foreach ($item in $AssayMap) {
                    if (-not $item) { continue }

                    $target = $null
                    try {
                        if ($item.PSObject.Properties.Match('Assay').Count -gt 0)      { $target = $item.Assay }
                        elseif ($item.PSObject.Properties.Match('Canonical').Count -gt 0){ $target = $item.Canonical }
                        elseif ($item.PSObject.Properties.Match('Tab').Count -gt 0)    { $target = $item.Tab }
                    } catch {}

                    $aliases = $null
                    try { if ($item.PSObject.Properties.Match('Aliases').Count -gt 0) { $aliases = $item.Aliases } } catch {}

                    foreach ($al in ($aliases | Where-Object { $_ })) {
                        if ($norm -eq (Normalize-AssayName ($al + ''))) {
                            $canon = $target
                            $source = 'ConfigAssayMap'
                            $matched = $al
                            break
                        }
                    }
                    if ($canon) { break }
                }
            }
        } catch {}
    }

    if (-not $canon) {
        $canon = if ($RawAssay) { $RawAssay } else { '_DEFAULT' }
        $source = if ($RawAssay) { 'Fallback' } else { 'Default' }
        $matched = $RawAssay
    }

    return [pscustomobject]@{
        Raw         = $RawAssay
        Normalized  = $norm
        Canonical   = $canon
        MatchSource = $source
        MatchedKey  = $matched
    }
}

function Parse-ErrorCode {
    param([string]$Text, [pscustomobject]$RuleBank)

    if ([string]::IsNullOrWhiteSpace($Text)) { return $null }
    $rxTxt = $null
    try { if ($RuleBank -and $RuleBank.ErrorBank -and $RuleBank.ErrorBank.ExtractRegex) { $rxTxt = $RuleBank.ErrorBank.ExtractRegex } } catch {}
    if (-not $rxTxt) { $rxTxt = '(?i)\b(?:error|err)?\s*(?:code)?\s*[:#]?\s*(?<Code>\d{3,})\b' }

    try {
        $m = [regex]::Match($Text, $rxTxt)
        if ($m.Success -and $m.Groups['Code'] -and $m.Groups['Code'].Value) {
            return $m.Groups['Code'].Value.ToUpperInvariant()
        }
    } catch {}
    return $null
}

function Convert-ToDoubleOrNull {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return $null }
    $t = ($Text + '').Trim()
    $t = $t -replace ',', '.'
    $v = $null
    if ([double]::TryParse($t, [System.Globalization.NumberStyles]::Any, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$v)) {
        return [double]$v
    }
    return $null
}

function Parse-SampleIdParts {
    param(
        [string]$SampleId,
        [pscustomobject]$RuleBank
    )

    $defaultResult = [pscustomobject]@{ Role=''; Id=''; Idx=''; Success=$false }
    if ([string]::IsNullOrWhiteSpace($SampleId)) { return $defaultResult }

    $pattern = '^(?<role>[A-Za-z0-9_]+)[-_](?<id>\d{1,4})[-_](?<idx>\d{1,3})$'
    try {
        if ($RuleBank -and $RuleBank.Global -and $RuleBank.Global.SampleId -and $RuleBank.Global.SampleId.Parse -and $RuleBank.Global.SampleId.Parse.Pattern) {
            $pattern = $RuleBank.Global.SampleId.Parse.Pattern
        }
    } catch {}

    try {
        $m = [regex]::Match($SampleId.Trim(), $pattern)
        if ($m.Success) {
            return [pscustomobject]@{
                Role    = if ($m.Groups['role']) { $m.Groups['role'].Value } else { '' }
                Id      = if ($m.Groups['id'])   { $m.Groups['id'].Value }   else { '' }
                Idx     = if ($m.Groups['idx'])  { $m.Groups['idx'].Value }  else { '' }
                Success = $true
            }
        }
    } catch {}
    return $defaultResult
}

function Add-FailureTag {
    param(
        [pscustomobject]$Row,
        [string]$RuleId,
        [string]$Severity
    )
    if (-not $Row) { return }

    if (-not $Row.FailureTags) { $Row.FailureTags = New-Object System.Collections.Generic.List[string] }
    if (-not $Row.FailureTags.Contains($RuleId)) { [void]$Row.FailureTags.Add($RuleId) }
    if (-not $Row.PrimaryRule) { $Row.PrimaryRule = $RuleId }

    $cur  = Get-SeverityRank $Row.Severity
    $next = Get-SeverityRank $Severity
    if ($next -gt $cur) { $Row.Severity = $Severity }
}

function Get-AssayRuleProfile {
    param(
        [string]$Canonical,
        [pscustomobject]$RuleBank
    )

    $profile = $null
    $keyUsed = $null

    try {
        if ($RuleBank -and $RuleBank.AssayProfiles) {
            if ($Canonical -and (Test-MapHasKey $RuleBank.AssayProfiles $Canonical)) {
                $profile = $RuleBank.AssayProfiles[$Canonical]
                $keyUsed = $Canonical
            } elseif (Test-MapHasKey $RuleBank.AssayProfiles '_DEFAULT') {
                $profile = $RuleBank.AssayProfiles['_DEFAULT']
                $keyUsed = '_DEFAULT'
            } elseif (Test-MapHasKey $RuleBank.AssayProfiles 'default') {
                $profile = $RuleBank.AssayProfiles['default']
                $keyUsed = 'default'
            }
        }
    } catch {}

    if (-not $profile) {
        $profile = [ordered]@{ Mode='GlobalOnly'; Description='Fallback profile'; DisplayName='_DEFAULT' }
        $keyUsed = '_DEFAULT'
    }

    return [pscustomobject]@{
        Profile = $profile
        Key     = $keyUsed
        Mode    = if ($profile -and $profile.Mode) { $profile.Mode } else { '' }
    }
}
