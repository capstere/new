if (-not $script:TestsSummaryBundleCache) { $script:TestsSummaryBundleCache = @{} }

function Read-AllLinesAuto {
    param([string]$Path)

    $fs = [IO.File]::Open($Path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
    try {
        $sr = New-Object IO.StreamReader($fs, [Text.Encoding]::UTF8, $true)
        $lines = New-Object System.Collections.Generic.List[string]
        while (-not $sr.EndOfStream) { $lines.Add($sr.ReadLine()) }
        $sr.Close()
        return ,$lines.ToArray()
    } finally {
        $fs.Dispose()
    }
}

function Count-SeparatorsOutsideQuotes {
    param([string]$line, [char]$sep)
    $inQ = $false
    $cnt = 0
    for ($i=0; $i -lt $line.Length; $i++) {
        $ch = $line[$i]
        if ($ch -eq '"') {
            if ($inQ -and $i+1 -lt $line.Length -and $line[$i+1] -eq '"') { $i++; continue }
            $inQ = -not $inQ
            continue
        }
        if (-not $inQ -and $ch -eq $sep) { $cnt++ }
    }
    return $cnt
}

function Detect-Delimiter {
    param([string]$line)
    $cComma = Count-SeparatorsOutsideQuotes -line $line -sep ','
    $cSemi  = Count-SeparatorsOutsideQuotes -line $line -sep ';'
    $cTab   = Count-SeparatorsOutsideQuotes -line $line -sep "`t"

    if ($cSemi -gt $cComma -and $cSemi -ge $cTab) { return ';' }
    if ($cTab  -gt $cComma -and $cTab  -ge $cSemi) { return "`t" }
    return ','
}

function Parse-CsvLine {
    param([string]$line, [string]$delim)

    $vals = New-Object System.Collections.Generic.List[string]
    $sb = New-Object System.Text.StringBuilder
    $inQ = $false
    $d = [char]$delim

    for ($i=0; $i -lt $line.Length; $i++) {
        $ch = $line[$i]

        if ($ch -eq '"') {
            if ($inQ -and $i+1 -lt $line.Length -and $line[$i+1] -eq '"') {
                [void]$sb.Append('"'); $i++; continue
            }
            $inQ = -not $inQ
            continue
        }

        if (-not $inQ -and $ch -eq $d) {
            $vals.Add($sb.ToString()) | Out-Null
            $sb.Length = 0
            continue
        }

        [void]$sb.Append($ch)
    }

    $vals.Add($sb.ToString()) | Out-Null
    return ,$vals.ToArray()
}

function ConvertTo-CsvFields {
    param([string]$Line)
    return [regex]::Split($Line, ',(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)')
}

function Get-CsvDelimiter {
    param([string]$Path)
    try {
        $first = Get-Content -LiteralPath $Path -Encoding Default -TotalCount 30 | Where-Object { $_ -and $_.Trim() } | Select-Object -First 1
        if (-not $first) { return ';' }
        $sc = ($first -split ';').Count; $cc = ($first -split ',').Count
        if ($cc -gt $sc -and $cc -ge 2) { return ',' } else { return ';' }
    } catch {
        Gui-Log "⚠️ Get-CsvDelimiter misslyckades: $($_.Exception.Message)" 'Warn'
        return ';'
    }
}

function New-TextFieldParser {
    param([string]$Path,[string]$Delimiter)
    try {
        $tp = New-Object Microsoft.VisualBasic.FileIO.TextFieldParser($Path, [System.Text.Encoding]::Default)
        $tp.TextFieldType = [Microsoft.VisualBasic.FileIO.FieldType]::Delimited
        $tp.SetDelimiters($Delimiter)
        $tp.HasFieldsEnclosedInQuotes = $true
        $tp.TrimWhiteSpace = $true
        return $tp
    } catch {
        Gui-Log "⚠️ New-TextFieldParser: $($_.Exception.Message)" 'Warn'
        return $null
    }
}

function Find-TestsSummaryHeaderRowIndex {
    param([string[]]$Lines)
    if (-not $Lines) { return -1 }
    $max = [Math]::Min(80, $Lines.Count - 1)
    for ($i = 0; $i -le $max; $i++) {
        $l = ($Lines[$i] + '').Trim()
        if ($l.Length -lt 10) { continue }
        if ($l -match '(?i)\bassay\b' -and $l -match '(?i)\btest\s*type\b') {
            return $i
        }
    }
    return -1
}

function Find-TestsSummaryDataStartRowIndex {
    param([string[]]$Lines, [int]$HeaderRowIndex)
    if (-not $Lines -or $HeaderRowIndex -lt 0) { return -1 }
    $max = [Math]::Min($Lines.Count - 1, $HeaderRowIndex + 30)
    for ($i = $HeaderRowIndex + 1; $i -le $max; $i++) {
        $l = ($Lines[$i] + '').Trim()
        if ($l.Length -eq 0) { continue }
        return $i
    }
    return ($HeaderRowIndex + 1)
}

function Find-HeaderRowIndex {
    param([string[]]$lines, [int]$maxScan = 80)

    $need = @(
        'assay',
        'assay version',
        'reagent lot id',
        'sample id',
        'cartridge s/n'
    )

    $max = [Math]::Min($lines.Count-1, $maxScan-1)
    for ($i=0; $i -le $max; $i++) {
        $line = $lines[$i]
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        $delim = Detect-Delimiter -line $line
        $cols = Parse-CsvLine -line $line -delim $delim

        $hits = 0
        foreach ($c in $cols) {
            $h = Normalize-HeaderName $c
            if ($need -contains $h) { $hits++ }
        }

        if ($hits -ge 3) { return @{ Index=$i; Delim=$delim } }
    }

    for ($i=0; $i -lt $lines.Count; $i++) {
        if (-not [string]::IsNullOrWhiteSpace($lines[$i])) { return @{ Index=$i; Delim=(Detect-Delimiter -line $lines[$i]) } }
    }
    return @{ Index=0; Delim=',' }
}

function Find-DataStartRowIndex {
    param([string[]]$lines, [int]$headerIndex, [string]$delim, [string[]]$headers)

    $hCount = $headers.Count
    for ($i=$headerIndex+1; $i -lt $lines.Count; $i++) {
        $line = $lines[$i]
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        $cols = Parse-CsvLine -line $line -delim $delim

        $nonEmpty = ($cols | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }).Count
        if ($cols.Count -ge [Math]::Max(5, [int]($hCount*0.5)) -and $nonEmpty -ge 3) {
            return $i
        }
    }
    return ($headerIndex + 1)
}

function Get-TestsSummaryBundle {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) { return $null }

    $fi = Get-Item -LiteralPath $Path -ErrorAction SilentlyContinue
    $key = $Path.ToLowerInvariant()
    $stamp = if ($fi) { $fi.LastWriteTimeUtc.Ticks } else { 0 }

    $cached = $script:TestsSummaryBundleCache[$key]
    if ($cached -and $cached.Stamp -eq $stamp) { return $cached.Bundle }

    $lines = $null
    try { $lines = Read-AllLinesAuto -Path $Path } catch {
        if (Get-Command Gui-Log -ErrorAction SilentlyContinue) {
            Gui-Log ("⚠️ Kunde inte läsa CSV: " + $_.Exception.Message) 'Warn'
        }
        return $null
    }

    if (-not $lines -or $lines.Count -eq 0) {
        return [pscustomobject]@{
            Path              = $Path
            Lines             = $lines
            Delimiter         = ','
            HeaderRowIndex    = 0
            HeaderRowNumber   = 1
            DataStartRowIndex = 0
            DataStartRowNumber= 1
            Headers           = @()
            HeaderIndex       = @{}
            RowCount          = 0
        }
    }

    $hdr = Find-HeaderRowIndex -lines $lines
    $headerRow = [int]$hdr.Index
    $delim = [string]$hdr.Delim

    $headers = Parse-CsvLine -line $lines[$headerRow] -delim $delim
    $headerIndex = @{}

    for ($i=0; $i -lt $headers.Count; $i++) {
        $norm = Normalize-HeaderName $headers[$i]
        if (-not [string]::IsNullOrWhiteSpace($norm) -and -not $headerIndex.ContainsKey($norm)) {
            $headerIndex[$norm] = $i
        }
    }

    $dataStart = Find-DataStartRowIndex -lines $lines -headerIndex $headerRow -delim $delim -headers $headers

    $bundle = [pscustomobject]@{
        Path              = $Path
        Lines             = $lines
        Delimiter         = $delim
        HeaderRowIndex    = $headerRow
        HeaderRowNumber   = ($headerRow + 1)
        DataStartRowIndex = $dataStart
        DataStartRowNumber= ($dataStart + 1)
        Headers           = $headers
        HeaderIndex       = $headerIndex
        RowCount          = ($lines.Count - $dataStart)
    }

    $script:TestsSummaryBundleCache[$key] = [pscustomobject]@{ Stamp = $stamp; Bundle = $bundle }
    return $bundle
}

function Get-AssayFromCsv {
    param([string]$Path,[int]$StartRow=10)
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    $tp = $null; $delim=Get-CsvDelimiter $Path; $row=0
    try {
        $tp = New-TextFieldParser -Path $Path -Delimiter $delim
        if (-not $tp) { return $null }
        while (-not $tp.EndOfData) {
            $row++; $f = $tp.ReadFields()
            if ($row -lt $StartRow) { continue }
            if (-not $f -or $f.Length -lt 1) { continue }
            $a=([string]$f[0]).Trim()
            if ($a -and $a -notmatch '^(?i)\s*assay\s*$') { return $a }
        }
    } catch {
        Gui-Log "⚠️ Get-AssayFromCsv: $($_.Exception.Message)" 'Warn'
    } finally { if ($tp){$tp.Close()} }
    return $null
}

function Import-CsvRows {
    param([string]$Path,[int]$StartRow=10)
    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    $delim=Get-CsvDelimiter $Path; $tp=$null; $rows=@()
    try {
        $tp = New-TextFieldParser -Path $Path -Delimiter $delim
        if (-not $tp) { return @() }
        $r=0
        while (-not $tp.EndOfData) {
            $r++; $f=$tp.ReadFields()
            if ($r -lt $StartRow) { continue }
            if (-not $f -or ($f -join '').Trim().Length -eq 0) { continue }
            $rows += ,$f
        }
    } catch {
        Gui-Log "⚠️ Import-CsvRows: $($_.Exception.Message)" 'Warn'
    } finally { if ($tp){$tp.Close()} }
    return ,@($rows)
}

function Get-CsvStats {
    param(
        [string]$Path,
        [string[]]$Lines,
        [pscustomobject]$Bundle
    )
    $out = [ordered]@{
        TestCount       = 0
        DupCount        = 0
        Duplicates      = @()
        LspValues       = @()
        LspOK           = $null
        InstrumentByType= [ordered]@{}
    }
    $lines = $Lines
    if (-not $lines) {
        if (-not (Test-Path -LiteralPath $Path)) { return [pscustomobject]$out }
        try { $lines = Get-Content -LiteralPath $Path } catch { Gui-Log "⚠️ Get-CsvStats: $($_.Exception.Message)" 'Warn'; return [pscustomobject]$out }
    }
    if (-not $lines -or $lines.Count -lt 8) { return [pscustomobject]$out }
    $hdrIdx = 7
    $dataIdx = 9
    if ($Bundle) {
        if ($Bundle.HeaderRowIndex -ge 0) { $hdrIdx = [int]$Bundle.HeaderRowIndex }
        if ($Bundle.DataStartRowIndex -ge 0) { $dataIdx = [int]$Bundle.DataStartRowIndex }
    } else {
        $tmp = Find-TestsSummaryHeaderRowIndex -Lines $lines
        if ($tmp -ge 0) { $hdrIdx = $tmp }
        $dataIdx = Find-TestsSummaryDataStartRowIndex -Lines $lines -HeaderRowIndex $hdrIdx
        if ($dataIdx -lt 0) { $dataIdx = ($hdrIdx + 2) }
    }
    $header = ConvertTo-CsvFields $lines[$hdrIdx]
    $dataLines = @()
    if ($lines.Count -gt $dataIdx) { $dataLines = $lines[$dataIdx..($lines.Count-1)] }
    $csv = $null
    try {
        if ($dataLines.Count -gt 0) {
            $csv = ConvertFrom-Csv -InputObject ($dataLines -join "`n") -Header $header
        }
    } catch { $csv = $null }

    $cartSnList = New-Object System.Collections.Generic.List[string]
    $lspList    = New-Object System.Collections.Generic.List[string]
    $instrList  = New-Object System.Collections.Generic.List[string]
    if ($csv) {
        foreach ($row in $csv) {
            $cart = $row.'Cartridge S/N'
            $lsp  = $row.'Reagent Lot ID'
            $ins  = $row.'Instrument S/N'
            if (-not $cart) { try { $cart = $row.Item(3) } catch {} }
            if (-not $ins)  { try { $ins  = $row.Item(6) } catch {} }
            if ($cart) { $cartSnList.Add( ($cart + '').Trim() ) }
            if ($lsp)  { $lspList.Add(  ($lsp  + '').Trim() ) }
            if ($ins)  { $instrList.Add(($ins  + '').Trim() ) }
        }
    } else {
        foreach ($ln in $dataLines) {
            if (-not $ln -or -not $ln.Trim()) { continue }
            $f = ConvertTo-CsvFields $ln
            if ($f.Count -lt 7) { continue }
            $cartSnList.Add( ($f[3] + '').Trim() )
            $lspList.Add(    ($f[4] + '').Trim() )
            $instrList.Add(  ($f[6] + '').Trim() )
        }
    }
    $cartSn = $cartSnList | Where-Object { $_ -and $_ -ne '' }
    $out.TestCount = @($cartSn).Count
    $dups = $cartSn | Group-Object | Where-Object { $_.Count -gt 1 }
    if ($dups) {
        $out.DupCount   = $dups.Count
        $out.Duplicates = $dups | ForEach-Object { "$($_.Name) x$($_.Count)" }
    }
    $lspClean = $lspList | ForEach-Object {
        $m = [regex]::Match($_, '(?<!\d)(\d{5})(?!\d)')
        if ($m.Success) { $m.Groups[1].Value } else { $null }
    } | Where-Object { $_ } | Select-Object -Unique
    $out.LspValues = $lspClean
    if ($lspClean.Count -gt 0) {
        $out.LspOK = ($lspClean.Count -eq 1)
    }
    $lut = @{}
    foreach ($k in $script:GXINF_Map.Keys) {
        $codes = $script:GXINF_Map[$k].Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ }
        foreach ($code in $codes) { $lut[$code] = $k }
    }
    foreach ($ins in ($instrList | Where-Object { $_ })) {
        $t = $null
        if ($lut.ContainsKey($ins)) { $t = $lut[$ins] } else { $t = 'Unknown' }
        if (-not $out.InstrumentByType.Contains($t)) { $out.InstrumentByType[$t] = 0 }
        $out.InstrumentByType[$t]++
    }
    return [pscustomobject]$out
}

function Format-SpPresenceGrandTotalStrict {
    param([hashtable]$Counts)
    if (-not $Counts -or $Counts.Count -eq 0) { return '—' }
    $present = @(
        $Counts.GetEnumerator() |
        Where-Object { $_.Value -gt 0 } |
        ForEach-Object { [int]$_.Key } |
        Sort-Object
    )
    if ($present.Count -eq 0) { return '—' }
    $parts = New-Object System.Collections.Generic.List[string]
    $i = 0
    while ($i -lt $present.Count) {
        $start = $present[$i]; $end = $start
        $j = $i + 1
        while ($j -lt $present.Count -and $present[$j] -eq $end + 1) {
            $end = $present[$j]; $j++
        }
        if ($start -eq $end) { $parts.Add( ('#{0:00}' -f $start) ) }
        else { $parts.Add( ('#{0:00}-{1:00}' -f $start, $end) ) }
        $i = $j
    }
    $total = (
        $Counts.GetEnumerator() |
        Where-Object { $_.Value -gt 0 } |
        Measure-Object -Property Value -Sum
    ).Sum
    return ( ($parts -join '+') + (' x{0}' -f $total) )
}

function Get-InfinitySpFromCsvStrict {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Alias('InfinitySerials')][string[]]$InstrumentSerials,
        [string[]]$Lines
    )
    if (-not $Lines -and -not (Test-Path -LiteralPath $Path)) { return '—' }
    $useConvertFn = $false
    try { $useConvertFn = [bool](Get-Command ConvertTo-CsvFields -ErrorAction Stop) } catch {}
    function Split-CsvSmart([string]$ln) {
        if ($ln -like '*;*' -and $ln -notlike '*,*') {
            return [regex]::Split($ln, ';(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)')
        } else {
            return [regex]::Split($ln, ',(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)')
        }
    }

    $serSet = New-Object System.Collections.Generic.HashSet[string]([StringComparer]::OrdinalIgnoreCase)
    foreach ($s in ($InstrumentSerials | Where-Object { $_ })) { $null = $serSet.Add( ($s + '').Trim().Trim('"') ) }
    if ($serSet.Count -eq 0) { return '—' }

    $lines = $Lines
    if (-not $lines) {
        try { $lines = Get-Content -LiteralPath $Path } catch { Gui-Log "⚠️ Get-InfinitySpFromCsvStrict: $($_.Exception.Message)" 'Warn'; return '—' }
    }
    if (-not $lines -or $lines.Count -lt 10) { return '—' }

    $headerIndex = 7
    $dataStart   = 9

    $hdr = if ($useConvertFn) { ConvertTo-CsvFields $lines[$headerIndex] } else { Split-CsvSmart $lines[$headerIndex] }
    $colCount = $hdr.Count

    $idxInstr = -1
    for ($i=0; $i -lt $colCount; $i++) {
        $h = (($hdr[$i] + '') -replace '[\uFEFF\u200B]','').Trim().ToLowerInvariant()
        if ($h -match 'instrument' -and ($h -match 's/?n' -or $h -match 'serial')) { $idxInstr = $i; break }
    }
    if ($idxInstr -lt 0) { $idxInstr = 6 }
    $idxSample = 2
    $counts = @{}

    for ($r = $dataStart; $r -lt $lines.Count; $r++) {
        $ln = $lines[$r]; if (-not $ln -or -not $ln.Trim()) { continue }
        $f = if ($useConvertFn) { ConvertTo-CsvFields $ln } else { Split-CsvSmart $ln }
        if ($f.Count -le [Math]::Max($idxInstr,$idxSample)) { continue }

        $instr  = ($f[$idxInstr] + '').Trim().Trim('"')
        if (-not $serSet.Contains($instr)) { continue }

        $sample = ($f[$idxSample] + '').Trim().Trim('"')
        if (-not $sample) { continue }

        $m = [regex]::Match($sample, '_(\d{2})_')
        if ($m.Success) {
            $nRaw = 0
            if ([int]::TryParse($m.Groups[1].Value, [ref]$nRaw)) {
                $sp = $nRaw
                if ($sp -ge 0 -and $sp -le 10) {
                    if (-not $counts.ContainsKey($sp)) { $counts[$sp] = 0 }
                    $counts[$sp]++
                }
            }
        }
    }

    if ($counts.Count -eq 0) { return '—' }
    return (Format-SpPresenceGrandTotalStrict -Counts $counts)
}
