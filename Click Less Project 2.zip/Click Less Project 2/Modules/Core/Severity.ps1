$script:SeverityOrder = @{
    'Error' = 3
    'Warn'  = 2
    'Info'  = 1
}

function Get-SeverityRank {
    param([string]$Severity)
    $k = ($Severity + '').Trim()
    if ($script:SeverityOrder.ContainsKey($k)) { return $script:SeverityOrder[$k] }
    return 0
}
