# RuleBank Configuration Guide

## Filhierarki
- 01_ResultCallPatterns.csv: Tolkar "Test Result" → Call (POS/NEG/ERROR)
- 02_SampleExpectationRules.csv: Förväntat call baserat på Sample ID
- 03_ErrorCodes.csv: Felkodsmappning (inkl. intervall)
- 04_MissingSamplesConfig.csv: Konfig för saknade samples (template)
- 05_SampleIdMarkers.csv: Markers/tokenindex för Sample ID
- 06_ParityCheckConfig.csv: Parity/suffix-logik per assay
- 07_SampleNumberRules.csv: Sample-nummerregler (regex, min/max, padding)

## Lägga till nytt assay (checklista)
1. Lägg till patterns i 01_ResultCallPatterns.csv
2. Lägg till expectations i 02_SampleExpectationRules.csv
3. Lägg till markers i 05_SampleIdMarkers.csv (om behövs)
4. Lägg till parity-config i 06_ParityCheckConfig.csv (om behövs)
5. Lägg till sample-number-regler i 07_SampleNumberRules.csv


## 08_AssayObservedCallRules.csv (NEW)

Purpose: data-driven fallback for mapping raw **Test Result** text to ObservedCall (POS/NEG/ERROR) for **non-MTB assays**, used **only** when 01_ResultCallPatterns does not match.

Schema:
- AssayPattern (wildcard or regex if AssayMatchType=REGEX)
- AssayMatchType: WILDCARD (default) or REGEX
- PosRegex / NegRegex / ErrRegex (regex evaluated against Test Result)
- PosWins (TRUE/FALSE) when both PosRegex and NegRegex match (multi-target strings)
- Enabled, Priority, Note

Notes:
- MTB assays are excluded in code (handled by MTB-specific logic / patterns).

## 06_ParityCheckConfig.csv change

The template row with AssayPattern="*" is now **Enabled = False** to avoid accidental SUFFIX checking on assays that do not follow X/+ naming. Enable per-assay rows instead.
