param(
    [string]$ScriptRoot = (Split-Path -Parent $MyInvocation.MyCommand.Path)
)

# --- Patch: Centraliserad IPT-root (ENV override) ---
$script:ScriptRoot = $ScriptRoot
$script:DefaultIptRoot = 'N:\QC\QC-1\IPT'
$script:IPTRoot = if ($env:IPT_ROOT -and $env:IPT_ROOT.Trim().Length -gt 0) { $env:IPT_ROOT.TrimEnd('\\') } else { $script:DefaultIptRoot }

function Resolve-IptPath {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return $Path }
    if ($Path -like "$($script:DefaultIptRoot)\*") {
        return ($script:IPTRoot + $Path.Substring($script:DefaultIptRoot.Length))
    }
    return $Path
}
# -------------------------------------------------

# === Inställningar ===
$ScriptVersion = "v45.1.0"

$RootPaths = @(
    'N:\QC\QC-1\IPT\Skiftspecifika dokument\PQC analyst\JESPER\Scripts\Tests',
    'N:\QC\QC-1\IPT\3. IPT - KLART FÖR SAMMANSTÄLLNING',
    'N:\QC\QC-1\IPT\4. IPT - KLART FÖR GRANSKNING'
)

$RootPaths = $RootPaths | ForEach-Object { Resolve-IptPath $_ }

$ikonSokvag = Join-Path $ScriptRoot "icon.png"
$UtrustningListPath = "N:\QC\QC-1\IPT\Skiftspecifika dokument\PQC analyst\JESPER\Scripts\Click Less Project\Utrustninglista5.0.xlsx"
$RawDataPath        = "N:\QC\QC-1\IPT\KONTROLLPROVSFIL - Version 2.5.xlsm"
$SlangAssayPath     = "N:\QC\QC-1\IPT\Skiftspecifika dokument\PQC analyst\JESPER\Scripts\Click Less Project\Click Less Project\slangassay.xlsx"

$OtherScriptPath = ''

$Script1Path  = 'N:\QC\QC-1\IPT\Skiftspecifika dokument\PQC analyst\JESPER\Kontrollprovsfil 2025\Script Raw Data\Kontrollprovsfil_EPPlus_2025.ps1'
$Script2Path  = 'N:\QC\QC-1\IPT\Skiftspecifika dokument\PQC analyst\JESPER\Scripts\Click Less Project\rename-GUI.bat'
$Script3Path  = 'N:\QC\QC-1\IPT\Skiftspecifika dokument\PQC analyst\JESPER\Scripts\Click Less Project\rename-GUI.bat'

$env:PNPPOWERSHELL_UPDATECHECK = "Off"
$global:SP_ClientId   = "INSERT MYSELF"
$global:SP_Tenant     = "danaher.onmicrosoft.com"
$global:SP_CertBase64 = "INSERT MYSELF"
$global:SP_SiteUrl    = "https://danaher.sharepoint.com/sites/CEP-Sweden-Production-Management"

# === Centraliserad konfiguration ===
$Config = [ordered]@{

    # === Feature flags (safe defaults) ===
    EnableEquipmentScan = $true       # WS equipment table scan can be slow
    EnableRuleEngine    = $true       # New RuleEngine (shadow-mode)
    EnableShadowCompare = $true        # Log diff between legacy and rules when EnableRuleEngine is on
    EnableRuleEngineDebugSheet = $true        # Add RuleEngine_Debug worksheet to output (safe, appended)
    RuleBankDir         = (Join-Path $ScriptRoot 'RuleBank')
    CsvStreamingThresholdMB = 25   # Byt till t.ex. 10 om du vill streama tidigare
    CsvPath       = ''           # Sökväg till CSV-fil
    SealNegPath   = ''           # Sökväg till Seal Test NEG
    SealPosPath   = ''           # Sökväg till Seal Test POS
    WorksheetPath = ''           # Sökväg till LSP worksheet (Worksheet.xlsx)
    SiteUrl      = $global:SP_SiteUrl
    Tenant       = $global:SP_Tenant
    ClientId     = $global:SP_ClientId
    Certificate  = $global:SP_CertBase64
    EpplusDllPath = (Join-Path $ScriptRoot 'EPPlus.dll')
    EpplusVersion = '4.5.3.3'
}

$script:GXINF_Map = @{
    'Infinity-VI'   = '847922'
    'Infinity-VIII' = '803094'
    'GX5'           = '750210,750211,750212,750213'
    'GX6'           = '750246,750247,750248,750249'
    'GX1'           = '709863,709864,709865,709866'
    'GX2'           = '709951,709952,709953,709954'
    'GX3'           = '710084,710085,710086,710087'
    'GX7'           = '750170,750171,750172,750213'
    'Infinity-I'    = '802069'
    'Infinity-III'  = '807363'
    'Infinity-V'    = '839032'
}

$SharePointBatchLinkTemplate = 'https://danaher.sharepoint.com/sites/CEP-Sweden-Production-Management/Lists/Cepheid%20%20Production%20orders/ROBAL.aspx?viewid=6c9e53c9-a377-40c1-a154-13a13866b52b&view=7&q={BatchNumber}'

$DevLogDir = Join-Path $ScriptRoot 'Loggar'
if (-not (Test-Path $DevLogDir)) { New-Item -ItemType Directory -Path $DevLogDir -Force | Out-Null }
$global:LogPath = Join-Path $DevLogDir ("$($env:USERNAME)_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt")
$global:StructuredLogPath = [System.IO.Path]::ChangeExtension($global:LogPath, '.jsonl')

function Test-Config {
    $result = [pscustomobject]@{
        Ok       = $true
        Errors   = New-Object System.Collections.Generic.List[object]
        Warnings = New-Object System.Collections.Generic.List[object]
    }

    try {
        $templatePath = Join-Path $ScriptRoot 'output_template-v4.xlsx'
        if (-not (Test-Path -LiteralPath $templatePath)) {
            $null = $result.Errors.Add("Mallfil saknas: $templatePath")
        }
    } catch {
        $null = $result.Errors.Add("Test-Config (template): $($_.Exception.Message)")
    }
    try {
        if (-not (Test-Path -LiteralPath $UtrustningListPath)) {
            $null = $result.Warnings.Add("Utrustningslista saknas: $UtrustningListPath")
        }
    } catch {
        $null = $result.Warnings.Add("Test-Config (utrustning): $($_.Exception.Message)")
    }

    try {

        if (-not (Test-Path -LiteralPath $RawDataPath)) {
            $null = $result.Warnings.Add("Kontrollprovsfil saknas: $RawDataPath")
        }
    } catch {
        $null = $result.Warnings.Add("Test-Config (rawdata): $($_.Exception.Message)")
    }
    try {
        if (-not (Test-Path -LiteralPath $SlangAssayPath)) {
            $null = $result.Warnings.Add("Slang/assay-tabell saknas: $SlangAssayPath")
        }
    } catch {
        $null = $result.Warnings.Add("Test-Config (slang/assay): $($_.Exception.Message)")
    }
    try {
        if (-not (Test-Path -LiteralPath $DevLogDir)) {
            New-Item -ItemType Directory -Path $DevLogDir -Force | Out-Null
        }
        $probe = Join-Path $DevLogDir "write_probe.txt"
        Set-Content -Path $probe -Value 'probe' -Encoding UTF8 -Force
        Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
    } catch {
        $null = $result.Warnings.Add("Kunde inte verifiera skrivning till loggmapp: $($_.Exception.Message)")
    }
    if ($result.Errors.Count -gt 0) { $result.Ok = $false }
    return $result

}

# Patch: ENV root override för ikonSokvag
$ikonSokvag = Resolve-IptPath $ikonSokvag

# Patch: ENV root override för UtrustningListPath
$UtrustningListPath = Resolve-IptPath $UtrustningListPath

# Patch: ENV root override för RawDataPath
$RawDataPath = Resolve-IptPath $RawDataPath

# Patch: ENV root override för SlangAssayPath
$SlangAssayPath = Resolve-IptPath $SlangAssayPath

# Patch: ENV root override för OtherScriptPath
$OtherScriptPath = Resolve-IptPath $OtherScriptPath

# Patch: ENV root override för Script1Path
$Script1Path = Resolve-IptPath $Script1Path

# Patch: ENV root override för Script2Path
$Script2Path = Resolve-IptPath $Script2Path

# Patch: ENV root override för Script3Path
$Script3Path = Resolve-IptPath $Script3Path
