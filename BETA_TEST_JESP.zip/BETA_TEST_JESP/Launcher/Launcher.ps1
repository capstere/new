﻿# Launcher.ps1 (Windows PowerShell 5.1)
# Cache-first runner for IPTCompile
#
# Behavior:
# 1) First run: copy project from network to C:\IPTCompile then run locally
# 2) Subsequent runs: run locally directly; only recopy if Version.txt changed
#
# The launcher sets IPT_NETWORK_ROOT to the network project root so logs/audits
# end up on N: even when the tool runs from local cache.

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# ----------------------------- Settings -----------------------------
$AppName            = 'IPTCompile'
$CacheRoot          = 'C:\IPTCompile'
$AuditFolderName    = '_LauncherAudit'
$VersionFileName    = 'Version.txt'
$SourcePathFileName = 'SourcePath.txt'

# Robocopy tuning (safe defaults for SMB shares)
$RoboCopyMT   = 8
$RoboRetries  = 2
$RoboWaitSec  = 1

# Exclude folders that should stay on the network only (avoid churn and oversized cache)
$ExcludeDirs = @($AuditFolderName, 'Loggar', 'audit')

# ----------------------------- Helpers -----------------------------
function Get-ScriptDir {
    if ($PSScriptRoot) { return $PSScriptRoot }
    if ($PSCommandPath) { return (Split-Path -LiteralPath $PSCommandPath -Parent) }
    return (Get-Location).Path
}

function Read-FirstNonEmptyLine([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    foreach ($line in [System.IO.File]::ReadAllLines($Path)) {
        $t = ($line + '').Trim()
        if ($t) {
            # Strip optional surrounding quotes
            if ($t.StartsWith('"') -and $t.EndsWith('"') -and $t.Length -ge 2) {
                $t = $t.Substring(1, $t.Length - 2)
            }
            return $t.Trim()
        }
    }
    return $null
}

function Ensure-DirWritable([string]$Path) {
    try {
        if (-not (Test-Path -LiteralPath $Path)) {
            New-Item -Path $Path -ItemType Directory -Force | Out-Null
        }
        $probe = Join-Path $Path ("._probe_{0}.tmp" -f [Guid]::NewGuid().ToString('N'))
        [System.IO.File]::WriteAllText($probe, 'ok')
        Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
        return $true
    } catch {
        return $false
    }
}

function Normalize-Version([string]$v) {
    $t = ($v + '').Trim()
    if (-not $t) { return '0' }
    return $t
}

function Write-Audit {
    param(
        [string]$AuditDir,
        [string]$Message,
        [ValidateSet('INFO','WARN','ERROR')] [string]$Level = 'INFO'
    )
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = '[{0}] [{1}] {2}' -f $ts, $Level, $Message

    Write-Host $line
    if (-not $AuditDir) { return }

    try {
        if (-not (Test-Path -LiteralPath $AuditDir)) {
            New-Item -Path $AuditDir -ItemType Directory -Force | Out-Null
        }
        $logPath = Join-Path $AuditDir 'Launcher.log'
        Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
    } catch {
        # best-effort
    }
}

function Invoke-Robocopy {
    param(
        [string]$Source,
        [string]$Dest,
        [string[]]$ExcludeDirectories,
        [string]$LogFile
    )

    $args = New-Object System.Collections.Generic.List[string]
    $args.Add("`"$Source`"")
    $args.Add("`"$Dest`"")
    $args.Add('/MIR')
    $args.Add("/R:$RoboRetries")
    $args.Add("/W:$RoboWaitSec")
    $args.Add('/FFT')
    $args.Add('/XJ')
    $args.Add('/NP')
    $args.Add('/NFL')
    $args.Add('/NDL')
    $args.Add('/NJH')
    $args.Add('/NJS')
    $args.Add("/MT:$RoboCopyMT")

    foreach ($xd in ($ExcludeDirectories | Where-Object { $_ })) {
        # /XD can take full paths; use full path for safety
        $args.Add('/XD')
        $args.Add("`"$([System.IO.Path]::Combine($Source, $xd))`"")
    }

    if ($LogFile) {
        # Robocopy requires /LOG:<path> to be a single token
        $args.Add("/LOG:`"$LogFile`"")
    }

    $p = Start-Process -FilePath 'robocopy.exe' -ArgumentList $args.ToArray() -Wait -PassThru -WindowStyle Hidden
    return $p.ExitCode
}

function Safe-DeleteDir([string]$Path) {
    try {
        if (Test-Path -LiteralPath $Path) {
            Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop
        }
    } catch {
        # best-effort
    }
}

function Run-Main([string]$MainPath) {
    if ($script:SourceRoot) { $env:IPT_NETWORK_ROOT = $script:SourceRoot }
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $MainPath
    exit $LASTEXITCODE
}

# ----------------------------- Main -----------------------------
$scriptDir = Get-ScriptDir
$srcFile   = Join-Path $scriptDir $SourcePathFileName
$script:SourceRoot = Read-FirstNonEmptyLine -Path $srcFile

if (-not $script:SourceRoot) {
    Write-Host '[ERROR] Missing or empty SourcePath.txt next to Launcher.ps1'
    exit 1
}

$script:SourceRoot = $script:SourceRoot.TrimEnd('\')
$mainNet = Join-Path $script:SourceRoot 'Main.ps1'
if (-not (Test-Path -LiteralPath $mainNet)) {
    Write-Host ('[ERROR] SourcePath does not contain Main.ps1: {0}' -f $script:SourceRoot)
    exit 1
}

$auditDir = Join-Path $script:SourceRoot $AuditFolderName
Write-Audit -AuditDir $auditDir -Level INFO -Message ('Launcher start. SourceRoot={0}' -f $script:SourceRoot)

if (-not (Ensure-DirWritable -Path $CacheRoot)) {
    Write-Audit -AuditDir $auditDir -Level ERROR -Message ('Could not create writable cache folder: {0}. Running from network.' -f $CacheRoot)
    Run-Main -MainPath $mainNet
}

# Cache root is the project root on C: (no \app subfolder)
$dest  = $CacheRoot
# Use sibling folders for robust staging + rollback (avoid half-copied cache)
$old   = ($CacheRoot + '__old')
$stage = ($CacheRoot + '__staging')

# Keep robocopy log outside the cache (cache is swapped)
$rbBase = Join-Path $env:TEMP ($AppName + '_Launcher')
try { if (-not (Test-Path -LiteralPath $rbBase)) { New-Item -Path $rbBase -ItemType Directory -Force | Out-Null } } catch { }
$rbLog = Join-Path $rbBase 'robocopy_last.log'

# Guard against rundgång
try {
    $srcFull  = [System.IO.Path]::GetFullPath($script:SourceRoot)
    $destFull = [System.IO.Path]::GetFullPath($dest)
    if ($destFull.StartsWith($srcFull, [System.StringComparison]::OrdinalIgnoreCase) -or
        $srcFull.StartsWith($destFull, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw ('Safety check failed: Source and cache paths overlap. Source={0} Cache={1}' -f $srcFull, $destFull)
    }
} catch {
    Write-Audit -AuditDir $auditDir -Level ERROR -Message $_.Exception.Message
    Run-Main -MainPath $mainNet
}

# Versions
$netVerPath = Join-Path $script:SourceRoot $VersionFileName
$locVerPath = Join-Path $dest $VersionFileName

$vNet = Normalize-Version (Read-FirstNonEmptyLine -Path $netVerPath)
$vLoc = Normalize-Version (Read-FirstNonEmptyLine -Path $locVerPath)

$needCopy = $false
if (-not (Test-Path -LiteralPath (Join-Path $dest 'Main.ps1'))) { $needCopy = $true }
elseif (Test-Path -LiteralPath $netVerPath) {
    if ($vNet -ne $vLoc) { $needCopy = $true }
}

$mutexName = ('Global\{0}_CacheUpdate' -f $AppName)
$mutex = New-Object System.Threading.Mutex($false, $mutexName)
$haveMutex = $false

try {
    $haveMutex = $mutex.WaitOne(25000)
    if (-not $haveMutex) {
        Write-Audit -AuditDir $auditDir -Level WARN -Message 'Cache update lock busy. Will run existing cache if present.'
        $needCopy = $false
    }

    if ($needCopy) {
        Write-Audit -AuditDir $auditDir -Level INFO -Message ('Updating cache. Dest={0} vNet={1} vLoc={2}' -f $dest, $vNet, $vLoc)

        Safe-DeleteDir -Path $stage
        New-Item -Path $stage -ItemType Directory -Force | Out-Null

        $rc = Invoke-Robocopy -Source $script:SourceRoot -Dest $stage -ExcludeDirectories $ExcludeDirs -LogFile $rbLog
        Write-Audit -AuditDir $auditDir -Level INFO -Message ('Robocopy exit code={0} (0-7 OK, 8+ error). Log={1}' -f $rc, $rbLog)

        if ($rc -ge 8) {
            # Prefer existing cache if present (avoid forcing slow network run on transient copy errors)
            $localMain = Join-Path $dest 'Main.ps1'
            if (Test-Path -LiteralPath $localMain) {
                Write-Audit -AuditDir $auditDir -Level WARN -Message ("Robocopy failed (code=$rc). Using existing cache: $dest")
                Safe-DeleteDir -Path $stage
                Run-Main -MainPath $localMain
            } else {
                Write-Audit -AuditDir $auditDir -Level ERROR -Message ("Robocopy failed (code=$rc). No local cache found; running from network.")
                Safe-DeleteDir -Path $stage
                Run-Main -MainPath $mainNet
            }
        }

        # Swap with rollback
        Safe-DeleteDir -Path $old
        if (Test-Path -LiteralPath $dest) {
            try {
                Rename-Item -LiteralPath $dest -NewName (Split-Path -Leaf $old) -ErrorAction Stop
            } catch {
                Safe-DeleteDir -Path $dest
            }
        }

        try {
            Rename-Item -LiteralPath $stage -NewName (Split-Path -Leaf $dest) -ErrorAction Stop
        } catch {
            Write-Audit -AuditDir $auditDir -Level ERROR -Message ('Cache swap failed: {0}. Running from network.' -f $_.Exception.Message)
            Safe-DeleteDir -Path $dest
            if (Test-Path -LiteralPath $old) {
                try { Rename-Item -LiteralPath $old -NewName (Split-Path -Leaf $dest) -ErrorAction SilentlyContinue } catch { }
            }
            Run-Main -MainPath $mainNet
        }

        $mainLocal = Join-Path $dest 'Main.ps1'
        if (-not (Test-Path -LiteralPath $mainLocal)) {
            Write-Audit -AuditDir $auditDir -Level ERROR -Message 'Cache missing Main.ps1 after swap. Rolling back + running from network.'
            Safe-DeleteDir -Path $dest
            if (Test-Path -LiteralPath $old) {
                try { Rename-Item -LiteralPath $old -NewName (Split-Path -Leaf $dest) -ErrorAction SilentlyContinue } catch { }
            }
            Run-Main -MainPath $mainNet
        }

        if (Test-Path -LiteralPath $netVerPath) {
            try { Set-Content -LiteralPath (Join-Path $dest $VersionFileName) -Value $vNet -Encoding ASCII } catch { }
        }

        Safe-DeleteDir -Path $old
    } else {
        Write-Audit -AuditDir $auditDir -Level INFO -Message ('Cache up-to-date. vLoc={0}' -f $vLoc)
    }

} finally {
    if ($haveMutex) { try { $mutex.ReleaseMutex() } catch { } }
    $mutex.Dispose()
}

$mainLocalFinal = Join-Path $dest 'Main.ps1'
Write-Audit -AuditDir $auditDir -Level INFO -Message ('Running locally: {0}' -f $mainLocalFinal)
Run-Main -MainPath $mainLocalFinal