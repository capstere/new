/* ClickLess Offline Analyzer v7 (CSV)
   - ES5 only (no const/let/arrow/template/module/async)
   - Offline XLSX reader: ZIP + raw DEFLATE (inflateRaw)
   - Reads: Seal Test NEG/POS (.xlsx), Worksheet (.xlsx), Test Summary (.csv)
   - Shows results on the page (no downloads).
*/

(function () {
  'use strict';

  // ----------------------------
  // Embedded RuleSheets (generated from Specification.xlsx)
  // ----------------------------
  var DEFAULT_RULES = {"resultCallPatterns":[{"Priority":2000,"AssayPattern":"CARBA[-\\s]R\\ IUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"IMP1 DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED","Call":"POS","Notes":"From Specification.xlsx sheet=CARBA, sampleGroup=1"},{"Priority":2000,"AssayPattern":"CARBA[-\\s]R\\ IUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"IMP1 NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=CARBA, sampleGroup=0"},{"Priority":2000,"AssayPattern":"CARBA[-\\s]R\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"IMP DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED","Call":"POS","Notes":"From Specification.xlsx sheet=CARBA, sampleGroup=1"},{"Priority":2000,"AssayPattern":"CARBA[-\\s]R\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"IMP NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=CARBA, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Carba[-\\s]R\\ BEU\\ IUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"IMP DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED","Call":"POS","Notes":"From Specification.xlsx sheet=CARBA, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Carba[-\\s]R\\ BEU\\ IUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"IMP NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=CARBA, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Carba[-\\s]R\\ BEU\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"IMP DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED","Call":"POS","Notes":"From Specification.xlsx sheet=CARBA, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Carba[-\\s]R\\ BEU\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"IMP NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=CARBA, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Ebola\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"Ebola GP DETECTED;Ebola NP DETECTED","Call":"POS","Notes":"From Specification.xlsx sheet=EBOLA, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Ebola\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"Ebola GP NOT DETECTED;Ebola NP NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=EBOLA, sampleGroup=0"},{"Priority":2000,"AssayPattern":"GBS\\ LB\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"GBS POSITIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=GBS XC, sampleGroup=0"},{"Priority":2000,"AssayPattern":"GBS\\ LB\\ XC\\ IUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"GBS POSITIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=GBS XC, sampleGroup=0"},{"Priority":2000,"AssayPattern":"GI\\ Panel\\ IUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"Campylobacter POSITIVE;Salmonella POSITIVE;STEC stx1 POSITIVE;STEC stx2 POSITIVE;Shigella EIEC POSITIVE;V. cholerae POSITIVE;V. parahaemolyticus POSITIVE;Yersinia POSITIVE;Cryptosporidium POSITIVE;Giardia POSITIVE;Norovirus POSITIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=GI Panel, sampleGroup=0"},{"Priority":2000,"AssayPattern":"GI\\ Panel\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"Campylobacter POSITIVE;Salmonella POSITIVE;STEC stx1 POSITIVE;STEC stx2 POSITIVE;Shigella EIEC POSITIVE;V. cholerae POSITIVE;V. parahaemolyticus POSITIVE;Yersinia POSITIVE;Cryptosporidium POSITIVE;Giardia POSITIVE;Norovirus POSITIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=GI Panel, sampleGroup=0"},{"Priority":2000,"AssayPattern":"HCV\\ IUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"HCV DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=GX HCV, sampleGroup=0"},{"Priority":2000,"AssayPattern":"HCV\\ VL\\ WB\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"HCV DETECTED * IU/mL (log *.*)","Call":"POS","Notes":"From Specification.xlsx sheet=HCV FS, sampleGroup=1"},{"Priority":2000,"AssayPattern":"HCV\\ VL\\ WB\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"HCV NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=HCV FS, sampleGroup=0"},{"Priority":2000,"AssayPattern":"HCV\\ Viral\\ Load\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"HCV DETECTED * IU/mL (log *.*)","Call":"POS","Notes":"From Specification.xlsx sheet=HCV VL, sampleGroup=1"},{"Priority":2000,"AssayPattern":"HCV\\ Viral\\ Load\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"HCV NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=HCV VL, sampleGroup=0"},{"Priority":2000,"AssayPattern":"HIV[-\\s]1\\ Viral\\ Load\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"HIV-1 DETECTED * copies/mL (log *.*)","Call":"POS","Notes":"From Specification.xlsx sheet=HIV VL, sampleGroup=1"},{"Priority":2000,"AssayPattern":"HIV[-\\s]1\\ Viral\\ Load\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"HIV-1 NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=HIV VL, sampleGroup=0"},{"Priority":2000,"AssayPattern":"HIV[-\\s]1\\ Viral\\ Load\\ XC\\ IUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"HIV-1 DETECTED * copies/mL (log *.*)","Call":"POS","Notes":"From Specification.xlsx sheet=HIV VL XC, sampleGroup=1"},{"Priority":2000,"AssayPattern":"HIV[-\\s]1\\ Viral\\ Load\\ XC\\ IUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"HIV-1 NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=HIV VL XC, sampleGroup=0"},{"Priority":2000,"AssayPattern":"HIV[-\\s]1\\ Viral\\ Load\\ XC\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"HIV-1 DETECTED * copies/mL (log *.*)","Call":"POS","Notes":"From Specification.xlsx sheet=HIV VL XC, sampleGroup=1"},{"Priority":2000,"AssayPattern":"HIV[-\\s]1\\ Viral\\ Load\\ XC\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"HIV-1 NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=HIV VL XC, sampleGroup=0"},{"Priority":2000,"AssayPattern":"HPV\\ HR\\ AND\\ GENOTYPE\\ RUO\\ ASSAY","Field":"Test Result","MatchType":"exact_ci","Pattern":"HR HPV POS","Call":"POS","Notes":"From Specification.xlsx sheet=HPV, sampleGroup=1"},{"Priority":2000,"AssayPattern":"HPV\\ HR\\ AND\\ GENOTYPE\\ RUO\\ ASSAY","Field":"Test Result","MatchType":"exact_ci","Pattern":"INVALID","Call":"NEG","Notes":"From Specification.xlsx sheet=HPV, sampleGroup=0"},{"Priority":2000,"AssayPattern":"LCE009\\ Xpress\\ SARS[-\\s]CoV[-\\s]2\\ plus","Field":"Test Result","MatchType":"exact_ci","Pattern":"SARS-CoV-2 NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=Covid plus, sampleGroup=0"},{"Priority":2000,"AssayPattern":"LCE009\\ Xpress\\ SARS[-\\s]CoV[-\\s]2\\ plus","Field":"Test Result","MatchType":"exact_ci","Pattern":"SARS-CoV-2 POSITIVE","Call":"POS","Notes":"From Specification.xlsx sheet=Covid plus, sampleGroup=1"},{"Priority":2000,"AssayPattern":"MRSA[-\\s]SA\\ ETA","Field":"Test Result","MatchType":"exact_ci","Pattern":"MRSA NEGATIVE;SA NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=MRSA SA, sampleGroup=0"},{"Priority":2000,"AssayPattern":"MRSA[-\\s]SA\\ ETA","Field":"Test Result","MatchType":"exact_ci","Pattern":"MRSA POSITIVE;SA POSITIVE","Call":"POS","Notes":"From Specification.xlsx sheet=MRSA SA, sampleGroup=1"},{"Priority":2000,"AssayPattern":"MRSA\\ NxG\\ IUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"MRSA DETECTED","Call":"POS","Notes":"From Specification.xlsx sheet=MRSA NxG, sampleGroup=1"},{"Priority":2000,"AssayPattern":"MRSA\\ NxG\\ IUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"MRSA NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=MRSA NxG, sampleGroup=0"},{"Priority":2000,"AssayPattern":"MRSA\\ NxG\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"MRSA DETECTED","Call":"POS","Notes":"From Specification.xlsx sheet=MRSA NxG, sampleGroup=1"},{"Priority":2000,"AssayPattern":"MRSA\\ NxG\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"MRSA NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=MRSA NxG, sampleGroup=0"},{"Priority":2000,"AssayPattern":"MTB[-\\s]RIF\\ Ultra\\ v2\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"MTB DETECTED *;Rif Resistance DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=MTB U, sampleGroup=0"},{"Priority":2000,"AssayPattern":"MTB[-\\s]XDR\\ IUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"MTB DETECTED;INH Resistance NOT DETECTED;FLQ Resistance NOT DETECTED;AMK Resistance NOT DETECTED;KAN Resistance NOT DETECTED;CAP Resistance NOT DETECTED;ETH Resistance NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=MTB XDR, sampleGroup=0"},{"Priority":2000,"AssayPattern":"MTB[-\\s]XDR\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"MTB DETECTED;INH Resistance NOT DETECTED;FLQ Resistance NOT DETECTED;AMK Resistance NOT DETECTED;KAN Resistance NOT DETECTED;CAP Resistance NOT DETECTED;ETH Resistance NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=MTB XDR, sampleGroup=0"},{"Priority":2000,"AssayPattern":"P0900","Field":"Test Result","MatchType":"exact_ci","Pattern":"HIV-1 DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=HIV QA XC, sampleGroup=0"},{"Priority":2000,"AssayPattern":"P0918","Field":"Test Result","MatchType":"exact_ci","Pattern":"HIV-1 DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=HIV QA XC, sampleGroup=0"},{"Priority":2000,"AssayPattern":"P0998","Field":"Test Result","MatchType":"exact_ci","Pattern":"HIV-1 DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=HIV QA XC, sampleGroup=0"},{"Priority":2000,"AssayPattern":"P0999","Field":"Test Result","MatchType":"exact_ci","Pattern":"HIV-1 DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=HIV QA XC, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Respiratory\\ Panel\\ IUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV POSITIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae POSITIVE;Myco. pneumoniae NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=Respiratory Panel, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Respiratory\\ Panel\\ IUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"Adenovirus POSITIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV POSITIVE;Parainfluenza POSITIVE;Rhino-Enterovirus POSITIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE","Call":"POS","Notes":"From Specification.xlsx sheet=Respiratory Panel, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Respiratory\\ Panel\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV POSITIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae POSITIVE;Myco. pneumoniae NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=Respiratory Panel, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Respiratory\\ Panel\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"Adenovirus POSITIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV POSITIVE;Parainfluenza POSITIVE;Rhino-Enterovirus POSITIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE","Call":"POS","Notes":"From Specification.xlsx sheet=Respiratory Panel, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Respiratory\\ panel","Field":"Test Result","MatchType":"exact_ci","Pattern":"Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV POSITIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae POSITIVE;Myco. pneumoniae NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=Respiratory Panel, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Respiratory\\ panel","Field":"Test Result","MatchType":"exact_ci","Pattern":"Adenovirus POSITIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV POSITIVE;Parainfluenza POSITIVE;Rhino-Enterovirus POSITIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE","Call":"POS","Notes":"From Specification.xlsx sheet=Respiratory Panel, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Respiratory\\ panel\\ CE[-\\s]IVD","Field":"Test Result","MatchType":"exact_ci","Pattern":"Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV POSITIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae POSITIVE;Myco. pneumoniae NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=Respiratory Panel, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Respiratory\\ panel\\ CE[-\\s]IVD","Field":"Test Result","MatchType":"exact_ci","Pattern":"Adenovirus POSITIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV POSITIVE;Parainfluenza POSITIVE;Rhino-Enterovirus POSITIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE","Call":"POS","Notes":"From Specification.xlsx sheet=Respiratory Panel, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Respiratory\\ panel\\ UKCA[-\\s]IVD","Field":"Test Result","MatchType":"exact_ci","Pattern":"Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV POSITIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae POSITIVE;Myco. pneumoniae NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=Respiratory Panel, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Respiratory\\ panel\\ UKCA[-\\s]IVD","Field":"Test Result","MatchType":"exact_ci","Pattern":"Adenovirus POSITIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV POSITIVE;Parainfluenza POSITIVE;Rhino-Enterovirus POSITIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE","Call":"POS","Notes":"From Specification.xlsx sheet=Respiratory Panel, sampleGroup=1"},{"Priority":2000,"AssayPattern":"TAP\\ Panel\\ IUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"Ft DETECTED;Ba DETECTED;Yp DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=TAP Panel, sampleGroup=0"},{"Priority":2000,"AssayPattern":"TAP\\ Panel\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"Ft DETECTED;Ba DETECTED;Yp DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=TAP Panel, sampleGroup=0"},{"Priority":2000,"AssayPattern":"XP\\ Flu[-\\s]RSV\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=FLU RSV, sampleGroup=0"},{"Priority":2000,"AssayPattern":"XP\\ Flu[-\\s]RSV\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE","Call":"POS","Notes":"From Specification.xlsx sheet=FLU RSV, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert[-\\s]C\\.\\ difficile\\ G2","Field":"Test Result","MatchType":"exact_ci","Pattern":"Toxigenic C.diff NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=C.DIFF, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert[-\\s]C\\.\\ difficile\\ G2","Field":"Test Result","MatchType":"exact_ci","Pattern":"Toxigenic C.diff POSITIVE","Call":"POS","Notes":"From Specification.xlsx sheet=C.DIFF, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ C\\.diff[-\\s]Epi","Field":"Test Result","MatchType":"exact_ci","Pattern":"Toxigenic C.diff NEGATIVE;027 PRESUMPTIVE NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=C.DIFF, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ C\\.diff[-\\s]Epi","Field":"Test Result","MatchType":"exact_ci","Pattern":"Toxigenic C.diff POSITIVE;027 PRESUMPTIVE POSITIVE","Call":"POS","Notes":"From Specification.xlsx sheet=C.DIFF, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ C\\.difficile\\ BT","Field":"Test Result","MatchType":"exact_ci","Pattern":"Toxigenic C.diff NEG;Binary Toxin NEG;027 NEG","Call":"NEG","Notes":"From Specification.xlsx sheet=C.DIFF, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ C\\.difficile\\ BT","Field":"Test Result","MatchType":"exact_ci","Pattern":"Toxigenic C.diff POS;Binary Toxin POS;027 PRESUMPTIVE POS","Call":"POS","Notes":"From Specification.xlsx sheet=C.DIFF, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ C\\.difficile\\ G3","Field":"Test Result","MatchType":"exact_ci","Pattern":"Toxigenic C.diff NEGATIVE;027 PRESUMPTIVE NEG","Call":"NEG","Notes":"From Specification.xlsx sheet=C.DIFF, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ C\\.difficile\\ G3","Field":"Test Result","MatchType":"exact_ci","Pattern":"Toxigenic C.diff POSITIVE;027 PRESUMPTIVE POS","Call":"POS","Notes":"From Specification.xlsx sheet=C.DIFF, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ Carba[-\\s]R","Field":"Test Result","MatchType":"exact_ci","Pattern":"IMP1 DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED","Call":"POS","Notes":"From Specification.xlsx sheet=CARBA, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ Carba[-\\s]R","Field":"Test Result","MatchType":"exact_ci","Pattern":"IMP1 NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=CARBA, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ Ebola\\ CE[-\\s]IVD","Field":"Test Result","MatchType":"exact_ci","Pattern":"Ebola GP DETECTED;Ebola NP DETECTED","Call":"POS","Notes":"From Specification.xlsx sheet=EBOLA, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ Ebola\\ CE[-\\s]IVD","Field":"Test Result","MatchType":"exact_ci","Pattern":"Ebola GP NOT DETECTED;Ebola NP NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=EBOLA, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ Ebola\\ EUA","Field":"Test Result","MatchType":"exact_ci","Pattern":"Ebola GP DETECTED;Ebola NP DETECTED","Call":"POS","Notes":"From Specification.xlsx sheet=EBOLA, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ Ebola\\ EUA","Field":"Test Result","MatchType":"exact_ci","Pattern":"Ebola GP NOT DETECTED;Ebola NP NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=EBOLA, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ GBS\\ LB\\ XC","Field":"Test Result","MatchType":"exact_ci","Pattern":"GBS POSITIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=GBS XC, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ GI\\ Panel","Field":"Test Result","MatchType":"exact_ci","Pattern":"Campylobacter POSITIVE;Salmonella POSITIVE;STEC stx1 POSITIVE;STEC stx2 POSITIVE;Shigella EIEC POSITIVE;V. cholerae POSITIVE;V. parahaemolyticus POSITIVE;Yersinia POSITIVE;Cryptosporidium POSITIVE;Giardia POSITIVE;Norovirus POSITIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=GI Panel, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ GI\\ Panel\\ CE[-\\s]IVD","Field":"Test Result","MatchType":"exact_ci","Pattern":"Campylobacter POSITIVE;Salmonella POSITIVE;STEC stx1 POSITIVE;STEC stx2 POSITIVE;Shigella EIEC POSITIVE;V. cholerae POSITIVE;V. parahaemolyticus POSITIVE;Yersinia POSITIVE;Cryptosporidium POSITIVE;Giardia POSITIVE;Norovirus POSITIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=GI Panel, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ HBV\\ Viral\\ Load","Field":"Test Result","MatchType":"exact_ci","Pattern":"HBV DETECTED * IU/mL (log *.*)","Call":"POS","Notes":"From Specification.xlsx sheet=HBV VL, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ HBV\\ Viral\\ Load","Field":"Test Result","MatchType":"exact_ci","Pattern":"HBV NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=HBV VL, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ HCV\\ PQC","Field":"Test Result","MatchType":"exact_ci","Pattern":"HCV DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=GX HCV, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ HCV\\ VL\\ Fingerstick","Field":"Test Result","MatchType":"exact_ci","Pattern":"HCV DETECTED * IU/mL (log *.*)","Call":"POS","Notes":"From Specification.xlsx sheet=HCV FS, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ HCV\\ VL\\ Fingerstick","Field":"Test Result","MatchType":"exact_ci","Pattern":"HCV NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=HCV FS, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ HIV[-\\s]1\\ Viral\\ Load\\ XC","Field":"Test Result","MatchType":"exact_ci","Pattern":"HIV-1 DETECTED * copies/mL (log *.*)","Call":"POS","Notes":"From Specification.xlsx sheet=HIV VL XC, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ HIV[-\\s]1\\ Viral\\ Load\\ XC","Field":"Test Result","MatchType":"exact_ci","Pattern":"HIV-1 NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=HIV VL XC, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ HPV\\ HR","Field":"Test Result","MatchType":"exact_ci","Pattern":"HR HPV POS","Call":"POS","Notes":"From Specification.xlsx sheet=HPV, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ HPV\\ HR","Field":"Test Result","MatchType":"exact_ci","Pattern":"INVALID","Call":"NEG","Notes":"From Specification.xlsx sheet=HPV, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ HPV\\ v2\\ HR","Field":"Test Result","MatchType":"exact_ci","Pattern":"HR HPV POS","Call":"POS","Notes":"From Specification.xlsx sheet=HPV, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ HPV\\ v2\\ HR","Field":"Test Result","MatchType":"exact_ci","Pattern":"INVALID","Call":"NEG","Notes":"From Specification.xlsx sheet=HPV, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ MRSA[-\\s]SA\\ BC\\ G3","Field":"Test Result","MatchType":"exact_ci","Pattern":"MRSA NEGATIVE;SA NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=MRSA SA, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ MRSA[-\\s]SA\\ BC\\ G3","Field":"Test Result","MatchType":"exact_ci","Pattern":"MRSA POSITIVE;SA POSITIVE","Call":"POS","Notes":"From Specification.xlsx sheet=MRSA SA, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ MRSA[-\\s]SA\\ SSTI\\ G3","Field":"Test Result","MatchType":"exact_ci","Pattern":"MRSA NEGATIVE;SA NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=MRSA SA, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ MRSA[-\\s]SA\\ SSTI\\ G3","Field":"Test Result","MatchType":"exact_ci","Pattern":"MRSA POSITIVE;SA POSITIVE","Call":"POS","Notes":"From Specification.xlsx sheet=MRSA SA, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ MRSA\\ NxG","Field":"Test Result","MatchType":"exact_ci","Pattern":"MRSA DETECTED","Call":"POS","Notes":"From Specification.xlsx sheet=MRSA NxG, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ MRSA\\ NxG","Field":"Test Result","MatchType":"exact_ci","Pattern":"MRSA NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=MRSA NxG, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ MRSA_SA_BC","Field":"Test Result","MatchType":"exact_ci","Pattern":"MRSA NEGATIVE;SA NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=MRSA SA, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ MRSA_SA_BC","Field":"Test Result","MatchType":"exact_ci","Pattern":"MRSA POSITIVE;SA POSITIVE","Call":"POS","Notes":"From Specification.xlsx sheet=MRSA SA, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ MRSA_SA_BC_CE","Field":"Test Result","MatchType":"exact_ci","Pattern":"MRSA NEGATIVE;SA NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=MRSA SA, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ MRSA_SA_BC_CE","Field":"Test Result","MatchType":"exact_ci","Pattern":"MRSA POSITIVE;SA POSITIVE","Call":"POS","Notes":"From Specification.xlsx sheet=MRSA SA, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ MTB[-\\s]RIF\\ Assay\\ G4","Field":"Test Result","MatchType":"exact_ci","Pattern":"MTB DETECTED *;Rif Resistance NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=MTB, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ MTB[-\\s]RIF\\ JP\\ IVD","Field":"Test Result","MatchType":"exact_ci","Pattern":"MTB DETECTED;Rif Resistance DETECTED","Call":"POS","Notes":"From Specification.xlsx sheet=MTB JP, sampleGroup=2"},{"Priority":2000,"AssayPattern":"Xpert\\ MTB[-\\s]RIF\\ JP\\ IVD","Field":"Test Result","MatchType":"exact_ci","Pattern":"MTB DETECTED;Rif Resistance NOT DETECTED","Call":"POS","Notes":"From Specification.xlsx sheet=MTB JP, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ MTB[-\\s]RIF\\ JP\\ IVD","Field":"Test Result","MatchType":"exact_ci","Pattern":"MTB NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=MTB JP, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ MTB[-\\s]RIF\\ US\\ IVD","Field":"Test Result","MatchType":"exact_ci","Pattern":"MTB DETECTED;Rif Resistance NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=MTB, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ MTB[-\\s]RIF\\ Ultra","Field":"Test Result","MatchType":"exact_ci","Pattern":"MTB DETECTED *;Rif Resistance DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=MTB U, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ MTB[-\\s]XDR","Field":"Test Result","MatchType":"exact_ci","Pattern":"MTB DETECTED;INH Resistance NOT DETECTED;FLQ Resistance NOT DETECTED;AMK Resistance NOT DETECTED;KAN Resistance NOT DETECTED;CAP Resistance NOT DETECTED;ETH Resistance NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=MTB XDR, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ Norovirus","Field":"Test Result","MatchType":"exact_ci","Pattern":"NORO GI DETECTED;NORO GII DETECTED","Call":"POS","Notes":"From Specification.xlsx sheet=NORO, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ Norovirus","Field":"Test Result","MatchType":"exact_ci","Pattern":"NORO GI NOT DETECTED;NORO GII NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=NORO, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ SA\\ Nasal\\ Complete\\ G3","Field":"Test Result","MatchType":"exact_ci","Pattern":"MRSA NEGATIVE;SA NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=MRSA SA, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ SA\\ Nasal\\ Complete\\ G3","Field":"Test Result","MatchType":"exact_ci","Pattern":"MRSA POSITIVE;SA POSITIVE","Call":"POS","Notes":"From Specification.xlsx sheet=MRSA SA, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ TAP\\ Panel","Field":"Test Result","MatchType":"exact_ci","Pattern":"Ft DETECTED;Ba DETECTED;Yp DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=TAP Panel, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ Xpress\\ CoV[-\\s]2\\ plus","Field":"Test Result","MatchType":"exact_ci","Pattern":"SARS-CoV-2 NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=Covid plus, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ Xpress\\ CoV[-\\s]2\\ plus","Field":"Test Result","MatchType":"exact_ci","Pattern":"SARS-CoV-2 POSITIVE","Call":"POS","Notes":"From Specification.xlsx sheet=Covid plus, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ Xpress\\ CoV[-\\s]2\\ plus\\ IVD","Field":"Test Result","MatchType":"exact_ci","Pattern":"SARS-CoV-2 NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=Covid plus, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ Xpress\\ CoV[-\\s]2\\ plus\\ IVD","Field":"Test Result","MatchType":"exact_ci","Pattern":"SARS-CoV-2 POSITIVE","Call":"POS","Notes":"From Specification.xlsx sheet=Covid plus, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ Xpress\\ Flu[-\\s]RSV","Field":"Test Result","MatchType":"exact_ci","Pattern":"Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=FLU RSV, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ Xpress\\ Flu[-\\s]RSV","Field":"Test Result","MatchType":"exact_ci","Pattern":"Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE","Call":"POS","Notes":"From Specification.xlsx sheet=FLU RSV, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ Xpress\\ GBS","Field":"Test Result","MatchType":"exact_ci","Pattern":"GBS POSITIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=GBS, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ Xpress\\ GBS\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"GBS POSITIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=GBS, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ Xpress\\ SARS[-\\s]CoV[-\\s]2","Field":"Test Result","MatchType":"exact_ci","Pattern":"SARS-CoV-2 NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=Sars, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ Xpress\\ SARS[-\\s]CoV[-\\s]2","Field":"Test Result","MatchType":"exact_ci","Pattern":"SARS-CoV-2 POSITIVE","Call":"POS","Notes":"From Specification.xlsx sheet=Sars, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ Xpress\\ SARS[-\\s]CoV[-\\s]2\\ CE[-\\s]IVD","Field":"Test Result","MatchType":"exact_ci","Pattern":"SARS-CoV-2 NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=Sars, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ Xpress\\ SARS[-\\s]CoV[-\\s]2\\ CE[-\\s]IVD","Field":"Test Result","MatchType":"exact_ci","Pattern":"SARS-CoV-2 POSITIVE","Call":"POS","Notes":"From Specification.xlsx sheet=Sars, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ Xpress\\ Strep\\ A","Field":"Test Result","MatchType":"exact_ci","Pattern":"Strep A DETECTED","Call":"POS","Notes":"From Specification.xlsx sheet=STREPA, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ Xpress\\ Strep\\ A","Field":"Test Result","MatchType":"exact_ci","Pattern":"Strep A NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=STREPA, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ Xpress_Strep\\ A","Field":"Test Result","MatchType":"exact_ci","Pattern":"Strep A DETECTED","Call":"POS","Notes":"From Specification.xlsx sheet=STREPA, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert\\ Xpress_Strep\\ A","Field":"Test Result","MatchType":"exact_ci","Pattern":"Strep A NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=STREPA, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ vanA\\ vanB","Field":"Test Result","MatchType":"exact_ci","Pattern":"vanA NEGATIVE;vanB NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=VAN AB, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert\\ vanA\\ vanB","Field":"Test Result","MatchType":"exact_ci","Pattern":"vanA POSITIVE;vanB POSITIVE","Call":"POS","Notes":"From Specification.xlsx sheet=VAN AB, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert_Carba[-\\s]R","Field":"Test Result","MatchType":"exact_ci","Pattern":"IMP DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED","Call":"POS","Notes":"From Specification.xlsx sheet=CARBA, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert_Carba[-\\s]R","Field":"Test Result","MatchType":"exact_ci","Pattern":"IMP NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=CARBA, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert_HCV\\ Viral\\ Load","Field":"Test Result","MatchType":"exact_ci","Pattern":"HCV DETECTED * IU/mL (log *.*)","Call":"POS","Notes":"From Specification.xlsx sheet=HCV VL, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert_HCV\\ Viral\\ Load","Field":"Test Result","MatchType":"exact_ci","Pattern":"HCV NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=HCV VL, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpert_HIV[-\\s]1\\ Viral\\ Load","Field":"Test Result","MatchType":"exact_ci","Pattern":"HIV-1 DETECTED * copies/mL (log *.*)","Call":"POS","Notes":"From Specification.xlsx sheet=HIV VL, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpert_HIV[-\\s]1\\ Viral\\ Load","Field":"Test Result","MatchType":"exact_ci","Pattern":"HIV-1 NOT DETECTED","Call":"NEG","Notes":"From Specification.xlsx sheet=HIV VL, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpress\\ CoV[-\\s]2\\ plus\\ IUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"SARS-CoV-2 NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=Covid plus, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpress\\ CoV[-\\s]2\\ plus\\ IUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"SARS-CoV-2 POSITIVE","Call":"POS","Notes":"From Specification.xlsx sheet=Covid plus, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpress\\ CoV[-\\s]2\\ plus\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"SARS-CoV-2 NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=Covid plus, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpress\\ CoV[-\\s]2\\ plus\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"SARS-CoV-2 POSITIVE","Call":"POS","Notes":"From Specification.xlsx sheet=Covid plus, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpress\\ Flu\\ IPT_EAT\\ off","Field":"Test Result","MatchType":"exact_ci","Pattern":"Flu A NEGATIVE;Flu B NEGATIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=FLU RSV, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpress\\ Flu\\ IPT_EAT\\ off","Field":"Test Result","MatchType":"exact_ci","Pattern":"Flu A POSITIVE;Flu B POSITIVE","Call":"POS","Notes":"From Specification.xlsx sheet=FLU RSV, sampleGroup=1"},{"Priority":2000,"AssayPattern":"Xpress\\ GBS\\ IUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"GBS POSITIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=GBS, sampleGroup=0"},{"Priority":2000,"AssayPattern":"Xpress\\ GBS\\ RUO","Field":"Test Result","MatchType":"exact_ci","Pattern":"GBS POSITIVE","Call":"NEG","Notes":"From Specification.xlsx sheet=GBS, sampleGroup=0"},{"Priority":1000,"AssayPattern":"","Field":"Test Result","MatchType":"contains_ci","Pattern":"ABORT","Call":"INDET","Notes":"Generic non-result"},{"Priority":1000,"AssayPattern":"","Field":"Test Result","MatchType":"contains_ci","Pattern":"INCOMPLETE","Call":"INDET","Notes":"Generic non-result"},{"Priority":1000,"AssayPattern":"","Field":"Test Result","MatchType":"contains_ci","Pattern":"INDETERMINATE","Call":"INDET","Notes":"Generic non-result"},{"Priority":1000,"AssayPattern":"","Field":"Test Result","MatchType":"contains_ci","Pattern":"NO RESULT","Call":"INDET","Notes":"Generic non-result"},{"Priority":980,"AssayPattern":"","Field":"Status","MatchType":"contains_ci","Pattern":"ABORT","Call":"INDET","Notes":"Status indicates abort"},{"Priority":970,"AssayPattern":"","Field":"Test Result","MatchType":"contains_ci","Pattern":"ERROR","Call":"INDET","Notes":"Generic error"},{"Priority":960,"AssayPattern":"","Field":"Status","MatchType":"contains_ci","Pattern":"ERROR","Call":"INDET","Notes":"Status indicates error"},{"Priority":950,"AssayPattern":"","Field":"Error","MatchType":"nonempty","Pattern":"","Call":"INDET","Notes":"If Error column is non-empty, treat as INDET unless assay-specific exact result overrides"},{"Priority":900,"AssayPattern":"","Field":"Test Result","MatchType":"contains_ci","Pattern":"INVALID","Call":"INDET","Notes":"Generic invalid (overridden by assay-specific expected results)"},{"Priority":50,"AssayPattern":"","Field":"Test Result","MatchType":"contains_ci","Pattern":"NOT DETECTED","Call":"NEG","Notes":"Fallback"},{"Priority":49,"AssayPattern":"","Field":"Test Result","MatchType":"contains_ci","Pattern":"NEGATIVE","Call":"NEG","Notes":"Fallback"},{"Priority":45,"AssayPattern":"","Field":"Test Result","MatchType":"contains_ci","Pattern":" DETECTED","Call":"POS","Notes":"Fallback (space helps avoid some collisions)"},{"Priority":44,"AssayPattern":"","Field":"Test Result","MatchType":"contains_ci","Pattern":"POSITIVE","Call":"POS","Notes":"Fallback"}],"sampleExpectationRules":[{"Priority":1000,"AssayPattern":"CARBA[-\\s]R\\ IUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=CARBA"},{"Priority":1000,"AssayPattern":"CARBA[-\\s]R\\ IUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=CARBA"},{"Priority":1000,"AssayPattern":"CARBA[-\\s]R\\ IUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=CARBA"},{"Priority":1000,"AssayPattern":"CARBA[-\\s]R\\ RUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=CARBA"},{"Priority":1000,"AssayPattern":"CARBA[-\\s]R\\ RUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=CARBA"},{"Priority":1000,"AssayPattern":"CARBA[-\\s]R\\ RUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=CARBA"},{"Priority":1000,"AssayPattern":"Carba[-\\s]R\\ BEU\\ IUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=CARBA"},{"Priority":1000,"AssayPattern":"Carba[-\\s]R\\ BEU\\ IUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=CARBA"},{"Priority":1000,"AssayPattern":"Carba[-\\s]R\\ BEU\\ IUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=CARBA"},{"Priority":1000,"AssayPattern":"Carba[-\\s]R\\ BEU\\ RUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=CARBA"},{"Priority":1000,"AssayPattern":"Carba[-\\s]R\\ BEU\\ RUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=CARBA"},{"Priority":1000,"AssayPattern":"Carba[-\\s]R\\ BEU\\ RUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=CARBA"},{"Priority":1000,"AssayPattern":"Ebola\\ RUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=EBOLA"},{"Priority":1000,"AssayPattern":"Ebola\\ RUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=EBOLA"},{"Priority":1000,"AssayPattern":"Ebola\\ RUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=EBOLA"},{"Priority":1000,"AssayPattern":"GBS\\ LB\\ RUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GBS XC"},{"Priority":1000,"AssayPattern":"GBS\\ LB\\ RUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GBS XC"},{"Priority":1000,"AssayPattern":"GBS\\ LB\\ RUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=GBS XC"},{"Priority":1000,"AssayPattern":"GBS\\ LB\\ XC\\ IUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GBS XC"},{"Priority":1000,"AssayPattern":"GBS\\ LB\\ XC\\ IUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GBS XC"},{"Priority":1000,"AssayPattern":"GBS\\ LB\\ XC\\ IUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=GBS XC"},{"Priority":1000,"AssayPattern":"GI\\ Panel\\ IUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GI Panel"},{"Priority":1000,"AssayPattern":"GI\\ Panel\\ IUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GI Panel"},{"Priority":1000,"AssayPattern":"GI\\ Panel\\ IUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=GI Panel"},{"Priority":1000,"AssayPattern":"GI\\ Panel\\ RUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GI Panel"},{"Priority":1000,"AssayPattern":"GI\\ Panel\\ RUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GI Panel"},{"Priority":1000,"AssayPattern":"GI\\ Panel\\ RUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=GI Panel"},{"Priority":1000,"AssayPattern":"HCV\\ IUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=GX HCV"},{"Priority":1000,"AssayPattern":"HCV\\ IUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=GX HCV"},{"Priority":1000,"AssayPattern":"HCV\\ IUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=GX HCV"},{"Priority":1000,"AssayPattern":"HCV\\ VL\\ WB\\ RUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=HCV FS"},{"Priority":1000,"AssayPattern":"HCV\\ VL\\ WB\\ RUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=HCV FS"},{"Priority":1000,"AssayPattern":"HCV\\ VL\\ WB\\ RUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=HCV FS"},{"Priority":1000,"AssayPattern":"HCV\\ Viral\\ Load\\ RUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=HCV VL"},{"Priority":1000,"AssayPattern":"HCV\\ Viral\\ Load\\ RUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=HCV VL"},{"Priority":1000,"AssayPattern":"HCV\\ Viral\\ Load\\ RUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=HCV VL"},{"Priority":1000,"AssayPattern":"HIV[-\\s]1\\ Viral\\ Load\\ RUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=HIV VL"},{"Priority":1000,"AssayPattern":"HIV[-\\s]1\\ Viral\\ Load\\ RUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=HIV VL"},{"Priority":1000,"AssayPattern":"HIV[-\\s]1\\ Viral\\ Load\\ RUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=HIV VL"},{"Priority":1000,"AssayPattern":"HIV[-\\s]1\\ Viral\\ Load\\ XC\\ IUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=HIV VL XC"},{"Priority":1000,"AssayPattern":"HIV[-\\s]1\\ Viral\\ Load\\ XC\\ IUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=HIV VL XC"},{"Priority":1000,"AssayPattern":"HIV[-\\s]1\\ Viral\\ Load\\ XC\\ IUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=HIV VL XC"},{"Priority":1000,"AssayPattern":"HIV[-\\s]1\\ Viral\\ Load\\ XC\\ RUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=HIV VL XC"},{"Priority":1000,"AssayPattern":"HIV[-\\s]1\\ Viral\\ Load\\ XC\\ RUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=HIV VL XC"},{"Priority":1000,"AssayPattern":"HIV[-\\s]1\\ Viral\\ Load\\ XC\\ RUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=HIV VL XC"},{"Priority":1000,"AssayPattern":"HPV\\ HR\\ AND\\ GENOTYPE\\ RUO\\ ASSAY","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=HPV"},{"Priority":1000,"AssayPattern":"HPV\\ HR\\ AND\\ GENOTYPE\\ RUO\\ ASSAY","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=HPV"},{"Priority":1000,"AssayPattern":"HPV\\ HR\\ AND\\ GENOTYPE\\ RUO\\ ASSAY","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=HPV"},{"Priority":1000,"AssayPattern":"LCE009\\ Xpress\\ SARS[-\\s]CoV[-\\s]2\\ plus","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=Covid plus"},{"Priority":1000,"AssayPattern":"LCE009\\ Xpress\\ SARS[-\\s]CoV[-\\s]2\\ plus","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=Covid plus"},{"Priority":1000,"AssayPattern":"LCE009\\ Xpress\\ SARS[-\\s]CoV[-\\s]2\\ plus","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=Covid plus"},{"Priority":1000,"AssayPattern":"MRSA[-\\s]SA\\ ETA","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=MRSA SA"},{"Priority":1000,"AssayPattern":"MRSA[-\\s]SA\\ ETA","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=MRSA SA"},{"Priority":1000,"AssayPattern":"MRSA[-\\s]SA\\ ETA","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=MRSA SA"},{"Priority":1000,"AssayPattern":"MRSA\\ NxG\\ IUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=MRSA NxG"},{"Priority":1000,"AssayPattern":"MRSA\\ NxG\\ IUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=MRSA NxG"},{"Priority":1000,"AssayPattern":"MRSA\\ NxG\\ IUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=MRSA NxG"},{"Priority":1000,"AssayPattern":"MRSA\\ NxG\\ RUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=MRSA NxG"},{"Priority":1000,"AssayPattern":"MRSA\\ NxG\\ RUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=MRSA NxG"},{"Priority":1000,"AssayPattern":"MRSA\\ NxG\\ RUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=MRSA NxG"},{"Priority":1000,"AssayPattern":"MTB[-\\s]RIF\\ Ultra\\ v2\\ RUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=MTB U"},{"Priority":1000,"AssayPattern":"MTB[-\\s]RIF\\ Ultra\\ v2\\ RUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=MTB U"},{"Priority":1000,"AssayPattern":"MTB[-\\s]RIF\\ Ultra\\ v2\\ RUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=MTB U"},{"Priority":1000,"AssayPattern":"MTB[-\\s]XDR\\ IUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=MTB XDR"},{"Priority":1000,"AssayPattern":"MTB[-\\s]XDR\\ IUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=MTB XDR"},{"Priority":1000,"AssayPattern":"MTB[-\\s]XDR\\ IUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=MTB XDR"},{"Priority":1000,"AssayPattern":"MTB[-\\s]XDR\\ RUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=MTB XDR"},{"Priority":1000,"AssayPattern":"MTB[-\\s]XDR\\ RUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=MTB XDR"},{"Priority":1000,"AssayPattern":"MTB[-\\s]XDR\\ RUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=MTB XDR"},{"Priority":1000,"AssayPattern":"P0900","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=HIV QA XC"},{"Priority":1000,"AssayPattern":"P0900","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=HIV QA XC"},{"Priority":1000,"AssayPattern":"P0900","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=HIV QA XC"},{"Priority":1000,"AssayPattern":"P0918","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=HIV QA XC"},{"Priority":1000,"AssayPattern":"P0918","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=HIV QA XC"},{"Priority":1000,"AssayPattern":"P0918","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=HIV QA XC"},{"Priority":1000,"AssayPattern":"P0998","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=HIV QA XC"},{"Priority":1000,"AssayPattern":"P0998","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=HIV QA XC"},{"Priority":1000,"AssayPattern":"P0998","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=HIV QA XC"},{"Priority":1000,"AssayPattern":"P0999","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=HIV QA XC"},{"Priority":1000,"AssayPattern":"P0999","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=HIV QA XC CN"},{"Priority":1000,"AssayPattern":"P0999","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=HIV QA XC"},{"Priority":1000,"AssayPattern":"P0999","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=HIV QA XC CN"},{"Priority":1000,"AssayPattern":"P0999","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=HIV QA XC"},{"Priority":1000,"AssayPattern":"P0999","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=HIV QA XC CN"},{"Priority":1000,"AssayPattern":"Respiratory\\ Panel\\ IUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=Respiratory Panel"},{"Priority":1000,"AssayPattern":"Respiratory\\ Panel\\ IUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=Respiratory Panel"},{"Priority":1000,"AssayPattern":"Respiratory\\ Panel\\ IUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=Respiratory Panel"},{"Priority":1000,"AssayPattern":"Respiratory\\ Panel\\ RUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=Respiratory Panel"},{"Priority":1000,"AssayPattern":"Respiratory\\ Panel\\ RUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=Respiratory Panel"},{"Priority":1000,"AssayPattern":"Respiratory\\ Panel\\ RUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=Respiratory Panel"},{"Priority":1000,"AssayPattern":"Respiratory\\ panel","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=Respiratory Panel"},{"Priority":1000,"AssayPattern":"Respiratory\\ panel","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=Respiratory Panel"},{"Priority":1000,"AssayPattern":"Respiratory\\ panel","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=Respiratory Panel"},{"Priority":1000,"AssayPattern":"Respiratory\\ panel\\ CE[-\\s]IVD","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=Respiratory Panel"},{"Priority":1000,"AssayPattern":"Respiratory\\ panel\\ CE[-\\s]IVD","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=Respiratory Panel"},{"Priority":1000,"AssayPattern":"Respiratory\\ panel\\ CE[-\\s]IVD","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=Respiratory Panel"},{"Priority":1000,"AssayPattern":"Respiratory\\ panel\\ UKCA[-\\s]IVD","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=Respiratory Panel"},{"Priority":1000,"AssayPattern":"Respiratory\\ panel\\ UKCA[-\\s]IVD","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=Respiratory Panel"},{"Priority":1000,"AssayPattern":"Respiratory\\ panel\\ UKCA[-\\s]IVD","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=Respiratory Panel"},{"Priority":1000,"AssayPattern":"TAP\\ Panel\\ IUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=TAP Panel"},{"Priority":1000,"AssayPattern":"TAP\\ Panel\\ IUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=TAP Panel"},{"Priority":1000,"AssayPattern":"TAP\\ Panel\\ IUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=TAP Panel"},{"Priority":1000,"AssayPattern":"TAP\\ Panel\\ RUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=TAP Panel"},{"Priority":1000,"AssayPattern":"TAP\\ Panel\\ RUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=TAP Panel"},{"Priority":1000,"AssayPattern":"TAP\\ Panel\\ RUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=TAP Panel"},{"Priority":1000,"AssayPattern":"XP\\ Flu[-\\s]RSV\\ RUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=FLU RSV"},{"Priority":1000,"AssayPattern":"XP\\ Flu[-\\s]RSV\\ RUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=FLU RSV"},{"Priority":1000,"AssayPattern":"XP\\ Flu[-\\s]RSV\\ RUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=FLU RSV"},{"Priority":1000,"AssayPattern":"Xpert[-\\s]C\\.\\ difficile\\ G2","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=C.DIFF"},{"Priority":1000,"AssayPattern":"Xpert[-\\s]C\\.\\ difficile\\ G2","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=C.DIFF"},{"Priority":1000,"AssayPattern":"Xpert[-\\s]C\\.\\ difficile\\ G2","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=C.DIFF"},{"Priority":1000,"AssayPattern":"Xpert\\ C\\.diff[-\\s]Epi","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=C.DIFF"},{"Priority":1000,"AssayPattern":"Xpert\\ C\\.diff[-\\s]Epi","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=C.DIFF"},{"Priority":1000,"AssayPattern":"Xpert\\ C\\.diff[-\\s]Epi","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=C.DIFF"},{"Priority":1000,"AssayPattern":"Xpert\\ C\\.difficile\\ BT","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=C.DIFF"},{"Priority":1000,"AssayPattern":"Xpert\\ C\\.difficile\\ BT","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=C.DIFF"},{"Priority":1000,"AssayPattern":"Xpert\\ C\\.difficile\\ BT","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=C.DIFF"},{"Priority":1000,"AssayPattern":"Xpert\\ C\\.difficile\\ G3","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=C.DIFF"},{"Priority":1000,"AssayPattern":"Xpert\\ C\\.difficile\\ G3","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=C.DIFF JP"},{"Priority":1000,"AssayPattern":"Xpert\\ C\\.difficile\\ G3","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=C.DIFF"},{"Priority":1000,"AssayPattern":"Xpert\\ C\\.difficile\\ G3","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=C.DIFF JP"},{"Priority":1000,"AssayPattern":"Xpert\\ C\\.difficile\\ G3","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=C.DIFF"},{"Priority":1000,"AssayPattern":"Xpert\\ C\\.difficile\\ G3","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=C.DIFF JP"},{"Priority":1000,"AssayPattern":"Xpert\\ Carba[-\\s]R","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=CARBA"},{"Priority":1000,"AssayPattern":"Xpert\\ Carba[-\\s]R","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=CARBA"},{"Priority":1000,"AssayPattern":"Xpert\\ Carba[-\\s]R","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=CARBA"},{"Priority":1000,"AssayPattern":"Xpert\\ Ebola\\ CE[-\\s]IVD","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=EBOLA"},{"Priority":1000,"AssayPattern":"Xpert\\ Ebola\\ CE[-\\s]IVD","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=EBOLA"},{"Priority":1000,"AssayPattern":"Xpert\\ Ebola\\ CE[-\\s]IVD","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=EBOLA"},{"Priority":1000,"AssayPattern":"Xpert\\ Ebola\\ EUA","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=EBOLA"},{"Priority":1000,"AssayPattern":"Xpert\\ Ebola\\ EUA","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=EBOLA"},{"Priority":1000,"AssayPattern":"Xpert\\ Ebola\\ EUA","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=EBOLA"},{"Priority":1000,"AssayPattern":"Xpert\\ GBS\\ LB\\ XC","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GBS XC"},{"Priority":1000,"AssayPattern":"Xpert\\ GBS\\ LB\\ XC","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GBS XC"},{"Priority":1000,"AssayPattern":"Xpert\\ GBS\\ LB\\ XC","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=GBS XC"},{"Priority":1000,"AssayPattern":"Xpert\\ GI\\ Panel","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GI Panel"},{"Priority":1000,"AssayPattern":"Xpert\\ GI\\ Panel","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GI Panel"},{"Priority":1000,"AssayPattern":"Xpert\\ GI\\ Panel","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=GI Panel"},{"Priority":1000,"AssayPattern":"Xpert\\ GI\\ Panel\\ CE[-\\s]IVD","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GI Panel"},{"Priority":1000,"AssayPattern":"Xpert\\ GI\\ Panel\\ CE[-\\s]IVD","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GI Panel"},{"Priority":1000,"AssayPattern":"Xpert\\ GI\\ Panel\\ CE[-\\s]IVD","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=GI Panel"},{"Priority":1000,"AssayPattern":"Xpert\\ HBV\\ Viral\\ Load","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=HBV VL"},{"Priority":1000,"AssayPattern":"Xpert\\ HBV\\ Viral\\ Load","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=HBV VL"},{"Priority":1000,"AssayPattern":"Xpert\\ HBV\\ Viral\\ Load","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=HBV VL"},{"Priority":1000,"AssayPattern":"Xpert\\ HCV\\ PQC","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=GX HCV"},{"Priority":1000,"AssayPattern":"Xpert\\ HCV\\ PQC","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=GX HCV"},{"Priority":1000,"AssayPattern":"Xpert\\ HCV\\ PQC","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=GX HCV"},{"Priority":1000,"AssayPattern":"Xpert\\ HCV\\ VL\\ Fingerstick","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=HCV FS"},{"Priority":1000,"AssayPattern":"Xpert\\ HCV\\ VL\\ Fingerstick","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=HCV FS"},{"Priority":1000,"AssayPattern":"Xpert\\ HCV\\ VL\\ Fingerstick","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=HCV FS"},{"Priority":1000,"AssayPattern":"Xpert\\ HIV[-\\s]1\\ Viral\\ Load\\ XC","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=HIV VL XC"},{"Priority":1000,"AssayPattern":"Xpert\\ HIV[-\\s]1\\ Viral\\ Load\\ XC","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=HIV VL XC"},{"Priority":1000,"AssayPattern":"Xpert\\ HIV[-\\s]1\\ Viral\\ Load\\ XC","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=HIV VL XC"},{"Priority":1000,"AssayPattern":"Xpert\\ HPV\\ HR","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=HPV"},{"Priority":1000,"AssayPattern":"Xpert\\ HPV\\ HR","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=HPV"},{"Priority":1000,"AssayPattern":"Xpert\\ HPV\\ HR","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=HPV"},{"Priority":1000,"AssayPattern":"Xpert\\ HPV\\ v2\\ HR","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=HPV"},{"Priority":1000,"AssayPattern":"Xpert\\ HPV\\ v2\\ HR","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=HPV"},{"Priority":1000,"AssayPattern":"Xpert\\ HPV\\ v2\\ HR","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=HPV"},{"Priority":1000,"AssayPattern":"Xpert\\ MRSA[-\\s]SA\\ BC\\ G3","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=MRSA SA"},{"Priority":1000,"AssayPattern":"Xpert\\ MRSA[-\\s]SA\\ BC\\ G3","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=MRSA SA"},{"Priority":1000,"AssayPattern":"Xpert\\ MRSA[-\\s]SA\\ BC\\ G3","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=MRSA SA"},{"Priority":1000,"AssayPattern":"Xpert\\ MRSA[-\\s]SA\\ SSTI\\ G3","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=MRSA SA"},{"Priority":1000,"AssayPattern":"Xpert\\ MRSA[-\\s]SA\\ SSTI\\ G3","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=MRSA SA"},{"Priority":1000,"AssayPattern":"Xpert\\ MRSA[-\\s]SA\\ SSTI\\ G3","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=MRSA SA"},{"Priority":1000,"AssayPattern":"Xpert\\ MRSA\\ NxG","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=MRSA NxG"},{"Priority":1000,"AssayPattern":"Xpert\\ MRSA\\ NxG","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=MRSA NxG"},{"Priority":1000,"AssayPattern":"Xpert\\ MRSA\\ NxG","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=MRSA NxG"},{"Priority":1000,"AssayPattern":"Xpert\\ MRSA_SA_BC","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=MRSA SA"},{"Priority":1000,"AssayPattern":"Xpert\\ MRSA_SA_BC","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=MRSA SA"},{"Priority":1000,"AssayPattern":"Xpert\\ MRSA_SA_BC","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=MRSA SA"},{"Priority":1000,"AssayPattern":"Xpert\\ MRSA_SA_BC_CE","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=MRSA SA"},{"Priority":1000,"AssayPattern":"Xpert\\ MRSA_SA_BC_CE","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=MRSA SA"},{"Priority":1000,"AssayPattern":"Xpert\\ MRSA_SA_BC_CE","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=MRSA SA"},{"Priority":1000,"AssayPattern":"Xpert\\ MTB[-\\s]RIF\\ Assay\\ G4","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=MTB"},{"Priority":1000,"AssayPattern":"Xpert\\ MTB[-\\s]RIF\\ Assay\\ G4","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=MTB"},{"Priority":1000,"AssayPattern":"Xpert\\ MTB[-\\s]RIF\\ Assay\\ G4","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=MTB"},{"Priority":1000,"AssayPattern":"Xpert\\ MTB[-\\s]RIF\\ JP\\ IVD","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=MTB JP"},{"Priority":1000,"AssayPattern":"Xpert\\ MTB[-\\s]RIF\\ JP\\ IVD","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=MTB JP"},{"Priority":1000,"AssayPattern":"Xpert\\ MTB[-\\s]RIF\\ JP\\ IVD","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=MTB JP"},{"Priority":1000,"AssayPattern":"Xpert\\ MTB[-\\s]RIF\\ US\\ IVD","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=MTB"},{"Priority":1000,"AssayPattern":"Xpert\\ MTB[-\\s]RIF\\ US\\ IVD","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=MTB"},{"Priority":1000,"AssayPattern":"Xpert\\ MTB[-\\s]RIF\\ US\\ IVD","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=MTB"},{"Priority":1000,"AssayPattern":"Xpert\\ MTB[-\\s]RIF\\ Ultra","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=MTB U"},{"Priority":1000,"AssayPattern":"Xpert\\ MTB[-\\s]RIF\\ Ultra","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=MTB U"},{"Priority":1000,"AssayPattern":"Xpert\\ MTB[-\\s]RIF\\ Ultra","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=MTB U"},{"Priority":1000,"AssayPattern":"Xpert\\ MTB[-\\s]XDR","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=MTB XDR"},{"Priority":1000,"AssayPattern":"Xpert\\ MTB[-\\s]XDR","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=MTB XDR"},{"Priority":1000,"AssayPattern":"Xpert\\ MTB[-\\s]XDR","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=MTB XDR"},{"Priority":1000,"AssayPattern":"Xpert\\ Norovirus","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=NORO"},{"Priority":1000,"AssayPattern":"Xpert\\ Norovirus","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=NORO"},{"Priority":1000,"AssayPattern":"Xpert\\ Norovirus","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=NORO"},{"Priority":1000,"AssayPattern":"Xpert\\ SA\\ Nasal\\ Complete\\ G3","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=MRSA SA"},{"Priority":1000,"AssayPattern":"Xpert\\ SA\\ Nasal\\ Complete\\ G3","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=MRSA SA"},{"Priority":1000,"AssayPattern":"Xpert\\ SA\\ Nasal\\ Complete\\ G3","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=MRSA SA"},{"Priority":1000,"AssayPattern":"Xpert\\ TAP\\ Panel","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=TAP Panel"},{"Priority":1000,"AssayPattern":"Xpert\\ TAP\\ Panel","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=TAP Panel"},{"Priority":1000,"AssayPattern":"Xpert\\ TAP\\ Panel","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=TAP Panel"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ CoV[-\\s]2\\ plus","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=Covid plus"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ CoV[-\\s]2\\ plus","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=Covid plus"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ CoV[-\\s]2\\ plus","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=Covid plus"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ CoV[-\\s]2\\ plus\\ IVD","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=Covid plus"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ CoV[-\\s]2\\ plus\\ IVD","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=Covid plus"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ CoV[-\\s]2\\ plus\\ IVD","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=Covid plus"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ Flu[-\\s]RSV","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=FLU RSV"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ Flu[-\\s]RSV","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=FLU RSV"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ Flu[-\\s]RSV","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=FLU RSV"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ GBS","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GBS"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ GBS","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GBS"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ GBS","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=GBS"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ GBS\\ RUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GBS"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ GBS\\ RUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GBS"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ GBS\\ RUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=GBS"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ SARS[-\\s]CoV[-\\s]2","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=Sars"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ SARS[-\\s]CoV[-\\s]2","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=Sars"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ SARS[-\\s]CoV[-\\s]2","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=Sars"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ SARS[-\\s]CoV[-\\s]2\\ CE[-\\s]IVD","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=Sars"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ SARS[-\\s]CoV[-\\s]2\\ CE[-\\s]IVD","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=Sars"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ SARS[-\\s]CoV[-\\s]2\\ CE[-\\s]IVD","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=Sars"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ Strep\\ A","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=STREPA"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ Strep\\ A","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=STREPA"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress\\ Strep\\ A","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=STREPA"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress_Strep\\ A","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=STREPA"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress_Strep\\ A","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=STREPA"},{"Priority":1000,"AssayPattern":"Xpert\\ Xpress_Strep\\ A","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=STREPA"},{"Priority":1000,"AssayPattern":"Xpert\\ vanA\\ vanB","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=VAN AB"},{"Priority":1000,"AssayPattern":"Xpert\\ vanA\\ vanB","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=VAN AB"},{"Priority":1000,"AssayPattern":"Xpert\\ vanA\\ vanB","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=VAN AB"},{"Priority":1000,"AssayPattern":"Xpert_Carba[-\\s]R","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=CARBA"},{"Priority":1000,"AssayPattern":"Xpert_Carba[-\\s]R","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=CARBA"},{"Priority":1000,"AssayPattern":"Xpert_Carba[-\\s]R","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=CARBA"},{"Priority":1000,"AssayPattern":"Xpert_HCV\\ Viral\\ Load","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=HCV VL"},{"Priority":1000,"AssayPattern":"Xpert_HCV\\ Viral\\ Load","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=HCV VL"},{"Priority":1000,"AssayPattern":"Xpert_HCV\\ Viral\\ Load","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=HCV VL"},{"Priority":1000,"AssayPattern":"Xpert_HIV[-\\s]1\\ Viral\\ Load","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=HIV VL"},{"Priority":1000,"AssayPattern":"Xpert_HIV[-\\s]1\\ Viral\\ Load","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=HIV VL"},{"Priority":1000,"AssayPattern":"Xpert_HIV[-\\s]1\\ Viral\\ Load","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=HIV VL"},{"Priority":1000,"AssayPattern":"Xpress\\ CoV[-\\s]2\\ plus\\ IUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=Covid plus"},{"Priority":1000,"AssayPattern":"Xpress\\ CoV[-\\s]2\\ plus\\ IUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=Covid plus"},{"Priority":1000,"AssayPattern":"Xpress\\ CoV[-\\s]2\\ plus\\ IUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=Covid plus"},{"Priority":1000,"AssayPattern":"Xpress\\ CoV[-\\s]2\\ plus\\ RUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=Covid plus"},{"Priority":1000,"AssayPattern":"Xpress\\ CoV[-\\s]2\\ plus\\ RUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=Covid plus"},{"Priority":1000,"AssayPattern":"Xpress\\ CoV[-\\s]2\\ plus\\ RUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=Covid plus"},{"Priority":1000,"AssayPattern":"Xpress\\ Flu\\ IPT_EAT\\ off","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Negative Control 1","Notes":"From Specification.xlsx sample-type table sheet=FLU RSV"},{"Priority":1000,"AssayPattern":"Xpress\\ Flu\\ IPT_EAT\\ off","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 1","Notes":"From Specification.xlsx sample-type table sheet=FLU RSV"},{"Priority":1000,"AssayPattern":"Xpress\\ Flu\\ IPT_EAT\\ off","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"Positive Control 2","Notes":"From Specification.xlsx sample-type table sheet=FLU RSV"},{"Priority":1000,"AssayPattern":"Xpress\\ GBS\\ IUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GBS"},{"Priority":1000,"AssayPattern":"Xpress\\ GBS\\ IUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GBS"},{"Priority":1000,"AssayPattern":"Xpress\\ GBS\\ IUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=GBS"},{"Priority":1000,"AssayPattern":"Xpress\\ GBS\\ RUO","SampleIdRegex":"^[^_]+_\\d+_0_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GBS"},{"Priority":1000,"AssayPattern":"Xpress\\ GBS\\ RUO","SampleIdRegex":"^[^_]+_\\d+_1_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"Specimen","Notes":"From Specification.xlsx sample-type table sheet=GBS"},{"Priority":1000,"AssayPattern":"Xpress\\ GBS\\ RUO","SampleIdRegex":"^[^_]+_\\d+_2_","SampleTypeCode":2,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"From Specification.xlsx sample-type table sheet=GBS"},{"Priority":200,"AssayPattern":"","SampleIdRegex":"^NEG_","SampleTypeCode":0,"ExpectedCall":"NEG","ExpectedTestType":"","Notes":"Generic prefix"},{"Priority":200,"AssayPattern":"","SampleIdRegex":"^POS_","SampleTypeCode":1,"ExpectedCall":"POS","ExpectedTestType":"","Notes":"Generic prefix"}],"errorCodeMap":{"5001":{"name":"Curve Fit Error","retest":"No"},"5002":{"name":"Curve Fit Error","retest":"No"},"5003":{"name":"Curve Fit Error","retest":"No"},"5004":{"name":"Curve Fit Error","retest":"No"},"5005":{"name":"Curve Fit Error","retest":"No"},"5015":{"name":"Curve Fit Error","retest":"No"},"5016":{"name":"Curve Fit Error","retest":"No"},"5007":{"name":"Probe Check Low","retest":"No"},"5017":{"name":"Probe Check Low","retest":"No"},"5019":{"name":"Probe Check Low","retest":"No"},"5006":{"name":"Probe Check High","retest":"No"},"5018":{"name":"Probe Check High","retest":"No"},"2037":{"name":"CIT","retest":"No"},"5011":{"name":"SLD","retest":"No"},"2008":{"name":"Pressure Abort","retest":"No"},"2096":{"name":"Sample Volume Adequacy","retest":"No"},"2097":{"name":"Sample Volume Adequacy","retest":"No"},"2125":{"name":"Sample Volume Adequacy","retest":"No"},"####":{"name":"Other error codes","retest":"Yes"}},"missingSamplesConfig":{"BagMin":0,"BagMax":10,"Bag0SampleMin":1,"Bag0SampleMax":10,"OtherBagSampleMin":1,"OtherBagSampleMax":20,"BagIndex_SampleID_SplitIndex":1,"SampleToken_SampleID_SplitIndex":3,"SampleNumberRegex":"\\d+","SampleNumberPad":2,"Notes":"Matches your HTML: bagSamples[bag] contains sample numbers (digits) from SampleID split '_' index 3"},"sampleIdMarkers":[{"MarkerType":"Replacement","SampleTokenIndex":3,"Marker":"A","Notes":"If sample token contains 'A' => Replacement"},{"MarkerType":"Delamination","SampleTokenIndex":3,"Marker":"D","Notes":"If sample token contains 'D' => Delamination"},{"MarkerType":"PlusX","SampleTokenIndex":3,"Marker":"+|X","Notes":"Used by parity-check logic"}],"parityConfig":{"Enabled":"Yes","AssayPattern":"","CartridgeField":"Cartridge S/N","SampleTokenIndex":"3","XChar":"X","PlusChar":"+","Reference":"lowest_numeric_cartridge","Notes":"Implements your HTML odd/even logic: use lowest numeric Cartridge S/N + whether that row is X to decide parity expectation"}};



  // ----------------------------
  // DOM helpers
  // ----------------------------
  function $(id) { return document.getElementById(id); }

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    if (attrs) {
      for (var k in attrs) {
        if (!attrs.hasOwnProperty(k)) continue;
        if (k === 'text') node.textContent = String(attrs[k]);
        else if (k === 'html') node.innerHTML = String(attrs[k]);
        else if (k === 'class') node.className = String(attrs[k]);
        else if (k === 'style') node.setAttribute('style', String(attrs[k]));
        else node.setAttribute(k, String(attrs[k]));
      }
    }
    if (children && children.length) {
      for (var i = 0; i < children.length; i++) node.appendChild(children[i]);
    }
    return node;
  }

  function clearNode(node) { while (node.firstChild) node.removeChild(node.firstChild); }

  function pill(text, kind) {
    var cls = 'pill';
    if (kind === 'ok') cls += ' ok';
    else if (kind === 'bad') cls += ' bad';
    else if (kind === 'warn') cls += ' warn';
    return el('span', { 'class': cls, text: text });
  }

  function setStatus(msg, isError) {
    var s = $('status');
    s.textContent = msg || '';
    s.className = 'small ' + (isError ? 'err' : 'muted');
  }

  // ----------------------------
  // File registry + detection
  // ----------------------------
  var TYPE_OPTIONS = [
    { key: 'auto', label: 'Auto' },
    { key: 'sealNeg', label: 'Seal Test NEG (xlsx)' },
    { key: 'sealPos', label: 'Seal Test POS (xlsx)' },
    { key: 'worksheet', label: 'Worksheet (xlsx)' },
    { key: 'testSummary', label: 'Test Summary (csv/xlsx)' }
  ];

  var files = []; // {file, typeKey, detectedKey}

  function detectTypeByName(name) {
    var n = (name || '').toLowerCase();
    if (n.indexOf('seal test') >= 0 && (n.indexOf('neg') >= 0 || n.indexOf('negative') >= 0)) return 'sealNeg';
    if (n.indexOf('seal test') >= 0 && (n.indexOf('pos') >= 0 || n.indexOf('positive') >= 0)) return 'sealPos';
    if (n.indexOf('worksheet') >= 0) return 'worksheet';
    if (n.indexOf('test summary') >= 0 || n.indexOf('tests summary') >= 0 || n.slice(-4) === '.csv') return 'testSummary';
    if (n.slice(-4) === '.csv') return 'testSummary';
    if (n.slice(-5) === '.xlsx') return 'auto';
    return 'auto';
  }

  // ----------------------------
  // Zip bundle support (Alternative 2)
  // Drop 1 .zip containing the 4 required files.
  // Requires JSZip (loaded via index.html)
  // ----------------------------
  function isZipFile(file) {
    if (!file) return false;
    var n = (file.name || '').toLowerCase();
    if (n.slice(-4) === '.zip') return true;
    var t = (file.type || '').toLowerCase();
    if (t.indexOf('zip') >= 0) return true;
    return false;
  }

  function makeFileLike(data, name, mime) {
    var opts = mime ? { type: mime } : {};
    try {
      return new File([data], name, opts);
    } catch (e) {
      var b = new Blob([data], opts);
      b.name = name;
      return b;
    }
  }

  function readAsArrayBuffer(file) {
    // Prefer modern File/Blob.arrayBuffer, fallback to FileReader
    if (file && typeof file.arrayBuffer === 'function') {
      return file.arrayBuffer();
    }
    return new Promise(function (resolve, reject) {
      try {
        var fr = new FileReader();
        fr.onload = function () { resolve(fr.result); };
        fr.onerror = function () { reject(fr.error || new Error('FileReader error')); };
        fr.readAsArrayBuffer(file);
      } catch (e) {
        reject(e);
      }
    });
  }

  function extractBundleFilesFromZip(zipFile) {
    if (typeof JSZip === 'undefined') {
      return Promise.reject(new Error('JSZip not loaded'));
    }

    return readAsArrayBuffer(zipFile).then(function (buf) {
      return JSZip.loadAsync(buf);
    }).then(function (zip) {
      var picked = { sealNeg: null, sealPos: null, worksheet: null, testSummary: null };

      zip.forEach(function (relPath, entry) {
        if (!entry || entry.dir) return;
        if (relPath.indexOf('__MACOSX/') === 0) return;

        var base = relPath.split('/').pop();
        if (!base) return;
        if (base.indexOf('._') === 0) return;

        var det = detectTypeByName(base);
        if (!picked[det]) {
          picked[det] = { base: base, entry: entry };
        }
      });

      var out = [];
      var tasks = [];

      function pushPicked(key, mime) {
        if (!picked[key]) return;
        tasks.push(
          picked[key].entry.async('arraybuffer').then(function (ab) {
            out.push(makeFileLike(ab, picked[key].base, mime));
          })
        );
      }

      pushPicked('sealNeg', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      pushPicked('sealPos', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      pushPicked('worksheet', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      pushPicked('testSummary', 'text/csv');

      return Promise.all(tasks).then(function () { return out; });
    });
  }


  function typeLabel(key) {
    for (var i = 0; i < TYPE_OPTIONS.length; i++) if (TYPE_OPTIONS[i].key === key) return TYPE_OPTIONS[i].label;
    return key;
  }

  function refreshFileList() {
    var list = $('fileList');
    clearNode(list);

    if (!files.length) {
      list.appendChild(el('div', { 'class': 'small muted', text: 'Inga filer valda.' }));
      $('runBtn').disabled = true;
      return;
    }

    var tbl = el('table');
    var thead = el('thead');
    var trh = el('tr');
    trh.appendChild(el('th', { text: 'Fil' }));
    trh.appendChild(el('th', { text: 'Detekterad typ' }));
    trh.appendChild(el('th', { text: 'Anvand som' }));
    trh.appendChild(el('th', { text: '' }));
    thead.appendChild(trh);
    tbl.appendChild(thead);

    var tbody = el('tbody');
    for (var i = 0; i < files.length; i++) {
      (function (idx) {
        var f = files[idx];
        var tr = el('tr');

        tr.appendChild(el('td', { 'class': 'mono', text: f.file.name }));
        tr.appendChild(el('td', { text: typeLabel(f.detectedKey) }));

        var sel = el('select');
        for (var j = 0; j < TYPE_OPTIONS.length; j++) {
          var opt = el('option', { value: TYPE_OPTIONS[j].key, text: TYPE_OPTIONS[j].label });
          if (TYPE_OPTIONS[j].key === f.typeKey) opt.selected = true;
          sel.appendChild(opt);
        }
        sel.addEventListener('change', function () { files[idx].typeKey = sel.value; validateReady(); });
        tr.appendChild(el('td', null, [sel]));

        var rm = el('button', { 'class': 'btn2', type: 'button', text: 'Ta bort' });
        rm.addEventListener('click', function () { files.splice(idx, 1); refreshFileList(); validateReady(); });
        tr.appendChild(el('td', null, [rm]));

        tbody.appendChild(tr);
      })(i);
    }
    tbl.appendChild(tbody);
    list.appendChild(tbl);

    validateReady();
  }

    function validateReady() {
    var want = { sealNeg: 0, sealPos: 0, worksheet: 0, testSummary: 0 };
    for (var i = 0; i < files.length; i++) {
      var tk = files[i].typeKey;
      if (tk === 'auto') tk = files[i].detectedKey;
      if (want.hasOwnProperty(tk)) want[tk]++;
    }

    // v7: CSV validation is the first milestone — only require Test Summary for now.
    var okCsv = (want.testSummary >= 1);
    $('runBtn').disabled = !okCsv;

    if (!okCsv) {
      setStatus('Välj minst 1 fil: Test Summary (csv).', false);
      return;
    }

    // If other files are missing, we still run CSV-only and show a note.
    var missing = [];
    if (want.sealNeg < 1) missing.push('Seal NEG');
    if (want.sealPos < 1) missing.push('Seal POS');
    if (want.worksheet < 1) missing.push('Worksheet');

    if (missing.length) {
      setStatus('Redo för CSV-validering. (XLSX-delar saknas: ' + missing.join(', ') + ')', false);
    } else {
      setStatus('Redo. Klicka "Kör analys".', false);
    }
  }


  function addFiles(fileList) {
    if (!fileList || !fileList.length) return;

    var incoming = [];
    var tasks = [];

    for (var i = 0; i < fileList.length; i++) {
      var f = fileList[i];
      if (!f) continue;

      if (isZipFile(f)) {
        (function (zipF) {
          setStatus('Reading zip bundle: ' + (zipF.name || 'bundle.zip') + ' ...', false);
          tasks.push(
            extractBundleFilesFromZip(zipF).then(function (extracted) {
              if (extracted && extracted.length) {
                for (var j = 0; j < extracted.length; j++) incoming.push(extracted[j]);
              } else {
                setStatus('Zip did not contain recognizable files: ' + (zipF.name || ''), true);
              }
            }).catch(function (e) {
              var msg = (e && e.message) ? e.message : String(e);
              setStatus('Could not read zip: ' + (zipF.name || '') + ' (' + msg + ')', true);
            })
          );
        })(f);
        continue;
      }

      incoming.push(f);
    }

    Promise.all(tasks).then(function () {
      for (var k = 0; k < incoming.length; k++) {
        var ff = incoming[k];
        var detected = detectTypeByName(ff.name || '');
        files.push({ file: ff, typeKey: 'auto', detectedKey: detected });
      }

      refreshFileList();
      setStatus('', false);
    });
  }

  // ----------------------------
  // CSV parse
  // ----------------------------
    // ----------------------------
  // CSV parse + validation (Test Summary)
  // ----------------------------
  function analyzeTestSummaryTable(headers, rows, extra) {
    extra = extra || {};
    headers = headers || [];
    rows = rows || [];

    // Build header index map (trimmed)
    var hmap = {};
    for (var hi = 0; hi < headers.length; hi++) {
      var hn = String(headers[hi] || '').replace(/\u00A0/g, ' ').trim();
      if (hn) hmap[hn.toLowerCase()] = hi;
    }

    function idxByName(nameLower) {
      return hmap.hasOwnProperty(nameLower) ? hmap[nameLower] : -1;
    }

    // Common columns
    var idxAssay      = idxByName('assay');
    var idxAssayVer   = idxByName('assay version');
    var idxSample     = idxByName('sample id');
    var idxCart       = idxByName('cartridge s/n');
    if (idxCart < 0) idxCart = findHeader(headers, /^cartridge/i);
    var idxLot        = idxByName('reagent lot id');
    if (idxLot < 0) idxLot = findHeader(headers, /reagent lot id/i);
    var idxTestType   = idxByName('test type');
    var idxInstr      = idxByName('instrument s/n');
    var idxModule     = idxByName('module s/n');
    var idxSw         = idxByName('s/w version');
    var idxStart      = idxByName('start time');
    var idxStatus     = idxByName('status');
    var idxResult     = idxByName('test result');
    var idxMaxP       = idxByName('max pressure (psi)');
    var idxError      = idxByName('error');

    function safeCol(cols, idx) {
      if (idx < 0) return '';
      var v = (idx < cols.length) ? cols[idx] : '';
      if (v === null || typeof v === 'undefined') return '';
      return String(v);
    }

    function parseSampleId(sampleId) {
      sampleId = String(sampleId || '');
      var parts = sampleId.split('_');
      var bag = null;
      var ctrl = '';
      var token = '';
      var prefix = String(parts[0] || '');
      if (parts.length >= 2) {
        var bn = parseInt(parts[1], 10);
        if (!isNaN(bn)) bag = bn;
      }
      if (parts.length >= 3) ctrl = String(parts[2] || '');
      if (parts.length >= 4) token = String(parts[3] || '');
      return { raw: sampleId, prefix: prefix, bag: bag, ctrl: ctrl, token: token, parts: parts };
    }

    function incMap(map, key) { map[key] = (map[key] || 0) + 1; }

    // -------- Rule matching helpers (ES5 + Safari-safe) ----------
    var _rxCache = {};
    function rxFromString(pat) {
      if (!pat) return null;
      if (_rxCache.hasOwnProperty(pat)) return _rxCache[pat];
      try { _rxCache[pat] = new RegExp(pat, 'i'); }
      catch (e) { _rxCache[pat] = null; }
      return _rxCache[pat];
    }

    function matchAssay(assay, assayPattern) {
      if (!assayPattern) return true;
      var rx = rxFromString(assayPattern);
      if (!rx) return false;
      return rx.test(String(assay || ''));
    }

    function matchText(val, matchType, pattern) {
      val = (val === undefined || val === null) ? '' : String(val);
      pattern = (pattern === undefined || pattern === null) ? '' : String(pattern);

      if (matchType === 'nonempty') return val.replace(/\s+/g,'').length > 0;

      var vlow = val.toLowerCase();
      var plow = pattern.toLowerCase();

      if (matchType === 'exact_ci') return vlow.trim() === plow.trim();
      // default: contains_ci
      return vlow.indexOf(plow) >= 0;
    }

    function resolveObservedCall(rowObj) {
      var assay = rowObj.assay;
      var pats = DEFAULT_RULES.resultCallPatterns;
      for (var i = 0; i < pats.length; i++) {
        var p = pats[i];
        if (!matchAssay(assay, p.AssayPattern)) continue;

        var field = p.Field || 'Test Result';
        var val = '';
        if (field === 'Test Result') val = rowObj.testResult;
        else if (field === 'Status') val = rowObj.status;
        else if (field === 'Error') val = rowObj.error;
        else val = rowObj[field] || '';

        if (matchText(val, p.MatchType, p.Pattern)) return (p.Call || 'INDET');
      }
      return 'INDET';
    }

    function resolveExpected(rowObj) {
      var assay = rowObj.assay;
      var sampleId = rowObj.sampleId;
      var rules = DEFAULT_RULES.sampleExpectationRules;
      for (var i = 0; i < rules.length; i++) {
        var r = rules[i];
        if (!matchAssay(assay, r.AssayPattern)) continue;
        var rx = rxFromString(r.SampleIdRegex);
        if (rx && rx.test(sampleId)) {
          return { expectedCall: r.ExpectedCall || '', expectedTestType: r.ExpectedTestType || '', sampleTypeCode: r.SampleTypeCode };
        }
      }
      return { expectedCall: '', expectedTestType: '', sampleTypeCode: -1 };
    }

    function extractErrorCode(err) {
      err = String(err || '').trim();
      if (!err) return '';
      var m = err.match(/^([0-9A-Za-z\-]+)\s*:/);
      if (m) return m[1];
      m = err.match(/^([0-9A-Za-z\-]+)$/);
      if (m) return m[1];
      return '';
    }

    function isNumericCartridge(x) {
      var n = parseFloat(String(x || '').trim());
      return !isNaN(n);
    }

    // -------- Aggregations --------
    var assays = {};
    var assayVers = {};
    var reagentLots = {};
    var controlMaterials = {};
    var bagSamples = {}; // bag -> map of sample numbers
    var replacements = [];
    var delaminations = [];

    var dupSample = {};
    var dupCart = {};

    var resultCounts = {};
    var invalidRows = [];
    var wrongTestType = [];
    var parityIssues = [];
    var functionalDeviations = [];

    var lowestCart = null;
    var refIsX = null;

    var liteRows = [];
    for (var ri = 0; ri < rows.length; ri++) {
      var cols = rows[ri];

      var sAssay = safeCol(cols, idxAssay);
      var sAssayVer = safeCol(cols, idxAssayVer);
      var sSample = safeCol(cols, idxSample);
      var sCart = safeCol(cols, idxCart);
      var sLot = safeCol(cols, idxLot);
      var sType = safeCol(cols, idxTestType);
      var sInstr = safeCol(cols, idxInstr);
      var sModule = safeCol(cols, idxModule);
      var sSw = safeCol(cols, idxSw);
      var sStart = safeCol(cols, idxStart);
      var sStatus = safeCol(cols, idxStatus);
      var sRes = safeCol(cols, idxResult);
      var sMaxP = safeCol(cols, idxMaxP);
      var sErr = safeCol(cols, idxError);

      if (sAssay === '') sAssay = 'Blank assay';
      if (sAssayVer === '') sAssayVer = 'Blank version';
      if (sLot === '') sLot = 'Blank reagent lot ID';

      incMap(assays, sAssay);
      incMap(assayVers, sAssayVer);
      incMap(reagentLots, sLot);

      var prefix = String(sSample || '').split('_')[0] || '';
      if (prefix === '') prefix = 'Blank sample ID';
      incMap(controlMaterials, prefix);

      var lineNo = (typeof extra.headerIdx === 'number' ? (extra.headerIdx + 2 + ri) : (ri + 2));

      if (sSample) {
        if (!dupSample[sSample]) dupSample[sSample] = { value: sSample, count: 0, lines: [] };
        dupSample[sSample].count++;
        dupSample[sSample].lines.push(lineNo);
      }
      if (sCart) {
        if (!dupCart[sCart]) dupCart[sCart] = { value: sCart, count: 0, lines: [] };
        dupCart[sCart].count++;
        dupCart[sCart].lines.push(lineNo);
      }

      if (sRes) incMap(resultCounts, sRes);

      var sid = parseSampleId(sSample);

      if (sid.bag !== null) {
        var bkey = String(sid.bag);
        if (!bagSamples.hasOwnProperty(bkey)) bagSamples[bkey] = {};
        var token = sid.token || '';
        var m2 = token.match(/\d+/);
        if (m2) {
          var num = parseInt(m2[0], 10);
          if (!isNaN(num)) {
            var sn = ('0' + String(num)).slice(-2);
            bagSamples[bkey][sn] = true;
          }
        }
      }

      if (sid.token.indexOf('A') >= 0) replacements.push({ line: lineNo, sampleId: sSample });
      if (sid.token.indexOf('D') >= 0) delaminations.push({ line: lineNo, sampleId: sSample });

      if (isNumericCartridge(sCart)) {
        var ncart = parseFloat(String(sCart));
        if (lowestCart === null || ncart < lowestCart) {
          lowestCart = ncart;
          refIsX = (sid.token.indexOf('X') >= 0);
        }
      }

      var rowObj = {
        line: lineNo,
        assay: sAssay,
        assayVer: sAssayVer,
        lot: sLot,
        sampleId: sSample,
        cartSn: sCart,
        testType: sType,
        instrumentSn: sInstr,
        moduleSn: sModule,
        swVersion: sSw,
        startTime: sStart,
        status: sStatus,
        testResult: sRes,
        maxPressure: sMaxP,
        error: sErr,
        prefix: prefix,
        bag: sid.bag,
        ctrl: sid.ctrl,
        token: sid.token
      };

      rowObj.observedCall = resolveObservedCall(rowObj);
      var exp = resolveExpected(rowObj);
      rowObj.expectedCall = exp.expectedCall;
      rowObj.expectedTestType = exp.expectedTestType;
      rowObj.sampleTypeCode = exp.sampleTypeCode;

      var errCode = extractErrorCode(rowObj.error);
      rowObj.errorCode = errCode;
      if (errCode && DEFAULT_RULES.errorCodeMap && DEFAULT_RULES.errorCodeMap[errCode]) {
        rowObj.errorName = DEFAULT_RULES.errorCodeMap[errCode].name || '';
        rowObj.retest = DEFAULT_RULES.errorCodeMap[errCode].retest || '';
      } else {
        rowObj.errorName = '';
        rowObj.retest = '';
      }

      if (rowObj.observedCall === 'INDET') invalidRows.push(rowObj);

      if (rowObj.expectedTestType && rowObj.testType && rowObj.testType.indexOf(rowObj.expectedTestType) < 0) {
        wrongTestType.push(rowObj);
      }

      if (rowObj.expectedCall && rowObj.observedCall && rowObj.expectedCall !== rowObj.observedCall) {
        var kind = (rowObj.expectedCall === 'POS' && rowObj.observedCall === 'NEG') ? 'False Negative'
                 : (rowObj.expectedCall === 'NEG' && rowObj.observedCall === 'POS') ? 'False Positive'
                 : 'Mismatch';
        functionalDeviations.push({ kind: kind, row: rowObj });
      }

      liteRows.push(rowObj);
    }

    // Missing samples (config)
    var ms = DEFAULT_RULES.missingSamplesConfig || {};
    var missingSamples = [];
    var bagMin = (typeof ms.BagMin === 'number') ? ms.BagMin : 0;
    var bagMax = (typeof ms.BagMax === 'number') ? ms.BagMax : 10;

    for (var b = bagMin; b <= bagMax; b++) {
      var setMap = bagSamples[String(b)] || {};
      var sMin = (b === 0) ? (ms.Bag0SampleMin || 1) : (ms.OtherBagSampleMin || 1);
      var sMax = (b === 0) ? (ms.Bag0SampleMax || 10) : (ms.OtherBagSampleMax || 20);

      for (var s = sMin; s <= sMax; s++) {
        var sn = ('0' + String(s)).slice(-2);
        if (!setMap[sn]) missingSamples.push({ bag: b, sampleNo: sn });
      }
    }

    // Parity check
    if (DEFAULT_RULES.parityConfig && String(DEFAULT_RULES.parityConfig.Enabled || '').toLowerCase() === 'yes' && lowestCart !== null) {
      var oddOrEvenX = refIsX ? (lowestCart % 2) : ((lowestCart + 1) % 2);

      for (ri = 0; ri < liteRows.length; ri++) {
        var rr2 = liteRows[ri];
        if (!isNumericCartridge(rr2.cartSn)) continue;

        var n2 = parseFloat(String(rr2.cartSn));
        var isX = rr2.token.indexOf('X') >= 0;
        var isPlus = rr2.token.indexOf('+') >= 0;

        if (isX && (n2 % 2) !== oddOrEvenX) {
          parityIssues.push({ line: rr2.line, sampleId: rr2.sampleId, cartSn: rr2.cartSn, expected: '+', observed: 'X' });
        } else if (isPlus && (n2 % 2) !== ((oddOrEvenX + 1) % 2)) {
          parityIssues.push({ line: rr2.line, sampleId: rr2.sampleId, cartSn: rr2.cartSn, expected: 'X', observed: '+' });
        }
      }
    }

    function mapToList(m) {
      var out = [];
      for (var k in m) if (m.hasOwnProperty(k)) out.push({ key: k, count: m[k] });
      out.sort(function (a, b) { return b.count - a.count; });
      return out;
    }

    var resultList = [];
    for (var rk in resultCounts) if (resultCounts.hasOwnProperty(rk)) resultList.push({ value: rk, count: resultCounts[rk] });
    resultList.sort(function (a, b) { return b.count - a.count; });

    var assayList = mapToList(assays);
    var assayVerList = mapToList(assayVers);
    var lotList = mapToList(reagentLots);
    var cmList = mapToList(controlMaterials);

    var dupSampleList = [];
    for (var ds in dupSample) if (dupSample.hasOwnProperty(ds) && dupSample[ds].count > 1) dupSampleList.push(dupSample[ds]);
    dupSampleList.sort(function (a, b) { return b.count - a.count; });

    var dupCartList = [];
    for (var dc in dupCart) if (dupCart.hasOwnProperty(dc) && dupCart[dc].count > 1) dupCartList.push(dupCart[dc]);
    dupCartList.sort(function (a, b) { return b.count - a.count; });

    return {
      ok: true,
      delim: extra.delim || '',
      headerIdx: (typeof extra.headerIdx === 'number' ? extra.headerIdx : -1),
      rowCount: rows.length,

      assays: assayList,
      assayVersions: assayVerList,
      reagentLots: lotList,
      controlMaterials: cmList,

      duplicateSamples: dupSampleList,
      duplicateCarts: dupCartList,

      results: resultList,
      invalid: invalidRows,

      missingSamples: missingSamples,
      replacements: replacements,
      delaminations: delaminations,
      wrongTestType: wrongTestType,
      parityIssues: parityIssues,
      functionalDeviations: functionalDeviations,

      _rows: liteRows
    };
  }


function parseCsv(text) {
    text = text || '';
    if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);

    var lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');

    // Guess delimiter from first non-empty line
    var delim = ';';
    for (var i = 0; i < lines.length; i++) {
      if (lines[i] && lines[i].length) {
        var cSemi = countChar(lines[i], ';');
        var cComma = countChar(lines[i], ',');
        delim = (cSemi >= cComma) ? ';' : ',';
        break;
      }
    }

    // Find header row dynamically (look for core columns)
    var headerIdx = -1;
    for (i = 0; i < lines.length; i++) {
      var l = lines[i];
      if (!l) continue;
      var low = l.toLowerCase();
      if (low.indexOf('assay') >= 0 && low.indexOf('sample') >= 0 && (low.indexOf('cartridge') >= 0 || low.indexOf('s/n') >= 0)) {
        headerIdx = i;
        break;
      }
    }
    if (headerIdx < 0) return { ok: false, error: 'Kunde inte hitta header-rad i CSV.' };

    var headers = splitCsvLine(lines[headerIdx], delim);
    var rows = [];
    for (i = headerIdx + 1; i < lines.length; i++) {
      if (!lines[i]) continue;
      if (/^(\s*;)+\s*$/.test(lines[i]) || /^(\s*,)+\s*$/.test(lines[i])) continue;
      var cols = splitCsvLine(lines[i], delim);
      if (cols.length < 4) continue;
      rows.push(cols);
    }

    return analyzeTestSummaryTable(headers, rows, { delim: delim, headerIdx: headerIdx });
  }


  function countChar(s, ch) {
    var n = 0;
    for (var i = 0; i < s.length; i++) if (s.charAt(i) === ch) n++;
    return n;
  }

  function splitCsvLine(line, delim) {
    var out = [];
    var cur = '';
    var inQ = false;
    for (var i = 0; i < line.length; i++) {
      var ch = line.charAt(i);
      if (inQ) {
        if (ch === '"') {
          if (i + 1 < line.length && line.charAt(i + 1) === '"') { cur += '"'; i++; }
          else inQ = false;
        } else {
          cur += ch;
        }
      } else {
        if (ch === '"') inQ = true;
        else if (ch === delim) { out.push(cur); cur = ''; }
        else cur += ch;
      }
    }
    out.push(cur);
    return out;
  }

  function findHeader(headers, regex) {
    for (var i = 0; i < headers.length; i++) {
      var h = (headers[i] || '').toString().trim();
      if (regex.test(h)) return i;
    }
    return -1;
  }

  function pickDuplicates(map) {
    var out = [];
    for (var k in map) {
      if (!map.hasOwnProperty(k)) continue;
      if (map[k] > 1) out.push({ key: k, count: map[k] });
    }
    out.sort(function (a, b) { return b.count - a.count; });
    return out;
  }

  // ----------------------------
  // ZIP + DEFLATE (raw) for XLSX
  // ----------------------------
  function readU16LE(bytes, off) { return bytes[off] | (bytes[off + 1] << 8); }
  function readU32LE(bytes, off) { return (bytes[off] | (bytes[off + 1] << 8) | (bytes[off + 2] << 16) | (bytes[off + 3] << 24)) >>> 0; }

  function decodeUtf8(bytes) {
    if (window.TextDecoder) return new TextDecoder('utf-8').decode(bytes);
    var s = '';
    for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i] & 0xFF);
    return s;
  }

  function unzipLocal(bytes) {
    var out = {};
    var off = 0;
    while (off + 30 < bytes.length) {
      var sig = readU32LE(bytes, off);
      if (sig !== 0x04034b50) break;

      var flags = readU16LE(bytes, off + 6);
      var method = readU16LE(bytes, off + 8);
      var compSize = readU32LE(bytes, off + 18);
      var uncompSize = readU32LE(bytes, off + 22);
      var nameLen = readU16LE(bytes, off + 26);
      var extraLen = readU16LE(bytes, off + 28);

      var nameBytes = bytes.subarray(off + 30, off + 30 + nameLen);
      var name = decodeUtf8(nameBytes);

      var dataStart = off + 30 + nameLen + extraLen;
      var dataEnd = dataStart + compSize;
      if (dataEnd > bytes.length) break;

      var comp = bytes.subarray(dataStart, dataEnd);
      var data;
      if (method === 0) data = comp;
      else if (method === 8) data = inflateRaw(comp, uncompSize);
      else data = new Uint8Array(0);

      out[name] = data;

      off = dataEnd;
      if (flags & 0x08) break;
    }
    return out;
  }

  function BitReader(bytes) {
    this.bytes = bytes;
    this.pos = 0;
    this.bitbuf = 0;
    this.bitcnt = 0;
  }

  BitReader.prototype.readBits = function (n) {
    while (this.bitcnt < n) {
      if (this.pos >= this.bytes.length) throw new Error('Unexpected EOF in bitstream');
      this.bitbuf |= (this.bytes[this.pos++] << this.bitcnt);
      this.bitcnt += 8;
    }
    var val = this.bitbuf & ((1 << n) - 1);
    this.bitbuf >>>= n;
    this.bitcnt -= n;
    return val;
  };

  BitReader.prototype.alignByte = function () {
    this.bitbuf = 0;
    this.bitcnt = 0;
  };

  function buildHuffman(codeLengths) {
    var maxLen = 0;
    for (var i = 0; i < codeLengths.length; i++) if (codeLengths[i] > maxLen) maxLen = codeLengths[i];

    var blCount = new Array(maxLen + 1);
    for (i = 0; i < blCount.length; i++) blCount[i] = 0;

    for (i = 0; i < codeLengths.length; i++) {
      var len = codeLengths[i];
      if (len > 0) blCount[len]++;
    }

    var nextCode = new Array(maxLen + 1);
    var code = 0;
    blCount[0] = 0;
    for (i = 1; i <= maxLen; i++) {
      code = (code + blCount[i - 1]) << 1;
      nextCode[i] = code;
    }

    var root = {};
    for (var sym = 0; sym < codeLengths.length; sym++) {
      var l = codeLengths[sym];
      if (!l) continue;
      var c = nextCode[l]++;
      var node = root;
      for (var bit = l - 1; bit >= 0; bit--) {
        var b = (c >> bit) & 1;
        if (!node[b]) node[b] = {};
        node = node[b];
      }
      node.sym = sym;
    }
    return root;
  }

  function decodeSym(br, tree) {
    var node = tree;
    while (true) {
      var b = br.readBits(1);
      node = node[b];
      if (!node) throw new Error('Bad Huffman code');
      if (node.sym !== undefined) return node.sym;
    }
  }

  var LEN_BASE = [3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258];
  var LEN_EXTRA= [0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0];
  var DIST_BASE=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577];
  var DIST_EXTRA=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13];

  function fixedLitLenTree() {
    var lengths = new Array(288);
    for (var i = 0; i <= 143; i++) lengths[i] = 8;
    for (i = 144; i <= 255; i++) lengths[i] = 9;
    for (i = 256; i <= 279; i++) lengths[i] = 7;
    for (i = 280; i <= 287; i++) lengths[i] = 8;
    return buildHuffman(lengths);
  }

  function fixedDistTree() {
    var lengths = new Array(32);
    for (var i = 0; i < 32; i++) lengths[i] = 5;
    return buildHuffman(lengths);
  }

  function inflateRaw(compBytes, expectedSize) {
    var br = new BitReader(compBytes);
    var out = [];
    var finalBlock = 0;

    var litTreeFixed = null, distTreeFixed = null;

    while (!finalBlock) {
      finalBlock = br.readBits(1);
      var btype = br.readBits(2);

      if (btype === 0) {
        br.alignByte();
        if (br.pos + 4 > br.bytes.length) throw new Error('Bad stored block');
        var len = br.bytes[br.pos] | (br.bytes[br.pos + 1] << 8);
        var nlen = br.bytes[br.pos + 2] | (br.bytes[br.pos + 3] << 8);
        br.pos += 4;
        if (((len ^ 0xFFFF) & 0xFFFF) !== (nlen & 0xFFFF)) throw new Error('Bad stored block len');
        for (var i = 0; i < len; i++) out.push(br.bytes[br.pos++]);
      } else {
        var litTree, distTree;

        if (btype === 1) {
          if (!litTreeFixed) litTreeFixed = fixedLitLenTree();
          if (!distTreeFixed) distTreeFixed = fixedDistTree();
          litTree = litTreeFixed;
          distTree = distTreeFixed;
        } else if (btype === 2) {
          var HLIT = br.readBits(5) + 257;
          var HDIST = br.readBits(5) + 1;
          var HCLEN = br.readBits(4) + 4;

          var order = [16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];
          var clen = new Array(19);
          for (var z = 0; z < 19; z++) clen[z] = 0;
          for (z = 0; z < HCLEN; z++) clen[order[z]] = br.readBits(3);
          var clenTree = buildHuffman(clen);

          var all = new Array(HLIT + HDIST);
          var idx = 0;
          while (idx < all.length) {
            var sym = decodeSym(br, clenTree);
            if (sym <= 15) {
              all[idx++] = sym;
            } else if (sym === 16) {
              var repeat = br.readBits(2) + 3;
              var prev = idx ? all[idx - 1] : 0;
              while (repeat-- && idx < all.length) all[idx++] = prev;
            } else if (sym === 17) {
              repeat = br.readBits(3) + 3;
              while (repeat-- && idx < all.length) all[idx++] = 0;
            } else if (sym === 18) {
              repeat = br.readBits(7) + 11;
              while (repeat-- && idx < all.length) all[idx++] = 0;
            } else {
              throw new Error('Bad code length symbol');
            }
          }

          var litLens = all.slice(0, HLIT);
          var distLens = all.slice(HLIT);

          litTree = buildHuffman(litLens);
          distTree = buildHuffman(distLens);
        } else {
          throw new Error('Unsupported block type');
        }

        while (true) {
          var s = decodeSym(br, litTree);
          if (s < 256) {
            out.push(s);
          } else if (s === 256) {
            break;
          } else {
            var li = s - 257;
            var length = LEN_BASE[li] + br.readBits(LEN_EXTRA[li]);

            var ds = decodeSym(br, distTree);
            var dist = DIST_BASE[ds] + br.readBits(DIST_EXTRA[ds]);

            var start = out.length - dist;
            if (start < 0) throw new Error('Bad distance');

            for (var k = 0; k < length; k++) out.push(out[start + k]);
          }
        }
      }
    }

    var u8 = new Uint8Array(out.length);
    for (var j = 0; j < out.length; j++) u8[j] = out[j] & 0xFF;

    if (expectedSize && u8.length !== expectedSize) {
      // keep anyway
    }
    return u8;
  }

  // ----------------------------
  // XLSX (OOXML) minimal reader
  // ----------------------------
  function xmlUnescape(s) {
    return (s || '')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'");
  }

  function parseSharedStrings(xml) {
    var out = [];
    var reSi = /<si[\s\S]*?<\/si>/g;
    var m;
    while ((m = reSi.exec(xml)) !== null) {
      var si = m[0];
      var reT = /<t[^>]*>([\s\S]*?)<\/t>/g;
      var mt, s = '';
      while ((mt = reT.exec(si)) !== null) s += xmlUnescape(mt[1]);
      out.push(s);
    }
    return out;
  }

  function colToNum(col) {
    var n = 0;
    for (var i = 0; i < col.length; i++) n = n * 26 + (col.charCodeAt(i) - 64);
    return n;
  }

  function numToCol(n) {
    var s = '';
    while (n > 0) {
      var r = (n - 1) % 26;
      s = String.fromCharCode(65 + r) + s;
      n = Math.floor((n - 1) / 26);
    }
    return s;
  }

  function decodeA1(a1) {
    var m = /^([A-Z]+)(\d+)$/.exec(a1);
    if (!m) return { c: 0, r: 0 };
    return { c: colToNum(m[1]), r: parseInt(m[2], 10) };
  }

  function parseDimension(xml) {
    var m = /<dimension[^>]*ref="([^"]+)"/.exec(xml);
    if (!m) return { s: { c: 1, r: 1 }, e: { c: 26, r: 50 } };
    var ref = m[1];
    var parts = ref.split(':');
    var a = decodeA1(parts[0]);
    var b = parts.length > 1 ? decodeA1(parts[1]) : a;
    return { s: { c: a.c, r: a.r }, e: { c: b.c, r: b.r } };
  }

  function parseSheet(xml, sharedStrings) {
    var cells = {};
    var reCell = /<c\b([^>]*)>([\s\S]*?)<\/c>/g;
    var mc;
    while ((mc = reCell.exec(xml)) !== null) {
      var attrs = mc[1];
      var inner = mc[2];

      var mr = /r="([^"]+)"/.exec(attrs);
      if (!mr) continue;
      var addr = mr[1];

      var mt = /t="([^"]+)"/.exec(attrs);
      var t = mt ? mt[1] : '';

      var vMatch = /<v>([\s\S]*?)<\/v>/.exec(inner);
      var v = vMatch ? vMatch[1] : '';

      if (t === 's') {
        var idx = parseInt(v, 10);
        cells[addr] = (sharedStrings && sharedStrings[idx] !== undefined) ? sharedStrings[idx] : '';
      } else if (t === 'b') {
        cells[addr] = (v === '1') ? 'TRUE' : 'FALSE';
      } else if (t === 'str') {
        cells[addr] = xmlUnescape(v);
      } else if (t === 'inlineStr') {
        var it = /<is>[\s\S]*?<\/is>/.exec(inner);
        if (it) {
          var rt = /<t[^>]*>([\s\S]*?)<\/t>/.exec(it[0]);
          cells[addr] = rt ? xmlUnescape(rt[1]) : '';
        } else {
          cells[addr] = '';
        }
      } else {
        if (v === '') cells[addr] = '';
        else {
          var num = Number(v);
          cells[addr] = (isNaN(num) ? xmlUnescape(v) : num);
        }
      }
    }

    var hf = {};
    var mHF = /<headerFooter[\s\S]*?<\/headerFooter>/.exec(xml);
    if (mHF) {
      var block = mHF[0];
      var mOddH = /<oddHeader>([\s\S]*?)<\/oddHeader>/.exec(block);
      var mOddF = /<oddFooter>([\s\S]*?)<\/oddFooter>/.exec(block);
      hf.oddHeader = mOddH ? xmlUnescape(mOddH[1]) : '';
      hf.oddFooter = mOddF ? xmlUnescape(mOddF[1]) : '';
    }

    return { cells: cells, dim: parseDimension(xml), headerFooter: hf, rawXml: xml };
  }

  function openXlsx(arrayBuffer) {
    var bytes = new Uint8Array(arrayBuffer);
    var fileMap = unzipLocal(bytes);

    var wbBytes = fileMap['xl/workbook.xml'];
    if (!wbBytes || !wbBytes.length) throw new Error('workbook.xml saknas');
    var wbXml = decodeUtf8(wbBytes);

    var relsXml = '';
    if (fileMap['xl/_rels/workbook.xml.rels']) relsXml = decodeUtf8(fileMap['xl/_rels/workbook.xml.rels']);

    var sharedStrings = [];
    if (fileMap['xl/sharedStrings.xml']) sharedStrings = parseSharedStrings(decodeUtf8(fileMap['xl/sharedStrings.xml']));

    var ridToTarget = {};
    relsXml.replace(/<Relationship\b[^>]*Id="([^"]+)"[^>]*Target="([^"]+)"[^>]*\/?>/g, function (_, id, target) {
      ridToTarget[id] = target;
      return '';
    });

    var sheetDefs = [];
    wbXml.replace(/<sheet\b[^>]*name="([^"]+)"[^>]*r:id="([^"]+)"[^>]*\/?>/g, function (_, name, rid) {
      sheetDefs.push({ name: name, rid: rid });
      return '';
    });

    var sheets = [];
    for (var i = 0; i < sheetDefs.length; i++) {
      var target = ridToTarget[sheetDefs[i].rid] || '';
      if (!target) continue;
      target = target.replace(/^\//, '');
      var path = 'xl/' + target;
      var sBytes = fileMap[path];
      if (!sBytes) continue;
      var sXml = decodeUtf8(sBytes);
      var sheet = parseSheet(sXml, sharedStrings);
      sheet.name = sheetDefs[i].name;
      sheets.push(sheet);
    }

    return { sheets: sheets, fileMap: fileMap };
  }

  function getCell(sheet, addr) {
    if (!sheet || !sheet.cells) return '';
    var v = sheet.cells[addr];
    if (v === undefined || v === null) return '';
    return v;
  }

  function getText(sheet, addr) {
    var v = getCell(sheet, addr);
    if (typeof v === 'number') return String(v);
    return (v || '').toString();
  }

  function isDigitStart(s) {
    s = (s || '').toString().trim();
    if (!s) return false;
    var c = s.charAt(0);
    return c >= '0' && c <= '9';
  }

  function trim(s) { return (s || '').toString().replace(/^\s+|\s+$/g, ''); }

  function normalizeSig(s) {
    s = (s || '').toString().trim();
    if (!s) return '';
    s = s.replace(/\./g, '').replace(/\s+/g, ' ').toUpperCase();
    return s;
  }

  function keys(map) {
    var out = [];
    for (var k in map) if (map.hasOwnProperty(k)) out.push(k);
    out.sort();
    return out;
  }

  // ----------------------------
  // Seal Test analysis
  // ----------------------------
  function findHeaderCol(sheet, headerText, headerRow) {
    headerRow = headerRow || 1;
    var dim = sheet.dim || { s: { c: 1, r: 1 }, e: { c: 26, r: 50 } };
    var maxC = dim.e.c || 26;
    var needle = (headerText || '').toLowerCase();
    for (var c = 1; c <= maxC; c++) {
      var addr = numToCol(c) + headerRow;
      var v = (getText(sheet, addr) || '').toLowerCase();
      if (v === needle) return numToCol(c);
    }
    return '';
  }

  function parseCellAddr(addr) {
    var m = /^([A-Z]+)(\d+)$/i.exec(String(addr || '').trim());
    if (!m) return null;
    return { c: colToNum(m[1].toUpperCase()), r: parseInt(m[2], 10) };
  }

  function makeAddr(c, r) {
    if (!c || !r) return '';
    return numToCol(c) + String(r);
  }

  function addrRight(addr, dx) {
    var p = parseCellAddr(addr);
    if (!p) return '';
    return makeAddr(p.c + (dx || 1), p.r);
  }

  function addrDown(addr, dy) {
    var p = parseCellAddr(addr);
    if (!p) return '';
    return makeAddr(p.c, p.r + (dy || 1));
  }

  function findLabelAddr(sheet, re) {
    if (!sheet || !sheet.cells) return '';
    for (var k in sheet.cells) {
      if (!sheet.cells.hasOwnProperty(k)) continue;
      var txt = trim(getText(sheet, k));
      if (txt && re.test(txt)) return k;
    }
    return '';
  }

  function valueNear(sheet, labelRe) {
    var a = findLabelAddr(sheet, labelRe);
    if (!a) return '';

    // Prefer right cell (common for key/value on same row)
    var v = trim(getText(sheet, addrRight(a, 1)));
    if (v && !labelRe.test(v)) return v;

    // Then below (common for key on row, value on next row)
    v = trim(getText(sheet, addrDown(a, 1)));
    if (v && !labelRe.test(v)) return v;

    // Fallback: a bit further away
    v = trim(getText(sheet, addrRight(a, 2)));
    if (v && !labelRe.test(v)) return v;

    v = trim(getText(sheet, addrDown(a, 2)));
    if (v && !labelRe.test(v)) return v;

    return '';
  }

  function readSealHeader(sheet) {
    return {
      ROBAL: valueNear(sheet, /^ROBAL\b/i),
      PartNumber: valueNear(sheet, /^Part\s*Number\b/i),
      BatchNumber: valueNear(sheet, /^Batch\s*Number/i),
      CartridgeLsp: valueNear(sheet, /(Cartridge.*\(LSP\)|Cartridge\s*LSP|Cartridge\s*No\.?\s*\(LSP\)|Cartridge\s*Number)/i),
      PO: valueNear(sheet, /^PO\s*Number\b/i),
      AssayFamily: valueNear(sheet, /^Assay\s*Family\b/i),
      WeightLossSpec: valueNear(sheet, /Weight\s*Loss\s*Spec/i)
    };
  }

  function readSealPeople(sheet) {
    var testers = [];
    var sigs = [];

    var t = trim(valueNear(sheet, /Name\s+of\s+Tester/i));
    if (!t) t = trim(valueNear(sheet, /Inspected\s+by/i));
    if (t) testers.push(t);

    var s = trim(valueNear(sheet, /Print\s+Full\s+Name.*Sign.*Date/i));
    if (s) sigs.push(s);

    return { testers: testers, sigs: sigs };
  }

  function analyzeSealTest(xlsxObj, label) {
    var dataSheets = [];
    for (var i = 0; i < xlsxObj.sheets.length; i++) {
      var sh = xlsxObj.sheets[i];
      if (sh.name === 'Worksheet Instructions') continue;
      if (isDigitStart(getText(sh, 'H3'))) dataSheets.push(sh);
    }

    var header = null;
    if (dataSheets.length) header = readSealHeader(dataSheets[0]);

    var testers = {};
    var signatures = {};
    for (i = 0; i < dataSheets.length; i++) {
      var t = trim(valueNear(dataSheets[i], /Name\s+of\s+Tester/i) || valueNear(dataSheets[i], /Inspected\s+by/i) || getText(dataSheets[i], 'B43'));
      if (t) {
        var parts = t.split(',');
        for (var p = 0; p < parts.length; p++) {
          var s = trim(parts[p]);
          if (s) testers[s] = true;
        }
      }
      var sig = normalizeSig(getText(dataSheets[i], 'B47'));
      if (sig) signatures[sig] = true;
    }

    var viol = [];
    for (i = 0; i < dataSheets.length; i++) {
      var sheet = dataSheets[i];
      var cart = getText(sheet, 'H3');
      var obsCol = findHeaderCol(sheet, 'Observation', 1);
      if (!obsCol) obsCol = 'M';
      for (var r = 3; r <= 45; r++) {
        var avg = getCell(sheet, 'K' + r);
        var status = (getText(sheet, 'L' + r) || '').toUpperCase();
        var avgNum = (typeof avg === 'number') ? avg : Number(avg);
        var bad = false;
        var reason = '';
        if (!isNaN(avgNum) && avgNum <= -3.0) { bad = true; reason = 'MinusValue<=-3'; }
        if (status === 'FAIL') { bad = true; reason = 'FAIL'; }
        if (!bad) continue;

        viol.push({
          source: label,
          sheet: sheet.name,
          cartridge: cart,
          avg: (!isNaN(avgNum) ? avgNum : getText(sheet, 'K' + r)),
          status: status || '',
          reason: reason,
          initial: getText(sheet, 'H' + r),
          final: getText(sheet, 'I' + r),
          observation: getText(sheet, obsCol + r)
        });
      }
    }

    return {
      label: label,
      sheetCount: xlsxObj.sheets.length,
      dataSheetCount: dataSheets.length,
      header: header,
      testers: keys(testers),
      signatures: keys(signatures),
      violations: viol
    };
  }

  // ----------------------------
  // Worksheet analysis (minimal)
  // ----------------------------
  function analyzeWorksheet(xlsxObj) {
    var sheet = null;
    for (var i = 0; i < xlsxObj.sheets.length; i++) {
      if (xlsxObj.sheets[i].name === 'Test Summary') { sheet = xlsxObj.sheets[i]; break; }
    }
    if (!sheet && xlsxObj.sheets.length) sheet = xlsxObj.sheets[0];
    if (!sheet) return { ok: false, error: 'Worksheet: inga sheets hittades' };

    return {
      ok: true,
      sheetName: sheet.name,
      partNumber: getText(sheet, 'B3'),
      cartridgeLsp: getText(sheet, 'B4')
    };
  }

  // ----------------------------
  // Render results
  // ----------------------------
  function escapeHtml(s) {
    s = (s === undefined || s === null) ? '' : String(s);
    return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }

  function renderDupList(title, arr) {
    if (!arr || !arr.length) return el('div', { 'class': 'small muted', text: title + ': inga dubletter.' });
    var wrap = el('div', { 'class': 'small' });
    wrap.appendChild(el('div', { 'class': 'muted', text: title + ': ' + arr.length + ' st.' }));
    var t = el('table');
    var th = el('thead');
    var tr = el('tr');
    tr.appendChild(el('th', { text: 'Value' }));
    tr.appendChild(el('th', { text: 'Count' }));
    th.appendChild(tr);
    t.appendChild(th);

    var tb = el('tbody');
    for (var i = 0; i < Math.min(arr.length, 20); i++) {
      var r = el('tr');
      r.appendChild(el('td', { 'class': 'mono', text: arr[i].key }));
      r.appendChild(el('td', { 'class': 'mono', text: String(arr[i].count) }));
      tb.appendChild(r);
    }
    t.appendChild(tb);
    wrap.appendChild(t);
    return wrap;
  }

    function renderResults(model) {
    var out = $('results');
    clearNode(out);

    out.appendChild(el('h2', { text: 'Resultat' }));

    if (!model || !model.csv || !model.csv.ok) {
      out.appendChild(el('div', { 'class': 'small err', text: 'Ingen CSV-data att visa.' }));
      return;
    }

    var csv = model.csv;

    function has(arr) { return (arr && arr.length); }

    var top = el('div', { 'class': 'card' });
    var pills = el('div');

    pills.appendChild(pill('Rows: ' + csv.rowCount, 'ok'));

    if (csv.assays && csv.assays.length) pills.appendChild(pill('Assay: ' + csv.assays[0].key, 'ok'));
    if (csv.assayVersions && csv.assayVersions.length) pills.appendChild(pill('Ver: ' + csv.assayVersions[0].key, 'ok'));
    if (csv.reagentLots && csv.reagentLots.length) pills.appendChild(pill('Lot: ' + csv.reagentLots[0].key, 'ok'));

    if (has(csv.functionalDeviations)) pills.appendChild(pill('Functional mismatches: ' + csv.functionalDeviations.length, 'bad'));
    else pills.appendChild(pill('Functional mismatches: 0', 'ok'));

    if (has(csv.invalid)) pills.appendChild(pill('INDET / Error / NoResult: ' + csv.invalid.length, 'warn'));
    else pills.appendChild(pill('INDET / Error / NoResult: 0', 'ok'));

    if (has(csv.duplicateSamples)) pills.appendChild(pill('Dup SampleID: ' + csv.duplicateSamples.length, 'warn'));
    else pills.appendChild(pill('Dup SampleID: 0', 'ok'));

    if (has(csv.duplicateCarts)) pills.appendChild(pill('Dup Cartridge S/N: ' + csv.duplicateCarts.length, 'warn'));
    else pills.appendChild(pill('Dup Cartridge S/N: 0', 'ok'));

    if (has(csv.missingSamples)) pills.appendChild(pill('Missing samples: ' + csv.missingSamples.length, 'warn'));
    else pills.appendChild(pill('Missing samples: 0', 'ok'));

    if (has(csv.wrongTestType)) pills.appendChild(pill('Wrong Test Type: ' + csv.wrongTestType.length, 'warn'));
    else pills.appendChild(pill('Wrong Test Type: 0', 'ok'));

    if (has(csv.parityIssues)) pills.appendChild(pill('+ / X issues: ' + csv.parityIssues.length, 'warn'));
    else pills.appendChild(pill('+ / X issues: 0', 'ok'));

    top.appendChild(pills);
    top.appendChild(el('div', { 'class': 'small muted', text: 'Delimiter: ' + csv.delim + ' | Header rad: ' + (csv.headerIdx + 1) + ' | Rules: embedded' }));
    out.appendChild(top);

    function renderTable(columns, rows, rowToCells) {
      var tbl = el('table');
      var thead = el('thead');
      var trh = el('tr');
      for (var c = 0; c < columns.length; c++) trh.appendChild(el('th', { text: columns[c] }));
      thead.appendChild(trh);
      tbl.appendChild(thead);

      var tbody = el('tbody');
      for (var r = 0; r < rows.length; r++) {
        var tr = el('tr');
        var cells = rowToCells(rows[r]);
        for (var k = 0; k < cells.length; k++) tr.appendChild(el('td', { text: cells[k] }));
        tbody.appendChild(tr);
      }
      tbl.appendChild(tbody);
      return tbl;
    }

    var secMeta = el('div', { 'class': 'card' });
    secMeta.appendChild(el('h3', { text: 'Sammanfattning (counts)' }));

    function renderCountList(title, list) {
      if (!list || !list.length) return el('div', { 'class': 'small muted', text: title + ': (tomt)' });
      return renderTable([title, 'Count'], list, function (x) { return [x.key, String(x.count)]; });
    }

    secMeta.appendChild(renderCountList('Assay', csv.assays));
    secMeta.appendChild(renderCountList('Assay Version', csv.assayVersions));
    secMeta.appendChild(renderCountList('Reagent Lot ID', csv.reagentLots));
    secMeta.appendChild(renderCountList('Control Materials (prefix)', csv.controlMaterials));
    out.appendChild(secMeta);

    var secDup = el('div', { 'class': 'card' });
    secDup.appendChild(el('h3', { text: 'Dubletter (med radnummer)' }));

    if (!has(csv.duplicateSamples) && !has(csv.duplicateCarts)) {
      secDup.appendChild(el('div', { 'class': 'small muted', text: 'Inga dubletter hittades.' }));
    } else {
      if (has(csv.duplicateSamples)) {
        secDup.appendChild(el('div', { 'class': 'small', text: 'Duplicate Sample ID:' }));
        secDup.appendChild(renderTable(['Sample ID', 'Count', 'Lines'], csv.duplicateSamples, function (x) { return [x.value, String(x.count), x.lines.join(', ')]; }));
      }
      if (has(csv.duplicateCarts)) {
        secDup.appendChild(el('div', { 'class': 'small', text: 'Duplicate Cartridge S/N:' }));
        secDup.appendChild(renderTable(['Cartridge S/N', 'Count', 'Lines'], csv.duplicateCarts, function (x) { return [x.value, String(x.count), x.lines.join(', ')]; }));
      }
    }
    out.appendChild(secDup);

    var secInv = el('div', { 'class': 'card' });
    secInv.appendChild(el('h3', { text: 'INDET / Error / No Result (rows)' }));
    if (!has(csv.invalid)) {
      secInv.appendChild(el('div', { 'class': 'small muted', text: 'Inga rader klassade som INDET hittades.' }));
    } else {
      secInv.appendChild(renderTable(
        ['Line', 'Sample ID', 'Cartridge S/N', 'Test Type', 'Observed Call', 'Test Result', 'Error Code', 'Error Name', 'Retest?'],
        csv.invalid,
        function (r) { return [String(r.line), r.sampleId, r.cartSn, r.testType, r.observedCall, r.testResult, r.errorCode, r.errorName, r.retest]; }
      ));
    }
    out.appendChild(secInv);

    var secRes = el('div', { 'class': 'card' });
    secRes.appendChild(el('h3', { text: 'Resultatsammanställning' }));
    if (!has(csv.results)) {
      secRes.appendChild(el('div', { 'class': 'small muted', text: 'Inga testresultat att summera.' }));
    } else {
      secRes.appendChild(renderTable(
        ['Test Result', 'Count'],
        csv.results,
        function (r) { return [r.value, String(r.count)]; }
      ));
    }
    out.appendChild(secRes);

    var secMissing = el('div', { 'class': 'card' });
    secMissing.appendChild(el('h3', { text: 'Missing samples (bag/sample)' }));
    if (!has(csv.missingSamples)) {
      secMissing.appendChild(el('div', { 'class': 'small muted', text: 'Inga saknade prover enligt konfigurationen.' }));
    } else {
      secMissing.appendChild(renderTable(['Bag', 'Sample'], csv.missingSamples, function (x) { return [String(x.bag), x.sampleNo]; }));
    }
    out.appendChild(secMissing);

    var secRD = el('div', { 'class': 'card' });
    secRD.appendChild(el('h3', { text: 'Replacements / Delaminations' }));
    if (!has(csv.replacements)) secRD.appendChild(el('div', { 'class': 'small muted', text: 'Replacements: inga.' }));
    else secRD.appendChild(renderTable(['Line', 'Sample ID'], csv.replacements, function (x) { return [String(x.line), x.sampleId]; }));
    if (!has(csv.delaminations)) secRD.appendChild(el('div', { 'class': 'small muted', text: 'Delaminations: inga.' }));
    else secRD.appendChild(renderTable(['Line', 'Sample ID'], csv.delaminations, function (x) { return [String(x.line), x.sampleId]; }));
    out.appendChild(secRD);

    var secTT = el('div', { 'class': 'card' });
    secTT.appendChild(el('h3', { text: 'Wrong Test Type' }));
    if (!has(csv.wrongTestType)) {
      secTT.appendChild(el('div', { 'class': 'small muted', text: 'Inga felaktiga Test Type hittades (eller saknar rule för expected).' }));
    } else {
      secTT.appendChild(renderTable(
        ['Line', 'Sample ID', 'Expected', 'Actual'],
        csv.wrongTestType,
        function (r) { return [String(r.line), r.sampleId, r.expectedTestType, r.testType]; }
      ));
    }
    out.appendChild(secTT);

    var secPX = el('div', { 'class': 'card' });
    secPX.appendChild(el('h3', { text: '+ / X parity check' }));
    if (!has(csv.parityIssues)) {
      secPX.appendChild(el('div', { 'class': 'small muted', text: 'Inga +/X-missar hittades (eller parity disabled).' }));
    } else {
      secPX.appendChild(renderTable(
        ['Line', 'Sample ID', 'Cartridge S/N', 'Expected', 'Observed'],
        csv.parityIssues,
        function (x) { return [String(x.line), x.sampleId, x.cartSn, x.expected, x.observed]; }
      ));
    }
    out.appendChild(secPX);

    var secFun = el('div', { 'class': 'card' });
    secFun.appendChild(el('h3', { text: 'Functional (Expected vs Observed Call)' }));
    if (!has(csv.functionalDeviations)) {
      secFun.appendChild(el('div', { 'class': 'small muted', text: 'Inga functional mismatches hittades.' }));
    } else {
      secFun.appendChild(renderTable(
        ['Kind', 'Line', 'Sample ID', 'Expected', 'Observed', 'Test Result', 'Error'],
        csv.functionalDeviations,
        function (x) {
          var r = x.row;
          return [x.kind, String(r.line), r.sampleId, r.expectedCall, r.observedCall, r.testResult, r.error];
        }
      ));
    }
    out.appendChild(secFun);

    out.appendChild(el('div', { 'class': 'small muted', text: 'Tips: Om något ser fel ut, öppna DevTools (F12) och kolla Console.' }));
  }



  

  // ----------------------------
  // Read files + run analysis
  // ----------------------------
function readFileAsArrayBuffer(file) {
  return new Promise(function (resolve, reject) {
    var fr = new FileReader();
    fr.onload = function () { resolve(fr.result); };
    fr.onerror = function () { reject(new Error('FileReader error: ' + (file && file.name ? file.name : ''))); };
    fr.readAsArrayBuffer(file);
  });
}

  function readFileAsText(file) {
    return new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onload = function () { resolve(fr.result); };
      fr.onerror = function () { reject(new Error('FileReader error: ' + (file && file.name ? file.name : ''))); };
      fr.readAsText(file);
    });
  }

function normStr(x) {
  if (x === null || x === undefined) return '';
  return String(x).replace(/\u00A0/g, ' ').trim();
}

// XLSX (minimal offline parser) -> { ok:true, headers:[...], rows:[ [..], [..] ], headerIdx:int }
// Uses JSZip + DOMParser (no external XLSX library required).
function parseXlsxGrid(arrayBuffer) {
  if (typeof JSZip === 'undefined') {
    return { ok: false, error: 'JSZip saknas (krävs för att läsa XLSX offline).' };
  }

  function colLettersToIndex(letters) {
    var n = 0;
    for (var i = 0; i < letters.length; i++) {
      var c = letters.charCodeAt(i);
      if (c >= 65 && c <= 90) n = n * 26 + (c - 64);
      else if (c >= 97 && c <= 122) n = n * 26 + (c - 96);
    }
    return n - 1; // 0-based
  }

  function parseCellRef(ref) {
    ref = String(ref || '');
    var m = ref.match(/^([A-Za-z]+)(\d+)$/);
    if (!m) return null;
    return { c: colLettersToIndex(m[1]), r: parseInt(m[2], 10) - 1 };
  }

  function xmlTextToDoc(xmlText) {
    try {
      return (new DOMParser()).parseFromString(xmlText, 'application/xml');
    } catch (e) {
      return null;
    }
  }

  // Helper: pick worksheet xml (prefer sheet1.xml)
  function pickWorksheetPath(zip) {
    if (zip.file('xl/worksheets/sheet1.xml')) return 'xl/worksheets/sheet1.xml';
    // fallback: first worksheet file
    var first = null;
    zip.forEach(function (relPath, entry) {
      if (first) return;
      if (entry && !entry.dir && relPath.indexOf('xl/worksheets/sheet') === 0 && relPath.slice(-4) === '.xml') {
        first = relPath;
      }
    });
    return first;
  }

  return JSZip.loadAsync(arrayBuffer).then(function (zip) {
    var tasks = [];
    var hasShared = !!zip.file('xl/sharedStrings.xml');
    var wsPath = pickWorksheetPath(zip);
    if (!wsPath) throw new Error('XLSX: kunde inte hitta worksheet xml.');

    // Load shared strings (optional)
    var pShared = hasShared
      ? zip.file('xl/sharedStrings.xml').async('string')
      : Promise.resolve('');

    tasks.push(pShared);
    tasks.push(zip.file(wsPath).async('string'));

    return Promise.all(tasks).then(function (res) {
      var sharedXml = res[0];
      var sheetXml = res[1];

      // sharedStrings
      var shared = [];
      if (sharedXml) {
        var sdoc = xmlTextToDoc(sharedXml);
        if (sdoc) {
          var si = sdoc.getElementsByTagName('si');
          for (var i = 0; i < si.length; i++) {
            // concatenate all <t>
            var tnodes = si[i].getElementsByTagName('t');
            var txt = '';
            for (var j = 0; j < tnodes.length; j++) {
              txt += tnodes[j].textContent || '';
            }
            shared.push(normStr(txt));
          }
        }
      }

      // sheet
      var doc = xmlTextToDoc(sheetXml);
      if (!doc) throw new Error('XLSX: kunde inte tolka sheet XML.');

      var cells = doc.getElementsByTagName('c');
      var grid = {}; // r -> { c -> value }
      var maxR = 0, maxC = 0;

      for (var k = 0; k < cells.length; k++) {
        var cEl = cells[k];
        var ref = cEl.getAttribute('r');
        var pos = parseCellRef(ref);
        if (!pos) continue;

        var t = cEl.getAttribute('t') || '';
        var vEl = cEl.getElementsByTagName('v')[0];
        var isEl = cEl.getElementsByTagName('is')[0];
        var val = '';

        if (t === 's') {
          var idx = vEl ? parseInt(vEl.textContent || '0', 10) : 0;
          val = (idx >= 0 && idx < shared.length) ? shared[idx] : '';
        } else if (t === 'inlineStr') {
          // inline string stored in <is><t>
          if (isEl) {
            var t2 = isEl.getElementsByTagName('t');
            var txt2 = '';
            for (var q = 0; q < t2.length; q++) txt2 += t2[q].textContent || '';
            val = normStr(txt2);
          }
        } else {
          // numbers, dates, etc -> read raw
          val = vEl ? normStr(vEl.textContent || '') : '';
        }

        if (!grid[pos.r]) grid[pos.r] = {};
        grid[pos.r][pos.c] = val;
        if (pos.r > maxR) maxR = pos.r;
        if (pos.c > maxC) maxC = pos.c;
      }

      // Build 2D array
      var rows2d = [];
      for (var rr = 0; rr <= maxR; rr++) {
        var rowObj = grid[rr] || {};
        var rowArr = [];
        for (var cc = 0; cc <= maxC; cc++) {
          rowArr.push(normStr(rowObj.hasOwnProperty(cc) ? rowObj[cc] : ''));
        }
        rows2d.push(rowArr);
      }

      // Header detection (same heuristic as CSV)
      var headerIdx = -1;
      for (rr = 0; rr < rows2d.length; rr++) {
        var joined = rows2d[rr].map(function (v) { return normStr(v).toLowerCase(); }).join(' ');
        if (joined.indexOf('assay') >= 0 && joined.indexOf('sample') >= 0 && (joined.indexOf('cartridge') >= 0 || joined.indexOf('s/n') >= 0)) {
          headerIdx = rr;
          break;
        }
      }
      if (headerIdx < 0) throw new Error('Kunde inte hitta header-rad i XLSX.');

      var headers = rows2d[headerIdx].map(normStr);
      var dataRows = [];
      for (rr = headerIdx + 1; rr < rows2d.length; rr++) {
        var r = rows2d[rr];
        if (!r || !r.length) continue;
        var any = false;
        for (cc = 0; cc < r.length; cc++) {
          if (normStr(r[cc])) { any = true; break; }
        }
        if (!any) continue;
        dataRows.push(r.map(normStr));
      }

      return { ok: true, headers: headers, rows: dataRows, headerIdx: headerIdx };
    });
  }).catch(function (e) {
    return { ok: false, error: (e && e.message) ? e.message : String(e) };
  });
}

  function pickByType(typeKey) {
    for (var i = 0; i < files.length; i++) {
      var tk = files[i].typeKey;
      if (tk === 'auto') tk = files[i].detectedKey;
      if (tk === typeKey) return files[i].file;
    }
    return null;
  }

    function runAnalysis() {
    var btn = $('runBtn');
    btn.disabled = true;
    setStatus('Analyserar...', false);

var fTs = pickByType('testSummary');

if (!fTs) {
  setStatus('Saknar Test Summary (csv/xlsx).', true);
  validateReady();
  return;
}

clearNode($('results'));
$('results').appendChild(el('div', { 'class': 'small muted', text: 'Läser och analyserar Test Summary...' }));

var nameLow = (fTs.name || '').toLowerCase();
var isXlsx = (nameLow.indexOf('.xlsx') >= 0 || nameLow.indexOf('.xls') >= 0);

var p;
if (isXlsx) {
  p = readFileAsArrayBuffer(fTs).then(function (buf) {
    var grid = parseXlsxGrid(buf); // <-- ingen .then här
    if (!grid.ok) throw new Error(grid.error || 'XLSX-parse misslyckades.');
    return analyzeTestSummaryTable(grid.headers, grid.rows, { delim: '', headerIdx: grid.headerIdx });
  });
} else {
  p = readFileAsText(fTs).then(function (csvText) {
    var csv = parseCsv(csvText);
    if (!csv.ok) throw new Error(csv.error || 'CSV-parse misslyckades.');
    return csv;
  });
}

p.then(function (csv) {
  // v7 milestone: Test Summary först
  var model = { csv: csv, sealNeg: null, sealPos: null, worksheet: null };

  // fortfarande: om andra XLSX valda, visa note
  var fNeg = pickByType('sealNeg');
  var fPos = pickByType('sealPos');
  var fWs = pickByType('worksheet');
  model._xlsxSelected = !!(fNeg || fPos || fWs);

  renderResults(model);
  setStatus('OK – Test Summary analys klar.', false);
  validateReady();
}).catch(function (e) {
  var msg = (e && e.message) ? e.message : String(e);
  setStatus('Fel: ' + msg, true);
  clearNode($('results'));
  $('results').appendChild(el('div', { 'class': 'small err', text: msg }));
  validateReady();
});

} // <-- LÄGG TILL DENNA (stänger function runAnalysis)

  // ----------------------------
  // Wire UI
  // ----------------------------
  function init() {
    $('pickBtn').addEventListener('click', function () { $('fileInput').click(); });
    $('fileInput').addEventListener('change', function (ev) {
      if (ev.target && ev.target.files) addFiles(ev.target.files);
      $('fileInput').value = '';
    });

    $('clearBtn').addEventListener('click', function () {
      files = [];
      refreshFileList();
      $('results').textContent = 'Ingen analys kord an.';
      setStatus('', false);
    });

    $('runBtn').addEventListener('click', runAnalysis);

    var drop = $('drop');
    drop.addEventListener('dragover', function (e) { e.preventDefault(); drop.style.borderColor = 'rgba(31,111,235,0.9)'; });
    drop.addEventListener('dragleave', function () { drop.style.borderColor = 'rgba(255,255,255,0.16)'; });
    drop.addEventListener('drop', function (e) {
      e.preventDefault();
      drop.style.borderColor = 'rgba(255,255,255,0.16)';
      if (e.dataTransfer && e.dataTransfer.files) addFiles(e.dataTransfer.files);
    });

    refreshFileList();
  }

  init();

})();


