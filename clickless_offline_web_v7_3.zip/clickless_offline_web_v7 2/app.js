/* ClickLess Offline Analyzer v7 (CSV)
   - ES5 only (no const/let/arrow/template/module/async)
   - Offline XLSX reader: ZIP + raw DEFLATE (inflateRaw)
   - Reads: Seal Test NEG/POS (.xlsx), Worksheet (.xlsx), Test Summary (.csv)
   - Shows results on the page (no downloads).
*/


/* CHANGELOG v7.3
   - Embedded rules CSVs (01..06) via embedded_rules.js (no fetch; offline-safe)
   - Added rules parser + rule-based expected/observed call mismatch computation (non-breaking; shown as extra section)
   - Re-integrated Seal Test NEG/POS + Worksheet XLSX parsing/validation and rendering cards
   - Open-once caching for file reads/parses per run; sequential Promise pipeline to avoid freezes
*/
(function () {
  'use strict';

  // ----------------------------
  // DOM helpers
  // ----------------------------
  function $(id) { return document.getElementById(id); }

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    if (attrs) {
      for (var k in attrs) {
        if (!attrs.hasOwnProperty(k)) continue;
        if (k === 'text') node.textContent = String(attrs[k]);
        else if (k === 'html') node.innerHTML = String(attrs[k]);
        else if (k === 'class') node.className = String(attrs[k]);
        else if (k === 'style') node.setAttribute('style', String(attrs[k]));
        else node.setAttribute(k, String(attrs[k]));
      }
    }
    if (children && children.length) {
      for (var i = 0; i < children.length; i++) node.appendChild(children[i]);
    }
    return node;
  }

  function clearNode(node) { while (node.firstChild) node.removeChild(node.firstChild); }

  function pill(text, kind) {
    var cls = 'pill';
    if (kind === 'ok') cls += ' ok';
    else if (kind === 'bad') cls += ' bad';
    else if (kind === 'warn') cls += ' warn';
    return el('span', { 'class': cls, text: text });
  }

  function setStatus(msg, isError) {
    var s = $('status');
    s.textContent = msg || '';
    s.className = 'small ' + (isError ? 'err' : 'muted');
  }

  // ----------------------------
  // File registry + detection
  // ----------------------------
  var TYPE_OPTIONS = [
    { key: 'auto', label: 'Auto' },
    { key: 'sealNeg', label: 'Seal Test NEG (xlsx)' },
    { key: 'sealPos', label: 'Seal Test POS (xlsx)' },
    { key: 'worksheet', label: 'Worksheet (xlsx)' },
    { key: 'testSummary', label: 'Test Summary (csv/xlsx)' }
  ];

  var files = []; // {file, typeKey, detectedKey}

  function detectTypeByName(name) {
    var n = (name || '').toLowerCase();
    if (n.indexOf('seal test') >= 0 && (n.indexOf('neg') >= 0 || n.indexOf('negative') >= 0)) return 'sealNeg';
    if (n.indexOf('seal test') >= 0 && (n.indexOf('pos') >= 0 || n.indexOf('positive') >= 0)) return 'sealPos';
    if (n.indexOf('worksheet') >= 0) return 'worksheet';
    if (n.indexOf('test summary') >= 0 || n.indexOf('tests summary') >= 0 || n.slice(-4) === '.csv') return 'testSummary';
    if (n.slice(-4) === '.csv') return 'testSummary';
    if (n.slice(-5) === '.xlsx') return 'auto';
    return 'auto';
  }

  // ----------------------------
  // Zip bundle support (Alternative 2)
  // Drop 1 .zip containing the 4 required files.
  // Requires JSZip (loaded via index.html)
  // ----------------------------
  function isZipFile(file) {
    if (!file) return false;
    var n = (file.name || '').toLowerCase();
    if (n.slice(-4) === '.zip') return true;
    var t = (file.type || '').toLowerCase();
    if (t.indexOf('zip') >= 0) return true;
    return false;
  }

  function makeFileLike(data, name, mime) {
    var opts = mime ? { type: mime } : {};
    try {
      return new File([data], name, opts);
    } catch (e) {
      var b = new Blob([data], opts);
      b.name = name;
      return b;
    }
  }

  function readAsArrayBuffer(file) {
    // Prefer modern File/Blob.arrayBuffer, fallback to FileReader
    if (file && typeof file.arrayBuffer === 'function') {
      return file.arrayBuffer();
    }
    return new Promise(function (resolve, reject) {
      try {
        var fr = new FileReader();
        fr.onload = function () { resolve(fr.result); };
        fr.onerror = function () { reject(fr.error || new Error('FileReader error')); };
        fr.readAsArrayBuffer(file);
      } catch (e) {
        reject(e);
      }
    });
  }

  function extractBundleFilesFromZip(zipFile) {
    if (typeof JSZip === 'undefined') {
      return Promise.reject(new Error('JSZip not loaded'));
    }

    return readAsArrayBuffer(zipFile).then(function (buf) {
      return JSZip.loadAsync(buf);
    }).then(function (zip) {
      var picked = { sealNeg: null, sealPos: null, worksheet: null, testSummary: null };

      zip.forEach(function (relPath, entry) {
        if (!entry || entry.dir) return;
        if (relPath.indexOf('__MACOSX/') === 0) return;

        var base = relPath.split('/').pop();
        if (!base) return;
        if (base.indexOf('._') === 0) return;

        var det = detectTypeByName(base);
        if (!picked[det]) {
          picked[det] = { base: base, entry: entry };
        }
      });

      var out = [];
      var tasks = [];

      function pushPicked(key, mime) {
        if (!picked[key]) return;
        tasks.push(
          picked[key].entry.async('arraybuffer').then(function (ab) {
            out.push(makeFileLike(ab, picked[key].base, mime));
          })
        );
      }

      pushPicked('sealNeg', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      pushPicked('sealPos', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      pushPicked('worksheet', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      pushPicked('testSummary', 'text/csv');

      return Promise.all(tasks).then(function () { return out; });
    });
  }


  function typeLabel(key) {
    for (var i = 0; i < TYPE_OPTIONS.length; i++) if (TYPE_OPTIONS[i].key === key) return TYPE_OPTIONS[i].label;
    return key;
  }

  function refreshFileList() {
    var list = $('fileList');
    clearNode(list);

    if (!files.length) {
      list.appendChild(el('div', { 'class': 'small muted', text: 'Inga filer valda.' }));
      $('runBtn').disabled = true;
      return;
    }

    var tbl = el('table');
    var thead = el('thead');
    var trh = el('tr');
    trh.appendChild(el('th', { text: 'Fil' }));
    trh.appendChild(el('th', { text: 'Detekterad typ' }));
    trh.appendChild(el('th', { text: 'Anvand som' }));
    trh.appendChild(el('th', { text: '' }));
    thead.appendChild(trh);
    tbl.appendChild(thead);

    var tbody = el('tbody');
    for (var i = 0; i < files.length; i++) {
      (function (idx) {
        var f = files[idx];
        var tr = el('tr');

        tr.appendChild(el('td', { 'class': 'mono', text: f.file.name }));
        tr.appendChild(el('td', { text: typeLabel(f.detectedKey) }));

        var sel = el('select');
        for (var j = 0; j < TYPE_OPTIONS.length; j++) {
          var opt = el('option', { value: TYPE_OPTIONS[j].key, text: TYPE_OPTIONS[j].label });
          if (TYPE_OPTIONS[j].key === f.typeKey) opt.selected = true;
          sel.appendChild(opt);
        }
        sel.addEventListener('change', function () { files[idx].typeKey = sel.value; validateReady(); });
        tr.appendChild(el('td', null, [sel]));

        var rm = el('button', { 'class': 'btn2', type: 'button', text: 'Ta bort' });
        rm.addEventListener('click', function () { files.splice(idx, 1); refreshFileList(); validateReady(); });
        tr.appendChild(el('td', null, [rm]));

        tbody.appendChild(tr);
      })(i);
    }
    tbl.appendChild(tbody);
    list.appendChild(tbl);

    validateReady();
  }

    function validateReady() {
    var want = { sealNeg: 0, sealPos: 0, worksheet: 0, testSummary: 0 };
    for (var i = 0; i < files.length; i++) {
      var tk = files[i].typeKey;
      if (tk === 'auto') tk = files[i].detectedKey;
      if (want.hasOwnProperty(tk)) want[tk]++;
    }

    // v7: CSV validation is the first milestone — only require Test Summary for now.
    var okCsv = (want.testSummary >= 1);
    $('runBtn').disabled = !okCsv;

    if (!okCsv) {
      setStatus('Välj minst 1 fil: Test Summary (csv).', false);
      return;
    }

    // If other files are missing, we still run CSV-only and show a note.
    var missing = [];
    if (want.sealNeg < 1) missing.push('Seal NEG');
    if (want.sealPos < 1) missing.push('Seal POS');
    if (want.worksheet < 1) missing.push('Worksheet');

    if (missing.length) {
      setStatus('Redo för CSV-validering. (XLSX-delar saknas: ' + missing.join(', ') + ')', false);
    } else {
      setStatus('Redo. Klicka "Kör analys".', false);
    }
  }


  function addFiles(fileList) {
    if (!fileList || !fileList.length) return;

    var incoming = [];
    var tasks = [];

    for (var i = 0; i < fileList.length; i++) {
      var f = fileList[i];
      if (!f) continue;

      if (isZipFile(f)) {
        (function (zipF) {
          setStatus('Reading zip bundle: ' + (zipF.name || 'bundle.zip') + ' ...', false);
          tasks.push(
            extractBundleFilesFromZip(zipF).then(function (extracted) {
              if (extracted && extracted.length) {
                for (var j = 0; j < extracted.length; j++) incoming.push(extracted[j]);
              } else {
                setStatus('Zip did not contain recognizable files: ' + (zipF.name || ''), true);
              }
            }).catch(function (e) {
              var msg = (e && e.message) ? e.message : String(e);
              setStatus('Could not read zip: ' + (zipF.name || '') + ' (' + msg + ')', true);
            })
          );
        })(f);
        continue;
      }

      incoming.push(f);
    }

    Promise.all(tasks).then(function () {
      for (var k = 0; k < incoming.length; k++) {
        var ff = incoming[k];
        var detected = detectTypeByName(ff.name || '');
        files.push({ file: ff, typeKey: 'auto', detectedKey: detected });
      }

      refreshFileList();
      setStatus('', false);
    });
  }

  // ----------------------------
  // CSV parse
  // ----------------------------
    // ----------------------------
  // CSV parse + validation (Test Summary)
  // ----------------------------
  function analyzeTestSummaryTable(headers, rows, extra) {
  extra = extra || {};

  function safeCol(cols, idx) {
    if (idx < 0) return '';
    var v = (idx < cols.length) ? cols[idx] : '';
    if (v === null || typeof v === 'undefined') return '';
    return String(v);
  }

  function parseSampleId(sampleId) {
    sampleId = String(sampleId || '');
    var parts = sampleId.split('_');
    var bag = null;
    var ctrl = '';
    var pos = '';
    if (parts.length >= 2) {
      var bn = parseInt(parts[1], 10);
      if (!isNaN(bn)) bag = bn;
    }
    if (parts.length >= 3) ctrl = String(parts[2] || '');
    if (parts.length >= 4) pos = String(parts[3] || '');
    return { raw: sampleId, prefix: String(parts[0] || ''), bag: bag, ctrl: ctrl, pos: pos };
  }

  function classifyDetected(testResult) {
    var low = String(testResult || '').toLowerCase();
    if (!low) return 'unknown';

    if (low.indexOf('no result') >= 0) return 'unknown';
    if (low.indexOf('error') >= 0) return 'unknown';
    if (low.indexOf('invalid') >= 0) return 'unknown';

    var tmp = low.replace(/not detected/g, '');
    if (tmp.indexOf('detected') >= 0) return 'detected';
    if (low.indexOf('not detected') >= 0) return 'not_detected';

    return 'unknown';
  }

  function incMap(map, key) { map[key] = (map[key] || 0) + 1; }

  function makeDuplicates(counts) {
    var out = [];
    for (var k in counts) {
      if (!counts.hasOwnProperty(k)) continue;
      if (counts[k] > 1) out.push({ value: k, count: counts[k] });
    }
    out.sort(function (a, b) { return b.count - a.count; });
    return out;
  }

  // --- index lookup (din befintliga helper)
  var idxAssay = findHeader(headers, /^assay$/i);
  var idxAssayVer = findHeader(headers, /^assay version$/i);
  var idxSample = findHeader(headers, /^sample id$/i);
  var idxCart = findHeader(headers, /^cartridge/i);
  var idxLot = findHeader(headers, /reagent lot id/i);
  var idxTestType = findHeader(headers, /^test type$/i);
  var idxTestResult = findHeader(headers, /^test result$/i);

  var countsSample = {};
  var countsCart = {};
  var resultCounts = {}; // <-- NYTT (resultatsammanställning)

  var assay = '';
  var assayVer = '';
  var lot = '';

  var bagCounts = {};
  var ctrlCounts = {};
  var ctrlPrefixMap = {};
  var invalidRows = [];
  var liteRows = [];

  for (var i = 0; i < rows.length; i++) {
    var r = rows[i];

    var sAssay = safeCol(r, idxAssay);
    var sAssayVer = safeCol(r, idxAssayVer);
    var sSample = safeCol(r, idxSample);
    var sCart = safeCol(r, idxCart);
    var sLot = safeCol(r, idxLot);
    var sType = safeCol(r, idxTestType);
    var sRes = safeCol(r, idxTestResult);

    if (!assay && sAssay) assay = sAssay;
    if (!assayVer && sAssayVer) assayVer = sAssayVer;
    if (!lot && sLot) lot = sLot;

    if (sSample) incMap(countsSample, sSample);
    if (sCart) incMap(countsCart, sCart);
    if (sRes) incMap(resultCounts, sRes); // <-- NYTT

    var sid = parseSampleId(sSample);
    if (sid.bag !== null) incMap(bagCounts, String(sid.bag));

    var detClass = classifyDetected(sRes);
    if (!ctrlCounts.hasOwnProperty(sid.ctrl)) ctrlCounts[sid.ctrl] = { detected: 0, not_detected: 0, unknown: 0, total: 0 };
    ctrlCounts[sid.ctrl][detClass] = (ctrlCounts[sid.ctrl][detClass] || 0) + 1;
    ctrlCounts[sid.ctrl].total++;

    if (!ctrlPrefixMap.hasOwnProperty(sid.ctrl)) ctrlPrefixMap[sid.ctrl] = {};
    incMap(ctrlPrefixMap[sid.ctrl], sid.prefix);

    var lowRes = String(sRes || '').toLowerCase();
    var isInvalid =
      (lowRes.indexOf('no result') >= 0 ||
       lowRes.indexOf('invalid') >= 0 ||
       lowRes.indexOf('error') >= 0 ||
       lowRes.indexOf('cancel') >= 0 ||
       lowRes.indexOf('abort') >= 0);

    var lite = {
      assay: sAssay, assayVer: sAssayVer, lot: sLot,
      sampleId: sSample, cartSn: sCart,
      testType: sType, testResult: sRes,
      bag: sid.bag, ctrl: sid.ctrl, prefix: sid.prefix, pos: sid.pos,
      detectedClass: detClass
    };
    liteRows.push(lite);

    if (isInvalid) invalidRows.push(lite);
  }

  // Bag range + missing
  var bagNums = [];
  for (var bk in bagCounts) if (bagCounts.hasOwnProperty(bk)) {
    var bn2 = parseInt(bk, 10);
    if (!isNaN(bn2)) bagNums.push(bn2);
  }
  bagNums.sort(function (a, b) { return a - b; });
  var bagMin = (bagNums.length ? bagNums[0] : null);
  var bagMax = (bagNums.length ? bagNums[bagNums.length - 1] : null);
  var bagMissing = [];
  if (bagMin !== null && bagMax !== null) {
    for (var b = bagMin; b <= bagMax; b++) {
      if (!bagCounts.hasOwnProperty(String(b))) bagMissing.push(b);
    }
  }

  // Control expected behavior = majority
  var ctrlExpected = {};
  for (var ck in ctrlCounts) if (ctrlCounts.hasOwnProperty(ck)) {
    var c = ctrlCounts[ck];
    var d = c.detected || 0;
    var nd = c.not_detected || 0;
    if (d === 0 && nd === 0) ctrlExpected[ck] = 'unknown';
    else if (d > nd) ctrlExpected[ck] = 'detected';
    else if (nd > d) ctrlExpected[ck] = 'not_detected';
    else ctrlExpected[ck] = 'unknown';
  }

  var ctrlDeviations = [];
  for (i = 0; i < liteRows.length; i++) {
    var row = liteRows[i];
    var exp = ctrlExpected[row.ctrl] || 'unknown';
    if (exp === 'unknown') continue;
    if (row.detectedClass !== exp) {
      ctrlDeviations.push({
        ctrl: row.ctrl, expected: exp,
        sampleId: row.sampleId, cartSn: row.cartSn,
        testType: row.testType, testResult: row.testResult,
        detectedClass: row.detectedClass, prefix: row.prefix, bag: row.bag, pos: row.pos
      });
    }
  }

  // Result list (sort)
  var resultList = [];
  for (var rk in resultCounts) if (resultCounts.hasOwnProperty(rk)) {
    resultList.push({ value: rk, count: resultCounts[rk] });
  }
  resultList.sort(function (a, b) { return b.count - a.count; });

  return {
    ok: true,
    delim: extra.delim || '',
    headerIdx: (typeof extra.headerIdx === 'number' ? extra.headerIdx : -1),
    rowCount: rows.length,
    assay: extra.assay || '',         // vi fyller assay/assayVer/lot från data om vi vill
    assayVer: extra.assayVer || '',
    lot: extra.lot || '',
    duplicateSamples: makeDuplicates(countsSample),
    duplicateCarts: makeDuplicates(countsCart),
    results: resultList,              // <-- NYTT: resultatsammanställning
    bag: { min: bagMin, max: bagMax, missing: bagMissing, counts: bagCounts },
    ctrl: { counts: ctrlCounts, expected: ctrlExpected, deviations: ctrlDeviations, prefixes: ctrlPrefixMap },
    invalid: invalidRows,
    _rows: liteRows
  };
}


function parseCsv(text) {
    text = text || '';
    if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);

    var lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');

    // Guess delimiter from first non-empty line
    var delim = ';';
    for (var i = 0; i < lines.length; i++) {
      if (lines[i] && lines[i].length) {
        var cSemi = countChar(lines[i], ';');
        var cComma = countChar(lines[i], ',');
        delim = (cSemi >= cComma) ? ';' : ',';
        break;
      }
    }

    // Find header row dynamically (same logic as PowerShell: look for core columns)
    var headerIdx = -1;
    for (i = 0; i < lines.length; i++) {
      var l = lines[i];
      if (!l) continue;
      var low = l.toLowerCase();
      if (low.indexOf('assay') >= 0 && low.indexOf('sample') >= 0 && (low.indexOf('cartridge') >= 0 || low.indexOf('s/n') >= 0)) {
        headerIdx = i;
        break;
      }
    }
    if (headerIdx < 0) return { ok: false, error: 'Kunde inte hitta header-rad i CSV.' };

    var headers = splitCsvLine(lines[headerIdx], delim);
    var rows = [];
    for (i = headerIdx + 1; i < lines.length; i++) {
      if (!lines[i]) continue;
      if (/^(\s*;)+\s*$/.test(lines[i]) || /^(\s*,)+\s*$/.test(lines[i])) continue;
      var cols = splitCsvLine(lines[i], delim);
      if (cols.length < 4) continue;
      rows.push(cols);
    }

return analyzeTestSummaryTable(headers, rows, {
  delim: delim,
  headerIdx: headerIdx
});

    return {
      ok: true,
      delim: delim,
      headerIdx: headerIdx,
      rowCount: rows.length,
      assay: assay,
      assayVer: assayVer,
      lot: lot,
      duplicateSamples: makeDuplicates(countsSample),
      duplicateCarts: makeDuplicates(countsCart),
      bag: { min: bagMin, max: bagMax, missing: bagMissing, counts: bagCounts },
      ctrl: { counts: ctrlCounts, expected: ctrlExpected, deviations: ctrlDeviations, prefixes: ctrlPrefixMap },
      invalid: invalidRows,
      // keep some raw for future rules
      _rows: liteRows
    };
  }


  function countChar(s, ch) {
    var n = 0;
    for (var i = 0; i < s.length; i++) if (s.charAt(i) === ch) n++;
    return n;
  }

  function splitCsvLine(line, delim) {
    var out = [];
    var cur = '';
    var inQ = false;
    for (var i = 0; i < line.length; i++) {
      var ch = line.charAt(i);
      if (inQ) {
        if (ch === '"') {
          if (i + 1 < line.length && line.charAt(i + 1) === '"') { cur += '"'; i++; }
          else inQ = false;
        } else {
          cur += ch;
        }
      } else {
        if (ch === '"') inQ = true;
        else if (ch === delim) { out.push(cur); cur = ''; }
        else cur += ch;
      }
    }
    out.push(cur);
    return out;
  }


  // ----------------------------
  // Embedded Rules (CSV) loader (v7.3)
  // ----------------------------
  var _rulesCache = null;

  function toBool(x) {
    var s = (x === null || x === undefined) ? '' : String(x);
    s = s.replace(/\u00A0/g, ' ').trim().toLowerCase();
    return (s === 'true' || s === 'yes' || s === '1');
  }

  function detectDelimiter(lines) {
    // prefer ; or , based on header row
    var i;
    for (i = 0; i < lines.length; i++) {
      var t = (lines[i] || '').trim();
      if (!t) continue;
      var sc = countChar(t, ';');
      var cc = countChar(t, ',');
      return (sc >= cc) ? ';' : ',';
    }
    return ',';
  }

  function parseCsvTextToObjects(csvText) {
    csvText = (csvText || '').replace(/^\uFEFF/, '');
    var lines = csvText.split(/\r\n|\n|\r/);
    var cleaned = [];
    for (var i = 0; i < lines.length; i++) {
      var t = (lines[i] || '');
      if (!t.trim()) continue;
      cleaned.push(t);
    }
    if (!cleaned.length) return { headers: [], rows: [] };

    var delim = detectDelimiter(cleaned);
    var headers = splitCsvLine(cleaned[0], delim);
    for (i = 0; i < headers.length; i++) headers[i] = (headers[i] || '').trim();

    var rows = [];
    for (i = 1; i < cleaned.length; i++) {
      var cols = splitCsvLine(cleaned[i], delim);
      if (!cols || !cols.length) continue;
      var obj = {};
      for (var c = 0; c < headers.length; c++) {
        obj[headers[c]] = (c < cols.length) ? cols[c] : '';
      }
      rows.push(obj);
    }
    return { headers: headers, rows: rows };
  }

  function getEmbeddedRules() {
    if (_rulesCache) return _rulesCache;
    if (!window.EMBEDDED_RULES_CSV) return null;

    function getTextByName(name) {
      return window.EMBEDDED_RULES_CSV && window.EMBEDDED_RULES_CSV[name] ? window.EMBEDDED_RULES_CSV[name] : '';
    }

    var p1 = parseCsvTextToObjects(getTextByName('01_ResultCallPatterns.csv')).rows;
    var p2 = parseCsvTextToObjects(getTextByName('02_SampleExpectationRules.csv')).rows;
    var p3 = parseCsvTextToObjects(getTextByName('03_ErrorCodes.csv')).rows;
    var p4 = parseCsvTextToObjects(getTextByName('04_MissingSamplesConfig.csv')).rows;
    var p5 = parseCsvTextToObjects(getTextByName('05_SampleIdMarkers.csv')).rows;
    var p6 = parseCsvTextToObjects(getTextByName('06_ParityCheckConfig.csv')).rows;

    // normalize + sort by priority desc
    function normAssay(a) { return (a || '').toString().trim().toLowerCase(); }

    var resultCallPatterns = [];
    for (var i = 0; i < p1.length; i++) {
      var r = p1[i];
      if (!toBool(r.Enabled)) continue;
      resultCallPatterns.push({
        assay: normAssay(r.Assay || '*'),
        call: (r.Call || '').toString().trim().toUpperCase(),
        matchType: (r.MatchType || 'contains').toString().trim().toLowerCase(),
        pattern: (r.Pattern || '').toString(),
        priority: parseInt(r.Priority || '0', 10) || 0,
        note: r.Note || ''
      });
    }
    resultCallPatterns.sort(function (a, b) { return (b.priority || 0) - (a.priority || 0); });

    var sampleExpectationRules = [];
    for (i = 0; i < p2.length; i++) {
      r = p2[i];
      if (!toBool(r.Enabled)) continue;
      sampleExpectationRules.push({
        assay: normAssay(r.Assay || '*'),
        expected: (r.Expected || '').toString().trim().toUpperCase(),
        matchType: (r.SampleIdMatchType || 'contains').toString().trim().toLowerCase(),
        pattern: (r.SampleIdPattern || '').toString(),
        priority: parseInt(r.Priority || '0', 10) || 0,
        note: r.Note || ''
      });
    }
    sampleExpectationRules.sort(function (a, b) { return (b.priority || 0) - (a.priority || 0); });

    var errorCodes = {};
    for (i = 0; i < p3.length; i++) {
      r = p3[i];
      var code = (r.ErrorCode || '').toString().trim();
      var nm = (r.Name || '').toString().trim();
      if (!code && !nm) continue;
      errorCodes[code || nm] = { code: code, name: nm, generatesRetest: toBool(r.GeneratesRetest) };
    }

    var missingSamplesConfig = p4 && p4.length ? p4[0] : {};
    var sampleIdMarkers = p5 || [];
    var parityCheckConfig = p6 && p6.length ? p6[0] : {};

    _rulesCache = {
      ok: true,
      resultCallPatterns: resultCallPatterns,
      sampleExpectationRules: sampleExpectationRules,
      errorCodes: errorCodes,
      missingSamplesConfig: missingSamplesConfig,
      sampleIdMarkers: sampleIdMarkers,
      parityCheckConfig: parityCheckConfig
    };
    return _rulesCache;
  }

  function matchRuleAssay(ruleAssayNorm, assayName) {
    var a = (assayName || '').toString().trim().toLowerCase();
    if (!ruleAssayNorm || ruleAssayNorm === '*') return true;
    return ruleAssayNorm === a;
  }

  function matchByType(matchType, pattern, text) {
    text = (text === null || text === undefined) ? '' : String(text);
    pattern = (pattern === null || pattern === undefined) ? '' : String(pattern);
    var t = text.toUpperCase();
    var p = pattern.toUpperCase();

    if (matchType === 'equals') {
      return normalizeHeaderText(t) === normalizeHeaderText(p);
    }
    if (matchType === 'prefix') {
      return t.indexOf(p) === 0;
    }
    if (matchType === 'suffix') {
      return p && t.slice(-p.length) === p;
    }
    if (matchType === 'regex') {
      try { return (new RegExp(pattern, 'i')).test(text); } catch (e) { return false; }
    }
    // default: contains (support semicolon-separated multi-part)
    if (p.indexOf(';') >= 0) {
      var parts = p.split(';');
      for (var i = 0; i < parts.length; i++) {
        var seg = normalizeHeaderText(parts[i]);
        if (!seg) continue;
        if (t.indexOf(seg.toUpperCase()) < 0) return false;
      }
      return true;
    }
    return t.indexOf(p) >= 0;
  }

  function callToClass(call) {
    call = (call || '').toString().toUpperCase();
    if (call === 'POS' || call === 'DETECTED') return 'detected';
    if (call === 'NEG' || call === 'NOT DETECTED') return 'not_detected';
    if (call === 'INDET' || call === 'INDETERMINATE') return 'unknown';
    return 'unknown';
  }

  function computeResultCallByRules(rules, assayName, testResultText) {
    if (!rules || !rules.resultCallPatterns) return { call: '', matchedRule: null };
    for (var i = 0; i < rules.resultCallPatterns.length; i++) {
      var rule = rules.resultCallPatterns[i];
      if (!matchRuleAssay(rule.assay, assayName)) continue;
      if (matchByType(rule.matchType, rule.pattern, testResultText)) {
        return { call: rule.call, matchedRule: rule };
      }
    }
    return { call: '', matchedRule: null };
  }

  function computeExpectedByRules(rules, assayName, sampleId) {
    if (!rules || !rules.sampleExpectationRules) return { expected: '', matchedRule: null };
    for (var i = 0; i < rules.sampleExpectationRules.length; i++) {
      var rule = rules.sampleExpectationRules[i];
      if (!matchRuleAssay(rule.assay, assayName)) continue;
      if (matchByType(rule.matchType, rule.pattern, sampleId)) {
        return { expected: rule.expected, matchedRule: rule };
      }
    }
    return { expected: '', matchedRule: null };
  }

  function applyEmbeddedRulesToCsvModel(csv) {
    var rules = getEmbeddedRules();
    if (!rules || !csv || !csv.ok || !csv._rows) return;

    var deviations = [];
    var counts = { POS: 0, NEG: 0, INDET: 0, UNKNOWN: 0 };

    for (var i = 0; i < csv._rows.length; i++) {
      var row = csv._rows[i];
      var assay = row.assay || csv.assay || '';
      var tr = row.testResult || '';
      var sid = row.sampleId || '';

      var rc = computeResultCallByRules(rules, assay, tr);
      var exp = computeExpectedByRules(rules, assay, sid);

      var call = rc.call || '';
      var expected = exp.expected || '';

      // only add counts when rule gives a call
      if (call === 'POS') counts.POS++;
      else if (call === 'NEG') counts.NEG++;
      else if (call === 'INDET') counts.INDET++;
      else counts.UNKNOWN++;

      row.ruleCall = call;
      row.ruleExpected = expected;
      row.ruleDetectedClass = call ? callToClass(call) : row.detectedClass;

      if (expected && call && expected !== call) {
        deviations.push({
          expected: expected,
          observed: call,
          sampleId: sid,
          bag: row.bag,
          ctrl: row.ctrl,
          cartSn: row.cartSn,
          testType: row.testType,
          testResult: tr
        });
      }
    }

    csv.rules = {
      loaded: true,
      deviations: deviations,
      counts: counts
    };
  }


  function findHeader(headers, regex) {
    for (var i = 0; i < headers.length; i++) {
      var h = (headers[i] || '').toString().trim();
      if (regex.test(h)) return i;
    }
    return -1;
  }

  function pickDuplicates(map) {
    var out = [];
    for (var k in map) {
      if (!map.hasOwnProperty(k)) continue;
      if (map[k] > 1) out.push({ key: k, count: map[k] });
    }
    out.sort(function (a, b) { return b.count - a.count; });
    return out;
  }

  // ----------------------------
  // ZIP + DEFLATE (raw) for XLSX
  // ----------------------------
  function readU16LE(bytes, off) { return bytes[off] | (bytes[off + 1] << 8); }
  function readU32LE(bytes, off) { return (bytes[off] | (bytes[off + 1] << 8) | (bytes[off + 2] << 16) | (bytes[off + 3] << 24)) >>> 0; }

  function decodeUtf8(bytes) {
    if (window.TextDecoder) return new TextDecoder('utf-8').decode(bytes);
    var s = '';
    for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i] & 0xFF);
    return s;
  }

  function unzipLocal(bytes) {
    var out = {};
    var off = 0;
    while (off + 30 < bytes.length) {
      var sig = readU32LE(bytes, off);
      if (sig !== 0x04034b50) break;

      var flags = readU16LE(bytes, off + 6);
      var method = readU16LE(bytes, off + 8);
      var compSize = readU32LE(bytes, off + 18);
      var uncompSize = readU32LE(bytes, off + 22);
      var nameLen = readU16LE(bytes, off + 26);
      var extraLen = readU16LE(bytes, off + 28);

      var nameBytes = bytes.subarray(off + 30, off + 30 + nameLen);
      var name = decodeUtf8(nameBytes);

      var dataStart = off + 30 + nameLen + extraLen;
      var dataEnd = dataStart + compSize;
      if (dataEnd > bytes.length) break;

      var comp = bytes.subarray(dataStart, dataEnd);
      var data;
      if (method === 0) data = comp;
      else if (method === 8) data = inflateRaw(comp, uncompSize);
      else data = new Uint8Array(0);

      out[name] = data;

      off = dataEnd;
      if (flags & 0x08) break;
    }
    return out;
  }

  function BitReader(bytes) {
    this.bytes = bytes;
    this.pos = 0;
    this.bitbuf = 0;
    this.bitcnt = 0;
  }

  BitReader.prototype.readBits = function (n) {
    while (this.bitcnt < n) {
      if (this.pos >= this.bytes.length) throw new Error('Unexpected EOF in bitstream');
      this.bitbuf |= (this.bytes[this.pos++] << this.bitcnt);
      this.bitcnt += 8;
    }
    var val = this.bitbuf & ((1 << n) - 1);
    this.bitbuf >>>= n;
    this.bitcnt -= n;
    return val;
  };

  BitReader.prototype.alignByte = function () {
    this.bitbuf = 0;
    this.bitcnt = 0;
  };

  function buildHuffman(codeLengths) {
    var maxLen = 0;
    for (var i = 0; i < codeLengths.length; i++) if (codeLengths[i] > maxLen) maxLen = codeLengths[i];

    var blCount = new Array(maxLen + 1);
    for (i = 0; i < blCount.length; i++) blCount[i] = 0;

    for (i = 0; i < codeLengths.length; i++) {
      var len = codeLengths[i];
      if (len > 0) blCount[len]++;
    }

    var nextCode = new Array(maxLen + 1);
    var code = 0;
    blCount[0] = 0;
    for (i = 1; i <= maxLen; i++) {
      code = (code + blCount[i - 1]) << 1;
      nextCode[i] = code;
    }

    var root = {};
    for (var sym = 0; sym < codeLengths.length; sym++) {
      var l = codeLengths[sym];
      if (!l) continue;
      var c = nextCode[l]++;
      var node = root;
      for (var bit = l - 1; bit >= 0; bit--) {
        var b = (c >> bit) & 1;
        if (!node[b]) node[b] = {};
        node = node[b];
      }
      node.sym = sym;
    }
    return root;
  }

  function decodeSym(br, tree) {
    var node = tree;
    while (true) {
      var b = br.readBits(1);
      node = node[b];
      if (!node) throw new Error('Bad Huffman code');
      if (node.sym !== undefined) return node.sym;
    }
  }

  var LEN_BASE = [3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258];
  var LEN_EXTRA= [0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0];
  var DIST_BASE=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577];
  var DIST_EXTRA=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13];

  function fixedLitLenTree() {
    var lengths = new Array(288);
    for (var i = 0; i <= 143; i++) lengths[i] = 8;
    for (i = 144; i <= 255; i++) lengths[i] = 9;
    for (i = 256; i <= 279; i++) lengths[i] = 7;
    for (i = 280; i <= 287; i++) lengths[i] = 8;
    return buildHuffman(lengths);
  }

  function fixedDistTree() {
    var lengths = new Array(32);
    for (var i = 0; i < 32; i++) lengths[i] = 5;
    return buildHuffman(lengths);
  }

  function inflateRaw(compBytes, expectedSize) {
    var br = new BitReader(compBytes);
    var out = [];
    var finalBlock = 0;

    var litTreeFixed = null, distTreeFixed = null;

    while (!finalBlock) {
      finalBlock = br.readBits(1);
      var btype = br.readBits(2);

      if (btype === 0) {
        br.alignByte();
        if (br.pos + 4 > br.bytes.length) throw new Error('Bad stored block');
        var len = br.bytes[br.pos] | (br.bytes[br.pos + 1] << 8);
        var nlen = br.bytes[br.pos + 2] | (br.bytes[br.pos + 3] << 8);
        br.pos += 4;
        if (((len ^ 0xFFFF) & 0xFFFF) !== (nlen & 0xFFFF)) throw new Error('Bad stored block len');
        for (var i = 0; i < len; i++) out.push(br.bytes[br.pos++]);
      } else {
        var litTree, distTree;

        if (btype === 1) {
          if (!litTreeFixed) litTreeFixed = fixedLitLenTree();
          if (!distTreeFixed) distTreeFixed = fixedDistTree();
          litTree = litTreeFixed;
          distTree = distTreeFixed;
        } else if (btype === 2) {
          var HLIT = br.readBits(5) + 257;
          var HDIST = br.readBits(5) + 1;
          var HCLEN = br.readBits(4) + 4;

          var order = [16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];
          var clen = new Array(19);
          for (var z = 0; z < 19; z++) clen[z] = 0;
          for (z = 0; z < HCLEN; z++) clen[order[z]] = br.readBits(3);
          var clenTree = buildHuffman(clen);

          var all = new Array(HLIT + HDIST);
          var idx = 0;
          while (idx < all.length) {
            var sym = decodeSym(br, clenTree);
            if (sym <= 15) {
              all[idx++] = sym;
            } else if (sym === 16) {
              var repeat = br.readBits(2) + 3;
              var prev = idx ? all[idx - 1] : 0;
              while (repeat-- && idx < all.length) all[idx++] = prev;
            } else if (sym === 17) {
              repeat = br.readBits(3) + 3;
              while (repeat-- && idx < all.length) all[idx++] = 0;
            } else if (sym === 18) {
              repeat = br.readBits(7) + 11;
              while (repeat-- && idx < all.length) all[idx++] = 0;
            } else {
              throw new Error('Bad code length symbol');
            }
          }

          var litLens = all.slice(0, HLIT);
          var distLens = all.slice(HLIT);

          litTree = buildHuffman(litLens);
          distTree = buildHuffman(distLens);
        } else {
          throw new Error('Unsupported block type');
        }

        while (true) {
          var s = decodeSym(br, litTree);
          if (s < 256) {
            out.push(s);
          } else if (s === 256) {
            break;
          } else {
            var li = s - 257;
            var length = LEN_BASE[li] + br.readBits(LEN_EXTRA[li]);

            var ds = decodeSym(br, distTree);
            var dist = DIST_BASE[ds] + br.readBits(DIST_EXTRA[ds]);

            var start = out.length - dist;
            if (start < 0) throw new Error('Bad distance');

            for (var k = 0; k < length; k++) out.push(out[start + k]);
          }
        }
      }
    }

    var u8 = new Uint8Array(out.length);
    for (var j = 0; j < out.length; j++) u8[j] = out[j] & 0xFF;

    if (expectedSize && u8.length !== expectedSize) {
      // keep anyway
    }
    return u8;
  }

  // ----------------------------
  // XLSX (OOXML) minimal reader
  // ----------------------------
  function xmlUnescape(s) {
    return (s || '')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'");
  }

  function parseSharedStrings(xml) {
    var out = [];
    var reSi = /<si[\s\S]*?<\/si>/g;
    var m;
    while ((m = reSi.exec(xml)) !== null) {
      var si = m[0];
      var reT = /<t[^>]*>([\s\S]*?)<\/t>/g;
      var mt, s = '';
      while ((mt = reT.exec(si)) !== null) s += xmlUnescape(mt[1]);
      out.push(s);
    }
    return out;
  }

  function colToNum(col) {
    var n = 0;
    for (var i = 0; i < col.length; i++) n = n * 26 + (col.charCodeAt(i) - 64);
    return n;
  }

  function numToCol(n) {
    var s = '';
    while (n > 0) {
      var r = (n - 1) % 26;
      s = String.fromCharCode(65 + r) + s;
      n = Math.floor((n - 1) / 26);
    }
    return s;
  }

  function decodeA1(a1) {
    var m = /^([A-Z]+)(\d+)$/.exec(a1);
    if (!m) return { c: 0, r: 0 };
    return { c: colToNum(m[1]), r: parseInt(m[2], 10) };
  }

  function parseDimension(xml) {
    var m = /<dimension[^>]*ref="([^"]+)"/.exec(xml);
    if (!m) return { s: { c: 1, r: 1 }, e: { c: 26, r: 50 } };
    var ref = m[1];
    var parts = ref.split(':');
    var a = decodeA1(parts[0]);
    var b = parts.length > 1 ? decodeA1(parts[1]) : a;
    return { s: { c: a.c, r: a.r }, e: { c: b.c, r: b.r } };
  }

  function parseSheet(xml, sharedStrings) {
    var cells = {};
    var reCell = /<c\b([^>]*)>([\s\S]*?)<\/c>/g;
    var mc;
    while ((mc = reCell.exec(xml)) !== null) {
      var attrs = mc[1];
      var inner = mc[2];

      var mr = /r="([^"]+)"/.exec(attrs);
      if (!mr) continue;
      var addr = mr[1];

      var mt = /t="([^"]+)"/.exec(attrs);
      var t = mt ? mt[1] : '';

      var vMatch = /<v>([\s\S]*?)<\/v>/.exec(inner);
      var v = vMatch ? vMatch[1] : '';

      if (t === 's') {
        var idx = parseInt(v, 10);
        cells[addr] = (sharedStrings && sharedStrings[idx] !== undefined) ? sharedStrings[idx] : '';
      } else if (t === 'b') {
        cells[addr] = (v === '1') ? 'TRUE' : 'FALSE';
      } else if (t === 'str') {
        cells[addr] = xmlUnescape(v);
      } else if (t === 'inlineStr') {
        var it = /<is>[\s\S]*?<\/is>/.exec(inner);
        if (it) {
          var rt = /<t[^>]*>([\s\S]*?)<\/t>/.exec(it[0]);
          cells[addr] = rt ? xmlUnescape(rt[1]) : '';
        } else {
          cells[addr] = '';
        }
      } else {
        if (v === '') cells[addr] = '';
        else {
          var num = Number(v);
          cells[addr] = (isNaN(num) ? xmlUnescape(v) : num);
        }
      }
    }

    var hf = {};
    var mHF = /<headerFooter[\s\S]*?<\/headerFooter>/.exec(xml);
    if (mHF) {
      var block = mHF[0];
      var mOddH = /<oddHeader>([\s\S]*?)<\/oddHeader>/.exec(block);
      var mOddF = /<oddFooter>([\s\S]*?)<\/oddFooter>/.exec(block);
      hf.oddHeader = mOddH ? xmlUnescape(mOddH[1]) : '';
      hf.oddFooter = mOddF ? xmlUnescape(mOddF[1]) : '';
    }

    return { cells: cells, dim: parseDimension(xml), headerFooter: hf, rawXml: xml };
  }

  function openXlsx(arrayBuffer) {
    var bytes = new Uint8Array(arrayBuffer);
    var fileMap = unzipLocal(bytes);

    var wbBytes = fileMap['xl/workbook.xml'];
    if (!wbBytes || !wbBytes.length) throw new Error('workbook.xml saknas');
    var wbXml = decodeUtf8(wbBytes);

    var relsXml = '';
    if (fileMap['xl/_rels/workbook.xml.rels']) relsXml = decodeUtf8(fileMap['xl/_rels/workbook.xml.rels']);

    var sharedStrings = [];
    if (fileMap['xl/sharedStrings.xml']) sharedStrings = parseSharedStrings(decodeUtf8(fileMap['xl/sharedStrings.xml']));

    var ridToTarget = {};
    relsXml.replace(/<Relationship\b[^>]*Id="([^"]+)"[^>]*Target="([^"]+)"[^>]*\/?>/g, function (_, id, target) {
      ridToTarget[id] = target;
      return '';
    });

    var sheetDefs = [];
    wbXml.replace(/<sheet\b[^>]*name="([^"]+)"[^>]*r:id="([^"]+)"[^>]*\/?>/g, function (_, name, rid) {
      sheetDefs.push({ name: name, rid: rid });
      return '';
    });

    var sheets = [];
    for (var i = 0; i < sheetDefs.length; i++) {
      var target = ridToTarget[sheetDefs[i].rid] || '';
      if (!target) continue;
      target = target.replace(/^\//, '');
      var path = 'xl/' + target;
      var sBytes = fileMap[path];
      if (!sBytes) continue;
      var sXml = decodeUtf8(sBytes);
      var sheet = parseSheet(sXml, sharedStrings);
      sheet.name = sheetDefs[i].name;
      sheets.push(sheet);
    }

    return { sheets: sheets, fileMap: fileMap };
  }

  function getCell(sheet, addr) {
    if (!sheet || !sheet.cells) return '';
    var v = sheet.cells[addr];
    if (v === undefined || v === null) return '';
    return v;
  }

  function getText(sheet, addr) {
    var v = getCell(sheet, addr);
    if (typeof v === 'number') return String(v);
    return (v || '').toString();
  }

  function isDigitStart(s) {
    s = (s || '').toString().trim();
    if (!s) return false;
    var c = s.charAt(0);
    return c >= '0' && c <= '9';
  }

  function trim(s) { return (s || '').toString().replace(/^\s+|\s+$/g, ''); }

  function normalizeSig(s) {
    s = (s || '').toString().trim();
    if (!s) return '';
    s = s.replace(/\./g, '').replace(/\s+/g, ' ').toUpperCase();
    return s;
  }

  function keys(map) {
    var out = [];
    for (var k in map) if (map.hasOwnProperty(k)) out.push(k);
    out.sort();
    return out;
  }

  // ----------------------------
  // Seal Test analysis
  // ----------------------------
  function findHeaderCol(sheet, headerText, headerRow) {
    headerRow = headerRow || 1;
    var dim = sheet.dim || { s: { c: 1, r: 1 }, e: { c: 26, r: 50 } };
    var maxC = dim.e.c || 26;
    var needle = (headerText || '').toLowerCase();
    for (var c = 1; c <= maxC; c++) {
      var addr = numToCol(c) + headerRow;
      var v = (getText(sheet, addr) || '').toLowerCase();
      if (v === needle) return numToCol(c);
    }
    return '';
  }

  function parseCellAddr(addr) {
    var m = /^([A-Z]+)(\d+)$/i.exec(String(addr || '').trim());
    if (!m) return null;
    return { c: colToNum(m[1].toUpperCase()), r: parseInt(m[2], 10) };
  }

  function makeAddr(c, r) {
    if (!c || !r) return '';
    return numToCol(c) + String(r);
  }

  function addrRight(addr, dx) {
    var p = parseCellAddr(addr);
    if (!p) return '';
    return makeAddr(p.c + (dx || 1), p.r);
  }

  function addrDown(addr, dy) {
    var p = parseCellAddr(addr);
    if (!p) return '';
    return makeAddr(p.c, p.r + (dy || 1));
  }

  function findLabelAddr(sheet, re) {
    if (!sheet || !sheet.cells) return '';
    for (var k in sheet.cells) {
      if (!sheet.cells.hasOwnProperty(k)) continue;
      var txt = trim(getText(sheet, k));
      if (txt && re.test(txt)) return k;
    }
    return '';
  }

  function valueNear(sheet, labelRe) {
    var a = findLabelAddr(sheet, labelRe);
    if (!a) return '';

    // Prefer right cell (common for key/value on same row)
    var v = trim(getText(sheet, addrRight(a, 1)));
    if (v && !labelRe.test(v)) return v;

    // Then below (common for key on row, value on next row)
    v = trim(getText(sheet, addrDown(a, 1)));
    if (v && !labelRe.test(v)) return v;

    // Fallback: a bit further away
    v = trim(getText(sheet, addrRight(a, 2)));
    if (v && !labelRe.test(v)) return v;

    v = trim(getText(sheet, addrDown(a, 2)));
    if (v && !labelRe.test(v)) return v;

    return '';
  }

  function readSealHeader(sheet) {
    return {
      ROBAL: valueNear(sheet, /^ROBAL\b/i),
      PartNumber: valueNear(sheet, /^Part\s*Number\b/i),
      BatchNumber: valueNear(sheet, /^Batch\s*Number/i),
      CartridgeLsp: valueNear(sheet, /(Cartridge.*\(LSP\)|Cartridge\s*LSP|Cartridge\s*No\.?\s*\(LSP\)|Cartridge\s*Number)/i),
      PO: valueNear(sheet, /^PO\s*Number\b/i),
      AssayFamily: valueNear(sheet, /^Assay\s*Family\b/i),
      WeightLossSpec: valueNear(sheet, /Weight\s*Loss\s*Spec/i)
    };
  }

  function readSealPeople(sheet) {
    var testers = [];
    var sigs = [];

    var t = trim(valueNear(sheet, /Name\s+of\s+Tester/i));
    if (!t) t = trim(valueNear(sheet, /Inspected\s+by/i));
    if (t) testers.push(t);

    var s = trim(valueNear(sheet, /Print\s+Full\s+Name.*Sign.*Date/i));
    if (s) sigs.push(s);

    return { testers: testers, sigs: sigs };
  }

  
  // ----------------------------
  // Seal Test analysis (v7.3)
  // ----------------------------
  function isBlankOrNA(s) {
    s = (s === null || s === undefined) ? '' : String(s);
    s = s.replace(/\u00A0/g, ' ').replace(/\s+/g, ' ').trim();
    if (!s) return true;
    var low = s.toLowerCase();
    if (low === 'na' || low === 'n/a' || low === 'tomt' || low === 'blank') return true;
    return false;
  }

  function parseLooseNumber(v) {
    if (v === null || v === undefined) return NaN;
    if (typeof v === 'number') return v;
    var s = String(v).replace(/\u00A0/g, ' ').trim();
    if (!s) return NaN;
    // accept comma decimals
    s = s.replace(',', '.');
    // strip non-number chars except . and -
    s = s.replace(/[^0-9\.\-]/g, '');
    var n = Number(s);
    return isNaN(n) ? NaN : n;
  }

  function normalizeHeaderText(s) {
    s = (s === null || s === undefined) ? '' : String(s);
    // remove BOM/ZW chars
    s = s.replace(/^\uFEFF/, '').replace(/[\u200B-\u200D\u2060]/g, '');
    s = s.replace(/\u00A0/g, ' ');
    s = s.replace(/[–—]/g, '-');
    s = s.replace(/\s+/g, ' ').trim();
    return s;
  }

  function parseAnyDateToIso(s) {
    s = normalizeHeaderText(s);
    if (!s) return '';
    // already ISO?
    var m = /^(\d{4})[-\/\.](\d{1,2})[-\/\.](\d{1,2})$/.exec(s);
    if (m) {
      var y = m[1], mo = ('0' + m[2]).slice(-2), d = ('0' + m[3]).slice(-2);
      return y + '-' + mo + '-' + d;
    }
    // dd/mm/yyyy or dd-mm-yyyy
    m = /^(\d{1,2})[-\/\.](\d{1,2})[-\/\.](\d{2,4})$/.exec(s);
    if (m) {
      var dd = ('0' + m[1]).slice(-2);
      var mm = ('0' + m[2]).slice(-2);
      var yy = m[3];
      if (yy.length === 2) yy = (parseInt(yy, 10) >= 70 ? '19' + yy : '20' + yy);
      return yy + '-' + mm + '-' + dd;
    }
    // fallback: return original
    return s;
  }

  function limitedScanLabelValue(sheet, labelRe, rMax, cMax) {
    rMax = rMax || 30;
    cMax = cMax || 20;
    for (var r = 1; r <= rMax; r++) {
      for (var c = 1; c <= cMax; c++) {
        var a = numToCol(c) + String(r);
        var t = normalizeHeaderText(getText(sheet, a));
        if (t && labelRe.test(t)) {
          // right, then down
          var v = normalizeHeaderText(getText(sheet, numToCol(c + 1) + String(r)));
          if (v && !labelRe.test(v)) return v;
          v = normalizeHeaderText(getText(sheet, numToCol(c) + String(r + 1)));
          if (v && !labelRe.test(v)) return v;
          v = normalizeHeaderText(getText(sheet, numToCol(c + 2) + String(r)));
          if (v && !labelRe.test(v)) return v;
          v = normalizeHeaderText(getText(sheet, numToCol(c) + String(r + 2)));
          if (v && !labelRe.test(v)) return v;
        }
      }
    }
    return '';
  }

  function extractSealDocHeader(xlsxObj) {
    var out = { documentNumber: '', rev: '', effective: '' };

    if (!xlsxObj || !xlsxObj.sheets || !xlsxObj.sheets.length) return out;

    // 1) header/footer if present
    var allHF = '';
    for (var i = 0; i < xlsxObj.sheets.length; i++) {
      var hf = (xlsxObj.sheets[i] && xlsxObj.sheets[i].headerFooter) ? xlsxObj.sheets[i].headerFooter : null;
      if (!hf) continue;
      allHF += ' ' + normalizeHeaderText(hf.oddHeader || '') + ' ' + normalizeHeaderText(hf.oddFooter || '');
    }

    var mDoc = /D\d{4,6}/i.exec(allHF);
    if (mDoc) out.documentNumber = mDoc[0].toUpperCase();

    var mRev = /\bRev(?:ision)?\b\s*[:\-]?\s*([A-Z0-9\.]+)/i.exec(allHF);
    if (mRev) out.rev = normalizeHeaderText(mRev[1]);

    var mEff = /\bEffective(?:\s*Date)?\b\s*[:\-]?\s*([0-9]{1,2}[-\/\.][0-9]{1,2}[-\/\.][0-9]{2,4}|[0-9]{4}[-\/\.][0-9]{1,2}[-\/\.][0-9]{1,2})/i.exec(allHF);
    if (mEff) out.effective = parseAnyDateToIso(mEff[1]);

    // 2) cell scan fallback (first reasonable data sheet)
    var base = null;
    for (i = 0; i < xlsxObj.sheets.length; i++) {
      if (xlsxObj.sheets[i] && xlsxObj.sheets[i].name === 'Worksheet Instructions') continue;
      base = xlsxObj.sheets[i];
      break;
    }
    if (!base) base = xlsxObj.sheets[0];

    if (!out.documentNumber) {
      var vDoc = limitedScanLabelValue(base, /(Document\s*(No|Number)|Doc\s*(No|Number))/i, 30, 20);
      var md = /D\d{4,6}/i.exec(vDoc);
      if (md) out.documentNumber = md[0].toUpperCase();
      else {
        // sometimes doc number is just present in nearby text
        md = /D\d{4,6}/i.exec(limitedScanLabelValue(base, /Document/i, 30, 20));
        if (md) out.documentNumber = md[0].toUpperCase();
      }
    }

    if (!out.rev) out.rev = limitedScanLabelValue(base, /^Rev(?:ision)?\b/i, 30, 20);
    if (!out.effective) out.effective = parseAnyDateToIso(limitedScanLabelValue(base, /Effective(\s*Date)?/i, 30, 20));

    return out;
  }

  function findObservationCol(sheet) {
    var dim = sheet && sheet.dim ? sheet.dim : { s: { c: 1, r: 1 }, e: { c: 26, r: 50 } };
    var maxC = dim.e && dim.e.c ? dim.e.c : 26;
    if (maxC > 60) maxC = 60;
    for (var r = 1; r <= 5; r++) {
      for (var c = 1; c <= maxC; c++) {
        var t = normalizeHeaderText(getText(sheet, numToCol(c) + String(r)));
        if (t && /^(obs|observation)\b/i.test(t)) return numToCol(c);
      }
    }
    return 'M';
  }

  function sealExtractIdsFromSheet(sheet) {
    // re-use the existing labels if present in template
    return {
      partNo: limitedScanLabelValue(sheet, /^Part\s*Number\b/i, 30, 20),
      batchNo: limitedScanLabelValue(sheet, /^Batch\s*Number\b/i, 30, 20),
      cartridgeNo: limitedScanLabelValue(sheet, /(Cartridge.*\(LSP\)|Cartridge\s*LSP|Cartridge\s*No\.?\s*\(LSP\)|Cartridge\s*Number|Cartridge\s*No\.?)/i, 30, 20)
    };
  }

  function analyzeSealTest(xlsxObj, side) {
    side = String(side || '').toUpperCase();
    var threshold = (side === 'POS') ? -2.4 : -3.0;

    var sheets = (xlsxObj && xlsxObj.sheets) ? xlsxObj.sheets : [];
    var dataSheets = [];
    for (var i = 0; i < sheets.length; i++) {
      var sh = sheets[i];
      if (!sh || sh.name === 'Worksheet Instructions') continue;
      if (!sh.cells) continue;
      // skip empty-ish sheets
      var any = false;
      for (var k in sh.cells) { if (sh.cells.hasOwnProperty(k) && !isBlankOrNA(sh.cells[k])) { any = true; break; } }
      if (!any) continue;
      dataSheets.push(sh);
    }

    var docHeader = extractSealDocHeader(xlsxObj);
    var ids = dataSheets.length ? sealExtractIdsFromSheet(dataSheets[0]) : { partNo: '', batchNo: '', cartridgeNo: '' };

    // testers (B43, comma-separated)
    var testersMap = {};
    for (i = 0; i < dataSheets.length; i++) {
      var t = normalizeHeaderText(getText(dataSheets[i], 'B43'));
      if (t) {
        var parts = t.split(',');
        for (var p = 0; p < parts.length; p++) {
          var tt = normalizeHeaderText(parts[p]);
          if (tt) testersMap[tt] = true;
        }
      }
    }

    // signatures (per spec)
    var sigRaw = [];
    var sigSet = {};
    if (dataSheets.length > 1) {
      for (i = 1; i < dataSheets.length; i++) {
        var h3 = normalizeHeaderText(getText(dataSheets[i], 'H3'));
        if (isBlankOrNA(h3)) break;
        if (!isDigitStart(h3)) continue;
        var sig = normalizeHeaderText(getText(dataSheets[i], 'B47'));
        if (sig) {
          var norm = normalizeSig(sig);
          if (norm && !sigSet[norm]) {
            sigSet[norm] = true;
            sigRaw.push(sig);
          }
        }
      }
    }

    // violations
    var viol = [];
    var failCount = 0;
    for (i = 0; i < dataSheets.length; i++) {
      var sheet = dataSheets[i];
      var obsCol = findObservationCol(sheet);

      for (var r = 3; r <= 45; r++) {
        var cartridge = normalizeHeaderText(getText(sheet, 'H' + r));
        var initialW = normalizeHeaderText(getText(sheet, 'I' + r));
        var finalW = normalizeHeaderText(getText(sheet, 'J' + r));
        var wlRaw = getCell(sheet, 'K' + r);
        var wl = parseLooseNumber(wlRaw);
        var statusText = normalizeHeaderText(getText(sheet, 'L' + r));
        var obs = normalizeHeaderText(getText(sheet, obsCol + r));

        // skip empty rows
        if (!cartridge && isNaN(wl) && !statusText && !obs) continue;

        var bad = false;
        var statusOut = '';
        if (statusText && statusText.toUpperCase() === 'FAIL') {
          bad = true;
          statusOut = 'FAIL';
          failCount++;
        } else if (!isNaN(wl) && wl <= threshold) {
          bad = true;
          statusOut = 'Minusvärde';
        }

        if (!bad) continue;

        viol.push({
          side: side,
          sheetName: sheet.name,
          cartridge: cartridge,
          initialW: initialW,
          finalW: finalW,
          weightLoss: (!isNaN(wl) ? wl : normalizeHeaderText(String(wlRaw))),
          status: statusOut,
          obs: obs
        });
      }
    }

    return {
      ok: true,
      side: side,
      header: {
        documentNumber: docHeader.documentNumber,
        rev: docHeader.rev,
        effective: docHeader.effective,
        partNo: ids.partNo,
        batchNo: ids.batchNo,
        cartridgeNo: ids.cartridgeNo
      },
      violations: viol,
      failCount: failCount,
      testers: keys(testersMap),
      signatures: { rawList: sigRaw, normSet: sigSet },
      dataSheetCount: dataSheets.length
    };
  }


  
  // ----------------------------
  // Worksheet analysis (v7.3)
  // ----------------------------
  function normIdPart(s) {
    s = normalizeHeaderText(s).toUpperCase();
    s = s.replace(/[^A-Z0-9\-]/g, '');
    return s;
  }
  function normIdDigits(s) {
    s = normalizeHeaderText(s);
    return s.replace(/\D/g, '');
  }

  function extractWorksheetHeaderFromSheet(sheet) {
    var out = {
      partNo: '',
      batchNo: '',
      cartridgeNo: '',
      documentNumber: '',
      attachment: '',
      rev: '',
      effective: '',
      hasPartLabel: false,
      hasBatchLabel: false,
      hasCartridgeLabel: false,
      hasDocLabel: false,
      hasRevLabel: false,
      hasEffLabel: false
    };

    // label-based extraction (limited scan)
    var v;

    v = limitedScanLabelValue(sheet, /^Part\s*(No|Number)\b/i, 40, 25);
    if (v) { out.partNo = v; out.hasPartLabel = true; }

    v = limitedScanLabelValue(sheet, /^Batch\s*(No|Number)\b/i, 40, 25);
    if (v) { out.batchNo = v; out.hasBatchLabel = true; }

    v = limitedScanLabelValue(sheet, /(Cartridge.*\(LSP\)|Cartridge\s*LSP|Cartridge\s*(No|Number)\b|Cartridge\s*No\.?\s*\(LSP\))/i, 40, 25);
    if (v) { out.cartridgeNo = v; out.hasCartridgeLabel = true; }

    v = limitedScanLabelValue(sheet, /(Document\s*(No|Number)|Doc\s*(No|Number))/i, 40, 25);
    if (v) { out.documentNumber = v; out.hasDocLabel = true; }

    v = limitedScanLabelValue(sheet, /Attachment\b/i, 40, 25);
    if (v) out.attachment = v;

    v = limitedScanLabelValue(sheet, /^Rev(?:ision)?\b/i, 40, 25);
    if (v) { out.rev = v; out.hasRevLabel = true; }

    v = limitedScanLabelValue(sheet, /Effective(\s*Date)?/i, 40, 25);
    if (v) { out.effective = parseAnyDateToIso(v); out.hasEffLabel = true; }

    // value-based fallback (find patterns in top region)
    var dim = sheet && sheet.dim ? sheet.dim : { s: { c: 1, r: 1 }, e: { c: 26, r: 60 } };
    var maxR = dim.e && dim.e.r ? dim.e.r : 60;
    var maxC = dim.e && dim.e.c ? dim.e.c : 26;
    if (maxR > 60) maxR = 60;
    if (maxC > 30) maxC = 30;

    for (var r = 1; r <= maxR; r++) {
      for (var c = 1; c <= maxC; c++) {
        var t = normalizeHeaderText(getText(sheet, numToCol(c) + String(r)));
        if (!t) continue;

        if (!out.partNo) {
          var mp = /\b\d{3}-\d{4}\b/.exec(t);
          if (mp) out.partNo = mp[0];
        }
        if (!out.batchNo) {
          var mb = /\b\d{10}\b/.exec(t.replace(/\s+/g, ''));
          if (mb) out.batchNo = mb[0];
        }
        if (!out.cartridgeNo) {
          var mc = /\b\d{5}\b/.exec(t.replace(/\s+/g, ''));
          if (mc) out.cartridgeNo = mc[0];
        }
        if (!out.documentNumber) {
          var md = /\bD\d{4,6}\b/i.exec(t);
          if (md) out.documentNumber = md[0].toUpperCase();
        }
        if (!out.rev) {
          var mr = /\bRev(?:ision)?\b\s*[:\-]?\s*([A-Z0-9\.]+)/i.exec(t);
          if (mr) out.rev = mr[1];
        }
        if (!out.effective) {
          var me = /\b(\d{4}[-\/\.]\d{1,2}[-\/\.]\d{1,2}|\d{1,2}[-\/\.]\d{1,2}[-\/\.]\d{2,4})\b/.exec(t);
          if (me) out.effective = parseAnyDateToIso(me[1]);
        }
      }
    }

    // normalize pretty fields
    if (out.partNo) out.partNo = normalizeHeaderText(out.partNo);
    if (out.batchNo) out.batchNo = normalizeHeaderText(out.batchNo);
    if (out.cartridgeNo) out.cartridgeNo = normalizeHeaderText(out.cartridgeNo);
    if (out.documentNumber) {
      var md2 = /\bD\d{4,6}\b/i.exec(out.documentNumber);
      if (md2) out.documentNumber = md2[0].toUpperCase();
      else out.documentNumber = normalizeHeaderText(out.documentNumber);
    }
    if (out.rev) out.rev = normalizeHeaderText(out.rev);
    if (out.effective) out.effective = parseAnyDateToIso(out.effective);

    return out;
  }

  function majorityValue(rows, field, normFn) {
    var counts = {};
    var pretty = {};
    for (var i = 0; i < rows.length; i++) {
      var v = rows[i][field] || '';
      var n = normFn ? normFn(v) : normalizeHeaderText(v);
      if (!n) continue;
      counts[n] = (counts[n] || 0) + 1;
      if (!pretty.hasOwnProperty(n)) pretty[n] = v;
    }
    var best = '';
    var bestN = 0;
    for (var k in counts) if (counts.hasOwnProperty(k)) {
      if (counts[k] > bestN) { best = k; bestN = counts[k]; }
    }
    return { norm: best, pretty: (best ? pretty[best] : '') };
  }

  function compareWorksheetHeaderSet(perSheetRows) {
    var issues = [];
    var deviantsByField = { PartNo: [], BatchNo: [], CartridgeNo: [], DocumentNumber: [], Rev: [], Effective: [] };

    function checkField(label, field, normFn, required, labelFlagKey) {
      var maj = majorityValue(perSheetRows, field, normFn);
      var majNorm = maj.norm;
      var majPretty = maj.pretty;

      var devi = [];
      var missingValueWhenLabel = [];

      for (var i = 0; i < perSheetRows.length; i++) {
        var r = perSheetRows[i];
        var v = r[field] || '';
        var n = normFn ? normFn(v) : normalizeHeaderText(v);
        if (n && majNorm && n !== majNorm) devi.push(r.sheet);
        if (required && r[labelFlagKey] && !normalizeHeaderText(v)) missingValueWhenLabel.push(r.sheet);
      }

      if (devi.length) {
        issues.push(label + ': avvikande sheets (' + devi.length + ')');
        deviantsByField[label] = devi.slice(0);
      }
      if (missingValueWhenLabel.length) {
        issues.push(label + ': label finns men värde saknas (' + missingValueWhenLabel.length + ')');
      }

      return { majorityPretty: majPretty, deviants: devi, missing: missingValueWhenLabel };
    }

    var summary = {};
    summary.PartNo = checkField('PartNo', 'partNo', normIdPart, true, 'hasPartLabel');
    summary.BatchNo = checkField('BatchNo', 'batchNo', normIdDigits, true, 'hasBatchLabel');
    summary.CartridgeNo = checkField('CartridgeNo', 'cartridgeNo', normIdDigits, true, 'hasCartridgeLabel');
    summary.DocumentNumber = checkField('DocumentNumber', 'documentNumber', function (s) { return normalizeHeaderText(s).toUpperCase(); }, false, 'hasDocLabel');
    summary.Rev = checkField('Rev', 'rev', function (s) { return normalizeHeaderText(s).toUpperCase(); }, false, 'hasRevLabel');
    summary.Effective = checkField('Effective', 'effective', function (s) { return parseAnyDateToIso(s); }, false, 'hasEffLabel');

    return {
      issues: issues,
      summary: summary,
      deviantsByField: deviantsByField
    };
  }

  function filenameCartridgeFallback(fileName) {
    var m = /(\d{5,7})/.exec(String(fileName || ''));
    return m ? m[1] : '';
  }

  function analyzeWorksheet(xlsxObj, fileName) {
    var sheets = (xlsxObj && xlsxObj.sheets) ? xlsxObj.sheets : [];
    var dataSheets = [];
    for (var i = 0; i < sheets.length; i++) {
      var sh = sheets[i];
      if (!sh || sh.name === 'Worksheet Instructions') continue;
      if (sh.name === 'Test Summary') continue;
      if (!sh.cells) continue;
      dataSheets.push(sh);
    }
    if (!dataSheets.length) return { ok: false, error: 'Worksheet: inga data-sheets hittades' };

    var perSheetRows = [];
    for (i = 0; i < dataSheets.length; i++) {
      var h = extractWorksheetHeaderFromSheet(dataSheets[i]);
      h.sheet = dataSheets[i].name;
      perSheetRows.push(h);
    }

    var check = compareWorksheetHeaderSet(perSheetRows);

    var majPart = majorityValue(perSheetRows, 'partNo', normIdPart);
    var majBatch = majorityValue(perSheetRows, 'batchNo', normIdDigits);
    var majCart = majorityValue(perSheetRows, 'cartridgeNo', normIdDigits);
    var majDoc = majorityValue(perSheetRows, 'documentNumber', function (s) { return normalizeHeaderText(s).toUpperCase(); });
    var majRev = majorityValue(perSheetRows, 'rev', function (s) { return normalizeHeaderText(s).toUpperCase(); });
    var majEff = majorityValue(perSheetRows, 'effective', function (s) { return parseAnyDateToIso(s); });

    var filenameFallbackUsed = false;
    var cartPretty = majCart.pretty;
    if (!normalizeHeaderText(cartPretty)) {
      var fb = filenameCartridgeFallback(fileName);
      if (fb) { cartPretty = fb; filenameFallbackUsed = true; }
    }

    return {
      ok: true,
      header: {
        partNo: majPart.pretty,
        batchNo: majBatch.pretty,
        cartridgeNo: cartPretty,
        documentNumber: majDoc.pretty,
        rev: majRev.pretty,
        effective: majEff.pretty
      },
      perSheetRows: perSheetRows,
      check: check,
      filenameFallbackUsed: filenameFallbackUsed
    };
  }



  // ----------------------------
  // Consensus helpers (WS vs POS vs NEG) (v7.3)
  // ----------------------------
  function getConsensusValue(wsPretty, posPretty, negPretty, kind) {
    function norm(kind, s) {
      if (kind === 'part') return normIdPart(s);
      return normIdDigits(s);
    }
    var wsN = norm(kind, wsPretty);
    var posN = norm(kind, posPretty);
    var negN = norm(kind, negPretty);

    function firstPrettyForNorm(targetNorm) {
      if (wsN && wsN === targetNorm) return { pretty: wsPretty, source: 'WS' };
      if (posN && posN === targetNorm) return { pretty: posPretty, source: 'POS' };
      if (negN && negN === targetNorm) return { pretty: negPretty, source: 'NEG' };
      return { pretty: wsPretty || posPretty || negPretty || '', source: (wsPretty ? 'WS' : (posPretty ? 'POS' : (negPretty ? 'NEG' : ''))) };
    }

    var chosenNorm = '';
    var note = '';
    var srcs = [];

    // 1) at least two match
    if (wsN && posN && wsN === posN) { chosenNorm = wsN; srcs = ['WS', 'POS']; note = 'Two sources match'; }
    else if (wsN && negN && wsN === negN) { chosenNorm = wsN; srcs = ['WS', 'NEG']; note = 'Two sources match'; }
    else if (posN && negN && posN === negN) { chosenNorm = posN; srcs = ['POS', 'NEG']; note = 'POS=NEG'; }
    else {
      // 2) WS exists and exactly one matches WS (already handled above)
      // 3) POS==NEG handled above
      // 4) choose first available by priority
      if (wsN) { chosenNorm = wsN; srcs = ['WS']; note = 'Chosen by priority'; }
      else if (posN) { chosenNorm = posN; srcs = ['POS']; note = 'Chosen by priority'; }
      else if (negN) { chosenNorm = negN; srcs = ['NEG']; note = 'Chosen by priority'; }
      else { chosenNorm = ''; srcs = []; note = 'No value'; }
    }

    var picked = firstPrettyForNorm(chosenNorm);
    return {
      valuePretty: picked.pretty,
      source: (srcs.length ? srcs.join('+') : picked.source),
      note: note
    };
  }


  // ----------------------------
  // Render results
  // ----------------------------
  function escapeHtml(s) {
    s = (s === undefined || s === null) ? '' : String(s);
    return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }

  function renderDupList(title, arr) {
    if (!arr || !arr.length) return el('div', { 'class': 'small muted', text: title + ': inga dubletter.' });
    var wrap = el('div', { 'class': 'small' });
    wrap.appendChild(el('div', { 'class': 'muted', text: title + ': ' + arr.length + ' st.' }));
    var t = el('table');
    var th = el('thead');
    var tr = el('tr');
    tr.appendChild(el('th', { text: 'Value' }));
    tr.appendChild(el('th', { text: 'Count' }));
    th.appendChild(tr);
    t.appendChild(th);

    var tb = el('tbody');
    for (var i = 0; i < Math.min(arr.length, 20); i++) {
      var r = el('tr');
      r.appendChild(el('td', { 'class': 'mono', text: arr[i].key }));
      r.appendChild(el('td', { 'class': 'mono', text: String(arr[i].count) }));
      tb.appendChild(r);
    }
    t.appendChild(tb);
    wrap.appendChild(t);
    return wrap;
  }

    function renderResults(model) {
    var out = $('results');
    clearNode(out);

    out.appendChild(el('h2', { text: 'Resultat' }));

    if (!model || !model.csv || !model.csv.ok) {
      out.appendChild(el('div', { 'class': 'small err', text: 'Ingen CSV-data att visa.' }));
      return;
    }

    var csv = model.csv;

    // Overall status
    var hasDupSample = (csv.duplicateSamples && csv.duplicateSamples.length);
    var hasDupCart = (csv.duplicateCarts && csv.duplicateCarts.length);
    var hasInvalid = (csv.invalid && csv.invalid.length);
    var hasResultCounts = (csv.results && csv.results.length);
    var hasCtrlDev = (csv.ctrl && csv.ctrl.deviations && csv.ctrl.deviations.length);
    var hasMissingBags = (csv.bag && csv.bag.missing && csv.bag.missing.length);

    var top = el('div', { 'class': 'card' });
    var pills = el('div');
    pills.appendChild(pill('Rows: ' + csv.rowCount, 'ok'));
    if (csv.assay) pills.appendChild(pill('Assay: ' + csv.assay, 'ok'));
    if (csv.assayVer) pills.appendChild(pill('Ver: ' + csv.assayVer, 'ok'));
    if (csv.lot) pills.appendChild(pill('Lot: ' + csv.lot, 'ok'));

    if (hasCtrlDev) pills.appendChild(pill('Control deviations: ' + csv.ctrl.deviations.length, 'bad'));
    else pills.appendChild(pill('Control deviations: 0', 'ok'));

    if (hasInvalid) pills.appendChild(pill('Invalid/NoResult/Error: ' + csv.invalid.length, 'warn'));
    else pills.appendChild(pill('Invalid/NoResult/Error: 0', 'ok'));

    if (hasDupSample) pills.appendChild(pill('Dup SampleID: ' + csv.duplicateSamples.length, 'warn'));
    else pills.appendChild(pill('Dup SampleID: 0', 'ok'));

    if (hasDupCart) pills.appendChild(pill('Dup Cartridge S/N: ' + csv.duplicateCarts.length, 'warn'));
    else pills.appendChild(pill('Dup Cartridge S/N: 0', 'ok'));

    if (hasMissingBags) pills.appendChild(pill('Missing bags: ' + csv.bag.missing.length, 'warn'));
    else pills.appendChild(pill('Missing bags: 0', 'ok'));

    if (hasResultCounts) pills.appendChild(pill('Distinct results: ' + csv.results.length, 'ok'));

    if (hasResultCounts) pills.appendChild(pill('Distinct results: ' + csv.results.length, 'ok'));

    // v7.3: extra summary pills (only if XLSX / rules are present)
    var sealViolTotal = 0;
    var sealFailNeg = 0, sealFailPos = 0;
    if (model.sealNeg && model.sealNeg.violations) { sealViolTotal += model.sealNeg.violations.length; sealFailNeg = model.sealNeg.failCount || 0; }
    if (model.sealPos && model.sealPos.violations) { sealViolTotal += model.sealPos.violations.length; sealFailPos = model.sealPos.failCount || 0; }

    var wsIssueCount = 0;
    if (model.worksheet && model.worksheet.check && model.worksheet.check.issues) wsIssueCount = model.worksheet.check.issues.length;

    if (model.sealNeg || model.sealPos) {
      pills.appendChild(pill('Seal violations: ' + sealViolTotal, sealViolTotal ? 'bad' : 'ok'));
      pills.appendChild(pill('Seal FAIL NEG: ' + sealFailNeg + ' / POS: ' + sealFailPos, (sealFailNeg || sealFailPos) ? 'bad' : 'ok'));
    }

    if (model.worksheet) {
      pills.appendChild(pill('Worksheet issues: ' + wsIssueCount, wsIssueCount ? 'warn' : 'ok'));
    }

    if (csv.rules && csv.rules.loaded) {
      var rd = (csv.rules.deviations && csv.rules.deviations.length) ? csv.rules.deviations.length : 0;
      pills.appendChild(pill('Rule deviations: ' + rd, rd ? 'warn' : 'ok'));
    }

    top.appendChild(pills);
    top.appendChild(el('div', { 'class': 'small muted', text: 'Delimiter: ' + csv.delim + ' | Header rad: ' + (csv.headerIdx + 1) }));
    out.appendChild(top);

    // v7.3: Seal Test card
    if (model.sealNeg || model.sealPos) {
      var secSeal = el('div', { 'class': 'card' });
      secSeal.appendChild(el('h3', { text: 'Seal Test (NEG/POS)' }));

      var pSeal = el('div');
      function addSealPills(obj, label) {
        if (!obj) {
          pSeal.appendChild(pill(label + ': saknas', 'warn'));
          return;
        }
        var vCount = (obj.violations && obj.violations.length) ? obj.violations.length : 0;
        pSeal.appendChild(pill(label + ' violations: ' + vCount, vCount ? 'bad' : 'ok'));
        pSeal.appendChild(pill(label + ' FAIL: ' + (obj.failCount || 0), (obj.failCount || 0) ? 'bad' : 'ok'));

        var h = obj.header || {};
        pSeal.appendChild(pill(label + ' Doc: ' + (h.documentNumber || 'saknas'), h.documentNumber ? 'ok' : 'warn'));
        pSeal.appendChild(pill(label + ' Rev: ' + (h.rev || 'saknas'), h.rev ? 'ok' : 'warn'));
        pSeal.appendChild(pill(label + ' Eff: ' + (h.effective || 'saknas'), h.effective ? 'ok' : 'warn'));
      }
      addSealPills(model.sealNeg, 'NEG');
      addSealPills(model.sealPos, 'POS');

      // Header consistency (NEG vs POS)
      if (model.sealNeg && model.sealPos) {
        var hn = model.sealNeg.header || {};
        var hp = model.sealPos.header || {};
        var sameDoc = normalizeHeaderText(hn.documentNumber).toUpperCase() === normalizeHeaderText(hp.documentNumber).toUpperCase();
        var sameRev = normalizeHeaderText(hn.rev).toUpperCase() === normalizeHeaderText(hp.rev).toUpperCase();
        var sameEff = normalizeHeaderText(hn.effective) === normalizeHeaderText(hp.effective);
        var okAll = (sameDoc || (!hn.documentNumber && !hp.documentNumber)) &&
                    (sameRev || (!hn.rev && !hp.rev)) &&
                    (sameEff || (!hn.effective && !hp.effective));
        pSeal.appendChild(pill('Seal consistency: ' + (okAll ? 'OK' : 'WARN'), okAll ? 'ok' : 'warn'));
      }

      // Signature mismatch pill
      if (model.signatureMismatch && model.signatureMismatch.mismatch) {
        pSeal.appendChild(pill('Signature mismatch', 'warn'));
      } else if (model.signatureMismatch) {
        pSeal.appendChild(pill('Signatures: OK', 'ok'));
      }

      secSeal.appendChild(pSeal);

      // Violations table
      var viol = [];
      if (model.sealNeg && model.sealNeg.violations) viol = viol.concat(model.sealNeg.violations);
      if (model.sealPos && model.sealPos.violations) viol = viol.concat(model.sealPos.violations);

      if (!viol.length) {
        secSeal.appendChild(el('div', { 'class': 'small muted', text: 'Inga violations hittades i Seal Test.' }));
      } else {
        var tbl = el('table');
        var thead = el('thead');
        var trh = el('tr');
        var cols = ['Side', 'Sheet', 'Cartridge', 'InitialW', 'FinalW', 'WeightLoss', 'Status', 'Obs'];
        for (var cc = 0; cc < cols.length; cc++) trh.appendChild(el('th', { text: cols[cc] }));
        thead.appendChild(trh);
        tbl.appendChild(thead);

        var tbody = el('tbody');
        for (var vi = 0; vi < viol.length; vi++) {
          var v = viol[vi];
          var tr = el('tr');
          if (String(v.status || '').toUpperCase() === 'FAIL') tr.className = 'bad';
          else tr.className = 'warn';
          var cells = [v.side, v.sheetName, v.cartridge, v.initialW, v.finalW, String(v.weightLoss), v.status, v.obs];
          for (var kk = 0; kk < cells.length; kk++) tr.appendChild(el('td', { text: cells[kk] || '' }));
          tbody.appendChild(tr);
        }
        tbl.appendChild(tbody);
        secSeal.appendChild(tbl);
      }

      // signature mismatch details
      if (model.signatureMismatch && model.signatureMismatch.mismatch) {
        var mm = model.signatureMismatch;
        var msg = 'Only NEG: ' + (mm.onlyNeg && mm.onlyNeg.length ? mm.onlyNeg.join(', ') : '-') +
                  ' | Only POS: ' + (mm.onlyPos && mm.onlyPos.length ? mm.onlyPos.join(', ') : '-');
        secSeal.appendChild(el('div', { 'class': 'small warn', text: msg }));
      }

      out.appendChild(secSeal);
    }

    // v7.3: Worksheet header card
    if (model.worksheet) {
      var ws = model.worksheet;
      var secWs = el('div', { 'class': 'card' });
      secWs.appendChild(el('h3', { text: 'Worksheet header' }));

      if (!ws.ok) {
        secWs.appendChild(el('div', { 'class': 'small err', text: ws.error || 'Worksheet analys misslyckades.' }));
      } else {
        var wsh = ws.header || {};
        var pWs = el('div');

        pWs.appendChild(pill('Part: ' + (wsh.partNo || 'saknas'), wsh.partNo ? 'ok' : 'warn'));
        pWs.appendChild(pill('Batch: ' + (wsh.batchNo || 'saknas'), wsh.batchNo ? 'ok' : 'warn'));
        pWs.appendChild(pill('Cartridge: ' + (wsh.cartridgeNo || 'saknas') + (ws.filenameFallbackUsed ? ' (filename)' : ''), wsh.cartridgeNo ? 'ok' : 'warn'));
        pWs.appendChild(pill('Doc: ' + (wsh.documentNumber || 'saknas'), wsh.documentNumber ? 'ok' : 'warn'));
        pWs.appendChild(pill('Rev: ' + (wsh.rev || 'saknas'), wsh.rev ? 'ok' : 'warn'));
        pWs.appendChild(pill('Eff: ' + (wsh.effective || 'saknas'), wsh.effective ? 'ok' : 'warn'));

        var issueCount = (ws.check && ws.check.issues) ? ws.check.issues.length : 0;
        pWs.appendChild(pill('Consistency: ' + (issueCount ? ('WARN (' + issueCount + ')') : 'OK'), issueCount ? 'warn' : 'ok'));

        // consensus values (WS vs POS vs NEG)
        var posH = model.sealPos ? (model.sealPos.header || {}) : {};
        var negH = model.sealNeg ? (model.sealNeg.header || {}) : {};
        var cPart = getConsensusValue(wsh.partNo, posH.partNo, negH.partNo, 'part');
        var cBatch = getConsensusValue(wsh.batchNo, posH.batchNo, negH.batchNo, 'batch');
        var cCart = getConsensusValue(wsh.cartridgeNo, posH.cartridgeNo, negH.cartridgeNo, 'cartridge');

        if (cPart && cPart.valuePretty) pWs.appendChild(pill('Consensus Part: ' + cPart.valuePretty + ' (' + cPart.source + ')', 'ok'));
        if (cBatch && cBatch.valuePretty) pWs.appendChild(pill('Consensus Batch: ' + cBatch.valuePretty + ' (' + cBatch.source + ')', 'ok'));
        if (cCart && cCart.valuePretty) pWs.appendChild(pill('Consensus Cart: ' + cCart.valuePretty + ' (' + cCart.source + ')', 'ok'));

        // POS vs NEG mismatch (IDs)
        var posBatchN = normIdDigits(posH.batchNo || '');
        var negBatchN = normIdDigits(negH.batchNo || '');
        if (posBatchN && negBatchN && posBatchN !== negBatchN) {
          pWs.appendChild(pill('Batch mismatch POS vs NEG', 'warn'));
        }

        secWs.appendChild(pWs);

        if (issueCount) {
          var ul = el('ul', { 'class': 'small' });
          for (var ii = 0; ii < ws.check.issues.length; ii++) {
            ul.appendChild(el('li', { text: ws.check.issues[ii] }));
          }
          secWs.appendChild(ul);
        }

        // Deviants table (compact)
        if (ws.check && ws.check.deviantsByField) {
          var rows = [];
          function addDev(field) {
            var list = ws.check.deviantsByField[field] || [];
            if (!list.length) return;
            rows.push({ field: field, dev: list.join(', ') });
          }
          addDev('PartNo');
          addDev('BatchNo');
          addDev('CartridgeNo');
          addDev('DocumentNumber');
          addDev('Rev');
          addDev('Effective');
          if (rows.length) {
            var t = renderTable(['Field', 'Deviating sheets'], rows, function (r) { return [r.field, r.dev]; });
            secWs.appendChild(t);
          }
        }
      }

      out.appendChild(secWs);
    }

    // v7.3: Embedded rules card (optional extra)
    if (csv.rules && csv.rules.loaded) {
      var secRules = el('div', { 'class': 'card' });
      secRules.appendChild(el('h3', { text: 'Rules (embedded)' }));

      var rd = (csv.rules.deviations && csv.rules.deviations.length) ? csv.rules.deviations.length : 0;
      secRules.appendChild(el('div', { 'class': 'small muted', text: 'Rules loaded: YES | Rule deviations: ' + rd }));

      if (rd) {
        var maxShow = (rd > 200) ? 200 : rd;
        var rowsR = csv.rules.deviations.slice(0, maxShow);
        var tblR = renderTable(['Expected', 'Observed', 'Sample ID', 'Bag', 'Ctrl', 'Cartridge S/N', 'Test Type'], rowsR, function (r) {
          return [r.expected, r.observed, r.sampleId, r.bag, r.ctrl, r.cartSn, r.testType];
        });
        secRules.appendChild(tblR);
        if (rd > maxShow) secRules.appendChild(el('div', { 'class': 'small muted', text: 'Visar första ' + maxShow + ' av ' + rd + ' avvikelser.' }));
      } else {
        secRules.appendChild(el('div', { 'class': 'small muted', text: 'Inga rule deviations.' }));
      }

      out.appendChild(secRules);
    }

    // Helper: render table
    function renderTable(columns, rows, rowToCells) {
      var tbl = el('table');
      var thead = el('thead');
      var trh = el('tr');
      for (var c = 0; c < columns.length; c++) trh.appendChild(el('th', { text: columns[c] }));
      thead.appendChild(trh);
      tbl.appendChild(thead);

      var tbody = el('tbody');
      for (var r = 0; r < rows.length; r++) {
        var tr = el('tr');
        var cells = rowToCells(rows[r]);
        for (var k = 0; k < cells.length; k++) tr.appendChild(el('td', { text: cells[k] }));
        tbody.appendChild(tr);
      }
      tbl.appendChild(tbody);
      return tbl;
    }

    // Section: duplicates
    var secDup = el('div', { 'class': 'card' });
    secDup.appendChild(el('h3', { text: 'Dubletter' }));

    if (!hasDupSample && !hasDupCart) {
      secDup.appendChild(el('div', { 'class': 'small muted', text: 'Inga dubletter hittades.' }));
    } else {
      if (hasDupSample) {
        secDup.appendChild(el('div', { 'class': 'small', text: 'Sample ID (>' + 1 + '):' }));
        secDup.appendChild(renderTable(['Sample ID', 'Count'], csv.duplicateSamples, function (x) { return [x.value, String(x.count)]; }));
      }
      if (hasDupCart) {
        secDup.appendChild(el('div', { 'class': 'small', text: 'Cartridge S/N (>' + 1 + '):' }));
        secDup.appendChild(renderTable(['Cartridge S/N', 'Count'], csv.duplicateCarts, function (x) { return [x.value, String(x.count)]; }));
      }
    }
    out.appendChild(secDup);

    // Section: invalid results
    var secInv = el('div', { 'class': 'card' });
    secInv.appendChild(el('h3', { text: 'Invalid / No Result / Error' }));
    if (!hasInvalid) {
      secInv.appendChild(el('div', { 'class': 'small muted', text: 'Inga rader med NO RESULT / INVALID / ERROR hittades.' }));
    } else {
      secInv.appendChild(renderTable(
        ['Sample ID', 'Ctrl', 'Bag', 'Cartridge S/N', 'Test Type', 'Test Result'],
        csv.invalid,
        function (r) { return [r.sampleId, r.ctrl, (r.bag === null ? '' : String(r.bag)), r.cartSn, r.testType, r.testResult]; }
      ));
    }
    out.appendChild(secInv);

    // Section: result summary
    var secRes = el('div', { 'class': 'card' });
    secRes.appendChild(el('h3', { text: 'Resultatsammanställning' }));
    if (!hasResultCounts) {
      secRes.appendChild(el('div', { 'class': 'small muted', text: 'Inga testresultat att summera.' }));
    } else {
      secRes.appendChild(renderTable(
        ['Test Result', 'Count'],
        csv.results,
        function (r) { return [r.value, String(r.count)]; }
      ));
    }
    out.appendChild(secRes);

    // Section: control expectations + deviations
    var secCtrl = el('div', { 'class': 'card' });
    secCtrl.appendChild(el('h3', { text: 'Kontroll-grupper (majoritet) + avvikelser' }));

    // Summary per ctrl
    var ctrlKeys = [];
    for (var ck in csv.ctrl.counts) if (csv.ctrl.counts.hasOwnProperty(ck)) ctrlKeys.push(ck);
    ctrlKeys.sort(function (a, b) {
      var ai = parseInt(a, 10), bi = parseInt(b, 10);
      if (!isNaN(ai) && !isNaN(bi)) return ai - bi;
      return String(a).localeCompare(String(b));
    });

    var ctrlRows = [];
    for (var ci = 0; ci < ctrlKeys.length; ci++) {
      var key = ctrlKeys[ci];
      var c = csv.ctrl.counts[key];
      var exp = csv.ctrl.expected[key] || 'unknown';
      // prefix summary (top 2)
      var pmap = csv.ctrl.prefixes[key] || {};
      var plist = [];
      for (var pk in pmap) if (pmap.hasOwnProperty(pk)) plist.push({ k: pk, n: pmap[pk] });
      plist.sort(function (a, b) { return b.n - a.n; });
      var ptxt = '';
      for (var pi = 0; pi < plist.length && pi < 2; pi++) {
        ptxt += (ptxt ? ', ' : '') + plist[pi].k + ' (' + plist[pi].n + ')';
      }

      ctrlRows.push({
        ctrl: key,
        expected: exp,
        detected: c.detected || 0,
        notDetected: c.not_detected || 0,
        unknown: c.unknown || 0,
        total: c.total || 0,
        prefixes: ptxt
      });
    }

    secCtrl.appendChild(renderTable(
      ['Ctrl', 'Expected', 'Detected', 'Not detected', 'Unknown', 'Total', 'Top prefixes'],
      ctrlRows,
      function (r) { return [r.ctrl, r.expected, String(r.detected), String(r.notDetected), String(r.unknown), String(r.total), r.prefixes]; }
    ));

    if (!hasCtrlDev) {
      secCtrl.appendChild(el('div', { 'class': 'small muted', text: 'Inga avvikelser mot majoritetsförväntan i kontroll-grupperna.' }));
    } else {
      secCtrl.appendChild(el('div', { 'class': 'small', text: 'Avvikelser (Expected != Observed):' }));
      secCtrl.appendChild(renderTable(
        ['Ctrl', 'Expected', 'Observed', 'Sample ID', 'Bag', 'Cartridge S/N', 'Test Type', 'Test Result'],
        csv.ctrl.deviations,
        function (r) {
          return [
            r.ctrl,
            r.expected,
            r.detectedClass,
            r.sampleId,
            (r.bag === null ? '' : String(r.bag)),
            r.cartSn,
            r.testType,
            r.testResult
          ];
        }
      ));
    }

    out.appendChild(secCtrl);

    // Section: bag coverage
    var secBag = el('div', { 'class': 'card' });
    secBag.appendChild(el('h3', { text: 'Bag coverage' }));
    if (csv.bag.min === null) {
      secBag.appendChild(el('div', { 'class': 'small muted', text: 'Kunde inte tolka bag-nummer från Sample ID.' }));
    } else {
      secBag.appendChild(el('div', { 'class': 'small', text: 'Bag range: ' + csv.bag.min + ' → ' + csv.bag.max }));
      if (hasMissingBags) {
        secBag.appendChild(el('div', { 'class': 'small err', text: 'Missing bags: ' + csv.bag.missing.join(', ') }));
      } else {
        secBag.appendChild(el('div', { 'class': 'small muted', text: 'Inga saknade bag-nummer inom spannet.' }));
      }
    }
    out.appendChild(secBag);

    // Debug footer
    out.appendChild(el('div', { 'class': 'small muted', text: 'Tips: Om något ser fel ut, öppna DevTools (F12) och kolla Console.' }));
  }


  // ----------------------------
  // Read files + run analysis
  // ----------------------------
function readFileAsArrayBuffer(file) {
  return new Promise(function (resolve, reject) {
    var fr = new FileReader();
    fr.onload = function () { resolve(fr.result); };
    fr.onerror = function () { reject(new Error('FileReader error: ' + (file && file.name ? file.name : ''))); };
    fr.readAsArrayBuffer(file);
  });
}

  function readFileAsText(file) {
    return new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onload = function () { resolve(fr.result); };
      fr.onerror = function () { reject(new Error('FileReader error: ' + (file && file.name ? file.name : ''))); };
      fr.readAsText(file);
    });
  }

function normStr(x) {
  if (x === null || x === undefined) return '';
  return String(x).replace(/\u00A0/g, ' ').trim();
}

// XLSX (minimal offline parser) -> { ok:true, headers:[...], rows:[ [..], [..] ], headerIdx:int }
// Uses JSZip + DOMParser (no external XLSX library required).
function parseXlsxGrid(arrayBuffer) {
  if (typeof JSZip === 'undefined') {
    return { ok: false, error: 'JSZip saknas (krävs för att läsa XLSX offline).' };
  }

  function colLettersToIndex(letters) {
    var n = 0;
    for (var i = 0; i < letters.length; i++) {
      var c = letters.charCodeAt(i);
      if (c >= 65 && c <= 90) n = n * 26 + (c - 64);
      else if (c >= 97 && c <= 122) n = n * 26 + (c - 96);
    }
    return n - 1; // 0-based
  }

  function parseCellRef(ref) {
    ref = String(ref || '');
    var m = ref.match(/^([A-Za-z]+)(\d+)$/);
    if (!m) return null;
    return { c: colLettersToIndex(m[1]), r: parseInt(m[2], 10) - 1 };
  }

  function xmlTextToDoc(xmlText) {
    try {
      return (new DOMParser()).parseFromString(xmlText, 'application/xml');
    } catch (e) {
      return null;
    }
  }

  // Helper: pick worksheet xml (prefer sheet1.xml)
  function pickWorksheetPath(zip) {
    if (zip.file('xl/worksheets/sheet1.xml')) return 'xl/worksheets/sheet1.xml';
    // fallback: first worksheet file
    var first = null;
    zip.forEach(function (relPath, entry) {
      if (first) return;
      if (entry && !entry.dir && relPath.indexOf('xl/worksheets/sheet') === 0 && relPath.slice(-4) === '.xml') {
        first = relPath;
      }
    });
    return first;
  }

  return JSZip.loadAsync(arrayBuffer).then(function (zip) {
    var tasks = [];
    var hasShared = !!zip.file('xl/sharedStrings.xml');
    var wsPath = pickWorksheetPath(zip);
    if (!wsPath) throw new Error('XLSX: kunde inte hitta worksheet xml.');

    // Load shared strings (optional)
    var pShared = hasShared
      ? zip.file('xl/sharedStrings.xml').async('string')
      : Promise.resolve('');

    tasks.push(pShared);
    tasks.push(zip.file(wsPath).async('string'));

    return Promise.all(tasks).then(function (res) {
      var sharedXml = res[0];
      var sheetXml = res[1];

      // sharedStrings
      var shared = [];
      if (sharedXml) {
        var sdoc = xmlTextToDoc(sharedXml);
        if (sdoc) {
          var si = sdoc.getElementsByTagName('si');
          for (var i = 0; i < si.length; i++) {
            // concatenate all <t>
            var tnodes = si[i].getElementsByTagName('t');
            var txt = '';
            for (var j = 0; j < tnodes.length; j++) {
              txt += tnodes[j].textContent || '';
            }
            shared.push(normStr(txt));
          }
        }
      }

      // sheet
      var doc = xmlTextToDoc(sheetXml);
      if (!doc) throw new Error('XLSX: kunde inte tolka sheet XML.');

      var cells = doc.getElementsByTagName('c');
      var grid = {}; // r -> { c -> value }
      var maxR = 0, maxC = 0;

      for (var k = 0; k < cells.length; k++) {
        var cEl = cells[k];
        var ref = cEl.getAttribute('r');
        var pos = parseCellRef(ref);
        if (!pos) continue;

        var t = cEl.getAttribute('t') || '';
        var vEl = cEl.getElementsByTagName('v')[0];
        var isEl = cEl.getElementsByTagName('is')[0];
        var val = '';

        if (t === 's') {
          var idx = vEl ? parseInt(vEl.textContent || '0', 10) : 0;
          val = (idx >= 0 && idx < shared.length) ? shared[idx] : '';
        } else if (t === 'inlineStr') {
          // inline string stored in <is><t>
          if (isEl) {
            var t2 = isEl.getElementsByTagName('t');
            var txt2 = '';
            for (var q = 0; q < t2.length; q++) txt2 += t2[q].textContent || '';
            val = normStr(txt2);
          }
        } else {
          // numbers, dates, etc -> read raw
          val = vEl ? normStr(vEl.textContent || '') : '';
        }

        if (!grid[pos.r]) grid[pos.r] = {};
        grid[pos.r][pos.c] = val;
        if (pos.r > maxR) maxR = pos.r;
        if (pos.c > maxC) maxC = pos.c;
      }

      // Build 2D array
      var rows2d = [];
      for (var rr = 0; rr <= maxR; rr++) {
        var rowObj = grid[rr] || {};
        var rowArr = [];
        for (var cc = 0; cc <= maxC; cc++) {
          rowArr.push(normStr(rowObj.hasOwnProperty(cc) ? rowObj[cc] : ''));
        }
        rows2d.push(rowArr);
      }

      // Header detection (same heuristic as CSV)
      var headerIdx = -1;
      for (rr = 0; rr < rows2d.length; rr++) {
        var joined = rows2d[rr].map(function (v) { return normStr(v).toLowerCase(); }).join(' ');
        if (joined.indexOf('assay') >= 0 && joined.indexOf('sample') >= 0 && (joined.indexOf('cartridge') >= 0 || joined.indexOf('s/n') >= 0)) {
          headerIdx = rr;
          break;
        }
      }
      if (headerIdx < 0) throw new Error('Kunde inte hitta header-rad i XLSX.');

      var headers = rows2d[headerIdx].map(normStr);
      var dataRows = [];
      for (rr = headerIdx + 1; rr < rows2d.length; rr++) {
        var r = rows2d[rr];
        if (!r || !r.length) continue;
        var any = false;
        for (cc = 0; cc < r.length; cc++) {
          if (normStr(r[cc])) { any = true; break; }
        }
        if (!any) continue;
        dataRows.push(r.map(normStr));
      }

      return { ok: true, headers: headers, rows: dataRows, headerIdx: headerIdx };
    });
  }).catch(function (e) {
    return { ok: false, error: (e && e.message) ? e.message : String(e) };
  });
}

  function pickByType(typeKey) {
    for (var i = 0; i < files.length; i++) {
      var tk = files[i].typeKey;
      if (tk === 'auto') tk = files[i].detectedKey;
      if (tk === typeKey) return files[i].file;
    }
    return null;
  }

    
    function runAnalysis() {
    var btn = $('runBtn');
    btn.disabled = true;
    clearNode($('results'));
    setStatus('Analyserar...', false);

    var fTs = pickByType('testSummary');
    if (!fTs) {
      setStatus('Saknar Test Summary (csv/xlsx).', true);
      validateReady();
      return;
    }

    var fNeg = pickByType('sealNeg');
    var fPos = pickByType('sealPos');
    var fWs  = pickByType('worksheet');

    var cache = { ab: {}, text: {}, xlsx: {} };

    function fileKey(f) {
      if (!f) return '';
      return String(f.name || '') + '|' + String(f.size || '') + '|' + String(f.lastModified || '');
    }

    function getArrayBufferCached(f) {
      var k = fileKey(f);
      if (cache.ab[k]) return Promise.resolve(cache.ab[k]);
      return readFileAsArrayBuffer(f).then(function (buf) {
        cache.ab[k] = buf;
        return buf;
      });
    }

    function getTextCached(f) {
      var k = fileKey(f);
      if (cache.text[k]) return Promise.resolve(cache.text[k]);
      return readFileAsText(f).then(function (txt) {
        cache.text[k] = txt;
        return txt;
      });
    }

    function getXlsxCached(f) {
      var k = fileKey(f);
      if (cache.xlsx[k]) return Promise.resolve(cache.xlsx[k]);
      return getArrayBufferCached(f).then(function (buf) {
        var obj = openXlsx(buf); // may throw
        cache.xlsx[k] = obj;
        return obj;
      });
    }

    function parseTestSummary() {
      $('results').appendChild(el('div', { 'class': 'small muted', text: 'Läser och analyserar Test Summary...' }));
      var nameLow = (fTs.name || '').toLowerCase();
      var isXlsx = (nameLow.indexOf('.xlsx') >= 0 || nameLow.indexOf('.xls') >= 0);

      if (isXlsx) {
        return getArrayBufferCached(fTs).then(function (buf) {
          return parseXlsxGrid(buf);
        }).then(function (grid) {
          if (!grid || !grid.ok) throw new Error((grid && grid.error) ? grid.error : 'XLSX-parse misslyckades.');
          return analyzeTestSummaryTable(grid.headers, grid.rows, { delim: '', headerIdx: grid.headerIdx });
        });
      }

      return getTextCached(fTs).then(function (csvText) {
        var csv = parseCsv(csvText);
        if (!csv.ok) throw new Error(csv.error || 'CSV-parse misslyckades.');
        return csv;
      });
    }

    var model = { csv: null, sealNeg: null, sealPos: null, worksheet: null, _xlsxSelected: false, signatureMismatch: null, rules: null };

    parseTestSummary().then(function (csv) {
      model.csv = csv;

      // embedded rules (non-breaking)
      var rules = getEmbeddedRules();
      model.rules = rules;
      applyEmbeddedRulesToCsvModel(csv);

      // now parse optional XLSX files sequentially
      model._xlsxSelected = !!(fNeg || fPos || fWs);

      var chain = Promise.resolve();

      if (fNeg) {
        chain = chain.then(function () {
          setStatus('Läser Seal Test NEG...', false);
          return getXlsxCached(fNeg).then(function (x) {
            model.sealNeg = analyzeSealTest(x, 'NEG');
          });
        });
      }
      if (fPos) {
        chain = chain.then(function () {
          setStatus('Läser Seal Test POS...', false);
          return getXlsxCached(fPos).then(function (x) {
            model.sealPos = analyzeSealTest(x, 'POS');
          });
        });
      }
      if (fWs) {
        chain = chain.then(function () {
          setStatus('Läser Worksheet...', false);
          return getXlsxCached(fWs).then(function (x) {
            model.worksheet = analyzeWorksheet(x, (fWs && fWs.name) ? fWs.name : '');
          });
        });
      }

      return chain.then(function () {
        // compare signature sets NEG vs POS
        if (model.sealNeg && model.sealPos && model.sealNeg.signatures && model.sealPos.signatures) {
          var onlyNeg = [];
          var onlyPos = [];
          var negSet = model.sealNeg.signatures.normSet || {};
          var posSet = model.sealPos.signatures.normSet || {};
          var hasNeg = false, hasPos = false;
          var k;
          for (k in negSet) if (negSet.hasOwnProperty(k)) { hasNeg = true; if (!posSet[k]) onlyNeg.push(k); }
          for (k in posSet) if (posSet.hasOwnProperty(k)) { hasPos = true; if (!negSet[k]) onlyPos.push(k); }
          model.signatureMismatch = { mismatch: (hasNeg && hasPos && (onlyNeg.length || onlyPos.length)), onlyNeg: onlyNeg, onlyPos: onlyPos };
        }

        renderResults(model);
        setStatus('OK – analys klar.', false);
        btn.disabled = false;
        validateReady();
      });
    }).catch(function (e) {
      var msg = (e && e.message) ? e.message : String(e);
      setStatus('Fel: ' + msg, true);
      clearNode($('results'));
      $('results').appendChild(el('div', { 'class': 'small err', text: msg }));
      btn.disabled = false;
      validateReady();
    });

  } // closes function runAnalysis


  // ----------------------------
  // Wire UI
  // ----------------------------
  function init() {
    $('pickBtn').addEventListener('click', function () { $('fileInput').click(); });
    $('fileInput').addEventListener('change', function (ev) {
      if (ev.target && ev.target.files) addFiles(ev.target.files);
      $('fileInput').value = '';
    });

    $('clearBtn').addEventListener('click', function () {
      files = [];
      refreshFileList();
      $('results').textContent = 'Ingen analys kord an.';
      setStatus('', false);
    });

    $('runBtn').addEventListener('click', runAnalysis);

    var drop = $('drop');
    drop.addEventListener('dragover', function (e) { e.preventDefault(); drop.style.borderColor = 'rgba(31,111,235,0.9)'; });
    drop.addEventListener('dragleave', function () { drop.style.borderColor = 'rgba(255,255,255,0.16)'; });
    drop.addEventListener('drop', function (e) {
      e.preventDefault();
      drop.style.borderColor = 'rgba(255,255,255,0.16)';
      if (e.dataTransfer && e.dataTransfer.files) addFiles(e.dataTransfer.files);
    });

    refreshFileList();
  }

  init();

})();


