# 📚 API DOCUMENTATION - IPT PROJECT

**Version:** 1.0  
**Datum:** 2026-02-03  
**Target:** Developers & Maintainers

---

## 🎯 QUICK START FOR DEVELOPERS

### Main Entry Points:

```powershell
# 1. Run the application
powershell.exe -ExecutionPolicy Bypass -File Main.ps1

# 2. Main script path
$ScriptRoot = Get-Location
$Modules = Join-Path $ScriptRoot "Modules"

# 3. Data directory
$global:LogPath              # Logging
$global:IPT_ROOT_EFFECTIVE   # Data root
```

---

## 📦 MODULE API REFERENCE

### 1. Initialize-DataPipeline.ps1

**Purpose:** Centralized input file reading & caching

#### Main Function:
```powershell
Initialize-DataPipeline -CsvPath <string> -NegPath <string> -PosPath <string> -WorksheetPath <string>
```

**Parameters:**
- `CsvPath` [string] - Path to CSV test data file
- `NegPath` [string] - Path to Seal Test NEG Excel file
- `PosPath` [string] - Path to Seal Test POS Excel file
- `WorksheetPath` [string] - Path to worksheet template

**Returns:**
```powershell
@{
    Success = [bool]
    Message = [string]
    StartTime = [DateTime]
    EndTime = [DateTime]
    LoadTime_MS = [int]
    CsvRows = [array] # Field arrays
    PackageNeg = [ExcelPackage]
    PackagePos = [ExcelPackage]
    PackageWorksheet = [ExcelPackage]
    CsvAssay = [string]
    Stats = [hashtable]
}
```

**Example:**
```powershell
$pipeline = Initialize-DataPipeline -CsvPath "test.csv" -NegPath "neg.xlsx" -PosPath "pos.xlsx" -WorksheetPath "template.xlsx"

if ($pipeline.Success) {
    $csvData = $pipeline.CsvRows
    $negPackage = $pipeline.PackageNeg
    # Process data...
} else {
    Write-Error "Pipeline failed: $($pipeline.Message)"
}
```

**Helper Functions:**
```powershell
# Get cached pipeline data
$pipe = Get-DataPipeline

# Get load statistics
$stats = Get-PipelineStats

# Cleanup resources
Cleanup-DataPipeline
```

---

### 2. RegexCache.ps1

**Purpose:** Pre-compiled regex patterns for performance

#### Main Function:
```powershell
Initialize-RegexCache
```

**Cached Patterns:** (30+ pre-compiled)
- `MTB_TRACE_DETECTED` - (?i)\bMTB\s+TRACE\s+DETECTED\b
- `DETECTED` - \bDETECTED\b
- `NEGATIVE` - \bNEGATIVE\b
- ... and 27 more

#### Get Regex:
```powershell
$regex = Get-CachedRegex -Pattern '(?i)DETECTED' -Name 'DETECTED'

# Usage:
if ($regex.IsMatch($testValue)) { ... }
```

#### Batch Operations:
```powershell
# Filter by regex
$matches = Filter-ByRegex -Items $csvRows -Pattern 'DETECTED' -Property 'Status'

# Count matches
$count = Count-RegexMatches -Items $results -Pattern 'ERROR' -Property 'Status'

# Test cached match
if (Test-CachedMatch -Text $value -Pattern 'MTB_DETECTED') { ... }
```

#### Statistics:
```powershell
$stats = Get-RegexCacheStats
# Returns: TotalCached, TotalCompiled, CacheHits, CacheMisses, HitRate

Show-RegexCacheStats  # Display formatted stats
```

---

### 3. ExcelHelpers.ps1

**Purpose:** Excel file operations & batch processing

#### Load EPPlus:
```powershell
$success = Load-EPPlus
# Returns: $true if EPPlus loaded, $false if error
```

#### Batch Write (OPTIMIZED):
```powershell
$data = New-Object 'object[,]' 100, 2
for ($i = 0; $i -lt 100; $i++) {
    $data[$i, 0] = "Row $i"
    $data[$i, 1] = $i * 10
}

Write-ExcelBatch -Worksheet $ws -StartRow 1 -StartColumn 1 -Data $data
# Performance: 25-30% faster than cell-by-cell
```

#### Batch Format (OPTIMIZED):
```powershell
Format-ExcelRange -Worksheet $ws -Range "A1:C10" `
    -Bold $true -BackgroundColor "00B050" -FontColor "FFFFFF"
# Performance: 20% faster than cell-by-cell
```

#### Cell Styling:
```powershell
Style-Cell -cell $ws.Cells["A1"] -bold $true -bg "FF0000" -fontColor "FFFFFF" -border "Medium"
```

#### Border Management:
```powershell
Set-RowBorder -ws $ws -row 1 -firstRow 1 -lastRow 10
```

#### File Operations:
```powershell
# Check if file is locked
$locked = Test-FileLocked -Path "C:\file.xlsx"

# Check if network path
$isNetwork = Test-IsNetworkPath -Path "\\server\share"
```

---

### 4. StyleHelpers.ps1

**Purpose:** Centralized styling & formatting

#### Color Management:
```powershell
$colorHex = Get-ColorValue -ColorName "Green"   # Returns "00B050"
$colorHex = Get-ColorValue -ColorName "00B050"  # Direct hex also works
```

#### Predefined Themes:
```powershell
Set-CellTheme -Cell $cell -Theme "Success"   # Green + white text + bold
Set-CellTheme -Cell $cell -Theme "Error"     # Red + white text + bold
Set-CellTheme -Cell $cell -Theme "Warning"   # Orange
Set-CellTheme -Cell $cell -Theme "Info"      # Blue
Set-CellTheme -Cell $cell -Theme "Neutral"   # Gray
```

#### Range Operations:
```powershell
# Set background
Set-RangeBackgroundColor -Range $range -ColorName "Green"

# Set text color
Set-RangeFontColor -Range $range -ColorName "White"

# Set border
Set-RangeBorder -Range $range -BorderStyle "Medium" -Sides "All"
```

#### Row Operations:
```powershell
# Adjust height with text wrap
Set-RowHeight -Worksheet $ws -Row 1 -Text "Multi-line text" -Wrap $true
```

#### AutoFit Optimization:
```powershell
# Smart AutoFit (skips if too many rows)
Safe-AutoFitColumns -Ws $ws -Range $range -Mode "SMART" -MaxRows 500

# Manual optimization
Optimize-ColumnWidths -Worksheet $ws -MinWidth 5 -MaxWidth 50
```

---

### 5. GUI.ps1

**Purpose:** Form & control creation (NO logic)

#### Exported Variables:

```powershell
# Main form
$form                      # System.Windows.Forms.Form

# Panels
$content                   # Main content panel
$pLog                      # Log output panel

# Buttons
$btnBuild                  # Build report button
$btnScan                   # Scan files button
$btnCsvBrowse, $btnNegBrowse, $btnPosBrowse

# Text inputs
$txtLSP                    # LSP number input
$txtSigner                 # Signature input

# Lists
$clbCsv, $clbNeg, $clbPos  # File selection lists

# Checkboxes
$chkWriteSign              # Write signature
$chkOverwriteSign          # Overwrite signature
$chkSharePointInfo         # SharePoint info

# RadioButtons
$rbSaveInLsp, $rbTempOnly  # Save location
```

#### Usage:
```powershell
# Access controls from EventHandlers
$btnBuild.Add_Click({ ... })
$txtLSP.Text = "ABC123"
$clbCsv.Items.Add("file.csv")
```

---

### 6. EventHandlers.ps1

**Purpose:** User interactions & business logic

#### Button Events:

```powershell
# File scan (searches for LSP files)
$btnScan.Add_Click({ ... })

# Build report (MAIN BUSINESS LOGIC)
$btnBuild.Add_Click({
    # 1. Validate input files
    # 2. Initialize data-pipeline
    # 3. Process data
    # 4. Generate report
    # 5. Save output
})

# Browse buttons
$btnCsvBrowse.Add_Click({ ... })
$btnNegBrowse.Add_Click({ ... })
$btnPosBrowse.Add_Click({ ... })
```

#### Helper Functions (internal):

```powershell
# UI state management
Set-UiBusy -Busy $true/false    # Disable controls during processing
Set-UiStep -Step 50 "Processing data..."  # Update progress bar

# UI updates
Update-BatchLink                # Refresh file link display
Invoke-UiPump                   # Process pending UI messages

# Dialogs
Confirm-SignatureInput -Text $signature
[System.Windows.Forms.MessageBox]::Show("Message", "Title")
```

---

## 🔄 DATA FLOW DIAGRAM

```
┌─────────────────────────────────────────────────────────────┐
│                      Main.ps1 (Entry)                       │
│                    (174 rader - Clean)                      │
└─────────────────────┬───────────────────────────────────────┘
                      │
        ┌─────────────┼─────────────┐
        │             │             │
        ▼             ▼             ▼
   ┌─────────┐  ┌─────────┐  ┌──────────────┐
   │ GUI.ps1 │  │ Modules │  │ EventHandler │
   │         │  │         │  │     s.ps1    │
   │ • Form  │  │ • Init  │  │              │
   │ • Layout│  │ • Cache │  │ • button_cli │
   │ • Tools │  │ • Funcs │  │ • menu_cli   │
   └─────────┘  └─────────┘  │ • logic      │
        │             │       │ • UI update  │
        │             │       └──────────────┘
        └─────────────┼───────────────────────┐
                      │                       │
                      ▼                       ▼
        ┌──────────────────────┐  ┌───────────────────┐
        │ Data Pipeline        │  │ Business Logic    │
        │ • Initialize-DP      │  │ • DataHelpers     │
        │ • Regex Cache        │  │ • RuleEngine      │
        │ • File Reading       │  │ • Excel Ops       │
        └──────────────────────┘  │ • Report Gen      │
                                  └───────────────────┘
```

---

## 🧪 EXAMPLE: Building a Report

```powershell
# This is how the flow works:

# 1. USER CLICKS BUILD BUTTON
# → EventHandlers.ps1: $btnBuild.Add_Click event fires
#
# 2. VALIDATION
# → Check files exist
# → Check signatures if needed
#
# 3. INITIALIZE PIPELINE
# → Initialize-DataPipeline.ps1: Initialize-DataPipeline()
# → Reads CSV, NEG, POS, Worksheet EN GÅNG
# → Returns cached data in $pipeline object
#
# 4. INITIALIZE REGEX CACHE
# → RegexCache.ps1: Initialize-RegexCache()
# → Pre-compiles 30+ regex patterns
# → Caches for performance
#
# 5. PROCESS DATA
# → DataHelpers: Read & process data
# → RuleEngine: Validate with rules
# → ExcelHelpers: Batch-write to output
# → StyleHelpers: Format cells
#
# 6. SAVE REPORT
# → $pipeline.PackageWorksheet.Save()
# → Open in Excel
#
# 7. CLEANUP
# → Cleanup-DataPipeline()
# → Dispose all Excel packages
# → Release file locks
```

---

## 📊 PERFORMANCE CONSIDERATIONS

### Best Practices:

1. **Reuse Pipeline Data**
   ```powershell
   # GOOD: Get from cache
   $pipeline = Get-DataPipeline
   $csvData = $pipeline.CsvRows

   # BAD: Re-read from file
   $csvRows = Import-CsvRows -Path $csvPath
   ```

2. **Use Batch Operations**
   ```powershell
   # GOOD: Batch write (fast)
   Write-ExcelBatch -Worksheet $ws -StartRow 1 -StartColumn 1 -Data $array

   # BAD: Cell-by-cell (slow)
   for ($i = 0; $i -lt 1000; $i++) {
       $ws.Cells[$i, 1].Value = $data[$i]
   }
   ```

3. **Use Cached Regex**
   ```powershell
   # GOOD: Cached (fast)
   if ($script:RegexCache['DETECTED'].IsMatch($value)) { ... }

   # BAD: Compile each time (slow)
   if ($value -match 'DETECTED') { ... }
   ```

4. **Smart AutoFit**
   ```powershell
   # GOOD: Smart mode (skips if too large)
   Safe-AutoFitColumns -Ws $ws -Mode "SMART" -MaxRows 500

   # BAD: Always AutoFit (slow on large data)
   $ws.Cells.AutoFitColumns()
   ```

---

## 🛠️ EXTENDING THE APPLICATION

### Add a New Feature:

1. **Add GUI Control** (in GUI.ps1)
   ```powershell
   $myButton = New-Object System.Windows.Forms.Button
   $myButton.Text = "My Button"
   $myButton.Location = New-Object System.Drawing.Point(100, 200)
   $form.Controls.Add($myButton)
   ```

2. **Add Event Handler** (in EventHandlers.ps1)
   ```powershell
   $myButton.Add_Click({
       # Your business logic here
   })
   ```

3. **Test**
   - Build and run
   - Verify button clickable
   - Verify logic executes

### Add a New Module:

1. **Create module file:** `Modules/MyFeature.ps1`
2. **Add import in Main.ps1:**
   ```powershell
   . (Join-Path $modulesRoot 'MyFeature.ps1')
   ```
3. **Use in EventHandlers.ps1:**
   ```powershell
   My-FeatureFunction -param $value
   ```

---

**Complete API reference. Ready to develop!** 🚀

