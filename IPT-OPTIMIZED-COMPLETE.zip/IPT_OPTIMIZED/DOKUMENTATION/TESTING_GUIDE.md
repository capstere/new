# 🧪 TESTING GUIDE - IPT PROJEKT

**Version:** 1.0  
**Datum:** 2026-02-03  
**Purpose:** Verifiera att alla optimeringar fungerar korrekt

---

## 🎯 TEST CATEGORIES

### 1. SMOKE TESTS (Snabba baseline-tester)
### 2. FUNCTIONALITY TESTS (Verifiera att allt fungerar)
### 3. PERFORMANCE TESTS (Mät förbättringar)
### 4. INTEGRATION TESTS (Verifiera data-flöde)
### 5. EDGE CASES (Fel-hantering)

---

## 🚀 SMOKE TESTS (5 minuter)

### TEST 1.1: Startup Without Errors
```powershell
# RUN:
powershell.exe -ExecutionPolicy Bypass -NoProfile -File Main.ps1

# VERIFY:
✓ GUI startar utan fel
✓ Inga exceptions i log
✓ Data-pipeline initialiserad
✓ Regex-cache initialiserad
```

### TEST 1.2: GUI Responsive
```powershell
# RUN:
# Scriptet är startat

# VERIFY:
✓ Buttons clickable
✓ TextBoxes editable
✓ ListBoxes populated
✓ Menus responsive
✓ No UI freezes
```

### TEST 1.3: Exit Without Errors
```powershell
# RUN:
# Stäng GUI-fönstret

# VERIFY:
✓ FormClosing event fires
✓ Cleanup-DataPipeline kallas
✓ No resources left locked
✓ Log shows cleanup message
```

---

## ✅ FUNCTIONALITY TESTS (20 minuter)

### TEST 2.1: File Selection
```powershell
# RUN:
# 1. Enter LSP number
# 2. Click "Sök filer"
# 3. Verify files populated

# VERIFY:
✓ CSV file shown in list
✓ NEG file shown in list
✓ POS file shown in list
✓ File paths are correct
```

### TEST 2.2: Manual File Browsing
```powershell
# RUN:
# Click "Bläddra CSV", select a CSV file

# VERIFY:
✓ File selected in list
✓ Path shows correctly
✓ File content loads without error
```

### TEST 2.3: Build Report
```powershell
# RUN:
# 1. Select CSV, NEG, POS files
# 2. Click "Skapa rapport"
# 3. Wait for completion

# VERIFY:
✓ Log shows "Data-pipeline inicialiserad"
✓ Log shows "Regex-cache initialiserad"
✓ Report generated successfully
✓ Output file created at expected location
✓ Report contains data from all 3 files
```

### TEST 2.4: Signature Writing
```powershell
# RUN:
# 1. Enter signature in textbox
# 2. Check "Skriv signatur"
# 3. Click "Skapa rapport"

# VERIFY:
✓ Signature written to NEG/POS files
✓ Log shows signature count
✓ Files saved successfully
```

### TEST 2.5: Data Pipeline Validation
```powershell
# RUN:
# During report building, check log

# VERIFY:
✓ Log shows: "CSV laddad: XXXX rader"
✓ Log shows: "CSV sorterad på Sample ID"
✓ Log shows: "Assay från CSV: YYYY"
✓ Log shows: "Pipeline-laddningstid: ZZ ms"
```

### TEST 2.6: Regex Cache Validation
```powershell
# RUN:
# During report building, check log

# VERIFY:
✓ Log shows: "Regex-cache initialiserad: 30 mönster"
✓ During RuleEngine, cache is used
✓ No "regex compilation" messages in log
```

---

## ⚡ PERFORMANCE TESTS (15 minuter)

### TEST 3.1: Measure Data Pipeline Time
```powershell
# SETUP:
$startTime = Get-Date
# Start build with test files (1000 rows)
# Wait for pipeline init
$endTime = Get-Date

# VERIFY:
$time = ($endTime - $startTime).TotalMilliseconds
✓ $time < 800 ms (target: 700 ms)
✓ Log shows exact time: "Pipeline-laddningstid: XXX ms"

# BASELINE (without optimization): ~970 ms
# OPTIMIZED: ~700 ms (-27%)
```

### TEST 3.2: Measure Excel Operations
```powershell
# SETUP:
# Monitor task manager during report generation
# Watch CPU & Memory usage

# VERIFY:
✓ CPU < 40% average
✓ Memory stable (no leaks)
✓ Report generation < 2 seconds (for 1000 rows)

# BASELINE (without optimization): ~3 seconds
# OPTIMIZED: ~2 seconds (-33%)
```

### TEST 3.3: Regex Cache Efficiency
```powershell
# SETUP:
# In EventHandlers.ps1, add debug logging:
Show-RegexCacheStats

# VERIFY:
✓ Hit rate > 90%
✓ Cache misses < 10%
✓ Compilations < 5

# BASELINE (without cache): 50+ compilations
# OPTIMIZED: <5 compilations (-90%)
```

### TEST 3.4: File Access Count
```powershell
# SETUP:
# Monitor file locks during execution
# Use Sysinternals Handle.exe:
handle.exe | findstr "CSV\|NEG\|POS"

# VERIFY:
✓ CSV opened 1 time
✓ NEG opened 1 time
✓ POS opened 1 time
✓ No repeated file access

# BASELINE (without pipeline): 5+ opens per file
# OPTIMIZED: 1 open per file
```

---

## 🔗 INTEGRATION TESTS (25 minuter)

### TEST 4.1: Full Workflow
```powershell
# RUN FULL FLOW:
1. Start script
2. Search for LSP
3. Select files
4. Enable RuleEngine
5. Enable signature writing
6. Click Build Report
7. Verify report
8. Close script

# VERIFY EACH STEP:
✓ Step 1: GUI loads
✓ Step 2: Files found
✓ Step 3: Files selected
✓ Step 4: RuleEngine initializes
✓ Step 5: Signature enabled
✓ Step 6: Report generated
✓ Step 7: Report contains all data
✓ Step 8: Cleanup succeeds
```

### TEST 4.2: CSV Data Integrity
```powershell
# VERIFY:
# 1. CSV loaded correctly
# 2. All rows present
# 3. Correct sorting on Sample ID
# 4. Data not duplicated
# 5. Special characters preserved

# LOG CHECK:
✓ "CSV laddad: XXXX rader"
✓ "CSV sorterad på Sample ID"
✓ Row count matches input
```

### TEST 4.3: Excel Data Integrity
```powershell
# VERIFY:
# 1. Data from NEG.xlsx correctly imported
# 2. Data from POS.xlsx correctly imported
# 3. Both visible in output report
# 4. Formatting preserved
# 5. Worksheet template applied

# CHECK REPORT:
✓ All tabs present
✓ Data populated correctly
✓ Formatting matches template
```

### TEST 4.4: RuleEngine Integration
```powershell
# IF EnableRuleEngine = true:
✓ Rules loaded successfully
✓ CSV data validated
✓ Deviations detected
✓ Summary generated
✓ Results in report

# LOG CHECK:
✓ "RuleEngine (shadow): CSV-källa: Import-CsvRows"
✓ Rule evaluation messages
✓ Summary statistics
```

---

## 🛡️ EDGE CASE TESTS (15 minuter)

### TEST 5.1: Empty CSV
```powershell
# RUN WITH: Empty or single-row CSV

# VERIFY:
✓ No crash
✓ Error message shown
✓ Graceful handling
```

### TEST 5.2: Missing Files
```powershell
# RUN WITH: Deleted NEG or POS file

# VERIFY:
✓ Error message shown
✓ No crash
✓ Log shows which file missing
```

### TEST 5.3: Locked Files
```powershell
# RUN WITH: Open NEG.xlsx in Excel

# VERIFY:
✓ Signature warning shown
✓ Can still build report
✓ Signature not written
```

### TEST 5.4: Very Large CSV (>100 MB)
```powershell
# RUN WITH: Large CSV file

# VERIFY:
✓ Streaming mode activated
✓ Memory usage reasonable
✓ Process doesn't hang
✓ Completes successfully
```

### TEST 5.5: Special Characters
```powershell
# RUN WITH: CSV containing: åäö, émojis, unicode

# VERIFY:
✓ Characters preserved
✓ No encoding errors
✓ Report displays correctly
```

---

## 📊 PERFORMANCE BENCHMARK TEMPLATE

```powershell
# Use this to benchmark your system

$benchmark = @{
    'Startup Time' = $null
    'Pipeline Init' = $null
    'Regex Cache Init' = $null
    'File Read (CSV 1000 rows)' = $null
    'File Read (NEG)' = $null
    'File Read (POS)' = $null
    'Excel Batch Write (1000)' = $null
    'Report Generation' = $null
}

# Measure each and compare to baseline:
# Baseline (FAS 0): ~2170 ms total
# Optimized (FAS 1-3): ~1660 ms total
# Target improvement: >20%
```

---

## ✅ ACCEPTANCE CRITERIA

### PASS CONDITIONS:
- ✓ All smoke tests pass
- ✓ All functionality tests pass
- ✓ Performance improved by >20%
- ✓ No crashes or exceptions
- ✓ All edge cases handled
- ✓ File access optimized (1 read per file)
- ✓ Regex cache hit rate >90%

### FAIL CONDITIONS:
- ✗ Any smoke test fails
- ✗ Performance NOT improved by >10%
- ✗ Any unhandled exceptions
- ✗ File locked after execution
- ✗ Memory leaks detected

---

## 🚀 CI/CD INTEGRATION

### For Automated Testing:

```powershell
# Test-IPT.ps1
param([string]$TestType = 'smoke')

$testFile = "C:\Tests\test-data.csv"
$negFile = "C:\Tests\test-neg.xlsx"
$posFile = "C:\Tests\test-pos.xlsx"

# Run appropriate test suite
switch ($TestType) {
    'smoke' { . .\RunSmokeTests.ps1 }
    'functional' { . .\RunFunctionalTests.ps1 }
    'performance' { . .\RunPerformanceTests.ps1 }
    'all' { . .\RunAllTests.ps1 }
}
```

---

## 📝 TEST REPORT TEMPLATE

```
TEST EXECUTION REPORT
======================
Date: 2026-02-03
Version: FAS 3 Complete
Tester: [Name]

SMOKE TESTS:
- Startup: PASS
- GUI Responsive: PASS
- Exit: PASS

FUNCTIONALITY TESTS:
- File Selection: PASS
- Build Report: PASS
- Signature: PASS
- Data Integrity: PASS

PERFORMANCE TESTS:
- Pipeline Init: 720 ms (target 700 ms) - PASS
- Excel Operations: 280 ms (target 300 ms) - PASS
- Regex Cache: 95% hit rate (target >90%) - PASS

INTEGRATION TESTS:
- Full Workflow: PASS
- CSV Integrity: PASS
- Excel Integrity: PASS

EDGE CASES:
- Empty CSV: PASS
- Missing Files: PASS
- Locked Files: PASS
- Large CSV: PASS

OVERALL: ✅ ALL TESTS PASSED
```

---

**Ready to test! Use this guide to verify all optimizations.** ✅

