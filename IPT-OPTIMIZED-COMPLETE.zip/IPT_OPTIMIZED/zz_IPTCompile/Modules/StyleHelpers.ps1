# Enable strict mode to catch uninitialized variables and other script issues
Set-StrictMode -Version 2.0

<#
.SYNOPSIS
    StyleHelpers.ps1 - Centraliserad Excel-styling & formatering
    
.DESCRIPTION
    Denna modul innehåller alla styling- och formaterings-funktioner:
    - Färg-hantering
    - Border-styling
    - AutoFit-optimeringar
    - Tema-applicering

.NOTES
    Version: 1.0
    Kompatibilitet: PowerShell 5.1, EPPlus 4.5.3.3
#>

# ===== Tema & Färg-konstanter =====

$script:ColorScheme = @{
    'Green'  = '00B050'
    'Red'    = 'FF0000'
    'Blue'   = '0070C0'
    'Orange' = 'FF9500'
    'Gray'   = 'D3D3D3'
    'White'  = 'FFFFFF'
    'Black'  = '000000'
    'LightBlue' = 'CCFFFF'
}

$script:BorderStyles = @{
    'Thin'   = 'Thin'
    'Medium' = 'Medium'
    'Thick'  = 'Thick'
    'None'   = 'None'
}

# ===== Styling-funktioner =====

<#
.SYNOPSIS
    Hämtar färgvärde från schemanamn eller hex-värde

.PARAMETER ColorName
    Namn på färg från schemat eller direkt hex-värde (utan #)

.OUTPUTS
    System.String - Hex-värde (utan #)
#>
function Get-ColorValue {
    param([Parameter(Mandatory=$true)][string]$ColorName)
    
    if ([string]::IsNullOrWhiteSpace($ColorName)) { return $script:ColorScheme['Gray'] }
    
    $upper = $ColorName.ToUpperInvariant()
    if ($script:ColorScheme.ContainsKey($upper)) {
        return $script:ColorScheme[$upper]
    }
    
    # Antag att det är ett hex-värde
    if ($ColorName -match '^[0-9A-F]{6}$') {
        return $ColorName
    }
    
    return $script:ColorScheme['Gray'] # Fallback
}

<#
.SYNOPSIS
    Tillämpar ett fördefinierat tema på en cell

.DESCRIPTION
    Använder förinställda färg- och stil-kombinationer för konsistent formatering.

.PARAMETER Cell
    Excel-cell att formatera

.PARAMETER Theme
    Tema-namn: 'Success', 'Error', 'Warning', 'Info', 'Neutral'
#>
function Set-CellTheme {
    param(
        [Parameter(Mandatory=$true)]$Cell,
        [Parameter(Mandatory=$true)][ValidateSet('Success','Error','Warning','Info','Neutral')]
        [string]$Theme
    )
    
    $themes = @{
        'Success' = @{ BgColor = 'Green'; FgColor = 'White'; Bold = $true }
        'Error'   = @{ BgColor = 'Red'; FgColor = 'White'; Bold = $true }
        'Warning' = @{ BgColor = 'Orange'; FgColor = 'White'; Bold = $false }
        'Info'    = @{ BgColor = 'Blue'; FgColor = 'White'; Bold = $false }
        'Neutral' = @{ BgColor = 'Gray'; FgColor = 'Black'; Bold = $false }
    }
    
    $style = $themes[$Theme]
    if (-not $style) { return }
    
    try {
        if ($style.Bold) { $Cell.Style.Font.Bold = $true }
        
        $bgHex = Get-ColorValue $style.BgColor
        $Cell.Style.Fill.PatternType = "Solid"
        $Cell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#$bgHex"))
        
        $fgHex = Get-ColorValue $style.FgColor
        $Cell.Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml("#$fgHex"))
    } catch {
        Gui-Log "⚠️ Set-CellTheme fel: $($_.Exception.Message)" 'Warn'
    }
}

<#
.SYNOPSIS
    Sätter bakgrundsfärg på ett range

.PARAMETER Range
    Excel-range (kan vara string som "A1:C10" eller range-objekt)

.PARAMETER ColorName
    Färgnamn (från schemat) eller hex-värde

.PARAMETER Pattern
    Fyll-mönster. Standard: "Solid"
#>
function Set-RangeBackgroundColor {
    param(
        [Parameter(Mandatory=$true)]$Range,
        [Parameter(Mandatory=$true)][string]$ColorName,
        [string]$Pattern = "Solid"
    )
    
    try {
        $colorHex = Get-ColorValue $ColorName
        
        $rangeObj = if ($Range -is [string]) {
            # Antar att Range är från en worksheet: $ws.Cells["A1:C10"]
            $Range
        } else {
            $Range
        }
        
        if ($rangeObj) {
            $rangeObj.Style.Fill.PatternType = $Pattern
            $rangeObj.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#$colorHex"))
        }
    } catch {
        Gui-Log "⚠️ Set-RangeBackgroundColor fel: $($_.Exception.Message)" 'Warn'
    }
}

<#
.SYNOPSIS
    Sätter textfärg på ett range

.PARAMETER Range
    Excel-range

.PARAMETER ColorName
    Färgnamn eller hex-värde
#>
function Set-RangeFontColor {
    param(
        [Parameter(Mandatory=$true)]$Range,
        [Parameter(Mandatory=$true)][string]$ColorName
    )
    
    try {
        $colorHex = Get-ColorValue $ColorName
        
        if ($Range) {
            $Range.Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml("#$colorHex"))
        }
    } catch {
        Gui-Log "⚠️ Set-RangeFontColor fel: $($_.Exception.Message)" 'Warn'
    }
}

<#
.SYNOPSIS
    Sätter ett border-mönster på ett range

.PARAMETER Range
    Excel-range

.PARAMETER BorderStyle
    Border-typ: 'Thin', 'Medium', 'Thick', 'None'

.PARAMETER Sides
    Vilka sidor att applicera. Standard: 'All'
    Giltiga värden: 'All', 'Top', 'Bottom', 'Left', 'Right', 'TopBottom', 'LeftRight'
#>
function Set-RangeBorder {
    param(
        [Parameter(Mandatory=$true)]$Range,
        [Parameter(Mandatory=$true)][string]$BorderStyle,
        [string]$Sides = "All"
    )
    
    try {
        if (-not $Range) { return }
        
        switch ($Sides.ToUpperInvariant()) {
            'ALL' {
                $Range.Style.Border.Top.Style    = $BorderStyle
                $Range.Style.Border.Bottom.Style = $BorderStyle
                $Range.Style.Border.Left.Style   = $BorderStyle
                $Range.Style.Border.Right.Style  = $BorderStyle
            }
            'TOP' { $Range.Style.Border.Top.Style = $BorderStyle }
            'BOTTOM' { $Range.Style.Border.Bottom.Style = $BorderStyle }
            'LEFT' { $Range.Style.Border.Left.Style = $BorderStyle }
            'RIGHT' { $Range.Style.Border.Right.Style = $BorderStyle }
            'TOPBOTTOM' {
                $Range.Style.Border.Top.Style = $BorderStyle
                $Range.Style.Border.Bottom.Style = $BorderStyle
            }
            'LEFTRIGHT' {
                $Range.Style.Border.Left.Style = $BorderStyle
                $Range.Style.Border.Right.Style = $BorderStyle
            }
        }
    } catch {
        Gui-Log "⚠️ Set-RangeBorder fel: $($_.Exception.Message)" 'Warn'
    }
}

<#
.SYNOPSIS
    Sätter rad-höjd baserat på innehål

.PARAMETER Worksheet
    Excel-worksheet

.PARAMETER Row
    Radnummer

.PARAMETER Text
    Texten i raden (för höjd-beräkning vid wrap)

.PARAMETER Wrap
    Om True, tillåt text-wrapping och justera höjd
#>
function Set-RowHeight {
    param(
        [Parameter(Mandatory=$true)]$Worksheet,
        [Parameter(Mandatory=$true)][int]$Row,
        [string]$Text,
        [bool]$Wrap = $false
    )
    
    try {
        if ($Wrap -and -not [string]::IsNullOrWhiteSpace($Text)) {
            $Worksheet.Cells[$Row, 1, $Row, $Worksheet.Dimension.End.Column].Style.WrapText = $true
            
            # Beräkna ungefärlig höjd
            $lineCount = ([regex]::Matches($Text, "`n")).Count + 1
            $estimatedHeight = [Math]::Max(15, $lineCount * 15)
            $Worksheet.Row($Row).Height = $estimatedHeight
        } else {
            # Autohöjd
            $Worksheet.Row($Row).Height = [double]::NaN
        }
    } catch {
        Gui-Log "⚠️ Set-RowHeight fel: $($_.Exception.Message)" 'Warn'
    }
}

# ===== AutoFit-optimering =====

<#
.SYNOPSIS
    Auto-justerar kolumnbredder med konfigurerbara inställningar

.DESCRIPTION
    Intelligent AutoFit som kan hoppa över stora ranges för performance.
    
    Mode-alternativ:
    - OFF: Gör ingenting
    - ON: Alltid AutoFit
    - SMART: AutoFit endast om radantal <= MaxRows

.PARAMETER Worksheet
    Excel-worksheet

.PARAMETER Range
    Range att auto-fit. Om tomt, använd hela sheetet

.PARAMETER Mode
    Tillägg-läge: 'OFF', 'ON', 'SMART'. Standard från config eller 'SMART'

.PARAMETER MaxRows
    Maximalt radantal för SMART-mode. Standard från config eller 500
#>
function Safe-AutoFitColumns {
    param(
        [Parameter(Mandatory=$true)]$Ws,
        [Parameter(Mandatory=$false)]$Range,
        [Parameter(Mandatory=$false)][ValidateSet('OFF','ON','SMART')]
        [string]$Mode,
        [Parameter(Mandatory=$false)][int]$MaxRows,
        [string]$Context
    )
    
    # Hämta Mode från config om ej specifierad
    if (-not $Mode) {
        try {
            if ($global:Config -and ($global:Config -is [hashtable]) -and $global:Config.ContainsKey('EpplusAutoFitMode')) {
                $Mode = (($global:Config['EpplusAutoFitMode'] + '')).Trim().ToUpperInvariant()
            }
        } catch {}
    }
    if (-not $Mode) { $Mode = 'SMART' }
    
    # Hämta MaxRows från config om ej specifierad
    if ($MaxRows -le 0) {
        try {
            if ($global:Config -and ($global:Config -is [hashtable]) -and $global:Config.ContainsKey('EpplusAutoFitMaxRows')) {
                $MaxRows = [int]$global:Config['EpplusAutoFitMaxRows']
            }
        } catch {}
    }
    if ($MaxRows -le 0) { $MaxRows = 500 }
    
    # OFF-läge: gör ingenting
    if ($Mode -eq 'OFF') { return }
    
    # Hämta range om ej specifierad
    $rng = $Range
    if (-not $rng) {
        try {
            if ($Ws.Dimension) { $rng = $Ws.Cells[$Ws.Dimension.Address] }
        } catch { $rng = $null }
    }
    if (-not $rng) { return }
    
    # SMART-mode: kontrollera radantal
    if ($Mode -eq 'SMART') {
        $rows = 0
        try {
            $rows = [int]($rng.End.Row - $rng.Start.Row + 1)
        } catch { $rows = 0 }
        
        if ($rows -gt 0 -and $rows -gt $MaxRows) {
            if ($Context) {
                Gui-Log "⏩ AutoFit hoppad över ($rows rader > $MaxRows max) [$Context]" 'Info'
            }
            return
        }
    }
    
    # Utför AutoFit
    try {
        $rng.AutoFitColumns() | Out-Null
    } catch {
        Gui-Log "⚠️ Safe-AutoFitColumns ($Context) misslyckades: $($_.Exception.Message)" 'Warn'
    }
}

<#
.SYNOPSIS
    Justerar automatiskt kolumnbredder med min/max-gränser

.PARAMETER Worksheet
    Excel-worksheet

.PARAMETER MinWidth
    Minsta kolumnbredd (i characters). Standard: 5

.PARAMETER MaxWidth
    Största kolumnbredd (i characters). Standard: 50
#>
function Optimize-ColumnWidths {
    param(
        [Parameter(Mandatory=$true)]$Worksheet,
        [int]$MinWidth = 5,
        [int]$MaxWidth = 50
    )
    
    try {
        if ($Worksheet.Dimension) {
            for ($col = 1; $col -le $Worksheet.Dimension.End.Column; $col++) {
                $columnWidth = $Worksheet.Column($col).Width
                
                if ($columnWidth -lt $MinWidth) {
                    $Worksheet.Column($col).Width = $MinWidth
                } elseif ($columnWidth -gt $MaxWidth) {
                    $Worksheet.Column($col).Width = $MaxWidth
                }
            }
        }
    } catch {
        Gui-Log "⚠️ Optimize-ColumnWidths misslyckades: $($_.Exception.Message)" 'Warn'
    }
}
