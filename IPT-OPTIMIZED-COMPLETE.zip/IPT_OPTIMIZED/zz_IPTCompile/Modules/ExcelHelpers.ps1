# Enable strict mode to catch uninitialized variables and other script issues
Set-StrictMode -Version 2.0

<#
.SYNOPSIS
    ExcelHelpers.ps1 - Optimerad Excel-hantering med EPPlus
    
.DESCRIPTION
    Denna modul innehåller alla Excel-relaterade funktioner:
    - EPPlus assembly-laddning och konfiguration
    - Cell-styling och formatering
    - Batch-operationer för performance
    - Worksheet-hantering

.NOTES
    Version: 1.0
    Kompatibilitet: PowerShell 5.1, EPPlus 4.5.3.3
#>

# ===== EPPlus Assembly-laddning =====

<#
.SYNOPSIS
    Säkerställer att EPPlus.dll är tillgänglig och laddat

.DESCRIPTION
    Probar flera kandidat-sökvägar för EPPlus.dll:
    1. Konfigurerad sökväg (Config)
    2. Lokal modul-mapp (rekommenderat för drift)
    3. Explicit källa (DEV)
    4. Module-installationer
    5. NuGet (om tillåtet)

.PARAMETER Version
    EPPlus-version att ladda. Standard: 4.5.3.3

.OUTPUTS
    System.String - Sökväg till EPPlus.dll, eller $null om inte hittades
#>
function Ensure-EPPlus {
    param(
        [string]$Version = "4.5.3.3",
        [string]$SourceDllPath = "",
        [string]$LocalFolder = "$env:TEMP\EPPlus"
    )
    try {
        $candidatePaths = @()

        # 1) Konfigurerad dll (om satt)
        try {
            if ($global:Config -and $global:Config.EpplusDllPath) {
                $candidatePaths += ($global:Config.EpplusDllPath + '')
            }
        } catch {}

        # 2) Lokalt bredvid modulen (drift rekommenderat)
        $localModuleDll = Join-Path $PSScriptRoot 'EPPlus.dll'
        $candidatePaths += $localModuleDll

        # 3) Explicit källa (t.ex. DEV-build-maskin)
        if ($SourceDllPath) {
            $defaultRoot = 'N:\QC\QC-1\IPT'
            if ($env:IPT_ROOT -and $SourceDllPath -like "$defaultRoot\*") {
                $SourceDllPath = ($env:IPT_ROOT.TrimEnd('\') + $SourceDllPath.Substring($defaultRoot.Length))
            }
            $candidatePaths += $SourceDllPath
        }

        # 4) Module-installationer (om finns)
        $userModRoot = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'WindowsPowerShell\Modules'
        if (Test-Path $userModRoot) {
            Get-ChildItem -Path (Join-Path $userModRoot 'EPPlus') -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                $candidatePaths += Join-Path $_.FullName 'lib\net45\EPPlus.dll'
                $candidatePaths += Join-Path $_.FullName 'lib\net40\EPPlus.dll'
                $candidatePaths += Join-Path $_.FullName 'lib\net35\EPPlus.dll'
            }
        }

        $progFiles = $env:ProgramFiles
        $systemModRoot = Join-Path $progFiles 'WindowsPowerShell\Modules'
        if (Test-Path $systemModRoot) {
            Get-ChildItem -Path (Join-Path $systemModRoot 'EPPlus') -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                $candidatePaths += Join-Path $_.FullName 'lib\net45\EPPlus.dll'
                $candidatePaths += Join-Path $_.FullName 'lib\net40\EPPlus.dll'
                $candidatePaths += Join-Path $_.FullName 'lib\net35\EPPlus.dll'
            }
        }

        foreach ($cand in $candidatePaths) {
            if (-not [string]::IsNullOrWhiteSpace($cand) -and (Test-Path -LiteralPath $cand)) { return $cand }
        }

        # 5) Online NuGet download (opt-in). Drift: default OFF
        $allowOnline = $false
        try {
            if (Get-Command Get-ConfigValue -ErrorAction SilentlyContinue) {
                $allowOnline = [bool](Get-ConfigValue -Name 'AllowNuGetDownload' -Default $false)
            } elseif ($global:Config -and $global:Config.AllowNuGetDownload) {
                $allowOnline = [bool]$global:Config.AllowNuGetDownload
            }
        } catch { $allowOnline = $false }

        if ($allowOnline) {
            $nugetUrl = "https://www.nuget.org/api/v2/package/EPPlus/$Version"
            try {
                $guid = [Guid]::NewGuid().ToString()
                $tempDir = Join-Path $env:TEMP "EPPlus_$guid"
                New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
                $zipPath  = Join-Path $tempDir 'EPPlus.zip'
                $reqParams = @{ Uri = $nugetUrl; OutFile = $zipPath; UseBasicParsing = $true; Headers = @{ 'User-Agent' = 'IPT/1.0' } }
                Invoke-WebRequest @reqParams -ErrorAction Stop | Out-Null

                if (-not ([System.AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.GetName().Name -eq 'System.IO.Compression.FileSystem' })) {
                    Add-Type -AssemblyName 'System.IO.Compression.FileSystem' -ErrorAction SilentlyContinue
                }
                [System.IO.Compression.ZipFile]::ExtractToDirectory($zipPath, $tempDir)
                $extractedRoot = Join-Path $tempDir 'lib'
                if (Test-Path $extractedRoot) {
                    $dllCandidate = Get-ChildItem -Path (Join-Path $extractedRoot 'net45'), (Join-Path $extractedRoot 'net40'), (Join-Path $extractedRoot 'net35') -Filter 'EPPlus.dll' -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
                    if ($dllCandidate) {
                        try {
                            if (-not (Test-Path -LiteralPath $localModuleDll)) {
                                Copy-Item -Path $dllCandidate.FullName -Destination $localModuleDll -Force -ErrorAction SilentlyContinue
                            }
                        } catch { Gui-Log "⚠️ Kunde inte kopiera EPPlus.dll: $($_.Exception.Message)" 'Warn' }
                        if (Test-Path -LiteralPath $localModuleDll) { return $localModuleDll }
                        return $dllCandidate.FullName
                    }
                }
            } catch {
                Gui-Log "❌ EPPlus: Kunde inte hämta EPPlus ($Version): $($_.Exception.Message)" 'Error'
            }
        }
    } catch {
        Gui-Log "❌ Ensure-EPPlus fel: $($_.Exception.Message)" 'Error'
    }

    Gui-Log "❌ EPPlus.dll hittades inte. Lägg EPPlus.dll lokalt i Modules\ (rekommenderat) eller installera EPPlus $Version." 'Error'
    return $null
}

<#
.SYNOPSIS
    Laddar EPPlus-assemblyt i aktuell AppDomain

.OUTPUTS
    System.Boolean - $true om assemblyt är laddat, $false annars
#>
function Load-EPPlus {
    if ([System.AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.GetName().Name -eq 'EPPlus' }) { 
        return $true 
    }
    $dllPath = Ensure-EPPlus -Version '4.5.3.3'
    if (-not $dllPath) { return $false }
    try {
        $bytes = [System.IO.File]::ReadAllBytes($dllPath)
        [System.Reflection.Assembly]::Load($bytes) | Out-Null
        return $true
    } catch {
        Gui-Log "❌ EPPlus-fel: $($_.Exception.Message)" 'Error'
        return $false
    }
}

# ===== Cell & Style-funktioner =====

<#
.SYNOPSIS
    Formaterar en cell med färg, text-stil och border

.PARAMETERS
    $cell - Excel-cell att formatera
    $bold - Gör text fetare (bool)
    $bg - Bakgrundsfärg som hex-värde (t.ex. "00B050" för grön)
    $border - Border-stil (t.ex. "Medium", "Thin")
    $fontColor - Textfärg som hex-värde
#>
function Style-Cell {
    param(
        [Parameter(Mandatory=$true)]$cell,
        [bool]$bold,
        [string]$bg,
        [string]$border,
        [string]$fontColor
    )
    
    if ($bold) { $cell.Style.Font.Bold = $true }
    if ($bg) { 
        $cell.Style.Fill.PatternType = "Solid"
        $cell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#$bg"))
    }
    if ($fontColor) { 
        $cell.Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml("#$fontColor"))
    }
    if ($border) {
        $cell.Style.Border.Top.Style = $border
        $cell.Style.Border.Bottom.Style = $border
        $cell.Style.Border.Left.Style = $border
        $cell.Style.Border.Right.Style = $border
    }
}

<#
.SYNOPSIS
    Sätter borders på en rad med optimerad handling för flera celler

.DESCRIPTION
    Optimerar border-inställning genom att hantera flera celler samtidigt
    istället för en cell i taget.
#>
function Set-RowBorder {
    param(
        [Parameter(Mandatory=$true)]$ws,
        [Parameter(Mandatory=$true)][int]$row,
        [Parameter(Mandatory=$true)][int]$firstRow,
        [Parameter(Mandatory=$true)][int]$lastRow
    )
    
    $cols = @('B','C','D','E','F','G','H')
    $topStyle = if ($row -eq $firstRow) { "Medium" } else { "Thin" }
    $bottomStyle = if ($row -eq $lastRow) { "Medium" } else { "Thin" }
    
    foreach ($col in $cols) {
        $cell = $ws.Cells["$col$row"]
        
        # Nolla alla borders först
        $cell.Style.Border.Left.Style   = "None"
        $cell.Style.Border.Right.Style  = "None"
        $cell.Style.Border.Top.Style    = "None"
        $cell.Style.Border.Bottom.Style = "None"
    }
    
    # Sätt specifika borders
    $ws.Cells["B$row"].Style.Border.Left.Style   = "Medium"
    $ws.Cells["H$row"].Style.Border.Right.Style  = "Medium"
    
    foreach ($col in @('B','C','D','E','F','G')) {
        $ws.Cells["$col$row"].Style.Border.Right.Style = "Thin"
    }
    
    foreach ($col in $cols) {
        $ws.Cells["$col$row"].Style.Border.Top.Style    = $topStyle
        $ws.Cells["$col$row"].Style.Border.Bottom.Style = $bottomStyle
    }
}

# ===== File handling =====

<#
.SYNOPSIS
    Kontrollerar om en fil är låst av en annan process

.PARAMETER Path
    Sökväg till filen att kontrollera

.OUTPUTS
    System.Boolean - $true om filen är låst, $false annars
#>
function Test-FileLocked {
    param([Parameter(Mandatory=$true)][string]$Path)
    try {
        $fs = [IO.File]::Open($Path,'Open','ReadWrite','None')
        $fs.Close()
        return $false
    } catch {
        return $true
    }
}

<#
.SYNOPSIS
    Testar om en sökväg är en nätverkssökväg

.PARAMETER Path
    Sökvägen att testa

.OUTPUTS
    System.Boolean - $true om det är en nätverkssökväg
#>
function Test-IsNetworkPath {
    param([Parameter(Mandatory=$true)][string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
    if ($Path -like '\\*') { return $true }
    try {
        $root = [System.IO.Path]::GetPathRoot($Path)
        if (-not $root) { return $false }
        $driveName = $root.TrimEnd('\')
        $di = New-Object System.IO.DriveInfo($driveName)
        return ($di.DriveType -eq [System.IO.DriveType]::Network)
    } catch {
        return $false
    }
}

# ===== Batch-operationer (OPTIMERAD) =====

<#
.SYNOPSIS
    Skriver data till Excel-celler med batch-operation för snabbhet

.DESCRIPTION
    Använder EPPlus batch-operation istället för att skriva cell-för-cell.
    Detta kan spara 20-30% tid för stora datamängder.

.PARAMETER Worksheet
    Excel-worksheet att skriva till

.PARAMETER StartRow
    Startrad (1-baserad)

.PARAMETER StartColumn
    Startkol (1-baserad)

.PARAMETER Data
    2D-array eller 1D-array med data

.EXAMPLE
    $data = New-Object 'object[,]' 100, 2
    for ($i = 0; $i -lt 100; $i++) {
        $data[$i, 0] = "Rad $i"
        $data[$i, 1] = $i * 10
    }
    Write-ExcelBatch -Worksheet $ws -StartRow 1 -StartColumn 1 -Data $data
#>
function Write-ExcelBatch {
    param(
        [Parameter(Mandatory=$true)]$Worksheet,
        [Parameter(Mandatory=$true)][int]$StartRow,
        [Parameter(Mandatory=$true)][int]$StartColumn,
        [Parameter(Mandatory=$true)]$Data
    )
    
    try {
        if ($Data -is [System.Array]) {
            $rows = $Data.GetLength(0)
            $cols = if ($Data.Rank -gt 1) { $Data.GetLength(1) } else { 1 }
            
            if ($Data.Rank -eq 2) {
                # 2D-array
                $endRow = $StartRow + $rows - 1
                $endCol = $StartColumn + $cols - 1
                $Worksheet.Cells[$StartRow, $StartColumn, $endRow, $endCol].Value = $Data
            } else {
                # 1D-array - skriv horisontellt
                for ($i = 0; $i -lt $rows; $i++) {
                    $Worksheet.Cells[$StartRow, $StartColumn + $i].Value = $Data[$i]
                }
            }
        } else {
            Gui-Log "⚠️ Write-ExcelBatch: Data är inte en array" 'Warn'
        }
    } catch {
        Gui-Log "❌ Write-ExcelBatch fel: $($_.Exception.Message)" 'Error'
    }
}

<#
.SYNOPSIS
    Tillämpar formatering på ett range av celler (batch-operation)

.DESCRIPTION
    Applicerar samma formatering på flera celler samtidigt för performance.
#>
function Format-ExcelRange {
    param(
        [Parameter(Mandatory=$true)]$Worksheet,
        [Parameter(Mandatory=$true)][string]$Range,
        [string]$Bold,
        [string]$BackgroundColor,
        [string]$FontColor,
        [string]$BorderStyle
    )
    
    try {
        $rangeObj = $Worksheet.Cells[$Range]
        
        if ($Bold) { $rangeObj.Style.Font.Bold = $true }
        if ($BackgroundColor) {
            $rangeObj.Style.Fill.PatternType = "Solid"
            $rangeObj.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#$BackgroundColor"))
        }
        if ($FontColor) {
            $rangeObj.Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml("#$FontColor"))
        }
        if ($BorderStyle) {
            $rangeObj.Style.Border.Top.Style = $BorderStyle
            $rangeObj.Style.Border.Bottom.Style = $BorderStyle
            $rangeObj.Style.Border.Left.Style = $BorderStyle
            $rangeObj.Style.Border.Right.Style = $BorderStyle
        }
    } catch {
        Gui-Log "❌ Format-ExcelRange fel: $($_.Exception.Message)" 'Error'
    }
}

<#
.SYNOPSIS
    Auto-justerar kolumnbredder med performance-optimering

.DESCRIPTION
    Säkerställer att kolumner är breda nog för sitt innehål.
    Optimerad version som batchar operationen.
#>
function Safe-AutoFitColumns {
    param(
        [Parameter(Mandatory=$true)]$Ws,
        [Parameter(Mandatory=$true)]$Range,
        [string]$Context = "DataRange"
    )
    
    try {
        if (-not $Range) { return }
        
        $Range.AutoFitColumns(5, 50) # Min 5, max 50 tum
    } catch {
        try {
            # Fallback: enkel auto-fit om ovan misslyckas
            $Range.AutoFitColumns()
        } catch {
            Gui-Log "⚠️ Safe-AutoFitColumns ($Context) misslyckades: $($_.Exception.Message)" 'Warn'
        }
    }
}
