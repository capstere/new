# Enable strict mode to catch uninitialized variables and other script issues
Set-StrictMode -Version 2.0

<#
.SYNOPSIS
    Initialize-DataPipeline.ps1 - Centraliserad initiering av alla input-data
    
.DESCRIPTION
    Denna modul hanterar:
    - Läsning av alla 4 input-filer EN GÅNG
    - Caching av data i script-scope
    - Validering av filformat
    - Performance-monitoring
    
    Filer som läses:
    1. CSV-fil (test-data)
    2. Seal Test NEG (.xlsx)
    3. Seal Test POS (.xlsx)
    4. Worksheet-mall (.xlsx)
    
    Filosofi: In-memory processing efter initial load

.NOTES
    Version: 1.0
    Kompatibilitet: PowerShell 5.1, EPPlus 4.5.3.3
    
.EXAMPLE
    $pipeline = Initialize-DataPipeline -CsvPath "test.csv" -NegPath "neg.xlsx" -PosPath "pos.xlsx" -WorksheetPath "worksheet.xlsx"
    if ($pipeline.Success) {
        $csvData = $pipeline.CsvRows
        $negPackage = $pipeline.PackageNeg
        # ... processa allt från pipeline
    }
#>

# ===== Caching variabler =====
$script:DataPipeline = $null
$script:PipelineLoadTime = $null
$script:PipelineStats = @{
    FileSize_CSV = 0
    FileSize_NEG = 0
    FileSize_POS = 0
    FileSize_Worksheet = 0
    RowCount_CSV = 0
    LoadTime_MS = 0
}

# ===== Huvudfunktion =====

<#
.SYNOPSIS
    Initialiserar data-pipeline genom att läsa alla 4 input-filer

.PARAMETER CsvPath
    Sökväg till CSV-fil med test-data

.PARAMETER NegPath
    Sökväg till Seal Test NEG Excel-fil

.PARAMETER PosPath
    Sökväg till Seal Test POS Excel-fil

.PARAMETER WorksheetPath
    Sökväg till Worksheet-mall Excel-fil

.PARAMETER ValidateOnly
    Om $true, validera endast utan att ladda data

.OUTPUTS
    PSCustomObject med struktur:
    @{
        Success = $true/$false
        Message = "Status-meddelande"
        StartTime = [DateTime]
        EndTime = [DateTime]
        LoadTime_MS = [int]
        CsvRows = @() # Array av fält-arrayer
        PackageNeg = [ExcelPackage]
        PackagePos = [ExcelPackage]
        PackageWorksheet = [ExcelPackage]
        CsvAssay = "Assay namn från CSV"
        Stats = @{...}
    }
#>
function Initialize-DataPipeline {
    param(
        [Parameter(Mandatory=$true)][string]$CsvPath,
        [Parameter(Mandatory=$true)][string]$NegPath,
        [Parameter(Mandatory=$true)][string]$PosPath,
        [Parameter(Mandatory=$true)][string]$WorksheetPath,
        [switch]$ValidateOnly
    )
    
    $startTime = Get-Date
    $result = [ordered]@{
        Success = $false
        Message = ""
        StartTime = $startTime
        EndTime = $null
        LoadTime_MS = 0
        CsvRows = @()
        PackageNeg = $null
        PackagePos = $null
        PackageWorksheet = $null
        CsvAssay = $null
        Stats = @{}
    }
    
    try {
        # --- Fas 1: Validering av filer ---
        Gui-Log "🔍 Validerar input-filer…" 'Info'
        
        $validationErrors = @()
        
        if (-not (Test-Path -LiteralPath $CsvPath)) {
            $validationErrors += "CSV-fil saknas: $CsvPath"
        } else {
            try {
                $csvItem = Get-Item -LiteralPath $CsvPath
                if ($csvItem.Length -lt 100) {
                    $validationErrors += "CSV-fil är för liten: $($csvItem.Length) bytes"
                }
                $result.Stats.FileSize_CSV = $csvItem.Length
            } catch {
                $validationErrors += "Kunde inte läsa CSV-info: $_"
            }
        }
        
        if (-not (Test-Path -LiteralPath $NegPath)) {
            $validationErrors += "NEG-fil saknas: $NegPath"
        } else {
            try {
                $negItem = Get-Item -LiteralPath $NegPath
                $result.Stats.FileSize_NEG = $negItem.Length
            } catch {
                $validationErrors += "Kunde inte läsa NEG-info: $_"
            }
        }
        
        if (-not (Test-Path -LiteralPath $PosPath)) {
            $validationErrors += "POS-fil saknas: $PosPath"
        } else {
            try {
                $posItem = Get-Item -LiteralPath $PosPath
                $result.Stats.FileSize_POS = $posItem.Length
            } catch {
                $validationErrors += "Kunde inte läsa POS-info: $_"
            }
        }
        
        if (-not (Test-Path -LiteralPath $WorksheetPath)) {
            $validationErrors += "Worksheet-fil saknas: $WorksheetPath"
        } else {
            try {
                $wsItem = Get-Item -LiteralPath $WorksheetPath
                $result.Stats.FileSize_Worksheet = $wsItem.Length
            } catch {
                $validationErrors += "Kunde inte läsa Worksheet-info: $_"
            }
        }
        
        if ($validationErrors.Count -gt 0) {
            $result.Success = $false
            $result.Message = "Validering misslyckades:`n" + ($validationErrors -join "`n")
            foreach ($err in $validationErrors) {
                Gui-Log "❌ $err" 'Error'
            }
            return [pscustomobject]$result
        }
        
        Gui-Log "✅ Alla filer validerade. Börjar ladda…" 'Info'
        
        if ($ValidateOnly) {
            $result.Success = $true
            $result.Message = "Validering lyckades (data ej laddad)"
            return [pscustomobject]$result
        }
        
        # --- Fas 2: Ladda Excel-paket (NEG, POS, Worksheet) ---
        Gui-Log "📂 Läser Excel-filer (NEG, POS, Worksheet)…" 'Info'
        
        try {
            $result.PackageNeg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($NegPath))
        } catch {
            $result.Message = "Kunde inte öppna NEG-fil: $_"
            Gui-Log "❌ $($result.Message)" 'Error'
            return [pscustomobject]$result
        }
        
        try {
            $result.PackagePos = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($PosPath))
        } catch {
            $result.Message = "Kunde inte öppna POS-fil: $_"
            Gui-Log "❌ $($result.Message)" 'Error'
            $result.PackageNeg.Dispose()
            return [pscustomobject]$result
        }
        
        try {
            $result.PackageWorksheet = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($WorksheetPath))
        } catch {
            $result.Message = "Kunde inte öppna Worksheet-fil: $_"
            Gui-Log "❌ $($result.Message)" 'Error'
            $result.PackageNeg.Dispose()
            $result.PackagePos.Dispose()
            return [pscustomobject]$result
        }
        
        Gui-Log "✅ Excel-filer laddade" 'Info'
        
        # --- Fas 3: Ladda CSV-data ---
        Gui-Log "📊 Läser CSV-data…" 'Info'
        
        try {
            $csvItem = Get-Item -LiteralPath $CsvPath
            $thresholdMb = 25
            
            try {
                if ($global:Config -and ($global:Config -is [System.Collections.IDictionary]) -and $global:Config.Contains('CsvStreamingThresholdMB')) {
                    $thresholdMb = [int]$global:Config['CsvStreamingThresholdMB']
                }
            } catch {}
            
            $useStreaming = ($csvItem.Length -ge ($thresholdMb * 1MB))
            
            if ($useStreaming) {
                Gui-Log "⏳ CSV är stor ($([Math]::Round($csvItem.Length/1MB, 1)) MB) – använder streaming…" 'Info'
                $list = New-Object System.Collections.Generic.List[object]
                
                try {
                    Import-CsvRowsStreaming -Path $CsvPath -StartRow 10 -ProcessRow {
                        param($Fields, $RowIndex)
                        [void]$list.Add($Fields)
                        if (($RowIndex % 2000) -eq 0) { 
                            Gui-Log "  Läst $RowIndex rader…" 'Info'
                        }
                    }
                    $result.CsvRows = @($list.ToArray())
                } catch {
                    Gui-Log "⚠️ Streaming misslyckades, försöker normalt import: $_" 'Warn'
                    $result.CsvRows = Import-CsvRows -Path $CsvPath -StartRow 10
                }
            } else {
                $result.CsvRows = Import-CsvRows -Path $CsvPath -StartRow 10
            }
            
            $result.Stats.RowCount_CSV = $result.CsvRows.Count
            Gui-Log "✅ CSV laddad: $($result.CsvRows.Count) rader" 'Info'
            
        } catch {
            $result.Message = "CSV-import misslyckades: $_"
            Gui-Log "❌ $($result.Message)" 'Error'
            $result.CsvRows = @()
        }
        
        # --- Fas 4: Sortera CSV-data ---
        try {
            if ($result.CsvRows -and $result.CsvRows.Count -gt 1) {
                if ($result.CsvRows[0] -is [object[]]) {
                    # Import-CsvRows returnerar fält-arrayer: kolumn C = index 2 (Sample ID)
                    $result.CsvRows = @($result.CsvRows | Sort-Object { [string]($_[2]) })
                } else {
                    # PSCustomObject-fallback
                    $result.CsvRows = @($result.CsvRows | Sort-Object { [string]($_.'Sample ID') })
                }
                Gui-Log "🔃 CSV sorterad på Sample ID" 'Info'
            }
        } catch {
            Gui-Log "⚠️ CSV-sortering misslyckades: $_" 'Warn'
        }
        
        # --- Fas 5: Extrahera metadata från CSV ---
        try {
            $result.CsvAssay = Get-AssayFromCsv -Path $CsvPath -StartRow 10
            if ($result.CsvAssay) {
                Gui-Log "🔎 Assay från CSV: $($result.CsvAssay)" 'Info'
            }
        } catch {
            Gui-Log "⚠️ Kunde inte läsa Assay från CSV: $_" 'Warn'
        }
        
        # --- Framgång! ---
        $result.Success = $true
        $result.Message = "Data-pipeline initierad framgångsrikt"
        
    } catch {
        $result.Success = $false
        $result.Message = "Oväntat fel i data-pipeline: $_"
        Gui-Log "❌ $($result.Message)" 'Error'
    } finally {
        $result.EndTime = Get-Date
        $result.LoadTime_MS = [int]($result.EndTime - $result.StartTime).TotalMilliseconds
        $result.Stats.LoadTime_MS = $result.LoadTime_MS
        
        if ($result.Success) {
            Gui-Log "⏱️ Data-pipeline klar på $($result.LoadTime_MS) ms" 'Info'
        }
    }
    
    # Cache resultatet globalt för åtkomst senare
    $script:DataPipeline = $result
    $script:PipelineStats = $result.Stats
    
    return [pscustomobject]$result
}

# ===== Hjälpfunktioner =====

<#
.SYNOPSIS
    Hämtar cachelagrad pipeline-data

.OUTPUTS
    PSCustomObject - Det senast initierade pipeline-objektet eller $null
#>
function Get-DataPipeline {
    return $script:DataPipeline
}

<#
.SYNOPSIS
    Hämtar pipeline-statistik

.OUTPUTS
    Hashtable med load-tider och filstorlekar
#>
function Get-PipelineStats {
    return $script:PipelineStats
}

<#
.SYNOPSIS
    Rensar alla pipeline-resurser (Dispose av Excel-paket)

.DESCRIPTION
    Bör anropas innan scriptet avslutas för att frigöra minne och låsa på filer
#>
function Cleanup-DataPipeline {
    param([pscustomobject]$Pipeline = $script:DataPipeline)
    
    try {
        if ($Pipeline) {
            if ($Pipeline.PackageNeg) { $Pipeline.PackageNeg.Dispose() }
            if ($Pipeline.PackagePos) { $Pipeline.PackagePos.Dispose() }
            if ($Pipeline.PackageWorksheet) { $Pipeline.PackageWorksheet.Dispose() }
            
            Gui-Log "🧹 Data-pipeline resurser rensat" 'Info'
        }
    } catch {
        Gui-Log "⚠️ Cleanup-DataPipeline fel: $_" 'Warn'
    }
    
    $script:DataPipeline = $null
}
