/* ClickLess Offline Analyzer v9
   - ES5 only (no const/let/arrow/template/module/async)
   - Offline XLSX reader: JSZip + SheetJS (xlsx.full.min.js)
   - Reads: Seal Test NEG/POS (.xlsx), Worksheet (.xlsx), Test Summary (.csv/.xlsx)
   - Uses bundled rulesheets (rules_bundle.js)
*/

(function () {
  'use strict';

  // ----------------------------
  // DOM helpers
  // ----------------------------
  function $(id) { return document.getElementById(id); }

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    if (attrs) {
      for (var k in attrs) {
        if (!attrs.hasOwnProperty(k)) continue;
        if (k === 'text') node.textContent = String(attrs[k]);
        else if (k === 'html') node.innerHTML = String(attrs[k]);
        else if (k === 'class') node.className = String(attrs[k]);
        else if (k === 'style') node.setAttribute('style', String(attrs[k]));
        else node.setAttribute(k, String(attrs[k]));
      }
    }
    if (children && children.length) {
      for (var i = 0; i < children.length; i++) node.appendChild(children[i]);
    }
    return node;
  }

  function clearNode(node) { while (node.firstChild) node.removeChild(node.firstChild); }

  function pill(text, kind) {
    var cls = 'pill';
    if (kind === 'ok') cls += ' ok';
    else if (kind === 'bad') cls += ' bad';
    else if (kind === 'warn') cls += ' warn';
    return el('span', { 'class': cls, text: text });
  }

  function setStatus(msg, isError) {
    var s = $('status');
    s.textContent = msg || '';
    s.className = 'small ' + (isError ? 'err' : 'muted');
  }

  // ----------------------------
  // Types + state
  // ----------------------------
  var TYPE_KEYS = {
    AUTO: 'AUTO',
    TEST_SUMMARY: 'TEST_SUMMARY',
    SEAL_POS: 'SEAL_POS',
    SEAL_NEG: 'SEAL_NEG',
    WORKSHEET: 'WORKSHEET',
    UNKNOWN: 'UNKNOWN'
  };

  var TYPE_OPTIONS = [
    { key: TYPE_KEYS.AUTO, label: 'Auto' },
    { key: TYPE_KEYS.TEST_SUMMARY, label: 'Test Summary (csv/xlsx)' },
    { key: TYPE_KEYS.SEAL_POS, label: 'Seal Test POS (xlsx)' },
    { key: TYPE_KEYS.SEAL_NEG, label: 'Seal Test NEG (xlsx)' },
    { key: TYPE_KEYS.WORKSHEET, label: 'Worksheet (xlsx)' }
  ];

  var files = []; // {file, typeKey, detectedKey}
  var rulesState = loadRulesBundle();

  // ----------------------------
  // Utilities
  // ----------------------------
  function trim(s) { return (s || '').toString().replace(/^\s+|\s+$/g, ''); }

  function safeText(v) {
    if (v === null || v === undefined) return '—';
    var s = String(v);
    if (!trim(s)) return '—';
    return s;
  }

  function escapeHtml(s) {
    s = (s === undefined || s === null) ? '' : String(s);
    return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
            .replace(/"/g,'&quot;').replace(/\'/g,'&#39;');
  }

  function countChar(s, ch) {
    var n = 0;
    for (var i = 0; i < s.length; i++) if (s.charAt(i) === ch) n++;
    return n;
  }

  function normalizeHeaderText(s) {
    if (!s) return '';
    s = String(s);
    s = s.replace(/[\uFEFF\u200B]/g, '');
    s = s.replace(/[\u00A0\u2007\u202F]/g, ' ');
    s = s.replace(/[\u2013\u2014\u2212]/g, '-');
    s = s.replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
    return s;
  }

  function normalizeId(value, type) {
    if (!value) return '';
    var v = String(value).trim();
    if (type === 'Batch') return v.replace(/[^0-9]/g, '');
    if (type === 'Part') return v.replace(/[^0-9A-Za-z\-]/g, '').toUpperCase();
    if (type === 'Cartridge') return v.replace(/[^0-9]/g, '');
    return v;
  }

  function tryParseHeaderDate(cellValue) {
    if (cellValue === null || cellValue === undefined) return '';
    if (typeof cellValue === 'number' && !isNaN(cellValue)) {
      // Excel serial date (1900 system)
      var ms = Math.round((cellValue - 25569) * 86400 * 1000);
      var d = new Date(ms);
      if (!isNaN(d.getTime())) return formatDateYmd(d);
    }

    if (Object.prototype.toString.call(cellValue) === '[object Date]') {
      if (!isNaN(cellValue.getTime())) return formatDateYmd(cellValue);
    }

    var s = normalizeHeaderText(String(cellValue));
    if (!s) return '';

    var parsed = Date.parse(s);
    if (!isNaN(parsed)) return formatDateYmd(new Date(parsed));

    var m;
    m = /^(\d{4})[-\/](\d{2})[-\/](\d{2})$/.exec(s);
    if (m) return m[1] + '-' + m[2] + '-' + m[3];

    m = /^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})$/.exec(s);
    if (m) {
      var dd = m[1], mm = m[2], yy = m[3];
      return yy + '-' + pad2(mm) + '-' + pad2(dd);
    }

    m = /^(\d{2})[-\/](\d{2})[-\/](\d{2})$/.exec(s);
    if (m) {
      return '20' + m[3] + '-' + m[2] + '-' + m[1];
    }

    return '';
  }

  function formatDateYmd(d) {
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
  }

  function pad2(n) {
    n = String(n);
    return (n.length < 2) ? ('0' + n) : n;
  }

  function padNumber(n, width) {
    var s = String(n);
    while (s.length < width) s = '0' + s;
    return s;
  }

  function parseNumberLoose(v) {
    if (typeof v === 'number' && !isNaN(v)) return v;
    var s = String(v || '').replace(',', '.');
    var n = parseFloat(s);
    return isNaN(n) ? null : n;
  }

  function toBool(v) {
    if (v === true) return true;
    if (v === false) return false;
    var s = String(v || '').toLowerCase();
    return (s === 'true' || s === '1' || s === 'yes' || s === 'y');
  }

  function makeKeyMap() {
    return { map: {}, list: [] };
  }

  // ----------------------------
  // CSV parsing
  // ----------------------------
  function splitCsvLine(line, delim) {
    var out = [];
    var cur = '';
    var inQ = false;
    for (var i = 0; i < line.length; i++) {
      var ch = line.charAt(i);
      if (inQ) {
        if (ch === '"') {
          if (i + 1 < line.length && line.charAt(i + 1) === '"') { cur += '"'; i++; }
          else inQ = false;
        } else {
          cur += ch;
        }
      } else {
        if (ch === '"') inQ = true;
        else if (ch === delim) { out.push(cur); cur = ''; }
        else cur += ch;
      }
    }
    out.push(cur);
    return out;
  }

  function detectDelimiter(lines) {
    var semi = 0, comma = 0, checked = 0;
    for (var i = 0; i < lines.length; i++) {
      var l = lines[i];
      if (!l || !trim(l)) continue;
      semi += countChar(l, ';');
      comma += countChar(l, ',');
      checked++;
      if (checked >= 5) break;
    }
    return (semi >= comma) ? ';' : ',';
  }

  function parseCsvTable(text) {
    text = text || '';
    if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);

    var lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
    var delim = detectDelimiter(lines);

    var headerIdx = -1;
    for (var i = 0; i < lines.length; i++) {
      var l = lines[i];
      if (!l) continue;
      var low = l.toLowerCase();
      if (low.indexOf('assay') >= 0 && low.indexOf('sample') >= 0 && (low.indexOf('cartridge') >= 0 || low.indexOf('s/n') >= 0)) {
        headerIdx = i;
        break;
      }
    }

    if (headerIdx < 0) return { ok: false, error: 'Kunde inte hitta header-rad i CSV.' };

    var headers = splitCsvLine(lines[headerIdx], delim);
    var rows = [];
    for (i = headerIdx + 1; i < lines.length; i++) {
      if (!lines[i]) continue;
      if (/^(\s*;)+\s*$/.test(lines[i]) || /^(\s*,)+\s*$/.test(lines[i])) continue;
      var cols = splitCsvLine(lines[i], delim);
      if (cols.length < 4) continue;
      rows.push(cols);
    }

    return { ok: true, delim: delim, headerIdx: headerIdx, headers: headers, rows: rows };
  }

  function parseRulesCsv(text) {
    text = text || '';
    if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
    var lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
    var delim = detectDelimiter(lines);

    var headerIdx = -1;
    for (var i = 0; i < lines.length; i++) {
      if (lines[i] && trim(lines[i])) { headerIdx = i; break; }
    }
    if (headerIdx < 0) return { headers: [], rows: [], delim: delim };

    var headers = splitCsvLine(lines[headerIdx], delim);
    var rows = [];
    for (i = headerIdx + 1; i < lines.length; i++) {
      if (!lines[i] || !trim(lines[i])) continue;
      var cols = splitCsvLine(lines[i], delim);
      rows.push(cols);
    }
    return { headers: headers, rows: rows, delim: delim };
  }

  function rowToObject(headers, row) {
    var obj = { _lc: {} };
    for (var i = 0; i < headers.length; i++) {
      var key = normalizeHeaderText(headers[i] || '');
      if (!key) continue;
      var val = (i < row.length ? row[i] : '');
      obj[key] = val;
      obj._lc[key.toLowerCase()] = val;
    }
    return obj;
  }

  function getField(obj, names) {
    if (!obj || !obj._lc) return '';
    for (var i = 0; i < names.length; i++) {
      var v = obj._lc[String(names[i]).toLowerCase()];
      if (v !== undefined && v !== null && trim(v) !== '') return v;
    }
    return '';
  }

  // ----------------------------
  // Rules bundle
  // ----------------------------
  function loadRulesBundle() {
    var state = {
      ok: true,
      errors: [],
      counts: {},
      data: {
        resultCallPatterns: [],
        sampleExpectationRules: [],
        errorCodes: { byCode: {}, fallbacks: [] },
        missingSamplesConfig: null,
        sampleIdMarkers: [],
        parityConfig: null
      }
    };

    if (!window.CLICKLESS_RULES_BUNDLE) {
      state.ok = false;
      state.errors.push('rules_bundle.js saknas.');
      return state;
    }

    function loadOne(name) {
      var text = window.CLICKLESS_RULES_BUNDLE[name];
      if (typeof text !== 'string') {
        state.errors.push('Saknar rulesheet: ' + name);
        state.ok = false;
        return { headers: [], rows: [] };
      }
      return parseRulesCsv(text);
    }

    // 01 ResultCallPatterns
    var r1 = loadOne('01_ResultCallPatterns.csv');
    var rules1 = [];
    for (var i = 0; i < r1.rows.length; i++) {
      var obj1 = rowToObject(r1.headers, r1.rows[i]);
      var enabled = getField(obj1, ['Enabled', 'Active', 'Use']);
      if (enabled && !toBool(enabled)) continue;

      var rule = {
        assay: trim(getField(obj1, ['Assay'])) || '*',
        matchType: trim(getField(obj1, ['MatchType', 'Match Type'])) || 'contains',
        pattern: trim(getField(obj1, ['Pattern', 'MatchPattern'])) || '',
        call: trim(getField(obj1, ['Call', 'NormalizedCall', 'Normalized', 'Expected'])) || '',
        priority: parseInt(getField(obj1, ['Priority']), 10) || 0,
        notes: trim(getField(obj1, ['Note', 'Notes'])) || ''
      };
      if (rule.pattern && rule.call) rules1.push(rule);
    }
    rules1.sort(function (a, b) {
      if (b.priority !== a.priority) return b.priority - a.priority;
      if (a.assay === '*' && b.assay !== '*') return 1;
      if (b.assay === '*' && a.assay !== '*') return -1;
      return 0;
    });
    state.data.resultCallPatterns = rules1;
    state.counts['01_ResultCallPatterns.csv'] = rules1.length;

    // 02 SampleExpectationRules
    var r2 = loadOne('02_SampleExpectationRules.csv');
    var rules2 = [];
    for (i = 0; i < r2.rows.length; i++) {
      var obj2 = rowToObject(r2.headers, r2.rows[i]);
      enabled = getField(obj2, ['Enabled', 'Active', 'Use']);
      if (enabled && !toBool(enabled)) continue;

      var rule2 = {
        assay: trim(getField(obj2, ['Assay'])) || '*',
        expected: trim(getField(obj2, ['Expected', 'ExpectedCall'])) || '',
        matchType: trim(getField(obj2, ['SampleIdMatchType', 'MatchType'])) || 'contains',
        samplePattern: trim(getField(obj2, ['SampleIdPattern', 'SamplePattern', 'Pattern'])) || '',
        priority: parseInt(getField(obj2, ['Priority']), 10) || 0,
        severity: trim(getField(obj2, ['Severity'])) || 'WARN',
        notes: trim(getField(obj2, ['Note', 'Notes'])) || ''
      };
      if (rule2.samplePattern && rule2.expected) rules2.push(rule2);
    }
    rules2.sort(function (a, b) {
      if (a.assay === '*' && b.assay !== '*') return 1;
      if (b.assay === '*' && a.assay !== '*') return -1;
      if (b.priority !== a.priority) return b.priority - a.priority;
      return 0;
    });
    state.data.sampleExpectationRules = rules2;
    state.counts['02_SampleExpectationRules.csv'] = rules2.length;

    // 03 ErrorCodes
    var r3 = loadOne('03_ErrorCodes.csv');
    var codes = { byCode: {}, fallbacks: [] };
    for (i = 0; i < r3.rows.length; i++) {
      var obj3 = rowToObject(r3.headers, r3.rows[i]);
      var code = trim(getField(obj3, ['ErrorCode', 'Error Code']));
      var name = trim(getField(obj3, ['Name', 'Description'])) || '';
      var retest = toBool(getField(obj3, ['GeneratesRetest', 'Retest']));
      if (code) {
        codes.byCode[code] = { code: code, name: name, generatesRetest: retest };
      } else if (name) {
        codes.fallbacks.push({ name: name, generatesRetest: retest });
      }
    }
    state.data.errorCodes = codes;
    state.counts['03_ErrorCodes.csv'] = Object.keys(codes.byCode).length;

    // 04 MissingSamplesConfig
    var r4 = loadOne('04_MissingSamplesConfig.csv');
    var cfg4 = { mode: '', rows: [] };
    for (i = 0; i < r4.rows.length; i++) {
      var obj4 = rowToObject(r4.headers, r4.rows[i]);
      if (!cfg4.mode) {
        if (obj4._lc['requiredsamples'] || obj4._lc['requiredsetname']) cfg4.mode = 'list';
        else if (obj4._lc['bagmin']) cfg4.mode = 'bagRange';
        else cfg4.mode = 'unknown';
      }

      if (cfg4.mode === 'list') {
        cfg4.rows.push({
          assay: trim(getField(obj4, ['Assay'])) || '*',
          requiredSetName: trim(getField(obj4, ['RequiredSetName', 'SetName'])) || 'Default',
          requiredSamples: trim(getField(obj4, ['RequiredSamples'])) || '',
          allowedMissing: trim(getField(obj4, ['AllowedMissing'])) || '',
          notes: trim(getField(obj4, ['Notes', 'Note'])) || ''
        });
      } else if (cfg4.mode === 'bagRange') {
        cfg4.rows.push({
          bagMin: parseInt(getField(obj4, ['BagMin']), 10),
          bagMax: parseInt(getField(obj4, ['BagMax']), 10),
          bag0SampleMin: parseInt(getField(obj4, ['Bag0SampleMin']), 10),
          bag0SampleMax: parseInt(getField(obj4, ['Bag0SampleMax']), 10),
          otherBagSampleMin: parseInt(getField(obj4, ['OtherBagSampleMin']), 10),
          otherBagSampleMax: parseInt(getField(obj4, ['OtherBagSampleMax']), 10),
          bagIndex: parseInt(getField(obj4, ['BagIndex_SampleID_SplitIndex', 'BagIndex']), 10),
          sampleTokenIndex: parseInt(getField(obj4, ['SampleToken_SampleID_SplitIndex', 'SampleTokenIndex']), 10),
          sampleNumberRegex: trim(getField(obj4, ['SampleNumberRegex'])) || '\\d+',
          sampleNumberPad: parseInt(getField(obj4, ['SampleNumberPad']), 10) || 0,
          allowedMissing: trim(getField(obj4, ['AllowedMissing'])) || '',
          notes: trim(getField(obj4, ['Notes', 'Note'])) || ''
        });
      }
    }
    state.data.missingSamplesConfig = cfg4.rows.length ? cfg4 : null;
    state.counts['04_MissingSamplesConfig.csv'] = cfg4.rows.length;

    // 05 SampleIdMarkers
    var r5 = loadOne('05_SampleIdMarkers.csv');
    var markers = [];
    for (i = 0; i < r5.rows.length; i++) {
      var obj5 = rowToObject(r5.headers, r5.rows[i]);
      var mType = trim(getField(obj5, ['MarkerType', 'Type'])) || '';
      var mIdx = parseInt(getField(obj5, ['SampleTokenIndex', 'TokenIndex']), 10);
      var mPat = trim(getField(obj5, ['Marker', 'MarkerPattern', 'Pattern'])) || '';
      if (mType && mPat) {
        markers.push({ markerType: mType, tokenIndex: mIdx, marker: mPat });
      }
    }
    state.data.sampleIdMarkers = markers;
    state.counts['05_SampleIdMarkers.csv'] = markers.length;

    // 06 ParityCheckConfig
    var r6 = loadOne('06_ParityCheckConfig.csv');
    var parity = { mode: '', rows: [] };
    for (i = 0; i < r6.rows.length; i++) {
      var obj6 = rowToObject(r6.headers, r6.rows[i]);
      if (!parity.mode) {
        if (obj6._lc['checkname']) parity.mode = 'config';
        else if (obj6._lc['sampletokenindex']) parity.mode = 'token';
        else parity.mode = 'unknown';
      }
      if (parity.mode === 'config') {
        parity.rows.push({
          assay: trim(getField(obj6, ['Assay'])) || '*',
          checkName: trim(getField(obj6, ['CheckName'])) || '',
          groupByField: trim(getField(obj6, ['GroupByField'])) || '',
          mustMatchField: trim(getField(obj6, ['MustMatchField'])) || '',
          condition: trim(getField(obj6, ['Condition'])) || '',
          severity: trim(getField(obj6, ['Severity'])) || 'WARN',
          notes: trim(getField(obj6, ['Notes', 'Note'])) || ''
        });
      } else if (parity.mode === 'token') {
        parity.rows.push({
          tokenIndex: parseInt(getField(obj6, ['SampleTokenIndex', 'TokenIndex']), 10),
          xChar: trim(getField(obj6, ['XChar', 'X'])) || 'X',
          plusChar: trim(getField(obj6, ['PlusChar', 'Plus'])) || '+',
          notes: trim(getField(obj6, ['Notes', 'Note'])) || ''
        });
      }
    }
    state.data.parityConfig = parity.rows.length ? parity : null;
    state.counts['06_ParityCheckConfig.csv'] = parity.rows.length;

    return state;
  }

  // ----------------------------
  // File detection + list
  // ----------------------------
  function detectTypeByName(name) {
    var n = (name || '').toLowerCase();
    if (n.indexOf('test summary') >= 0 || n.indexOf('tests summary') >= 0) return TYPE_KEYS.TEST_SUMMARY;
    if (n.indexOf('seal test pos') >= 0 || n.indexOf('seal test positive') >= 0) return TYPE_KEYS.SEAL_POS;
    if (n.indexOf('seal test neg') >= 0 || n.indexOf('seal test negative') >= 0) return TYPE_KEYS.SEAL_NEG;
    if (n.indexOf('worksheet') >= 0 || n.indexOf('lsp worksheet') >= 0) return TYPE_KEYS.WORKSHEET;
    if (n.slice(-4) === '.csv') return TYPE_KEYS.TEST_SUMMARY;
    if (n.slice(-5) === '.xlsx' || n.slice(-4) === '.xls') return TYPE_KEYS.UNKNOWN;
    return TYPE_KEYS.UNKNOWN;
  }

  function typeLabel(key) {
    for (var i = 0; i < TYPE_OPTIONS.length; i++) if (TYPE_OPTIONS[i].key === key) return TYPE_OPTIONS[i].label;
    return key;
  }

  function refreshFileList() {
    var list = $('fileList');
    clearNode(list);

    if (!files.length) {
      list.appendChild(el('div', { 'class': 'small muted', text: 'Inga filer valda.' }));
      $('runBtn').disabled = true;
      return;
    }

    var tbl = el('table');
    var thead = el('thead');
    var trh = el('tr');
    trh.appendChild(el('th', { text: 'Fil' }));
    trh.appendChild(el('th', { text: 'Detekterad typ' }));
    trh.appendChild(el('th', { text: 'Anvand som' }));
    trh.appendChild(el('th', { text: '' }));
    thead.appendChild(trh);
    tbl.appendChild(thead);

    var tbody = el('tbody');
    for (var i = 0; i < files.length; i++) {
      (function (idx) {
        var f = files[idx];
        var tr = el('tr');

        tr.appendChild(el('td', { 'class': 'mono', text: f.file.name }));
        tr.appendChild(el('td', { text: typeLabel(f.detectedKey) }));

        var sel = el('select');
        for (var j = 0; j < TYPE_OPTIONS.length; j++) {
          var opt = el('option', { value: TYPE_OPTIONS[j].key, text: TYPE_OPTIONS[j].label });
          if (TYPE_OPTIONS[j].key === f.typeKey) opt.selected = true;
          sel.appendChild(opt);
        }
        sel.addEventListener('change', function () { files[idx].typeKey = sel.value; validateReady(); });
        tr.appendChild(el('td', null, [sel]));

        var rm = el('button', { 'class': 'btn2', type: 'button', text: 'Ta bort' });
        rm.addEventListener('click', function () { files.splice(idx, 1); refreshFileList(); validateReady(); });
        tr.appendChild(el('td', null, [rm]));

        tbody.appendChild(tr);
      })(i);
    }
    tbl.appendChild(tbody);
    list.appendChild(tbl);

    validateReady();
  }

  function validateReady() {
    var want = { TEST_SUMMARY: 0, SEAL_POS: 0, SEAL_NEG: 0, WORKSHEET: 0 };
    for (var i = 0; i < files.length; i++) {
      var tk = files[i].typeKey;
      if (tk === TYPE_KEYS.AUTO) tk = files[i].detectedKey;
      if (want.hasOwnProperty(tk)) want[tk]++;
    }

    var okCsv = (want.TEST_SUMMARY >= 1);
    $('runBtn').disabled = !okCsv;

    if (!okCsv) {
      setStatus('Valj minst 1 fil: Test Summary (csv).', false);
      return;
    }

    var missing = [];
    if (want.SEAL_NEG < 1) missing.push('Seal NEG');
    if (want.SEAL_POS < 1) missing.push('Seal POS');
    if (want.WORKSHEET < 1) missing.push('Worksheet');

    if (missing.length) {
      setStatus('Redo for CSV-validering. (XLSX-delar saknas: ' + missing.join(', ') + ')', false);
    } else {
      setStatus('Redo. Klicka \"Kora analys\".', false);
    }
  }

  // ----------------------------
  // Zip bundle support
  // ----------------------------
  function isZipFile(file) {
    if (!file) return false;
    var n = (file.name || '').toLowerCase();
    if (n.slice(-4) === '.zip') return true;
    var t = (file.type || '').toLowerCase();
    if (t.indexOf('zip') >= 0) return true;
    return false;
  }

  function makeFileLike(data, name, mime) {
    var opts = mime ? { type: mime } : {};
    try {
      return new File([data], name, opts);
    } catch (e) {
      var b = new Blob([data], opts);
      b.name = name;
      return b;
    }
  }

  function readAsArrayBuffer(file) {
    if (file && typeof file.arrayBuffer === 'function') return file.arrayBuffer();
    return new Promise(function (resolve, reject) {
      try {
        var fr = new FileReader();
        fr.onload = function () { resolve(fr.result); };
        fr.onerror = function () { reject(fr.error || new Error('FileReader error')); };
        fr.readAsArrayBuffer(file);
      } catch (e) { reject(e); }
    });
  }

  function extractBundleFilesFromZip(zipFile) {
    if (typeof JSZip === 'undefined') {
      return Promise.reject(new Error('JSZip not loaded'));
    }

    return readAsArrayBuffer(zipFile).then(function (buf) {
      return JSZip.loadAsync(buf);
    }).then(function (zip) {
      var picked = { TEST_SUMMARY: null, SEAL_POS: null, SEAL_NEG: null, WORKSHEET: null };

      zip.forEach(function (relPath, entry) {
        if (!entry || entry.dir) return;
        if (relPath.indexOf('__MACOSX/') === 0) return;

        var base = relPath.split('/').pop();
        if (!base) return;
        if (base.indexOf('._') === 0) return;

        var det = detectTypeByName(base);
        if (!picked[det]) picked[det] = { base: base, entry: entry };
      });

      var out = [];
      var tasks = [];

      function pushPicked(key, mime) {
        if (!picked[key]) return;
        tasks.push(
          picked[key].entry.async('arraybuffer').then(function (ab) {
            out.push(makeFileLike(ab, picked[key].base, mime));
          })
        );
      }

      pushPicked(TYPE_KEYS.SEAL_NEG, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      pushPicked(TYPE_KEYS.SEAL_POS, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      pushPicked(TYPE_KEYS.WORKSHEET, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      pushPicked(TYPE_KEYS.TEST_SUMMARY, 'text/csv');

      return Promise.all(tasks).then(function () { return out; });
    });
  }

  function addFiles(fileList) {
    if (!fileList || !fileList.length) return;

    var incoming = [];
    var tasks = [];

    for (var i = 0; i < fileList.length; i++) {
      var f = fileList[i];
      if (!f) continue;

      if (isZipFile(f)) {
        (function (zipF) {
          setStatus('Reading zip bundle: ' + (zipF.name || 'bundle.zip') + ' ...', false);
          tasks.push(
            extractBundleFilesFromZip(zipF).then(function (extracted) {
              if (extracted && extracted.length) {
                for (var j = 0; j < extracted.length; j++) incoming.push(extracted[j]);
              } else {
                setStatus('Zip did not contain recognizable files: ' + (zipF.name || ''), true);
              }
            }).catch(function (e) {
              var msg = (e && e.message) ? e.message : String(e);
              setStatus('Could not read zip: ' + (zipF.name || '') + ' (' + msg + ')', true);
            })
          );
        })(f);
        continue;
      }

      incoming.push(f);
    }

    Promise.all(tasks).then(function () {
      for (var k = 0; k < incoming.length; k++) {
        var ff = incoming[k];
        var detected = detectTypeByName(ff.name || '');
        files.push({ file: ff, typeKey: TYPE_KEYS.AUTO, detectedKey: detected });
      }

      refreshFileList();
      setStatus('', false);
    });
  }

  function pickByType(typeKey) {
    for (var i = 0; i < files.length; i++) {
      var tk = files[i].typeKey;
      if (tk === TYPE_KEYS.AUTO) tk = files[i].detectedKey;
      if (tk === typeKey) return files[i].file;
    }
    return null;
  }

  // ----------------------------
  // Instrument mapping + Infinity
  // ----------------------------
  var GXINF_MAP = {
    'Infinity-VI': '847922',
    'Infinity-VIII': '803094',
    'GX5': '750210,750211,750212,750213',
    'GX6': '750246,750247,750248,750249',
    'GX1': '709863,709864,709865,709866',
    'GX2': '709951,709952,709953,709954',
    'GX3': '710084,710085,710086,710087',
    'GX7': '750170,750171,750172,750213',
    'Infinity-I': '802069',
    'Infinity-III': '807363',
    'Infinity-V': '839032'
  };

  function buildInstrumentLookup() {
    var lut = {};
    var infinity = {};
    for (var k in GXINF_MAP) if (GXINF_MAP.hasOwnProperty(k)) {
      var parts = String(GXINF_MAP[k]).split(',');
      for (var i = 0; i < parts.length; i++) {
        var code = trim(parts[i]);
        if (!code) continue;
        lut[code] = k;
        if (k.indexOf('Infinity-') === 0) infinity[code] = true;
      }
    }
    return { lookup: lut, infinity: infinity };
  }

  var INSTRUMENT_MAP = buildInstrumentLookup();

  // ----------------------------
  // File cache
  // ----------------------------
  function fileKey(file) {
    return (file.name || '') + '|' + String(file.size || 0) + '|' + String(file.lastModified || 0);
  }

  function readFileAsTextCached(file, cache) {
    var key = fileKey(file);
    var entry = cache[key] || (cache[key] = {});
    if (entry.text !== undefined) return Promise.resolve(entry.text);
    if (entry.textPromise) return entry.textPromise;

    entry.textPromise = new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onload = function () { entry.text = fr.result; resolve(entry.text); };
      fr.onerror = function () { reject(new Error('FileReader error: ' + (file && file.name ? file.name : ''))); };
      fr.readAsText(file);
    });
    return entry.textPromise;
  }

  function readFileAsArrayBufferCached(file, cache) {
    var key = fileKey(file);
    var entry = cache[key] || (cache[key] = {});
    if (entry.arrayBuffer !== undefined) return Promise.resolve(entry.arrayBuffer);
    if (entry.arrayBufferPromise) return entry.arrayBufferPromise;

    entry.arrayBufferPromise = new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onload = function () { entry.arrayBuffer = fr.result; resolve(entry.arrayBuffer); };
      fr.onerror = function () { reject(new Error('FileReader error: ' + (file && file.name ? file.name : ''))); };
      fr.readAsArrayBuffer(file);
    });
    return entry.arrayBufferPromise;
  }

  // ----------------------------
  // XLSX helpers
  // ----------------------------
  function xmlUnescape(s) {
    return (s || '')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'");
  }

  function splitHeaderFooterParts(text) {
    var out = { left: '', center: '', right: '' };
    if (!text) return out;
    var current = 'center';
    var re = /&[LCR]/g;
    var last = 0;
    var m;
    while ((m = re.exec(text)) !== null) {
      var seg = text.slice(last, m.index);
      if (seg) out[current] += seg;
      var code = m[0].charAt(1);
      current = (code === 'L') ? 'left' : (code === 'R' ? 'right' : 'center');
      last = m.index + m[0].length;
    }
    var tail = text.slice(last);
    if (tail) out[current] += tail;

    out.left = normalizeHeaderText(stripHeaderCodes(out.left));
    out.center = normalizeHeaderText(stripHeaderCodes(out.center));
    out.right = normalizeHeaderText(stripHeaderCodes(out.right));
    return out;
  }

  function stripHeaderCodes(s) {
    if (!s) return '';
    s = s.replace(/&\"[^\"]+\"/g, '');
    s = s.replace(/&\d+/g, '');
    s = s.replace(/&[A-Za-z]/g, '');
    return s;
  }

  function parseHeaderFooterXml(xml) {
    var out = { oddHeader: '', evenHeader: '', firstHeader: '', oddFooter: '', evenFooter: '', firstFooter: '' };
    if (!xml) return out;
    var block = /<headerFooter[\s\S]*?<\/headerFooter>/i.exec(xml);
    if (!block) return out;
    block = block[0];

    function pick(tag) {
      var re = new RegExp('<' + tag + '>([\\s\\S]*?)<\\/' + tag + '>', 'i');
      var m = re.exec(block);
      return m ? xmlUnescape(m[1]) : '';
    }

    out.oddHeader = pick('oddHeader');
    out.evenHeader = pick('evenHeader');
    out.firstHeader = pick('firstHeader');
    out.oddFooter = pick('oddFooter');
    out.evenFooter = pick('evenFooter');
    out.firstFooter = pick('firstFooter');
    return out;
  }

  function readHeaderFooterFromArrayBuffer(arrayBuffer) {
    if (typeof JSZip === 'undefined') return Promise.resolve({});

    return JSZip.loadAsync(arrayBuffer).then(function (zip) {
      var wbTask = zip.file('xl/workbook.xml') ? zip.file('xl/workbook.xml').async('string') : Promise.resolve('');
      var relsTask = zip.file('xl/_rels/workbook.xml.rels') ? zip.file('xl/_rels/workbook.xml.rels').async('string') : Promise.resolve('');

      return Promise.all([wbTask, relsTask]).then(function (res) {
        var wbXml = res[0] || '';
        var relsXml = res[1] || '';

        var ridToTarget = {};
        relsXml.replace(/<Relationship\b[^>]*Id="([^"]+)"[^>]*Target="([^"]+)"[^>]*\/?>/g, function (_, id, target) {
          ridToTarget[id] = target;
          return '';
        });

        var sheetDefs = [];
        wbXml.replace(/<sheet\b[^>]*name="([^"]+)"[^>]*r:id="([^"]+)"[^>]*\/?>/g, function (_, name, rid) {
          sheetDefs.push({ name: name, rid: rid });
          return '';
        });

        var map = {};
        var tasks = [];
        for (var i = 0; i < sheetDefs.length; i++) {
          (function (sd) {
            var target = ridToTarget[sd.rid] || '';
            if (!target) return;
            target = target.replace(/^\//, '');
            var path = 'xl/' + target;
            var f = zip.file(path);
            if (!f) return;
            tasks.push(
              f.async('string').then(function (xml) {
                map[sd.name] = parseHeaderFooterXml(xml);
              })
            );
          })(sheetDefs[i]);
        }

        return Promise.all(tasks).then(function () { return map; });
      });
    }).catch(function () {
      return {};
    });
  }

  function readXlsxCached(file, cache) {
    var key = fileKey(file);
    var entry = cache[key] || (cache[key] = {});
    if (entry.xlsx) return Promise.resolve(entry.xlsx);
    if (entry.xlsxPromise) return entry.xlsxPromise;

    entry.xlsxPromise = readFileAsArrayBufferCached(file, cache).then(function (buf) {
      if (typeof XLSX === 'undefined') throw new Error('XLSX library saknas.');
      var wb = XLSX.read(buf, { type: 'array' });
      return readHeaderFooterFromArrayBuffer(buf).then(function (hfMap) {
        entry.xlsx = { workbook: wb, headerFooter: hfMap };
        return entry.xlsx;
      });
    });

    return entry.xlsxPromise;
  }

  function numToCol(n) {
    var s = '';
    while (n > 0) {
      var r = (n - 1) % 26;
      s = String.fromCharCode(65 + r) + s;
      n = Math.floor((n - 1) / 26);
    }
    return s;
  }

  function makeAddr(c, r) {
    if (!c || !r) return '';
    return numToCol(c) + String(r);
  }

  function getSheetCell(sheet, addr) {
    if (!sheet) return '';
    var cell = sheet[addr];
    if (!cell || cell.v === undefined || cell.v === null) return '';
    return cell.v;
  }

  function getSheetText(sheet, addr) {
    var v = getSheetCell(sheet, addr);
    if (v === null || v === undefined) return '';
    return String(v);
  }

  function isDigitStart(s) {
    s = (s || '').toString().trim();
    if (!s) return false;
    var c = s.charAt(0);
    return c >= '0' && c <= '9';
  }

  function findLabelCell(sheet, re, maxR, maxC) {
    maxR = maxR || 30;
    maxC = maxC || 20;
    for (var r = 1; r <= maxR; r++) {
      for (var c = 1; c <= maxC; c++) {
        var addr = makeAddr(c, r);
        var txt = normalizeHeaderText(getSheetText(sheet, addr));
        if (txt && re.test(txt)) return { r: r, c: c };
      }
    }
    return null;
  }

  function valueNear(sheet, labelRe, maxR, maxC) {
    var hit = findLabelCell(sheet, labelRe, maxR, maxC);
    if (!hit) return '';

    var right = normalizeHeaderText(getSheetText(sheet, makeAddr(hit.c + 1, hit.r)));
    if (right && !labelRe.test(right)) return right;

    var down = normalizeHeaderText(getSheetText(sheet, makeAddr(hit.c, hit.r + 1)));
    if (down && !labelRe.test(down)) return down;

    var right2 = normalizeHeaderText(getSheetText(sheet, makeAddr(hit.c + 2, hit.r)));
    if (right2 && !labelRe.test(right2)) return right2;

    var down2 = normalizeHeaderText(getSheetText(sheet, makeAddr(hit.c, hit.r + 2)));
    if (down2 && !labelRe.test(down2)) return down2;

    return '';
  }

  function getHeaderFooterLR(hf) {
    var left = '', right = '';
    var lr;
    if (hf && hf.oddHeader) {
      lr = splitHeaderFooterParts(hf.oddHeader);
      left = lr.left;
      right = lr.right;
    }
    if ((!left || !right) && hf && hf.evenHeader) {
      lr = splitHeaderFooterParts(hf.evenHeader);
      if (!left) left = lr.left;
      if (!right) right = lr.right;
    }
    return { left: left || '', right: right || '' };
  }

  // ----------------------------
  // Rules matching helpers
  // ----------------------------
  function wildcardToRegex(pattern, exact) {
    var esc = pattern.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    esc = esc.replace(/\\\*/g, '.*');
    return new RegExp(exact ? ('^' + esc + '$') : esc, 'i');
  }

  function matchText(text, matchType, pattern) {
    text = String(text || '');
    pattern = String(pattern || '');
    matchType = String(matchType || '').toLowerCase();

    if (!pattern) return false;

    if (matchType === 'regex') {
      try {
        var re = new RegExp(pattern, 'i');
        return re.test(text);
      } catch (e) {
        return false;
      }
    }

    if (matchType === 'exact') {
      return wildcardToRegex(pattern, true).test(text);
    }

    if (matchType === 'prefix') {
      return text.toLowerCase().indexOf(pattern.toLowerCase()) === 0;
    }

    if (matchType === 'suffix') {
      var t = text.toLowerCase();
      var p = pattern.toLowerCase();
      return t.slice(t.length - p.length) === p;
    }

    if (matchType === 'wildcard') {
      return wildcardToRegex(pattern, false).test(text);
    }

    // default: contains
    return wildcardToRegex(pattern, false).test(text);
  }

  function matchPatternAnd(text, matchType, pattern) {
    var parts = pattern.split(';');
    for (var i = 0; i < parts.length; i++) {
      var p = trim(parts[i]);
      if (!p) continue;
      if (!matchText(text, matchType, p)) return false;
    }
    return true;
  }

  function normalizeCall(assay, testResult, rules) {
    var list = (rules && rules.resultCallPatterns) ? rules.resultCallPatterns : [];
    var t = String(testResult || '');

    for (var i = 0; i < list.length; i++) {
      var r = list[i];
      if (r.assay !== '*' && String(assay || '').toLowerCase() !== String(r.assay).toLowerCase()) continue;
      if (matchPatternAnd(t, r.matchType, r.pattern)) return r.call;
    }

    var low = t.toLowerCase();
    if (low.indexOf('not detected') >= 0 || low.indexOf('negative') >= 0) return 'NEG';
    if (low.indexOf('detected') >= 0 || low.indexOf('positive') >= 0) return 'POS';
    if (low.indexOf('invalid') >= 0 || low.indexOf('error') >= 0 || low.indexOf('no result') >= 0 || low.indexOf('indeterminate') >= 0) return 'INDET';
    return 'UNKNOWN';
  }

  function detectSampleMarker(sampleId, markers) {
    var out = { markerType: '', markerNormalized: '' };
    var s = String(sampleId || '');
    var low = s.toLowerCase();

    if (low.indexOf('cartridge replacement') >= 0) {
      out.markerType = 'CartridgeReplacement';
      out.markerNormalized = 'Replacement';
      return out;
    }

    if (low.indexOf('delam') >= 0) {
      out.markerType = 'Delamination';
      out.markerNormalized = 'Delamination';
      return out;
    }

    var tokens = s.split('_');
    if (markers && markers.length) {
      for (var i = 0; i < markers.length; i++) {
        var m = markers[i];
        var idx = m.tokenIndex;
        if (isNaN(idx) || idx < 0 || idx >= tokens.length) continue;
        var tok = tokens[idx];
        if (tok && tok.toLowerCase().indexOf(String(m.marker).toLowerCase()) >= 0) {
          out.markerType = m.markerType || '';
          out.markerNormalized = m.markerType || m.marker || '';
          return out;
        }
      }
    }

    if (low.indexOf('positive control') >= 0 || low.indexOf('pos_') === 0 || low.indexOf('pc') >= 0) {
      out.markerType = 'PositiveControl';
      out.markerNormalized = 'POS';
    } else if (low.indexOf('negative control') >= 0 || low.indexOf('neg_') === 0 || low.indexOf('nc') >= 0) {
      out.markerType = 'NegativeControl';
      out.markerNormalized = 'NEG';
    }

    return out;
  }

  function findExpectedCall(assay, sampleId, rules) {
    var list = (rules && rules.sampleExpectationRules) ? rules.sampleExpectationRules : [];
    for (var i = 0; i < list.length; i++) {
      var r = list[i];
      if (r.assay !== '*' && String(assay || '').toLowerCase() !== String(r.assay).toLowerCase()) continue;
      if (matchText(sampleId, r.matchType, r.samplePattern)) return r;
    }
    return null;
  }

  function parseErrorCode(rowError, testResult, rules) {
    var code = trim(rowError || '');
    var text = String(testResult || '');
    var out = { code: '', name: '', generatesRetest: false };

    if (!code) {
      var m = /\b(\d{4,5})\b/.exec(text);
      if (m) code = m[1];
    }

    if (code) {
      var hit = rules && rules.errorCodes && rules.errorCodes.byCode ? rules.errorCodes.byCode[code] : null;
      if (hit) {
        out.code = code;
        out.name = hit.name || '';
        out.generatesRetest = !!hit.generatesRetest;
        return out;
      }
      out.code = code;
      return out;
    }

    if (rules && rules.errorCodes && rules.errorCodes.fallbacks && rules.errorCodes.fallbacks.length) {
      for (var i = 0; i < rules.errorCodes.fallbacks.length; i++) {
        var fb = rules.errorCodes.fallbacks[i];
        if (fb.name && text.toLowerCase().indexOf(String(fb.name).toLowerCase()) >= 0) {
          out.name = fb.name;
          out.generatesRetest = !!fb.generatesRetest;
          return out;
        }
      }
    }

    return out;
  }

  // ----------------------------
  // Test Summary analyzer
  // ----------------------------
  function findHeaderIndex(headers, regexes) {
    for (var i = 0; i < headers.length; i++) {
      var h = normalizeHeaderText(headers[i] || '').toLowerCase();
      for (var j = 0; j < regexes.length; j++) {
        if (regexes[j].test(h)) return i;
      }
    }
    return -1;
  }

  function analyzeTestSummaryTable(model, headers, rows, meta) {
    meta = meta || {};

    var idxAssay = findHeaderIndex(headers, [/^assay$/i]);
    var idxAssayVer = findHeaderIndex(headers, [/^assay version$/i]);
    var idxSample = findHeaderIndex(headers, [/^sample id$/i]);
    var idxCart = findHeaderIndex(headers, [/^cartridge/i]);
    var idxLot = findHeaderIndex(headers, [/reagent lot id/i]);
    var idxTestType = findHeaderIndex(headers, [/^test type$/i]);
    var idxTestResult = findHeaderIndex(headers, [/^test result$/i]);
    var idxInstr = findHeaderIndex(headers, [/instrument.*s\/?n/i]);
    var idxError = findHeaderIndex(headers, [/^error$/i]);

    var countsSample = {};
    var countsCart = {};
    var normCounts = {};
    var rawResultCounts = {};
    var instrumentTypes = {};
    var lspSet = {};

    var assay = '';
    var assayVer = '';
    var lot = '';

    var testCount = 0;
    var expectationMismatches = [];
    var delamFindings = [];
    var parityFindings = [];
    var missingSamples = null;

    var rowsLite = [];

    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      var sAssay = idxAssay >= 0 && idxAssay < r.length ? r[idxAssay] : '';
      var sAssayVer = idxAssayVer >= 0 && idxAssayVer < r.length ? r[idxAssayVer] : '';
      var sSample = idxSample >= 0 && idxSample < r.length ? r[idxSample] : '';
      var sCart = idxCart >= 0 && idxCart < r.length ? r[idxCart] : '';
      var sLot = idxLot >= 0 && idxLot < r.length ? r[idxLot] : '';
      var sType = idxTestType >= 0 && idxTestType < r.length ? r[idxTestType] : '';
      var sRes = idxTestResult >= 0 && idxTestResult < r.length ? r[idxTestResult] : '';
      var sInstr = idxInstr >= 0 && idxInstr < r.length ? r[idxInstr] : '';
      var sError = idxError >= 0 && idxError < r.length ? r[idxError] : '';

      if (!assay && sAssay) assay = sAssay;
      if (!assayVer && sAssayVer) assayVer = sAssayVer;
      if (!lot && sLot) lot = sLot;

      if (sSample) countsSample[sSample] = (countsSample[sSample] || 0) + 1;
      if (sCart) countsCart[sCart] = (countsCart[sCart] || 0) + 1;
      if (sCart) testCount++;
      if (sRes) rawResultCounts[sRes] = (rawResultCounts[sRes] || 0) + 1;

      // LSP extraction (5 digits)
      var mLsp = String(sLot || '').match(/\b\d{5}\b/g);
      if (mLsp) {
        for (var k = 0; k < mLsp.length; k++) lspSet[mLsp[k]] = true;
      }

      // Instrument type
      var instrKey = trim(String(sInstr || ''));
      if (instrKey) {
        var t = INSTRUMENT_MAP.lookup[instrKey] || 'Unknown';
        instrumentTypes[t] = (instrumentTypes[t] || 0) + 1;
      }

      var normCall = normalizeCall(sAssay, sRes, model.rules.data || {});
      normCounts[normCall] = (normCounts[normCall] || 0) + 1;

      var marker = detectSampleMarker(sSample, model.rules.data.sampleIdMarkers || []);
      if (marker.markerType === 'Delamination') {
        delamFindings.push({ sampleId: sSample, marker: marker.markerType });
      }

      var expectedRule = findExpectedCall(sAssay, sSample, model.rules.data || {});
      var expectedCall = expectedRule ? expectedRule.expected : '';
      if (expectedCall && normCall && normCall !== expectedCall) {
        expectationMismatches.push({
          sampleId: sSample,
          expectedCall: expectedCall,
          normalizedCall: normCall,
          severity: expectedRule.severity || 'WARN'
        });
      }

      var err = parseErrorCode(sError, sRes, model.rules.data || {});

      rowsLite.push({
        assay: sAssay,
        assayVer: sAssayVer,
        lot: sLot,
        sampleId: sSample,
        cartSn: sCart,
        testType: sType,
        testResult: sRes,
        instrumentSn: sInstr,
        errorCode: err.code,
        errorName: err.name,
        generatesRetest: err.generatesRetest,
        normalizedCall: normCall,
        expectedCall: expectedCall,
        markerType: marker.markerType,
        markerNormalized: marker.markerNormalized
      });
    }

    // Missing samples check
    missingSamples = evaluateMissingSamples(rowsLite, model.rules.data.missingSamplesConfig);

    // Parity check
    parityFindings = evaluateParity(rowsLite, model.rules.data.parityConfig);

    var normList = mapToList(normCounts);
    var rawList = mapToList(rawResultCounts);
    var instrList = mapToList(instrumentTypes);

    return {
      ok: true,
      delim: meta.delim || '',
      headerIdx: (typeof meta.headerIdx === 'number') ? meta.headerIdx : -1,
      rowCount: rows.length,
      testCount: testCount,
      assay: assay,
      assayVer: assayVer,
      lot: lot,
      normalizedCounts: normList,
      rawResultCounts: rawList,
      duplicateSamples: pickDuplicates(countsSample),
      duplicateCarts: pickDuplicates(countsCart),
      lspList: Object.keys(lspSet).sort(),
      instrumentTypes: instrList,
      infinitySpPresence: calculateInfinitySpPresence(rowsLite, INSTRUMENT_MAP.infinity),
      expectationMismatches: expectationMismatches,
      delaminationFindings: delamFindings,
      missingSamples: missingSamples,
      parityFindings: parityFindings,
      rows: rowsLite
    };
  }

  function analyzeTestSummaryCsv(model, csvText) {
    var parsed = parseCsvTable(csvText);
    if (!parsed.ok) return parsed;
    return analyzeTestSummaryTable(model, parsed.headers, parsed.rows, { delim: parsed.delim, headerIdx: parsed.headerIdx });
  }

  function analyzeTestSummaryXlsx(model, fileObj) {
    return readXlsxCached(fileObj, model.cache).then(function (xlsx) {
      if (!xlsx || !xlsx.workbook || !xlsx.workbook.SheetNames || !xlsx.workbook.SheetNames.length) {
        return { ok: false, error: 'XLSX: inga sheets hittades.' };
      }
      var sheet = xlsx.workbook.Sheets[xlsx.workbook.SheetNames[0]];
      if (!sheet || !XLSX || !XLSX.utils) return { ok: false, error: 'XLSX: kunde inte lasa sheet.' };

      var rows = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: true });
      var headerIdx = -1;
      for (var i = 0; i < rows.length; i++) {
        var row = rows[i] || [];
        var joined = row.join(' ').toLowerCase();
        if (joined.indexOf('assay') >= 0 && joined.indexOf('sample') >= 0 && (joined.indexOf('cartridge') >= 0 || joined.indexOf('s/n') >= 0)) {
          headerIdx = i;
          break;
        }
      }
      if (headerIdx < 0) return { ok: false, error: 'Kunde inte hitta header-rad i XLSX.' };

      var headers = rows[headerIdx] || [];
      var dataRows = [];
      for (i = headerIdx + 1; i < rows.length; i++) {
        var r = rows[i];
        if (!r || !r.length) continue;
        var any = false;
        for (var c = 0; c < r.length; c++) {
          if (String(r[c] || '').length) { any = true; break; }
        }
        if (!any) continue;
        dataRows.push(r);
      }

      return analyzeTestSummaryTable(model, headers, dataRows, { delim: '', headerIdx: headerIdx });
    }).catch(function (e) {
      return { ok: false, error: (e && e.message) ? e.message : String(e) };
    });
  }

  function mapToList(map) {
    var out = [];
    for (var k in map) if (map.hasOwnProperty(k)) out.push({ value: k, count: map[k] });
    out.sort(function (a, b) { return b.count - a.count; });
    return out;
  }

  function pickDuplicates(map) {
    var out = [];
    for (var k in map) {
      if (!map.hasOwnProperty(k)) continue;
      if (map[k] > 1) out.push({ value: k, count: map[k] });
    }
    out.sort(function (a, b) { return b.count - a.count; });
    return out;
  }

  function calculateInfinitySpPresence(rows, infinitySet) {
    if (!rows || !rows.length) return '—';
    var counts = {};
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      if (!r.instrumentSn || !infinitySet[String(r.instrumentSn).trim()]) continue;
      var m = String(r.sampleId || '').match(/_(\d{2})_/);
      if (!m) continue;
      var n = parseInt(m[1], 10);
      if (isNaN(n) || n < 0 || n > 10) continue;
      counts[n] = (counts[n] || 0) + 1;
    }
    return formatSpPresenceGrandTotal(counts);
  }

  function formatSpPresenceGrandTotal(counts) {
    if (!counts) return '—';
    var present = [];
    var total = 0;
    for (var k in counts) if (counts.hasOwnProperty(k)) {
      if (counts[k] > 0) {
        present.push(parseInt(k, 10));
        total += counts[k];
      }
    }
    if (!present.length) return '—';
    present.sort(function (a, b) { return a - b; });

    var parts = [];
    var i = 0;
    while (i < present.length) {
      var start = present[i];
      var end = start;
      var j = i + 1;
      while (j < present.length && present[j] === end + 1) {
        end = present[j];
        j++;
      }
      if (start === end) parts.push('#' + pad2(start));
      else parts.push('#' + pad2(start) + '-' + pad2(end));
      i = j;
    }

    return parts.join('+') + ' x' + total;
  }

  function evaluateMissingSamples(rows, cfg) {
    if (!cfg || !cfg.rows || !cfg.rows.length) return { ok: true, findings: [] };
    if (!rows || !rows.length) return { ok: true, findings: [] };

    if (cfg.mode === 'list') {
      var sampleSet = {};
      for (var i = 0; i < rows.length; i++) {
        if (rows[i].sampleId) sampleSet[rows[i].sampleId] = true;
      }
      var findings = [];
      for (i = 0; i < cfg.rows.length; i++) {
        var row = cfg.rows[i];
        var required = splitList(row.requiredSamples);
        var allowed = splitList(row.allowedMissing);
        var missing = [];
        for (var j = 0; j < required.length; j++) {
          var s = required[j];
          if (!s) continue;
          if (allowed.indexOf(s) >= 0) continue;
          if (!sampleSet[s]) missing.push(s);
        }
        if (missing.length) findings.push({ name: row.requiredSetName, missing: missing });
      }
      return { ok: true, findings: findings };
    }

    if (cfg.mode === 'bagRange') {
      var map = {}; // bag -> set
      for (i = 0; i < rows.length; i++) {
        var r = rows[i];
        var s = String(r.sampleId || '');
        if (!s) continue;
        var tokens = s.split('_');
        var cfgRow = cfg.rows[0];
        var bagIdx = cfgRow.bagIndex;
        var sampleIdx = cfgRow.sampleTokenIndex;
        if (isNaN(bagIdx) || isNaN(sampleIdx) || bagIdx < 0 || sampleIdx < 0) continue;
        if (bagIdx >= tokens.length || sampleIdx >= tokens.length) continue;
        var bagNum = parseInt(tokens[bagIdx], 10);
        if (isNaN(bagNum)) continue;
        var tok = tokens[sampleIdx] || '';
        var re = new RegExp(cfgRow.sampleNumberRegex || '\\d+');
        var m = re.exec(tok);
        if (!m) continue;
        var sn = parseInt(m[0], 10);
        if (isNaN(sn)) continue;
        if (!map.hasOwnProperty(bagNum)) map[bagNum] = {};
        map[bagNum][sn] = true;
      }

      var findings2 = [];
      for (i = 0; i < cfg.rows.length; i++) {
        var cr = cfg.rows[i];
        var allowedRaw = splitList(cr.allowedMissing);
        var allowedSet = {};
        for (var a = 0; a < allowedRaw.length; a++) {
          var num = parseInt(allowedRaw[a], 10);
          if (!isNaN(num)) allowedSet[num] = true;
        }
        if (isNaN(cr.bagMin) || isNaN(cr.bagMax)) continue;
        for (var b = cr.bagMin; b <= cr.bagMax; b++) {
          var rangeMin = (b === 0) ? cr.bag0SampleMin : cr.otherBagSampleMin;
          var rangeMax = (b === 0) ? cr.bag0SampleMax : cr.otherBagSampleMax;
          if (isNaN(rangeMin) || isNaN(rangeMax)) continue;
          var missingList = [];
          for (var snum = rangeMin; snum <= rangeMax; snum++) {
            if (allowedSet[snum]) continue;
            if (!map[b] || !map[b][snum]) {
              var lbl = (cr.sampleNumberPad && cr.sampleNumberPad > 0) ? padNumber(snum, cr.sampleNumberPad) : String(snum);
              missingList.push(lbl);
            }
          }
          if (missingList.length) {
            findings2.push({
              name: 'Bag ' + pad2(b),
              missing: missingList
            });
          }
        }
      }
      return { ok: true, findings: findings2 };
    }

    return { ok: true, findings: [] };
  }

  function evaluateParity(rows, cfg) {
    if (!cfg || !cfg.rows || !cfg.rows.length) return [];
    if (!rows || !rows.length) return [];

    if (cfg.mode === 'token') {
      var rule = cfg.rows[0];
      var tokenIndex = rule.tokenIndex;
      var xChar = rule.xChar || 'X';
      var plusChar = rule.plusChar || '+';
      var withMarkers = [];

      for (var i = 0; i < rows.length; i++) {
        var s = String(rows[i].sampleId || '');
        var tokens = s.split('_');
        if (tokenIndex < 0 || tokenIndex >= tokens.length) continue;
        var token = tokens[tokenIndex];
        if (!token) continue;
        var marker = '';
        if (token.indexOf(xChar) >= 0) marker = xChar;
        else if (token.indexOf(plusChar) >= 0) marker = plusChar;
        if (!marker) continue;
        var cart = parseInt(String(rows[i].cartSn || '').replace(/\D/g, ''), 10);
        if (isNaN(cart)) continue;
        withMarkers.push({ sampleId: s, cartSn: cart, marker: marker });
      }

      if (!withMarkers.length) return [];

      withMarkers.sort(function (a, b) { return a.cartSn - b.cartSn; });
      var baseline = withMarkers[0].marker || xChar;
      var other = (baseline === xChar) ? plusChar : xChar;
      var minCart = withMarkers[0].cartSn;
      var findings = [];

      for (i = 0; i < withMarkers.length; i++) {
        var row = withMarkers[i];
        var expected = ((row.cartSn - minCart) % 2 === 0) ? baseline : other;
        if (row.marker !== expected) {
          findings.push({
            sampleId: row.sampleId,
            cartSn: row.cartSn,
            expectedMarker: expected,
            actualMarker: row.marker,
            severity: 'WARN'
          });
        }
      }

      return findings;
    }

    if (cfg.mode === 'config') {
      // Minimal support: SampleID_CartridgeSN_Parity (duplicate/mismatch)
      var findings2 = [];
      var sampleToCart = {};
      var cartToSample = {};
      for (var j = 0; j < rows.length; j++) {
        var sId = rows[j].sampleId || '';
        var cSn = rows[j].cartSn || '';
        if (sId && cSn) {
          if (!sampleToCart[sId]) sampleToCart[sId] = {};
          sampleToCart[sId][cSn] = true;
          if (!cartToSample[cSn]) cartToSample[cSn] = {};
          cartToSample[cSn][sId] = true;
        }
      }
      for (var sid in sampleToCart) if (sampleToCart.hasOwnProperty(sid)) {
        var carts = Object.keys(sampleToCart[sid]);
        if (carts.length > 1) {
          findings2.push({ sampleId: sid, detail: 'Sample ID kopplad till flera Cartridge S/N', severity: 'WARN' });
        }
      }
      for (var csn in cartToSample) if (cartToSample.hasOwnProperty(csn)) {
        var sams = Object.keys(cartToSample[csn]);
        if (sams.length > 1) {
          findings2.push({ sampleId: sams.join(', '), detail: 'Cartridge S/N kopplad till flera Sample ID: ' + csn, severity: 'WARN' });
        }
      }
      return findings2;
    }

    return [];
  }

  function splitList(text) {
    if (!text) return [];
    var parts = String(text).split(/[,;]+/);
    var out = [];
    for (var i = 0; i < parts.length; i++) {
      var p = trim(parts[i]);
      if (p) out.push(p);
    }
    return out;
  }

  // ----------------------------
  // Seal Test analysis
  // ----------------------------
  function readSealHeader(sheet, hfInfo) {
    var hf = getHeaderFooterLR(hfInfo);
    var doc = '';
    var rev = '';
    var eff = '';

    var text = hf.right || hf.left;
    if (text) {
      var m = /\bDocument\s*(?:No|Number|#)\s*[:#]?\s*(D\d+)\b/i.exec(text);
      if (m) doc = m[1];
      m = /\bRev(?:ision)?\.?\s*[:#]?\s*([A-Z]{1,3}(?:\.\d+)?)\b/i.exec(text);
      if (m) rev = m[1];
      m = /\bEffective\s*[:#]?\s*([0-9]{1,2}[\/\-][0-9]{1,2}[\/\-][0-9]{4}|[0-9]{4}[\/\-][0-9]{2}[\/\-][0-9]{2})/i.exec(text);
      if (m) eff = m[1];
    }

    if (!eff) {
      var eff2 = tryParseHeaderDate(text);
      if (eff2) eff = eff2;
    }

    var batch = '';
    var d2 = normalizeHeaderText(getSheetText(sheet, 'D2'));
    if (d2) {
      if (/batch/i.test(d2)) {
        batch = normalizeHeaderText(getSheetText(sheet, 'E2')) || normalizeHeaderText(getSheetText(sheet, 'D3'));
      } else if (/\b\d{10}\b/.test(d2)) {
        batch = d2;
      }
    }
    if (!batch) batch = valueNear(sheet, /^Batch\s*Number/i, 20, 10);

    if (!doc) doc = valueNear(sheet, /^Document\s*(?:No|Number|#)/i, 20, 10);
    if (!rev) rev = valueNear(sheet, /^Rev(?:ision)?/i, 20, 10);
    if (!eff) {
      var effCell = valueNear(sheet, /^Effective/i, 20, 10);
      eff = tryParseHeaderDate(effCell) || effCell;
    }

    return {
      BatchNumber: batch,
      PartNumber: valueNear(sheet, /^Part\s*Number\b/i, 20, 10),
      CartridgeLsp: valueNear(sheet, /(Cartridge.*\(LSP\)|Cartridge\s*LSP|Cartridge\s*No\.?\s*\(LSP\)|Cartridge\s*Number)/i, 20, 10),
      DocumentNumber: doc,
      Rev: rev,
      Effective: eff
    };
  }

  function collectSignaturesFromSheets(sheetNames, workbook) {
    var sigs = {};
    var startAt = 1; // 2..N (index 1)

    for (var i = startAt; i < sheetNames.length; i++) {
      var name = sheetNames[i];
      if (name === 'Worksheet Instructions' || name === 'Test Summary') continue;
      var sheet = workbook.Sheets[name];
      if (!sheet) continue;
      var h3 = normalizeHeaderText(getSheetText(sheet, 'H3'));
      if (!h3 || h3.toLowerCase() === 'n/a') break;
      if (!isDigitStart(h3)) continue;
      var sig = normalizeHeaderText(getSheetText(sheet, 'B47'));
      if (sig) sigs[sig.toUpperCase()] = true;
    }

    return Object.keys(sigs).sort();
  }

  function analyzeSealTestXlsx(model, fileObj, kind) {
    return readXlsxCached(fileObj, model.cache).then(function (xlsx) {
      var wb = xlsx.workbook;
      var sheetNames = wb.SheetNames || [];
      var dataSheets = [];

      for (var i = 0; i < sheetNames.length; i++) {
        var n = sheetNames[i];
        if (n === 'Worksheet Instructions') continue;
        var sh = wb.Sheets[n];
        if (!sh) continue;
        if (isDigitStart(getSheetText(sh, 'H3'))) dataSheets.push(n);
      }

      var header = null;
      if (dataSheets.length) {
        var firstSheet = wb.Sheets[dataSheets[0]];
        header = readSealHeader(firstSheet, xlsx.headerFooter[dataSheets[0]]);
      }

      var signatures = collectSignaturesFromSheets(sheetNames, wb);

      var violations = [];
      for (i = 0; i < dataSheets.length; i++) {
        var sName = dataSheets[i];
        var s = wb.Sheets[sName];
        if (!s) continue;
        for (var r = 3; r <= 45; r++) {
          var avgVal = parseNumberLoose(getSheetCell(s, 'K' + r));
          var status = normalizeHeaderText(getSheetText(s, 'L' + r)).toUpperCase();
          var bad = false;
          var reason = '';
          if (status === 'FAIL') { bad = true; reason = 'FAIL'; }
          if (avgVal !== null && avgVal <= -3) { bad = true; reason = reason || 'MinusValue<=-3'; }
          if (!bad) continue;
          violations.push({
            sheet: sName,
            row: r,
            status: status || '',
            avg: (avgVal !== null ? avgVal : ''),
            observation: getSheetText(s, 'M' + r) || ''
          });
        }
      }

      return {
        ok: true,
        kind: kind,
        fileName: fileObj.name,
        sheetCount: sheetNames.length,
        dataSheetCount: dataSheets.length,
        header: header,
        signatures: signatures,
        violations: violations
      };
    }).catch(function (e) {
      return { ok: false, error: (e && e.message) ? e.message : String(e) };
    });
  }

  // ----------------------------
  // Worksheet analysis
  // ----------------------------
  function worksheetHeaderFromHeaderFooter(lr, kind) {
    var left = lr.left || '';
    var right = lr.right || '';
    var has = false, val = '';

    function pick(re) {
      var m = re.exec(right);
      if (m) return m[1];
      m = re.exec(left);
      if (m) return m[1];
      return '';
    }

    if (kind === 'Part') {
      val = pick(/\bPart\s*(?:No|Number)\b[^0-9]*(\d{3}-\d{4})/i);
      if (val) has = true;
    } else if (kind === 'Batch') {
      val = pick(/\bBatch\s*(?:No|Number|No\(s\)|Number\(s\))\b[^0-9]*(\d{10})/i);
      if (val) has = true;
      if (!has && (left.match(/\bBatch\b/i) || right.match(/\bBatch\b/i))) has = true;
    } else if (kind === 'Cartridge') {
      var t = pick(/\bCartridge\b[^\r\n]*/i);
      if (t) {
        has = true;
        var m = /\b(\d{5})\b/.exec(t);
        if (m) val = m[1];
      }
    } else if (kind === 'Doc') {
      val = pick(/\bDocument\s*(?:No|Number|#)\b[^\r\n]*(D\d+)/i);
      if (val) has = true;
    } else if (kind === 'REV') {
      val = pick(/\bRev(?:ision)?\b[^\r\n]*([A-Z]{1,3}(?:\.\d+)?)/i);
      if (val) has = true;
    } else if (kind === 'EFF') {
      if (left.match(/\bEffective(\s*Date)?\b/i) || right.match(/\bEffective(\s*Date)?\b/i)) has = true;
      var dt = tryParseHeaderDate(left) || tryParseHeaderDate(right);
      if (dt) val = dt;
    }

    return { has: has, val: val };
  }

  function worksheetHeaderFromCells(sheet, labelRe, maxR, maxC, canon) {
    var hit = findLabelCell(sheet, labelRe, maxR, maxC);
    var has = false, val = '';
    if (hit) {
      has = true;
      var right = normalizeHeaderText(getSheetText(sheet, makeAddr(hit.c + 1, hit.r)));
      var down = normalizeHeaderText(getSheetText(sheet, makeAddr(hit.c, hit.r + 1)));
      val = right || down || '';
      if (canon === 'Cartridge' && val) {
        var m = /\b(\d{5})\b/.exec(val);
        if (m) val = m[1];
      }
      if (canon === 'EFF' && val) {
        var dt = tryParseHeaderDate(val);
        if (dt) val = dt;
      }
    }
    return { has: has, val: val };
  }

  function getWorksheetHeaderPerSheet(workbook, headerFooterMap) {
    var rows = [];
    var names = workbook.SheetNames || [];
    var rxPart = /^\s*Part\s*(?:No|Number)\.?\s*(?:\(s\))?\s*$/i;
    var rxBatch = /^\s*Batch\s*(?:No|Number)(?:\s*\(s\))?\.?\s*$/i;
    var rxCartridge = /^\s*Cartridge\s*(?:No|Number)?\s*(?:\(?LSP\)?)?\.?\s*$/i;
    var rxDoc = /^\s*Document\s*(?:No|Number|#)\s*$/i;
    var rxRev = /^\s*Rev(?:ision)?\.?\s*$/i;
    var rxEff = /^\s*Effective(?:\s*Date)?\s*$/i;

    for (var i = 0; i < names.length; i++) {
      var name = names[i];
      if (name === 'Worksheet Instructions' || name === 'Test Summary') continue;
      var sheet = workbook.Sheets[name];
      if (!sheet) continue;

      var lr = getHeaderFooterLR(headerFooterMap[name] || {});
      var partLabel = false, batchLabel = false, cartLabel = false, docLabel = false, revLabel = false, effLabel = false;
      var part = '', batch = '', cart = '', doc = '', rev = '', eff = '';

      var r1 = worksheetHeaderFromHeaderFooter(lr, 'Part'); partLabel = partLabel || r1.has; if (r1.val) part = r1.val;
      var r2 = worksheetHeaderFromHeaderFooter(lr, 'Batch'); batchLabel = batchLabel || r2.has; if (r2.val) batch = r2.val;
      var r3 = worksheetHeaderFromHeaderFooter(lr, 'Cartridge'); cartLabel = cartLabel || r3.has; if (r3.val) cart = r3.val;
      var r4 = worksheetHeaderFromHeaderFooter(lr, 'Doc'); docLabel = docLabel || r4.has; if (r4.val) doc = r4.val;
      var r5 = worksheetHeaderFromHeaderFooter(lr, 'REV'); revLabel = revLabel || r5.has; if (r5.val) rev = r5.val;
      var r6 = worksheetHeaderFromHeaderFooter(lr, 'EFF'); effLabel = effLabel || r6.has; if (r6.val) eff = r6.val;

      if (!part) { var c1 = worksheetHeaderFromCells(sheet, rxPart, 30, 20, 'Part'); partLabel = partLabel || c1.has; if (c1.val) part = c1.val; }
      if (!batch) { var c2 = worksheetHeaderFromCells(sheet, rxBatch, 30, 20, 'Batch'); batchLabel = batchLabel || c2.has; if (c2.val) batch = c2.val; }
      if (!cart) { var c3 = worksheetHeaderFromCells(sheet, rxCartridge, 30, 20, 'Cartridge'); cartLabel = cartLabel || c3.has; if (c3.val) cart = c3.val; }
      if (!doc) { var c4 = worksheetHeaderFromCells(sheet, rxDoc, 30, 20, 'Doc'); docLabel = docLabel || c4.has; if (c4.val) doc = c4.val; }
      if (!rev) { var c5 = worksheetHeaderFromCells(sheet, rxRev, 30, 20, 'REV'); revLabel = revLabel || c5.has; if (c5.val) rev = c5.val; }
      if (!eff) { var c6 = worksheetHeaderFromCells(sheet, rxEff, 30, 20, 'EFF'); effLabel = effLabel || c6.has; if (c6.val) eff = c6.val; }

      rows.push({
        Sheet: name,
        PartNo: part,
        BatchNo: batch,
        CartridgeNo: cart,
        DocumentNumber: doc,
        Rev: rev,
        Effective: eff,
        HasPartNoLabel: partLabel,
        HasBatchNoLabel: batchLabel,
        HasCartridgeLabel: cartLabel,
        HasDocumentLabel: docLabel,
        HasRevLabel: revLabel,
        HasEffectiveLabel: effLabel
      });
    }

    return rows;
  }

  function canonHeaderValue(raw, type) {
    if (!raw) return '';
    var txt = normalizeHeaderText(raw);
    var m;
    if (type === 'Part') { m = /\b(\d{3}-\d{4})\b/.exec(txt); return m ? m[1] : txt.toUpperCase(); }
    if (type === 'Batch') { m = /\b(\d{10})\b/.exec(txt); return m ? m[1] : txt.toUpperCase(); }
    if (type === 'Cartridge') { m = /\b(\d{5})\b/.exec(txt); return m ? m[1] : txt.toUpperCase(); }
    if (type === 'Doc') { m = /\b(D\d+)\b/i.exec(txt); return m ? m[1].toUpperCase() : txt.toUpperCase(); }
    if (type === 'REV') return txt.toUpperCase();
    if (type === 'EFF') { var dt = tryParseHeaderDate(txt); return dt || txt; }
    return txt;
  }

  function compareWorksheetHeaderSet(rows) {
    var devIssues = 0;
    var reqIssues = 0;
    var details = [];

    var keys = [
      { k: 'PartNo', t: 'Part', req: true, label: 'HasPartNoLabel' },
      { k: 'BatchNo', t: 'Batch', req: true, label: 'HasBatchNoLabel' },
      { k: 'CartridgeNo', t: 'Cartridge', req: true, label: 'HasCartridgeLabel' },
      { k: 'DocumentNumber', t: 'Doc', req: false, label: 'HasDocumentLabel' },
      { k: 'Rev', t: 'REV', req: false, label: 'HasRevLabel' },
      { k: 'Effective', t: 'EFF', req: false, label: 'HasEffectiveLabel' }
    ];

    for (var i = 0; i < keys.length; i++) {
      var entry = keys[i];
      var vals = [];
      for (var r = 0; r < rows.length; r++) {
        var row = rows[r];
        vals.push({
          Sheet: row.Sheet,
          Canon: canonHeaderValue(row[entry.k], entry.t),
          Raw: row[entry.k] || '',
          HasLbl: !!row[entry.label]
        });
      }

      var nonEmpty = [];
      for (r = 0; r < vals.length; r++) if (vals[r].Canon) nonEmpty.push(vals[r]);
      var useSet = nonEmpty.length ? nonEmpty : vals;
      var counts = {};
      for (r = 0; r < useSet.length; r++) {
        var cval = useSet[r].Canon || '';
        counts[cval] = (counts[cval] || 0) + 1;
      }
      var major = '';
      var max = 0;
      for (var c in counts) if (counts.hasOwnProperty(c)) {
        if (counts[c] > max) { max = counts[c]; major = c; }
      }

      var deviants = [];
      if (major) {
        for (r = 0; r < vals.length; r++) {
          if (vals[r].Canon && vals[r].Canon !== major) deviants.push(vals[r].Sheet);
        }
      }

      if (deviants.length) {
        devIssues++;
        details.push('- ' + entry.k + ' majoritet=\'' + major + '\' | avvikande flikar: ' + deviants.join(', '));
      }

      if (entry.req) {
        var missingSheets = [];
        for (r = 0; r < vals.length; r++) {
          if (vals[r].HasLbl && !vals[r].Canon) missingSheets.push(vals[r].Sheet);
        }
        if (missingSheets.length) {
          reqIssues++;
          details.push('*Saknas* - ' + entry.k + ' ' + missingSheets.join(', '));
        }
      }
    }

    var total = devIssues + reqIssues;
    var summary = (total === 0) ? 'OK' : ('Avvikelser: ' + total + ' (avvikare=' + devIssues + ', saknas=' + reqIssues + ')');

    return { Issues: total, Summary: summary, Details: details.join('\n') };
  }

  function majorityValue(rows, key, type) {
    if (!rows || !rows.length) return '';
    var counts = {};
    for (var i = 0; i < rows.length; i++) {
      var v = canonHeaderValue(rows[i][key], type);
      if (!v) continue;
      counts[v] = (counts[v] || 0) + 1;
    }
    var major = '';
    var max = 0;
    for (var k in counts) if (counts.hasOwnProperty(k)) {
      if (counts[k] > max) { max = counts[k]; major = k; }
    }
    if (!major) return '';

    for (i = 0; i < rows.length; i++) {
      var raw = rows[i][key];
      if (raw && canonHeaderValue(raw, type) === major) return raw;
    }
    return major;
  }

  function analyzeWorksheetXlsx(model, fileObj) {
    return readXlsxCached(fileObj, model.cache).then(function (xlsx) {
      var wb = xlsx.workbook;
      var names = wb.SheetNames || [];
      var headerRows = getWorksheetHeaderPerSheet(wb, xlsx.headerFooter);
      if (!headerRows.length) return { ok: false, error: 'Worksheet: inga sheets hittades' };

      var headerCheck = compareWorksheetHeaderSet(headerRows);
      var signatures = collectSignaturesFromSheets(names, wb);

      return {
        ok: true,
        fileName: fileObj.name,
        sheetCount: names.length,
        headerRows: headerRows,
        headerCheck: headerCheck,
        signatures: signatures,
        majority: {
          PartNo: majorityValue(headerRows, 'PartNo', 'Part'),
          BatchNo: majorityValue(headerRows, 'BatchNo', 'Batch'),
          CartridgeNo: majorityValue(headerRows, 'CartridgeNo', 'Cartridge')
        }
      };
    }).catch(function (e) {
      return { ok: false, error: (e && e.message) ? e.message : String(e) };
    });
  }

  // ----------------------------
  // Consensus
  // ----------------------------
  function getConsensusValue(ws, pos, neg, type) {
    var nWs = normalizeId(ws, type);
    var nPos = normalizeId(pos, type);
    var nNeg = normalizeId(neg, type);

    var present = {};
    if (nWs) present.WS = nWs;
    if (nPos) present.POS = nPos;
    if (nNeg) present.NEG = nNeg;

    var chosen = '';
    var sources = [];

    // Majority
    var counts = {};
    for (var k in present) if (present.hasOwnProperty(k)) {
      counts[present[k]] = (counts[present[k]] || 0) + 1;
    }
    var max = 0, maxVal = '';
    for (k in counts) if (counts.hasOwnProperty(k)) {
      if (counts[k] > max) { max = counts[k]; maxVal = k; }
    }
    if (max >= 2) {
      chosen = maxVal;
      for (k in present) if (present.hasOwnProperty(k)) {
        if (present[k] === chosen) sources.push(k);
      }
    }

    // WS matches one of POS/NEG
    if (!chosen && nWs) {
      var posMatch = (nPos && nPos === nWs);
      var negMatch = (nNeg && nNeg === nWs);
      if ((posMatch && !negMatch) || (negMatch && !posMatch)) {
        chosen = nWs;
        sources = ['WS'];
        if (posMatch) sources.push('POS');
        if (negMatch) sources.push('NEG');
      }
    }

    // POS == NEG
    if (!chosen && nPos && nNeg && nPos === nNeg) {
      chosen = nPos;
      sources = ['POS', 'NEG'];
    }

    // fallback priority
    if (!chosen) {
      if (nWs) { chosen = nWs; sources = ['WS']; }
      else if (nPos) { chosen = nPos; sources = ['POS']; }
      else if (nNeg) { chosen = nNeg; sources = ['NEG']; }
    }

    var orig = { WS: ws, POS: pos, NEG: neg };
    var pretty = '';
    for (var i = 0; i < sources.length; i++) {
      var src = sources[i];
      if (orig[src]) { pretty = orig[src]; break; }
    }

    var note = '';
    if (sources.length) {
      note = 'Consensus: ' + sources.join('+');
      var others = [];
      var keys = ['WS', 'POS', 'NEG'];
      for (i = 0; i < keys.length; i++) {
        var kk = keys[i];
        if (present.hasOwnProperty(kk) && sources.indexOf(kk) < 0) {
          if (orig[kk]) others.push(kk + '=' + orig[kk]);
        }
      }
      if (others.length) note += ' | Others: ' + others.join(', ');
    }

    return { Value: pretty, Source: sources.join('+'), Note: note };
  }

  // ----------------------------
  // Render results
  // ----------------------------
  function renderTable(columns, rows, rowToCells) {
    var tbl = el('table');
    var thead = el('thead');
    var trh = el('tr');
    for (var c = 0; c < columns.length; c++) trh.appendChild(el('th', { text: columns[c] }));
    thead.appendChild(trh);
    tbl.appendChild(thead);

    var tbody = el('tbody');
    for (var r = 0; r < rows.length; r++) {
      var tr = el('tr');
      var cells = rowToCells(rows[r]);
      for (var k = 0; k < cells.length; k++) tr.appendChild(el('td', { text: cells[k] }));
      tbody.appendChild(tr);
    }
    tbl.appendChild(tbody);
    return tbl;
  }

  function renderRulesStatus(out, rules) {
    var card = el('div', { 'class': 'card' });
    card.appendChild(el('h3', { text: 'Rules loaded' }));

    if (!rules.ok) {
      card.appendChild(el('div', { 'class': 'small err', text: 'Rules bundle fel: ' + rules.errors.join('; ') }));
      out.appendChild(card);
      return;
    }
    card.appendChild(el('div', { 'class': 'small muted', text: 'Status: OK' }));

    var list = [];
    for (var k in rules.counts) if (rules.counts.hasOwnProperty(k)) {
      list.push({ name: k, count: rules.counts[k] });
    }
    list.sort(function (a, b) { return a.name.localeCompare(b.name); });

    card.appendChild(renderTable(
      ['Rulesheet', 'Count'],
      list,
      function (r) { return [r.name, String(r.count)]; }
    ));

    out.appendChild(card);
  }

  function renderResults(model) {
    var out = $('results');
    clearNode(out);

    if (!model || !model.testSummary || !model.testSummary.ok) {
      out.appendChild(el('div', { 'class': 'small err', text: 'Ingen data att visa.' }));
      return;
    }

    renderRulesStatus(out, model.rules);

    var csv = model.testSummary;

    // Overview
    var top = el('div', { 'class': 'card' });
    top.appendChild(el('h3', { text: 'Test Summary - Overview' }));
    var pills = el('div');
    pills.appendChild(pill('Rows: ' + csv.rowCount, 'ok'));
    pills.appendChild(pill('TestCount: ' + csv.testCount, 'ok'));
    if (csv.assay) pills.appendChild(pill('Assay: ' + csv.assay, 'ok'));
    if (csv.assayVer) pills.appendChild(pill('Ver: ' + csv.assayVer, 'ok'));
    if (csv.lot) pills.appendChild(pill('Lot: ' + csv.lot, 'ok'));

    pills.appendChild(pill('Infinity SP: ' + (csv.infinitySpPresence || '—'), 'ok'));
    pills.appendChild(pill('LSP unique: ' + (csv.lspList ? csv.lspList.length : 0), 'ok'));

    top.appendChild(pills);
    top.appendChild(el('div', { 'class': 'small muted', text: 'Delimiter: ' + csv.delim + ' | Header rad: ' + (csv.headerIdx + 1) }));
    out.appendChild(top);

    // Normalized calls
    var secCalls = el('div', { 'class': 'card' });
    secCalls.appendChild(el('h3', { text: 'Normalized calls' }));
    if (!csv.normalizedCounts || !csv.normalizedCounts.length) {
      secCalls.appendChild(el('div', { 'class': 'small muted', text: 'Inga normalized calls att visa.' }));
    } else {
      secCalls.appendChild(renderTable(
        ['Normalized Call', 'Count'],
        csv.normalizedCounts,
        function (r) { return [r.value, String(r.count)]; }
      ));
    }
    out.appendChild(secCalls);

    // Sample expectation mismatches
    var secExp = el('div', { 'class': 'card' });
    secExp.appendChild(el('h3', { text: 'Expected vs Normalized' }));
    if (!csv.expectationMismatches || !csv.expectationMismatches.length) {
      secExp.appendChild(el('div', { 'class': 'small muted', text: 'Inga avvikelser mot expected rules.' }));
    } else {
      secExp.appendChild(renderTable(
        ['Sample ID', 'Expected', 'Normalized', 'Severity'],
        csv.expectationMismatches,
        function (r) { return [r.sampleId, r.expectedCall, r.normalizedCall, r.severity]; }
      ));
    }
    out.appendChild(secExp);

    // Duplicates
    var secDup = el('div', { 'class': 'card' });
    secDup.appendChild(el('h3', { text: 'Duplicates' }));
    if ((!csv.duplicateSamples || !csv.duplicateSamples.length) && (!csv.duplicateCarts || !csv.duplicateCarts.length)) {
      secDup.appendChild(el('div', { 'class': 'small muted', text: 'Inga dubletter hittades.' }));
    } else {
      if (csv.duplicateSamples && csv.duplicateSamples.length) {
        secDup.appendChild(el('div', { 'class': 'small', text: 'Sample ID (>' + 1 + '):' }));
        secDup.appendChild(renderTable(['Sample ID', 'Count'], csv.duplicateSamples, function (x) { return [x.value, String(x.count)]; }));
      }
      if (csv.duplicateCarts && csv.duplicateCarts.length) {
        secDup.appendChild(el('div', { 'class': 'small', text: 'Cartridge S/N (>' + 1 + '):' }));
        secDup.appendChild(renderTable(['Cartridge S/N', 'Count'], csv.duplicateCarts, function (x) { return [x.value, String(x.count)]; }));
      }
    }
    out.appendChild(secDup);

    // Instrument types + LSP
    var secInstr = el('div', { 'class': 'card' });
    secInstr.appendChild(el('h3', { text: 'Instrument types + LSP' }));
    if (!csv.instrumentTypes || !csv.instrumentTypes.length) {
      secInstr.appendChild(el('div', { 'class': 'small muted', text: 'Ingen instrumentdata hittades.' }));
    } else {
      secInstr.appendChild(renderTable(
        ['Instrument Type', 'Count'],
        csv.instrumentTypes,
        function (r) { return [r.value, String(r.count)]; }
      ));
    }
    secInstr.appendChild(el('div', { 'class': 'small muted', text: 'LSP list: ' + (csv.lspList && csv.lspList.length ? csv.lspList.join(', ') : '—') }));
    out.appendChild(secInstr);

    // Missing samples + parity
    var secChecks = el('div', { 'class': 'card' });
    secChecks.appendChild(el('h3', { text: 'Missing samples + parity' }));

    if (csv.missingSamples && csv.missingSamples.findings && csv.missingSamples.findings.length) {
      secChecks.appendChild(el('div', { 'class': 'small', text: 'Missing samples:' }));
      secChecks.appendChild(renderTable(
        ['Group', 'Missing'],
        csv.missingSamples.findings,
        function (r) { return [r.name, r.missing.join(', ')]; }
      ));
    } else {
      secChecks.appendChild(el('div', { 'class': 'small muted', text: 'Inga saknade samples enligt config.' }));
    }

    if (csv.parityFindings && csv.parityFindings.length) {
      secChecks.appendChild(el('div', { 'class': 'small', text: 'Parity findings:' }));
      secChecks.appendChild(renderTable(
        ['Sample ID', 'Cartridge S/N', 'Expected', 'Actual', 'Severity'],
        csv.parityFindings,
        function (r) { return [r.sampleId || '', String(r.cartSn || ''), r.expectedMarker || r.detail || '', r.actualMarker || '', r.severity || 'WARN']; }
      ));
    } else {
      secChecks.appendChild(el('div', { 'class': 'small muted', text: 'Inga parity findings.' }));
    }
    out.appendChild(secChecks);

    // Seal POS
    out.appendChild(renderSealCard(model.sealPos, 'Seal Test POS'));
    // Seal NEG
    out.appendChild(renderSealCard(model.sealNeg, 'Seal Test NEG'));

    // Worksheet
    out.appendChild(renderWorksheetCard(model.worksheet));

    // Consensus
    if (model.consensus) {
      var secCons = el('div', { 'class': 'card' });
      secCons.appendChild(el('h3', { text: 'Cross-file consensus' }));
      var consRows = [
        { name: 'Batch', data: model.consensus.batch },
        { name: 'Part', data: model.consensus.part },
        { name: 'Cartridge', data: model.consensus.cartridge }
      ];
      secCons.appendChild(renderTable(
        ['Field', 'Value', 'Source', 'Note'],
        consRows,
        function (r) { return [r.name, safeText(r.data.Value), safeText(r.data.Source), safeText(r.data.Note)]; }
      ));
      out.appendChild(secCons);
    }
  }

  function renderSealCard(data, title) {
    var card = el('div', { 'class': 'card' });
    card.appendChild(el('h3', { text: title }));

    if (!data || !data.ok) {
      card.appendChild(el('div', { 'class': 'small muted', text: 'Ingen fil vald.' }));
      return card;
    }

    card.appendChild(el('div', { 'class': 'small muted', text: 'File: ' + data.fileName + ' | Sheets: ' + data.sheetCount + ' | Data sheets: ' + data.dataSheetCount }));

    if (data.header) {
      card.appendChild(renderTable(
        ['Batch', 'Part', 'Cartridge', 'Doc', 'Rev', 'Effective'],
        [data.header],
        function (h) {
          return [safeText(h.BatchNumber), safeText(h.PartNumber), safeText(h.CartridgeLsp), safeText(h.DocumentNumber), safeText(h.Rev), safeText(h.Effective)];
        }
      ));
    }

    if (data.signatures && data.signatures.length) {
      card.appendChild(el('div', { 'class': 'small muted', text: 'Signatures: ' + data.signatures.join(', ') }));
    } else {
      card.appendChild(el('div', { 'class': 'small muted', text: 'Signatures: —' }));
    }

    if (data.violations && data.violations.length) {
      card.appendChild(el('div', { 'class': 'small', text: 'Fail / minus value findings: ' + data.violations.length }));
      card.appendChild(renderTable(
        ['Sheet', 'Row', 'Status', 'Avg', 'Observation'],
        data.violations.slice(0, 20),
        function (v) { return [v.sheet, String(v.row), v.status, String(v.avg), v.observation]; }
      ));
      if (data.violations.length > 20) {
        card.appendChild(el('div', { 'class': 'small muted', text: 'Visar 20 av ' + data.violations.length + ' rader.' }));
      }
    } else {
      card.appendChild(el('div', { 'class': 'small muted', text: 'Fail / minus value findings: 0' }));
    }

    return card;
  }

  function renderWorksheetCard(data) {
    var card = el('div', { 'class': 'card' });
    card.appendChild(el('h3', { text: 'Worksheet' }));

    if (!data || !data.ok) {
      card.appendChild(el('div', { 'class': 'small muted', text: 'Ingen fil vald.' }));
      return card;
    }

    card.appendChild(el('div', { 'class': 'small muted', text: 'File: ' + data.fileName + ' | Sheets: ' + data.sheetCount }));

    if (data.headerCheck) {
      var summaryKind = (data.headerCheck.Issues && data.headerCheck.Issues > 0) ? 'warn' : 'ok';
      card.appendChild(pill('Header check: ' + data.headerCheck.Summary, summaryKind));
      if (data.headerCheck.Details) {
        card.appendChild(el('div', { 'class': 'small', text: data.headerCheck.Details }));
      }
    }

    if (data.signatures && data.signatures.length) {
      card.appendChild(el('div', { 'class': 'small muted', text: 'Signatures: ' + data.signatures.join(', ') }));
    } else {
      card.appendChild(el('div', { 'class': 'small muted', text: 'Signatures: —' }));
    }

    return card;
  }

  // ----------------------------
  // Main pipeline
  // ----------------------------
  function runAnalysis() {
    var btn = $('runBtn');
    btn.disabled = true;
    setStatus('Analyserar...', false);

    var fTs = pickByType(TYPE_KEYS.TEST_SUMMARY);
    if (!fTs) {
      setStatus('Saknar Test Summary (csv/xlsx).', true);
      validateReady();
      return;
    }

    var fPos = pickByType(TYPE_KEYS.SEAL_POS);
    var fNeg = pickByType(TYPE_KEYS.SEAL_NEG);
    var fWs = pickByType(TYPE_KEYS.WORKSHEET);

    clearNode($('results'));
    $('results').appendChild(el('div', { 'class': 'small muted', text: 'Laser och analyserar filer...' }));

    var model = {
      cache: {},
      rules: rulesState,
      testSummary: null,
      sealPos: null,
      sealNeg: null,
      worksheet: null,
      consensus: null
    };

    var tasks = [];

    var nameLow = (fTs.name || '').toLowerCase();
    var isXlsx = (nameLow.indexOf('.xlsx') >= 0 || nameLow.indexOf('.xls') >= 0);
    if (isXlsx) {
      tasks.push(analyzeTestSummaryXlsx(model, fTs).then(function (res) {
        model.testSummary = res;
        if (!model.testSummary.ok) throw new Error(model.testSummary.error || 'XLSX-parse misslyckades.');
      }));
    } else {
      tasks.push(readFileAsTextCached(fTs, model.cache).then(function (text) {
        model.testSummary = analyzeTestSummaryCsv(model, text);
        if (!model.testSummary.ok) throw new Error(model.testSummary.error || 'CSV-parse misslyckades.');
      }));
    }

    if (fPos) {
      tasks.push(analyzeSealTestXlsx(model, fPos, 'POS').then(function (res) { model.sealPos = res; }));
    }

    if (fNeg) {
      tasks.push(analyzeSealTestXlsx(model, fNeg, 'NEG').then(function (res) { model.sealNeg = res; }));
    }

    if (fWs) {
      tasks.push(analyzeWorksheetXlsx(model, fWs).then(function (res) { model.worksheet = res; }));
    }

    Promise.all(tasks).then(function () {
      // Consensus
      var wsPart = model.worksheet && model.worksheet.majority ? model.worksheet.majority.PartNo : '';
      var wsBatch = model.worksheet && model.worksheet.majority ? model.worksheet.majority.BatchNo : '';
      var wsCart = model.worksheet && model.worksheet.majority ? model.worksheet.majority.CartridgeNo : '';

      var posHeader = model.sealPos && model.sealPos.header ? model.sealPos.header : {};
      var negHeader = model.sealNeg && model.sealNeg.header ? model.sealNeg.header : {};

      model.consensus = {
        batch: getConsensusValue(wsBatch, posHeader.BatchNumber, negHeader.BatchNumber, 'Batch'),
        part: getConsensusValue(wsPart, posHeader.PartNumber, negHeader.PartNumber, 'Part'),
        cartridge: getConsensusValue(wsCart, posHeader.CartridgeLsp, negHeader.CartridgeLsp, 'Cartridge')
      };

      renderResults(model);
      setStatus('OK - analys klar.', false);
      validateReady();
    }).catch(function (e) {
      var msg = (e && e.message) ? e.message : String(e);
      setStatus('Fel: ' + msg, true);
      clearNode($('results'));
      $('results').appendChild(el('div', { 'class': 'small err', text: msg }));
      validateReady();
    });
  }

  // ----------------------------
  // Wire UI
  // ----------------------------
  function init() {
    $('pickBtn').addEventListener('click', function () { $('fileInput').click(); });
    $('fileInput').addEventListener('change', function (ev) {
      if (ev.target && ev.target.files) addFiles(ev.target.files);
      $('fileInput').value = '';
    });

    $('clearBtn').addEventListener('click', function () {
      files = [];
      refreshFileList();
      $('results').textContent = 'Ingen analys kord an.';
      setStatus('', false);
    });

    $('runBtn').addEventListener('click', runAnalysis);

    var drop = $('drop');
    drop.addEventListener('dragover', function (e) { e.preventDefault(); drop.style.borderColor = 'rgba(31,111,235,0.9)'; });
    drop.addEventListener('dragleave', function () { drop.style.borderColor = 'rgba(255,255,255,0.16)'; });
    drop.addEventListener('drop', function (e) {
      e.preventDefault();
      drop.style.borderColor = 'rgba(255,255,255,0.16)';
      if (e.dataTransfer && e.dataTransfer.files) addFiles(e.dataTransfer.files);
    });

    refreshFileList();
  }

  init();

})();
