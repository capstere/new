﻿function Start-PerfTimer {
    <#
    .SYNOPSIS
        Start a performance timer with a friendly label.

    .DESCRIPTION
        Wraps System.Diagnostics.Stopwatch to provide easy start/stop timing.  The returned object
        contains the stopwatch instance and the supplied label so that durations can be logged
        consistently.  Requires that Logging.ps1 has been dot-sourced so Gui-Log is available.

    .PARAMETER Label
        A descriptive name for the timed block.  This will be included in the log output when
        the timer is stopped.

    .OUTPUTS
        PSCustomObject with properties Timer and Label.

    #>
    param(
        [Parameter(Mandatory=$true)][string]$Label
    )
    $timer = [System.Diagnostics.Stopwatch]::StartNew()
    return [PSCustomObject]@{
        Timer = $timer
        Label = $Label
    }
}

function Stop-PerfTimer {
    <#
    .SYNOPSIS
        Stop a performance timer and log the elapsed time.

    .DESCRIPTION
        Stops the Stopwatch stored on the provided performance object and logs the elapsed time
        via Gui-Log.  If Gui-Log is not available the message will be written to the host.

    .PARAMETER Perf
        The performance object returned by Start-PerfTimer.
    #>
    param(
        [Parameter(Mandatory=$true)][pscustomobject]$Perf
    )
    try {
        if ($Perf -and $Perf.Timer) { $Perf.Timer.Stop() }
        $elapsed = if ($Perf -and $Perf.Timer) { $Perf.Timer.Elapsed } else { $null }
        if ($elapsed) {
            $seconds = [math]::Round($elapsed.TotalSeconds, 2)
            $msg = "⏱️ $($Perf.Label) tog $seconds s"
            try { Gui-Log $msg 'Info' } catch { Write-Host $msg }
        }
    } catch {
        # Swallow any timing/logging errors to avoid affecting main code paths
    }
}

Export-ModuleMember -Function Start-PerfTimer, Stop-PerfTimer