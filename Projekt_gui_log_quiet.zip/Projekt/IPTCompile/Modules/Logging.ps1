try { Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop } catch { }

function Get-OutputBox {
    try { return $script:outputBox } catch { return $null }
}

function Set-LogOutputControl {
    param([System.Windows.Forms.TextBox]$Control)
    $script:outputBox = $Control
}

function Get-GuiLogVerbosity {
    # Returns: QUIET | NORMAL | DEV
    try {
        if ($global:Config) {
            if ($global:Config -is [System.Collections.IDictionary] -and $global:Config.Contains('GuiLogVerbosity')) {
                $v = [string]$global:Config['GuiLogVerbosity']
                if (-not [string]::IsNullOrWhiteSpace($v)) { return $v.Trim().ToUpperInvariant() }
            } elseif ($global:Config.PSObject.Properties.Match('GuiLogVerbosity').Count -gt 0) {
                $v = [string]$global:Config.GuiLogVerbosity
                if (-not [string]::IsNullOrWhiteSpace($v)) { return $v.Trim().ToUpperInvariant() }
            }
        }
    } catch { }

    $envV = ($env:IPT_GUI_LOG + '').Trim()
    if ($envV) { return $envV.ToUpperInvariant() }

    return 'QUIET'
}

function Should-WriteGuiLine {
    param(
        [string]$Text,
        [ValidateSet('Info','Warn','Error')][string]$Severity,
        [string]$Category
    )

    $v = Get-GuiLogVerbosity

    # Always show fatal/user-actionable messages
    if ($Severity -eq 'Error') { return $true }

    # Warnings: show in NORMAL/DEV; in QUIET hide selected noisy categories
    if ($Severity -eq 'Warn') {
        if ($v -eq 'QUIET') {
            if ($Category -in @('RULEENGINE_DEV','RULEENGINE_STATS','SANITY','DEBUG','PERF')) { return $false }
        }
        return $true
    }

    # Info: depends on verbosity
    if ($v -eq 'DEV') { return $true }

    if ($v -eq 'NORMAL') {
        # Hide explicitly noisy categories
        if ($Category -in @('RULEENGINE_DEV','RULEENGINE_STATS','SANITY','DEBUG','PERF')) { return $false }
        return $true
    }

    # QUIET:
    # Only show user-relevant summary/result lines
    if ($Category -in @('RESULT','SUMMARY')) { return $true }

    # Also allow some very short success markers if they are already "user-facing"
    if ($Text -like '✅ Rapport sparad:*') { return $true }

    return $false
}

function Gui-Log {
    param(
        [string]$Text,
        [ValidateSet('Info', 'Warn', 'Error')]
        [string]$Severity = 'Info',
        [string]$Category = 'UI',
        [hashtable]$Data,
        [switch]$Immediate
    )

    $prefix = switch ($Severity) {
        'Warn'  { '⚠️' }
        'Error' { '❌' }
        default { 'ℹ️' }
    }

    $timestamp = (Get-Date).ToString('HH:mm:ss')
    $line = "[$timestamp] $prefix $Text"

    # Decide if we show this in the GUI/console (file logs are still written)
    $writeUi = $true
    try { $writeUi = (Should-WriteGuiLine -Text $Text -Severity $Severity -Category $Category) } catch { $writeUi = $true }

    if ($writeUi) {
        $outputBox = Get-OutputBox

        if ($outputBox) {
            try {
                if ($outputBox.IsDisposed -or -not $outputBox.IsHandleCreated) {
                    $outputBox = $null
                }
            } catch {
                $outputBox = $null
            }
        }

        if ($outputBox) {
            try {
                $tb  = $outputBox
                $msg = $line
                $append = [System.Action[System.Windows.Forms.TextBox,string]]{
                    param($tbox, $text)
                    $tbox.AppendText("$text`r`n")
                    $tbox.SelectionStart = $tbox.TextLength
                    $tbox.ScrollToCaret()
                    $tbox.Refresh()
                }

                if ($tb.InvokeRequired) {
                    $null = $tb.BeginInvoke($append, @($tb, $msg))
                } else {
                    $append.Invoke($tb, $msg)
                }

                if ($Immediate) { [System.Windows.Forms.Application]::DoEvents() }
            }
            catch {
                Write-Host $line
            }
        }
        else {
            Write-Host $line
        }
    }

    # Structured log (always)
    try {
        Write-StructuredLog `
            -Message  $Text `
            -Severity $Severity `
            -Category $Category `
            -Context  $Data
    } catch {}

    # Classic file log (always)
    if ($global:LogPath) {
        try {
            Add-Content -Path $global:LogPath -Value $line -Encoding UTF8
        }
        catch {
            if ($writeUi) { Write-Host "Loggning misslyckades: $($_.Exception.Message)" }
        }
    }
}

function Add-AuditEntry {
    param(
        [string]$Lsp,
        [string]$Assay,
        [string]$BatchNumber,
        [int]$TestCount,
        [string]$Status,
        [string]$ReportPath,
        [string]$AuditDir
    )

    try {
        if (-not $AuditDir) {
            $netRootForAudit = ($env:IPT_NETWORK_ROOT + '').Trim()

            if ($netRootForAudit -and (Test-Path -LiteralPath $netRootForAudit)) {
                $AuditDir = Join-Path $netRootForAudit 'audit'
            }
            elseif ($PSScriptRoot) {
                $AuditDir = Join-Path $PSScriptRoot 'audit'
            }
            else {
                $AuditDir = Join-Path $env:TEMP 'audit'
            }
        }

        if (-not (Test-Path -LiteralPath $AuditDir)) {
            New-Item -ItemType Directory -Path $AuditDir -Force | Out-Null
        }

        $date = (Get-Date).ToString('yyyyMMdd')
        $safeLsp = if ($Lsp) { $Lsp } else { 'NA' }
        $file = Join-Path $AuditDir ("Audit_{0}_{1}_{2}.csv" -f $date, $env:USERNAME, $safeLsp)

        $row = [pscustomobject]@{
            Timestamp  = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
            Username   = $env:USERNAME
            LSP        = $Lsp
            Assay      = $Assay
            Batch      = $BatchNumber
            TestCount  = $TestCount
            Status     = if ($Status) { $Status } else { 'OK' }
            ReportPath = $ReportPath
        }

        $exists = Test-Path -LiteralPath $file
        if ($exists) {
            $row | Export-Csv -Path $file -NoTypeInformation -Append -Encoding UTF8
        }
        else {
            $row | Export-Csv -Path $file -NoTypeInformation -Encoding UTF8
        }
    }
    catch {
        Gui-Log -Text "Kunde inte skriva audit-fil: $($_.Exception.Message)" -Severity 'Warn' -Category 'AUDIT'
    }
}

function Write-StructuredLog {
    param(
        [string]$Message,
        [ValidateSet('Info','Warn','Error')][string]$Severity = 'Info',
        [string]$Category = 'General',
        [hashtable]$Context
    )

    if (-not $global:LogPath) { return }

    $jsonPath = $null
    try {
        if ($global:StructuredLogPath) {
            $jsonPath = $global:StructuredLogPath
        } else {
            $jsonPath = "$($global:LogPath).jsonl"
        }
    }
    catch {
        $jsonPath = "$($global:LogPath).jsonl"
    }

    $entry = [ordered]@{
        Timestamp = (Get-Date).ToString('o')
        Severity  = $Severity
        Category  = $Category
        Message   = $Message
    }

    if ($Context) {
        foreach ($k in $Context.Keys) {
            $entry[$k] = $Context[$k]
        }
    }

    try {
        Add-Content -Path $jsonPath -Value ($entry | ConvertTo-Json -Compress) -Encoding UTF8
    }
    catch {
        # silent
    }
}
