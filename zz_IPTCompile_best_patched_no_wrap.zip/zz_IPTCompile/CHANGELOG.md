# CHANGELOG (IPTCompile)

## 2026-01-30
- Centraliserade konfig åtkomst via `Get-ConfigValue/Get-ConfigFlag` för säkrare flagg‑läsning (ingen krasch vid fel).
- Låste **KONTROLLPROVSFIL - Version 2.5.xlsm** till nätet och lade nät‑undantag i staging.
- Förfinade GUI‑loggfilter (DEV/NORMAL/QUIET) för kort svensk användarlogg, men behöll full teknisk logg i fil.
- Lade in extra skydd mot race conditions (blockera "Skapa rapport" när sökning pågår).
- Centraliserade genvägs‑paths och SharePoint‑styrning i `Modules/Config.ps1`.
- Förbättrade "hittad mapp"‑logik så att den bara loggas om mappen faktiskt finns.
- Uppdaterade README med steg‑för‑steg och tydligare felhantering.
