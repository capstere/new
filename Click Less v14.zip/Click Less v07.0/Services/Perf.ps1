﻿#requires -Version 5.1

using namespace System.Diagnostics

if (-not $Global:CL_TimerResults) {
    $Global:CL_TimerResults = [ordered]@{}
}

function Start-Timer {
    param([Parameter(Mandatory)][string]$Name)
    $sw = [Stopwatch]::StartNew()
    return $sw
}

function Stop-Timer {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][Stopwatch]$Stopwatch
    )
    try {
        $Stopwatch.Stop()
        $elapsed = $Stopwatch.Elapsed.TotalSeconds
        if (-not $Global:CL_TimerResults.ContainsKey($Name)) {
            $Global:CL_TimerResults[$Name] = @()
        }
        $Global:CL_TimerResults[$Name] += $elapsed
    } catch {
        # ignore timing failures
    }
}

function Get-TopTimers {
    param([int]$Top = 10)
    $res = @()
    foreach ($k in $Global:CL_TimerResults.Keys) {
        $total = ($Global:CL_TimerResults[$k] | Measure-Object -Sum).Sum
        $res += [pscustomobject]@{ Name = $k; TotalSeconds = [math]::Round($total,2) }
    }
    return $res | Sort-Object -Property TotalSeconds -Descending | Select-Object -First $Top
}
