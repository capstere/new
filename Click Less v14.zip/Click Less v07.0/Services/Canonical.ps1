﻿function Normalize-HeaderName {
    param([string]$s)
    if ([string]::IsNullOrWhiteSpace($s)) { return '' }
    $t = $s.Trim().ToLowerInvariant()
    $t = $t.Replace('_',' ')
    $t = ($t -replace '[\(\)]',' ')
    $t = ($t -replace '\s+',' ').Trim()
    return $t
}

function Normalize-AssayName {
    param([string]$Name)
    if ([string]::IsNullOrWhiteSpace($Name)) { return '' }
    $x = $Name.Trim().ToLowerInvariant()
    $x = $x -replace '[_]+',' '
    $x = $x -replace '[^a-z0-9]+',' '
    $x = ($x -replace '\s+',' ').Trim()
    return $x
}

function Get-HeaderIndexValue {
    param(
        [object]$HeaderIndex,
        [string[]]$Keys
    )
    if (-not $HeaderIndex) { return -1 }

    foreach ($k in ($Keys | Where-Object { $_ })) {
        $n = Normalize-HeaderName $k
        if ($HeaderIndex.ContainsKey($n)) { return [int]$HeaderIndex[$n] }
        if ($HeaderIndex.ContainsKey($k)) { return [int]$HeaderIndex[$k] }
    }
    return -1
}

function Parse-SampleIdParts {
    param(
        [string]$SampleId,
        [string]$Pattern
    )

    $default = [pscustomobject]@{
        Prefix  = ''
        Bag     = ''
        Rep     = ''
        Sample  = ''
        Suffix  = ''
        Obs     = ''
        Success = $false
    }

    if ([string]::IsNullOrWhiteSpace($SampleId)) { return $default }
    $usePattern = if ($Pattern) { $Pattern } else { '^(?<prefix>[^_]+)_(?<bag>\d{2})_(?<rep>\d)_(?<sample>\d{2})(?<suffix>[A-Z0-9+]*)(?:_(?<obs>.+))?$' }

    try {
        $m = [regex]::Match($SampleId.Trim(), $usePattern)
        if (-not $m.Success) { return $default }
        return [pscustomobject]@{
            Prefix  = if ($m.Groups['prefix']) { $m.Groups['prefix'].Value } else { '' }
            Bag     = if ($m.Groups['bag'])    { $m.Groups['bag'].Value }    else { '' }
            Rep     = if ($m.Groups['rep'])    { $m.Groups['rep'].Value }    else { '' }
            Sample  = if ($m.Groups['sample']) { $m.Groups['sample'].Value } else { '' }
            Suffix  = if ($m.Groups['suffix']) { $m.Groups['suffix'].Value } else { '' }
            Obs     = if ($m.Groups['obs'])    { $m.Groups['obs'].Value }    else { '' }
            Success = $true
        }
    } catch {
        return $default
    }
}
