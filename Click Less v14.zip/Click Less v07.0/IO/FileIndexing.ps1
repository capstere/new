﻿#requires -Version 5.1

<#
    FileIndexing.ps1

    Provides simple helper functions for indexing and looking up LSP
    folders.  Performing a deep recursive directory enumeration for
    every search can be costly; this module caches the mapping from
    folder names to full paths in memory.  The index is built once
    per session and reused for subsequent searches.  A wildcard
    regular expression is used to match against folders that end
    with the user supplied LSP (optionally preceded by a '#').
#>

if (-not $script:LspFolderIndex) {
    $script:LspFolderIndex = @{}
}

function Build-LspFolderIndex {
    <#
        .SYNOPSIS
            Builds a hashtable mapping folder names to full paths.

        .PARAMETER RootPaths
            One or more base directories to search for LSP folders.
    #>
    param([Parameter(Mandatory)][string[]]$RootPaths)
    $idx = @{}
    foreach ($root in $RootPaths) {
        try {
            Get-ChildItem -Path $root -Directory -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
                $idx[$_.Name] = $_.FullName
            }
        } catch {
            # ignore enumeration errors
        }
    }
    $script:LspFolderIndex = $idx
    return $idx
}

function Find-LspFolder {
    <#
        .SYNOPSIS
            Looks up the directory corresponding to the specified LSP.

        .PARAMETER Lsp
            The LSP identifier (number).  Both exact and '#12345' style
            folder names are supported.

        .PARAMETER RootPaths
            Optional root paths to build the index from if it has not
            already been built.
    #>
    param(
        [Parameter(Mandatory)][string]$Lsp,
        [string[]]$RootPaths
    )
    if (-not $script:LspFolderIndex -or $script:LspFolderIndex.Count -eq 0) {
        if (-not $RootPaths) { return $null }
        Build-LspFolderIndex -RootPaths $RootPaths
    }
    $pattern = "#?$Lsp$"
    foreach ($name in $script:LspFolderIndex.Keys) {
        if ($name -match $pattern) {
            return $script:LspFolderIndex[$name]
        }
    }
    return $null
}

Export-ModuleMember -Function Build-LspFolderIndex,Find-LspFolder