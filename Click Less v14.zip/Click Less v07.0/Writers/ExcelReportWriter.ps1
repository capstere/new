﻿function New-2DArray {
    param([object[]]$Rows)
    if (-not $Rows -or $Rows.Count -eq 0) { return $null }
    $rowCount = $Rows.Count
    $colCount = $Rows[0].Count
    $arr = New-Object object[,] $rowCount, $colCount
    for ($r=0; $r -lt $rowCount; $r++) {
        $row = $Rows[$r]
        for ($c=0; $c -lt $colCount; $c++) {
            $arr[$r,$c] = $row[$c]
        }
    }
    return $arr
}

function Write-Information2Sheet {
    param(
        [Parameter(Mandatory)][OfficeOpenXml.ExcelWorksheet]$Worksheet,
        [Parameter(Mandatory)]$Report,
        [Parameter(Mandatory)]$RuleBank
    )

    if (-not $Worksheet) { return }

    $sectionOrder = @()
    if ($RuleBank -and $RuleBank.Defaults -and $RuleBank.Defaults.SectionOrder) {
        $sectionOrder = @($RuleBank.Defaults.SectionOrder)
    }

    $defaultHeaders = @('Rule','Sample ID','Cartridge S/N','Test Type','Instrument S/N','Module S/N','Start Time','Status','Test Result','Max Pressure (PSI)','Error')
    if ($RuleBank -and $RuleBank.Defaults -and $RuleBank.Defaults.ColumnHeaders -and $RuleBank.Defaults.ColumnHeaders.Default) {
        $defaultHeaders = @($RuleBank.Defaults.ColumnHeaders.Default)
    }

    $missingHeaders = @('Missing Samples','Hint')
    if ($RuleBank -and $RuleBank.Defaults -and $RuleBank.Defaults.ColumnHeaders -and $RuleBank.Defaults.ColumnHeaders.MissingSamples) {
        $missingHeaders = @($RuleBank.Defaults.ColumnHeaders.MissingSamples)
    }

    $controlHeaders = @('Control Materials','Count')
    if ($RuleBank -and $RuleBank.Defaults -and $RuleBank.Defaults.ColumnHeaders -and $RuleBank.Defaults.ColumnHeaders.ControlMaterials) {
        $controlHeaders = @($RuleBank.Defaults.ColumnHeaders.ControlMaterials)
    }

    # Clear only values in a conservative range; preserve formatting/widths
    try {
        if ($Worksheet.Dimension) {
            $endRow = [Math]::Max($Worksheet.Dimension.End.Row, 200)
            $Worksheet.Cells[1,1,$endRow,11].Value = $null
        }
    } catch {}

    $rowCursor = 1
    foreach ($sectionName in $sectionOrder) {
        $rows = @()
        $headerRow = @($sectionName)
        if ($sectionName -eq 'Missing Samples') {
            $headerRow += $missingHeaders[1]
        } elseif ($sectionName -eq 'Control Materials') {
            $headerRow += $controlHeaders[1]
        } else {
            $headerRow += $defaultHeaders[1..($defaultHeaders.Count - 1)]
        }

        $rows += ,($headerRow)
        $sectionRows = @()
        if ($Report -and $Report.Sections -and $Report.Sections.ContainsKey($sectionName)) {
            $sectionRows = @($Report.Sections[$sectionName])
        }
        foreach ($r in $sectionRows) { $rows += ,$r }

        $array = New-2DArray -Rows $rows
        if ($array) {
            Set-RangeFromArray -Worksheet $Worksheet -StartRow $rowCursor -StartCol 1 -Values $array
            $rowCursor += $rows.Count + 1
        } else {
            $rowCursor += 1
        }
    }
}
