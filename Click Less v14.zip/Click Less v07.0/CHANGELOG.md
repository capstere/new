v07.0.0
- Switched Information2 to template-v5 layout with sectioned, generalized output.
- Added InputLoader cache to enforce open-once reads and log open counts.
- Rebuilt RuleBank + RuleEngine for Info2 section rules and missing/control material summaries.
- Added 2D-array bulk writer for Info2 and preserved template column widths (no AutoFit).
- Consolidated services (logging, EPPlus loader, UI helpers) into the new folder layout.
