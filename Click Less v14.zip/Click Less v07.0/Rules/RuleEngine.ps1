﻿function Resolve-AssayProfile {
    param(
        [string]$Assay,
        [pscustomobject]$RuleBank
    )

    if (-not $RuleBank -or -not $RuleBank.AssayProfiles) { return $null }
    $norm = Normalize-AssayName $Assay
    foreach ($profile in $RuleBank.AssayProfiles) {
        if (-not $profile) { continue }
        foreach ($name in ($profile.MatchNames | Where-Object { $_ })) {
            if ($norm -eq (Normalize-AssayName $name)) {
                return $profile
            }
        }
    }
    return $null
}

function Copy-Hashtable {
    param([hashtable]$Source)
    $out = @{}
    foreach ($k in $Source.Keys) {
        $v = $Source[$k]
        if ($v -is [hashtable]) { $out[$k] = Copy-Hashtable -Source $v }
        else { $out[$k] = $v }
    }
    return $out
}

function Merge-Settings {
    param(
        [hashtable]$Defaults,
        [hashtable]$Overrides
    )
    $merged = Copy-Hashtable -Source $Defaults
    foreach ($k in $Overrides.Keys) {
        if ($merged[$k] -is [hashtable] -and $Overrides[$k] -is [hashtable]) {
            $merged[$k] = Merge-Settings -Defaults $merged[$k] -Overrides $Overrides[$k]
        } else {
            $merged[$k] = $Overrides[$k]
        }
    }
    return $merged
}

function Normalize-Empty {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return '' }
    if ($Text -match '^(?i)(none|na|n/a)$') { return '' }
    return $Text
}

function Test-ReplacementSample {
    param([pscustomobject]$Row)
    if (-not $Row) { return $false }
    try {
        if ($Row.SampleParts -and $Row.SampleParts.Success) {
            if ($Row.SampleParts.Suffix -match '(?i)a') { return $true }
        }
    } catch {}
    if ($Row.SampleID -match '(?i)\\d{2}a') { return $true }
    return $false
}

function Test-RuleMatch {
    param(
        [pscustomobject]$Row,
        [hashtable]$When
    )
    if (-not $When) { return $false }

    if ($When.TestTypeLike) {
        $hit = $false
        foreach ($t in $When.TestTypeLike) {
            if ($Row.TestType -and ($Row.TestType -like "*$t*")) { $hit = $true; break }
        }
        if (-not $hit) { return $false }
    }

    if ($When.SamplePrefixLike) {
        $hit = $false
        foreach ($t in $When.SamplePrefixLike) {
            if ($Row.SampleParts -and $Row.SampleParts.Prefix -and ($Row.SampleParts.Prefix -like "$t*")) { $hit = $true; break }
        }
        if (-not $hit) { return $false }
    }

    if ($When.ExcludeSamplePrefixLike) {
        foreach ($t in $When.ExcludeSamplePrefixLike) {
            if ($Row.SampleParts -and $Row.SampleParts.Prefix -and ($Row.SampleParts.Prefix -like "$t*")) { return $false }
        }
    }

    if ($When.ResultContains) {
        $hit = $false
        foreach ($t in $When.ResultContains) {
            if ($Row.TestResultRaw -and ($Row.TestResultRaw -like "*$t*")) { $hit = $true; break }
        }
        if (-not $hit) { return $false }
    }

    if ($When.ResultNotContains) {
        foreach ($t in $When.ResultNotContains) {
            if ($Row.TestResultRaw -and ($Row.TestResultRaw -like "*$t*")) { return $false }
        }
    }

    if ($When.ErrorCodeIn) {
        if (-not ($When.ErrorCodeIn -contains $Row.ErrorCode)) { return $false }
    }

    if ($When.SpcCtEquals -ne $null) {
        if ($Row.SpcCt -ne $When.SpcCtEquals) { return $false }
    }

    if ($When.SampleIdHasReplacement) {
        if (-not (Test-ReplacementSample -Row $Row)) { return $false }
    }

    if ($When.SampleIdObsLike) {
        $hit = $false
        foreach ($t in $When.SampleIdObsLike) {
            if ($Row.SampleParts -and $Row.SampleParts.Obs -and ($Row.SampleParts.Obs -like "*$t*")) { $hit = $true; break }
        }
        if (-not $hit) { return $false }
    }

    if ($When.ExcludeReplacement) {
        if (Test-ReplacementSample -Row $Row) { return $false }
    }

    if ($When.StatusIn) {
        if (-not ($When.StatusIn -contains $Row.Status)) { return $false }
    }

    if ($When.ErrorEmpty) {
        if (-not [string]::IsNullOrWhiteSpace((Normalize-Empty $Row.ErrorRaw))) { return $false }
    }

    return $true
}

function Get-ExpectedTestType {
    param([string]$Prefix, [hashtable]$Map)
    if (-not $Prefix -or -not $Map) { return $null }
    foreach ($k in $Map.Keys) {
        if ($Prefix -like "$k*" -or $Prefix -eq $k) { return $Map[$k] }
    }
    return $null
}

function New-ReportRow {
    param([pscustomobject]$Row, [string]$Label)
    return @(
        $Label,
        $Row.SampleID,
        $Row.CartridgeSN,
        $Row.TestType,
        $Row.InstrumentSN,
        $Row.ModuleSN,
        $Row.StartTime,
        $Row.Status,
        $Row.TestResultRaw,
        $Row.MaxPressure,
        (Normalize-Empty $Row.ErrorRaw)
    )
}

function Get-Info2Report {
    param(
        [Parameter(Mandatory)][object[]]$Rows,
        [Parameter(Mandatory)][pscustomobject]$RuleBank
    )

    $assay = ($Rows | Where-Object { $_.Assay } | Group-Object -Property Assay | Sort-Object Count -Descending | Select-Object -First 1).Name
    $profile = Resolve-AssayProfile -Assay $assay -RuleBank $RuleBank

    $settings = @{}
    if ($RuleBank -and $RuleBank.Defaults) { $settings = Copy-Hashtable -Source $RuleBank.Defaults }
    if ($profile -and $profile.Settings) { $settings = Merge-Settings -Defaults $settings -Overrides $profile.Settings }

    $sections = [ordered]@{}
    foreach ($name in $RuleBank.Defaults.SectionOrder) { $sections[$name] = @() }

    $enabledRules = @()
    if ($profile -and $profile.EnabledRules) { $enabledRules = @($profile.EnabledRules) }
    if (-not $enabledRules -or $enabledRules.Count -eq 0) { $enabledRules = @($RuleBank.RuleDefinitions.Keys) }

    foreach ($ruleId in $enabledRules) {
        $rule = $RuleBank.RuleDefinitions[$ruleId]
        if (-not $rule) { continue }
        $sectionName = $rule.Section
        foreach ($row in $Rows) {
            if (-not (Test-RuleMatch -Row $row -When $rule.When)) { continue }
            $label = ''
            if ($rule.RowLabel) { $label = $rule.RowLabel }
            elseif ($rule.RowLabelFrom -eq 'ErrorCode') { $label = $row.ErrorCode }
            elseif ($rule.RowLabelFrom -eq 'ErrorCodeOrBlank') { $label = $row.ErrorCode }
            $sections[$sectionName] += ,(New-ReportRow -Row $row -Label $label)
        }
    }

    $incorrectSampleRows = @()
    $incorrectBagFlags = @{}
    foreach ($row in $Rows) {
        if (-not $row.SampleID) { continue }
        $parts = $row.SampleParts
        $bagKey = $null
        if ($parts -and $parts.Success) {
            $bagKey = "$($parts.Prefix)|$($parts.Bag)"
        }

        $invalidMsg = $null
        if (-not $parts.Success) {
            $invalidMsg = 'Does not match Sample Code or Test Type'
        } else {
            if ($parts.Prefix -notmatch '^(?i)c') { continue }
            if ($parts.Suffix -match '(?i)a') {
                continue
            }
            $num = $null
            if (-not [int]::TryParse($parts.Sample, [ref]$num)) {
                $invalidMsg = 'Does not match Sample Code or Test Type'
            } else {
                $min = [int]$settings.ExpectedSampleRange.Min
                $max = [int]$settings.ExpectedSampleRange.Max
                if ($num -lt $min -or $num -gt $max) {
                    $invalidMsg = 'Does not match Sample Code or Test Type'
                } else {
                    if ($parts.Suffix -match '\\d') {
                        $invalidMsg = "Incorrect \"+/X\", should be: \"X\""
                    }
                }
            }
        }

        if ($invalidMsg) {
            if ($bagKey) { $incorrectBagFlags[$bagKey] = $true }
            $incorrectSampleRows += ,(New-ReportRow -Row $row -Label $invalidMsg)
        }
    }
    $sections['Incorrect Sample ID'] = $incorrectSampleRows

    $incorrectTypeRows = @()
    foreach ($row in $Rows) {
        if (-not $row.SampleID -or -not $row.SampleParts -or -not $row.SampleParts.Success) { continue }
        $expected = Get-ExpectedTestType -Prefix $row.SampleParts.Prefix -Map $settings.ExpectedTestTypeByPrefix
        if ($expected -and $row.TestType -and $row.TestType -ne $expected) {
            $label = ("Incorrect \"Test Type\", should be: \"{0}\"" -f $expected)
            $incorrectTypeRows += ,(New-ReportRow -Row $row -Label $label)
        }
    }
    $sections['Incorrect Test Type'] = $incorrectTypeRows

    $dupSampleRows = @()
    foreach ($grp in ($Rows | Where-Object { $_.SampleID } | Group-Object SampleID | Where-Object { $_.Count -gt 1 })) {
        foreach ($row in $grp.Group) { $dupSampleRows += ,(New-ReportRow -Row $row -Label '') }
    }
    $sections['Duplicate of Sample ID'] = $dupSampleRows

    $dupCartRows = @()
    foreach ($grp in ($Rows | Where-Object { $_.CartridgeSN } | Group-Object CartridgeSN | Where-Object { $_.Count -gt 1 })) {
        foreach ($row in $grp.Group) { $dupCartRows += ,(New-ReportRow -Row $row -Label '') }
    }
    $sections['Duplicate of Cartridge S/N'] = $dupCartRows

    $missingRows = @()
    $bagSets = @{}
    foreach ($row in $Rows) {
        if (-not $row.SampleParts -or -not $row.SampleParts.Success) { continue }
        if ($row.SampleParts.Prefix -notmatch '^(?i)c') { continue }
        $num = $null
        if (-not [int]::TryParse($row.SampleParts.Sample, [ref]$num)) { continue }
        $bagKey = "$($row.SampleParts.Prefix)|$($row.SampleParts.Bag)"
        if (-not $bagSets.ContainsKey($bagKey)) {
            $bagSets[$bagKey] = [ordered]@{
                Prefix = $row.SampleParts.Prefix
                Bag    = $row.SampleParts.Bag
                Samples = New-Object 'System.Collections.Generic.HashSet[int]'
                HasObsMatch = $false
            }
        }
        [void]$bagSets[$bagKey].Samples.Add($num)
        if ($row.SampleParts.Obs -match '^D(\\d{2})$') {
            if ($matches[1] -eq $row.SampleParts.Bag) { $bagSets[$bagKey].HasObsMatch = $true }
        }
    }

    foreach ($bagKey in $bagSets.Keys) {
        $bag = $bagSets[$bagKey]
        $min = [int]$settings.ExpectedSampleRange.Min
        $max = [int]$settings.ExpectedSampleRange.Max
        $skip = @()
        if ($settings.ExpectedSampleSkip) { $skip = @($settings.ExpectedSampleSkip) }
        if ($bag.HasObsMatch) { $max = [Math]::Max($max, 20) }
        if ($min -le 0 -or $max -lt $min) { continue }
        for ($i=$min; $i -le $max; $i++) {
            if ($skip -contains "$i") { continue }
            if (-not $bag.Samples.Contains($i)) {
                $hint = if ($incorrectBagFlags.ContainsKey($bagKey)) { 'May be incorrect Sample ID' } else { 'May be a Visual Failure' }
                $missingRows += ,@("Bag $($bag.Bag) missing sample number $i", $hint)
            }
        }
    }
    $sections['Missing Samples'] = $missingRows

    $controlRows = @()
    $prefixBuckets = @{}
    foreach ($row in $Rows) {
        if (-not $row.SampleID) { continue }
        $prefix = $null
        if ($row.SampleParts -and $row.SampleParts.Success -and $row.SampleParts.Prefix) {
            $prefix = $row.SampleParts.Prefix
        } else {
            $prefix = ($row.SampleID -split '_')[0]
        }
        if (-not $prefix) { continue }
        if (-not $prefixBuckets.ContainsKey($prefix)) { $prefixBuckets[$prefix] = 0 }
        $prefixBuckets[$prefix]++
    }
    foreach ($k in ($prefixBuckets.Keys | Sort-Object)) {
        $controlRows += ,@($k, [int]$prefixBuckets[$k])
    }
    $sections['Control Materials'] = $controlRows

    return [pscustomobject]@{
        Assay    = $assay
        Sections = $sections
    }
}
