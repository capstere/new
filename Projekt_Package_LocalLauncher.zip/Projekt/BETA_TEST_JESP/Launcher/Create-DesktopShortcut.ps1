# Create-DesktopShortcut.ps1 (PowerShell 5.1)
# Skapar en .lnk på användarens Skrivbord som kör en PS1-fil

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

param(
    [Parameter(Mandatory=$true)][string]$ShortcutName,
    [Parameter(Mandatory=$true)][string]$LauncherPs1,
    [Parameter(Mandatory=$true)][string]$WorkingDir
)

function Get-PowerShellExe {
    # Använd samma process-arch som den som kör (PS 5.1)
    return (Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe')
}

if (-not (Test-Path -LiteralPath $LauncherPs1)) {
    throw "LauncherPs1 finns inte: $LauncherPs1"
}

$desktop = [Environment]::GetFolderPath('DesktopDirectory')
if ([string]::IsNullOrWhiteSpace($desktop)) {
    throw "Kunde inte hitta DesktopDirectory"
}

$lnkPath = Join-Path $desktop ($ShortcutName + '.lnk')
$exe = Get-PowerShellExe
$args = '-NoProfile -ExecutionPolicy Bypass -File "{0}"' -f $LauncherPs1

$wsh = New-Object -ComObject WScript.Shell
$sc = $wsh.CreateShortcut($lnkPath)
$sc.TargetPath = $exe
$sc.Arguments  = $args
$sc.WorkingDirectory = $WorkingDir
$sc.WindowStyle = 1
$sc.Description = "Startar IPTCompile via lokal launcher (snabb start)"
$sc.Save()

Write-Host ("[INFO] Skapade genväg: {0}" -f $lnkPath)
