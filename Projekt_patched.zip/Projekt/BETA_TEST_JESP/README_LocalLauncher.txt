IPTCompile – Local launcher (fast start) + cached project run

WHAT YOU CLICK
1) First time (install): BETA_TEST_JESP\IPTCompile_Launcher.bat  (runs from network once)
2) After install: Desktop shortcut "IPTCompile (Local)" (runs locally)

WHY THIS EXISTS
Even if Main.ps1 runs from C:\IPTCompile, starting the entrypoint from a network path can be slow
(extra checks/AV/EDR/UNC handling). The desktop shortcut starts from local disk instead.

FOLDER ROLES
A) Network project root (source for cache):
   \\SE.CEPHEID.PRI\Cepheid Sweden\QC\QC-1\IPT\Skiftspecifika dokument\PQC analyst\JESPER\IPTCompile

B) Network launcher folder (installer + source for launcher self-update):
   BETA_TEST_JESP\Launcher\

C) Local launcher folder (entrypoint that users run every day):
   C:\IPTCompileLauncher
   (fallback: %LOCALAPPDATA%\Danaher\IPTCompileLauncher)

D) Local project cache:
   C:\IPTCompile

FLOW (daily)
Desktop shortcut -> Run.ps1 (local) -> self-update launcher from network -> Launcher.ps1 (local)
-> copy/update project cache (C:\IPTCompile) -> run C:\IPTCompile\Main.ps1

LOGGING
- Launcher audit (network): <ProjectRoot>\_LauncherAudit\Launcher.log
- Launcher self-update audit (local): <LocalLauncher>\_LocalLauncherAudit\Run.log
- Project logs (network, because IPT_NETWORK_ROOT is set): <ProjectRoot>\Loggar\...

