# Run.ps1 (Windows PowerShell 5.1)
# Local entrypoint for IPTCompile
# - Starts from local disk (fast process start)
# - Best-effort self-update of the LOCAL launcher folder from NETWORK launcher source (LauncherSource.txt)
# - Then invokes local Launcher.ps1 (cache runner that executes Main.ps1 from C:\IPTCompile)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Get-ScriptDir {
    # Avoid Split-Path to dodge any environment shadowing.
    try {
        if ($PSScriptRoot) { return $PSScriptRoot }
    } catch { }
    try {
        if ($PSCommandPath) { return [System.IO.Path]::GetDirectoryName([System.IO.Path]::GetFullPath($PSCommandPath)) }
    } catch { }
    return [System.IO.Directory]::GetCurrentDirectory()
}

function Read-FirstNonEmptyLine([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    foreach ($line in [System.IO.File]::ReadAllLines($Path)) {
        $t = ($line + '').Trim()
        if ($t) {
            if ($t.StartsWith('"') -and $t.EndsWith('"') -and $t.Length -ge 2) {
                $t = $t.Substring(1, $t.Length - 2)
            }
            return $t.Trim()
        }
    }
    return $null
}

function Write-RunLog {
    param(
        [string]$LocalAuditDir,
        [string]$Message,
        [ValidateSet('INFO','WARN','ERROR')][string]$Level = 'INFO'
    )
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = '[{0}] [{1}] {2}' -f $ts, $Level, $Message
    Write-Host $line
    try {
        if ($LocalAuditDir) {
            if (-not (Test-Path -LiteralPath $LocalAuditDir)) {
                New-Item -Path $LocalAuditDir -ItemType Directory -Force | Out-Null
            }
            Add-Content -LiteralPath (Join-Path $LocalAuditDir 'Run.log') -Value $line -Encoding UTF8
        }
    } catch { }
}

function Invoke-RobocopyMirror {
    param(
        [Parameter(Mandatory=$true)][string]$Source,
        [Parameter(Mandatory=$true)][string]$Dest,
        [string[]]$ExcludeDirs,
        [string[]]$ExcludeFiles,
        [string]$LogFile
    )

    $args = New-Object System.Collections.Generic.List[string]
    $args.Add("`"$Source`"")
    $args.Add("`"$Dest`"")

    $args.Add('/MIR')
    $args.Add('/R:2')
    $args.Add('/W:1')
    $args.Add('/FFT')
    $args.Add('/XJ')

    # Keep logs readable and non-empty (no /NJH /NJS)
    $args.Add('/NP')
    $args.Add('/NFL')
    $args.Add('/NDL')

    foreach ($xd in ($ExcludeDirs | Where-Object { $_ })) {
        $args.Add('/XD')
        $args.Add("`"$xd`"")
    }
    foreach ($xf in ($ExcludeFiles | Where-Object { $_ })) {
        $args.Add('/XF')
        $args.Add("`"$xf`"")
    }

    if ($LogFile) {
        $args.Add("/LOG:`"$LogFile`"")
    }

    $p = Start-Process -FilePath 'robocopy.exe' -ArgumentList $args.ToArray() -Wait -PassThru -WindowStyle Hidden
    return $p.ExitCode
}

function Get-PowerShellExe {
    $sysnative = Join-Path $env:WINDIR 'sysnative\WindowsPowerShell\v1.0\powershell.exe'
    if ([Environment]::Is64BitOperatingSystem -and -not [Environment]::Is64BitProcess -and (Test-Path -LiteralPath $sysnative)) {
        return $sysnative
    }
    return (Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe')
}

# ---- Main ----
$localRoot = Get-ScriptDir
$localAudit = Join-Path $localRoot '_LocalLauncherAudit'
$launcherSourceFile = Join-Path $localRoot 'LauncherSource.txt'
$netLauncherRoot = Read-FirstNonEmptyLine -Path $launcherSourceFile

Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ("Run start. LocalRoot={0}" -f $localRoot)

if ($netLauncherRoot -and (Test-Path -LiteralPath $netLauncherRoot)) {

    $mutexName = 'Local\IPTCompile_LauncherUpdate'
    $mutex = $null
    $haveMutex = $false

    try {
        $mutex = New-Object System.Threading.Mutex($false, $mutexName)
        $haveMutex = $mutex.WaitOne(5000)

        if (-not $haveMutex) {
            Write-RunLog -LocalAuditDir $localAudit -Level WARN -Message "Launcher update lock busy; skipping self-update."
        } else {
            $logFile = Join-Path $localAudit 'robocopy_launcher_update.log'

            # Exclude local-only folder from mirroring/deletion
            $excludeDirs = @(
                (Join-Path $localRoot '_LocalLauncherAudit')
            )

            # Do not overwrite the currently running stub or the pointer file
            $excludeFiles = @(
                (Join-Path $localRoot 'Run.ps1'),
                (Join-Path $localRoot 'LauncherSource.txt')
            )

            Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ("Self-update /MIR from {0} -> {1}" -f $netLauncherRoot, $localRoot)

            $rc = Invoke-RobocopyMirror -Source $netLauncherRoot -Dest $localRoot -ExcludeDirs $excludeDirs -ExcludeFiles $excludeFiles -LogFile $logFile
            Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ("Self-update robocopy exit code={0} (0-7 OK, 8+ error). Log={1}" -f $rc, $logFile)

            if ($rc -ge 8) {
                Write-RunLog -LocalAuditDir $localAudit -Level WARN -Message "Self-update failed; continuing with existing local launcher."
            }
        }
    } catch {
        Write-RunLog -LocalAuditDir $localAudit -Level WARN -Message ("Self-update exception; continuing. {0}" -f $_.Exception.Message)
    } finally {
        if ($mutex) {
            if ($haveMutex) { try { $mutex.ReleaseMutex() } catch { } }
            $mutex.Dispose()
        }
    }
} else {
    Write-RunLog -LocalAuditDir $localAudit -Level WARN -Message "LauncherSource.txt missing/invalid or network path not reachable; skipping self-update."
}

$launcherPs1 = Join-Path $localRoot 'Launcher.ps1'
if (-not (Test-Path -LiteralPath $launcherPs1)) {
    Write-RunLog -LocalAuditDir $localAudit -Level ERROR -Message ("Missing local Launcher.ps1: {0}" -f $launcherPs1)
    exit 20
}

$exe = Get-PowerShellExe
Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ("Invoking local Launcher.ps1: {0}" -f $launcherPs1)

& $exe -NoProfile -ExecutionPolicy Bypass -File $launcherPs1
exit $LASTEXITCODE
