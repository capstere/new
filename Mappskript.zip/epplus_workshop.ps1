﻿write-host "Loading EPPlus Assembly" -ForegroundColor DarkYellow      
$epplus = @('\\SE.CEPHEID.PRI\Cepheid Sweden\QC\QC-1\IPT\Skiftspecifika dokument\Skift 1\Mahdi\powerpoint\AutoMappscript\Modules\EPPlus\EPPlus.6.2.7\lib\net35\EPPlus.dll', '\\SE.CEPHEID.PRI\Cepheid Sweden\QC\QC-1\IPT\Skiftspecifika dokument\Skift 1\Mahdi\powerpoint\AutoMappscript\Modules\EPPlus\EPPlus.Interfaces.6.1.1\lib\net35\EPPlus.Interfaces.dll',
'\\SE.CEPHEID.PRI\Cepheid Sweden\QC\QC-1\IPT\Skiftspecifika dokument\Skift 1\Mahdi\powerpoint\AutoMappscript\Modules\EPPlus\EPPlus.System.Drawing.6.1.1\lib\net35\EPPlus.System.Drawing.dll')

foreach($assembly in $epplus){

    $epplus64 = [System.Convert]::ToBase64String([System.IO.File]::ReadAllBytes($assembly))

    $bits = [Convert]::FromBase64String($epplus64)

    [System.Reflection.Assembly]::Load($bits) | Out-Null
}





$path = "N:\QC\QC-1\IPT\Skiftspecifika dokument\Skift 1\Mahdi\projects\AutoMappscript rework\worksheet rework\D68621 Attachment 1 Xpert GBS LB XC PQC Testing Worksheet_rev B.xlsx"


$excel = New-Object -TypeName OfficeOpenXml.ExcelPackage $path

$FirstDataSheet = $excel.Workbook.Worksheets[2]

$FirstDataSheet.Cells["J4"].Style.Fill.PatternType = "Solid"
$FirstDataSheet.Cells["J4"].Style.Fill.BackgroundColor.Indexed = 41

$excelLightGreenColor = [System.Drawing.Color]::FromArgb(0xFF, 0xCC, 0xFF, 0xCC)

$FirstDataSheet.Cells["K49"].Style.Fill.PatternType = "Solid"
$FirstDataSheet.Cells["K49"].Style.Fill.BackgroundColor.SetColor($excelLightGreenColor)




$FirstDataSheet.Cells["L44"].Style.Fill.BackgroundColor


#/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#N/A FILL FOR TEST SUMMARY ! BOTH GREEN AND BLUE CELLS
#Per Intended Use, information can be entered either manually or electronically on cells with a specific green background color. Blue must be entered electronically.
#The code below uses the RBG or Indexed value of that specified green/blue background to find cells that needs to be entered. The cells that require special info will not be affected by this
#as the code also checks if the cell has no text value since the special cells will be handled first.
# Green has RBG of FFCCFFCC or Index 42
# Blue has RGB of FFCCFFFF or Index 41
                                                                            #Green                                             #Blue                                                  #Green                                         #Blue
$TestSummaryInputCells = $FirstDataSheet.Cells | ?{($_.Style.Fill.BackgroundColor.Indexed -eq 42) -or ($_.Style.Fill.BackgroundColor.Indexed -eq 41) -or ($_.Style.Fill.BackgroundColor.Rgb -eq 'FFCCFFCC') -or ($_.Style.Fill.BackgroundColor.Rgb -eq 'FFCCFFFF')}

$TestSummaryInputCells | %{if($_.Text -eq ""){$_.Value = "N/A"}}

#/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


$MergedCell = $FirstDataSheet.Cells['H3']


    if($Cell.Merge){

        $idx = $Sheet.GetMergeCellId($Cell.Start.Row, $Cell.Start.Column)

        $Range = $Sheet.MergedCells[$idx-1]

        return $Range

    }else{

        return $Cell.Address
        

    }

$TypeOfResampleCell = $FirstDataSheet.Cells| ?{$_.Text -like "*Type Of Resample*"} 

$Range = GetMergedCellRange -Sheet $FirstDataSheet -Cell $TypeOfResampleCell

$TypeOfResampleCellEndRow = $FirstDataSheet.Cells[$Range].End.Row
        
$TypeOfResampleCellEndColumn = $FirstDataSheet.Cells[$Range].End.Column

$FirstDataSheet.Cells[$TypeOfResampleCellEndRow, ($TypeOfResampleCellEndColumn + 1)].Value = 'NA'


#/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



$excel.Save()

$excel.Dispose()






if($cellvalue.Merge){

    $id = $sheet.GetMergeCellId($cellvalue.start.Row, $cellvalue.start.Column)

    $range = $sheet.MergedCells[$id-1]

    if($sheet.Cells[$range].Start.Row -ne $sheet.Cells[$range].End.Row){
                
        $cellrow, $cellcolumn = $sheet.Cells[$range].Start.Row, $sheet.Cells[$range].End.Column

    }else{

        $cellrow, $cellcolumn = $sheet.Cells[$range].End.Row, $sheet.Cells[$range].End.Column
    }

}else{

$celladdress = $cellvalue.Address

$cellrow, $cellcolumn = $sheet.Cells[$celladdress].End.Row, $sheet.Cells[$celladdress].End.column
}












$path = ".\worksheet rework\D10552 Cartridge Seal Integrity Vacuum Test Worksheet.xlsx"


$excel = New-Object -TypeName OfficeOpenXml.ExcelPackage $path

$FirstDataSheet = $excel.Workbook.Worksheets[1]

$FirstDataSheet.MergedCells[52,11]

$FirstDataSheet.Cells["H41"].Style.Fill.BackgroundColor.Rgb

$FirstDataSheet.Cells["K52"].Style.Fill.BackgroundColor

$DataValidations = $FirstDataSheet.DataValidations | Select -Property Address



$NAFillCells = $FirstDataSheet.Cells | ?{($_.Style.Fill.BackgroundColor.Theme -eq "Background1") -and ($_.Style.Fill.BackgroundColor.Tint)}

$NAFillCells | %{

    if($_.Text -eq "" -and (Test-RangeOverlap)){$_.Value = "N/A"}


}


$excel.Dispose()






function Test-CellHasValidation {
    param (
        [OfficeOpenXml.ExcelWorksheet] $ws,
        [string] $cellAddress
    )

    $cell = [OfficeOpenXml.ExcelAddress]::new($cellAddress)

    foreach ($dv in $ws.DataValidations) {
        foreach ($addr in $dv.Address.Addresses) {
            $range = [OfficeOpenXml.ExcelAddress]::new($addr.Address)

            if (
                $cell.Start.Row    -ge $range.Start.Row    -and
                $cell.Start.Row    -le $range.End.Row      -and
                $cell.Start.Column -ge $range.Start.Column -and
                $cell.Start.Column -le $range.End.Column
            ) {
                return $true
            }
        }
    }
    return $false
}





function Test-RangeOverlap {
    param(
        [string] $R1,
        [string] $R2
    )

    $a = [OfficeOpenXml.ExcelAddress]::new($R1)
    $b = [OfficeOpenXml.ExcelAddress]::new($R2)

    $rowsOverlap = ($a.Start.Row -le $b.End.Row) -and ($a.End.Row -ge $b.Start.Row)
    $colsOverlap = ($a.Start.Column -le $b.End.Column) -and ($a.End.Column -ge $b.Start.Column)

    return ($rowsOverlap -and $colsOverlap)
}

Test-RangeOverlap -R1 "M1:M3" -R2 "M3:M46"



$OCFillCellReferenceRow = ($FirstDataSheet.Cells | ?{$_.Text -like "*For information only*"}).Start.Row

$OCFillCells = $FirstDataSheet.Cells | ?{$_.Style.Fill.BackgroundColor.Theme -eq "Background1"}

$OCFillCells | %{

    if($_.Text -eq "" -and ($_.Start.Row -gt $NAFillCellReferenceRow)){$_.Value = "N/A"}


}



$CartridgeIDReferenceColumn = ($FirstDataSheet.Cells | ?{$_.Text -like "*Cartridge ID*"}).Start.Column

$targetCols = @($CartridgeIDReferenceColumn, ($CartridgeIDReferenceColumn + 1), ($CartridgeIDReferenceColumn + 2))

#$OCFillCells = $FirstDataSheet.Cells | ?{$_.Style.Fill.BackgroundColor.Rgb -eq "FFCCFFFF" -and
#($_.Start.Column -eq $CartridgeIDReferenceColumn -xor $_.Start.Column -eq ($CartridgeIDReferenceColumn + 1) -xor $_.Start.Column -eq ($CartridgeIDReferenceColumn + 2)) -and $_.Start.Row -lt $OCFillCellReferenceRow} | Select -Property Address



$bluecells = $FirstDataSheet.Cells | ?{$_.Style.Fill.BackgroundColor.Rgb -eq 'FFCCFFFF'}

$test = $bluecells | ?{$_.End.Column -eq 10}



$OCFillCells | %{

    if($_.Text -eq "" -and ($_.Start.Row -gt $NAFillCellReferenceRow)){$_.Value = "N/A"}


}







$excel.Save()