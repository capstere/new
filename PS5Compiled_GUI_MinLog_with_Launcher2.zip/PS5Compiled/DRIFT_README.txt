DRIFT-paket (compiled RuleBank only)

Detta paket är avsett för körning av kollegor från N:.
RuleBank laddas endast från 'RuleBank\RuleBank.compiled.psd1' (inget CSV-fallback behövs i drift).

Om regler behöver uppdateras:
- använd DEV/QA-paketet med CSV + Build-RuleBank.ps1 för att generera en ny RuleBank.compiled.psd1
- ersätt sedan RuleBank\RuleBank.compiled.psd1 i denna DRIFT-mapp

---

Prestanda: kör lokalt med launcher (rekommenderat)

Den här mappen innehåller en "Launcher"-mapp med:
  - Launcher\Main.bat
  - Launcher\Launcher.ps1
  - Launcher\SourcePath.txt

Upplägg:
  1) Lägg Launcher\Main.bat + Launcher\Launcher.ps1 + Launcher\SourcePath.txt i valfri
     start-mapp på N: (t.ex. "BETA_TEST").
  2) Skriv EN rad i SourcePath.txt: sökvägen till projektroten (den här mappen som innehåller Main.ps1).
  3) Kör Main.bat.

Launchern kopierar projektet första gången till C:\IPTCompile\app och kör därifrån.
Nästa körning körs direkt lokalt (ingen kopiering) så länge Version.txt är oförändrad.

Versionering:
  - Uppdatera Version.txt i projektroten när ni publicerar en ny version.
  - Launchern recopy:ar endast när Version.txt ändrats.

Loggar/Audit:
  - Launchern sätter miljövariabeln IPT_NETWORK_ROOT till projektroten på N:.
  - Config.ps1 + Logging.ps1 använder IPT_NETWORK_ROOT för Loggar/audit så att loggar hamnar på N:
    även när verktyget körs från lokal cache.

