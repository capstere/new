﻿function Resolve-AssayProfile {
    param(
        [string]$Assay,
        [pscustomobject]$RuleBank
    )

    if (-not $RuleBank -or -not $RuleBank.AssayProfiles) { return $null }
    $norm = Normalize-AssayName $Assay
    foreach ($profile in $RuleBank.AssayProfiles) {
        if (-not $profile) { continue }
        foreach ($name in ($profile.MatchNames | Where-Object { $_ })) {
            if ($norm -eq (Normalize-AssayName $name)) {
                return $profile
            }
        }
    }
    return $null
}

function Copy-Hashtable {
    param([hashtable]$Source)
    $out = @{}
    foreach ($k in $Source.Keys) {
        $v = $Source[$k]
        if ($v -is [hashtable]) { $out[$k] = Copy-Hashtable -Source $v }
        else { $out[$k] = $v }
    }
    return $out
}

function Merge-Settings {
    param(
        [hashtable]$Defaults,
        [hashtable]$Overrides
    )
    $merged = Copy-Hashtable -Source $Defaults
    foreach ($k in $Overrides.Keys) {
        if ($merged[$k] -is [hashtable] -and $Overrides[$k] -is [hashtable]) {
            $merged[$k] = Merge-Settings -Defaults $merged[$k] -Overrides $Overrides[$k]
        } else {
            $merged[$k] = $Overrides[$k]
        }
    }
    return $merged
}

function Normalize-Empty {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return '' }
    if ($Text -match '^(?i)(none|na|n/a)$') { return '' }
    return $Text
}

function Get-RowSampleDerived {
    param([pscustomobject]$Row, [string]$Pattern)
    if (-not $Row) { return $null }
    if ($Row.SampleDerived) { return $Row.SampleDerived }
    if (Get-Command Parse-SampleIdDerived -ErrorAction SilentlyContinue) {
        return Parse-SampleIdDerived -SampleId $Row.SampleID -Pattern $Pattern
    }
    return $null
}

function Test-ReplacementSample {
    param([pscustomobject]$Row)
    if (-not $Row) { return $false }
    try {
        $sample = Get-RowSampleDerived -Row $Row
        if ($sample -and $sample.IsReplacement) { return $true }
    } catch {}
    if ($Row.SampleID -match '(?i)\\d{2}a') { return $true }
    return $false
}

function Test-RuleMatch {
    param(
        [pscustomobject]$Row,
        [hashtable]$When
    )
    if (-not $When) { return $false }
    $sample = Get-RowSampleDerived -Row $Row

    if ($When.TestTypeLike) {
        $hit = $false
        foreach ($t in $When.TestTypeLike) {
            if ($Row.TestType -and ($Row.TestType -like "*$t*")) { $hit = $true; break }
        }
        if (-not $hit) { return $false }
    }

    if ($When.SamplePrefixLike) {
        $hit = $false
        foreach ($t in $When.SamplePrefixLike) {
            if ($sample -and $sample.Prefix -and ($sample.Prefix -like "$t*")) { $hit = $true; break }
        }
        if (-not $hit) { return $false }
    }

    if ($When.ExcludeSamplePrefixLike) {
        foreach ($t in $When.ExcludeSamplePrefixLike) {
            if ($sample -and $sample.Prefix -and ($sample.Prefix -like "$t*")) { return $false }
        }
    }

    if ($When.ResultContains) {
        $hit = $false
        foreach ($t in $When.ResultContains) {
            if ($Row.TestResultRaw -and ($Row.TestResultRaw -like "*$t*")) { $hit = $true; break }
        }
        if (-not $hit) { return $false }
    }

    if ($When.ResultNotContains) {
        foreach ($t in $When.ResultNotContains) {
            if ($Row.TestResultRaw -and ($Row.TestResultRaw -like "*$t*")) { return $false }
        }
    }

    if ($When.ErrorCodeIn) {
        if (-not ($When.ErrorCodeIn -contains $Row.ErrorCode)) { return $false }
    }

    if ($When.SpcCtEquals -ne $null) {
        if ($Row.SpcCt -ne $When.SpcCtEquals) { return $false }
    }

    if ($When.SampleIdHasReplacement) {
        if (-not (Test-ReplacementSample -Row $Row)) { return $false }
    }

    if ($When.SampleIdObsLike) {
        $hit = $false
        foreach ($t in $When.SampleIdObsLike) {
            if ($sample -and $sample.Obs -and ($sample.Obs -like "*$t*")) { $hit = $true; break }
        }
        if (-not $hit) { return $false }
    }

    if ($When.ExcludeReplacement) {
        if (Test-ReplacementSample -Row $Row) { return $false }
    }

    if ($When.StatusIn) {
        if (-not ($When.StatusIn -contains $Row.Status)) { return $false }
    }

    if ($When.ErrorEmpty) {
        if (-not [string]::IsNullOrWhiteSpace((Normalize-Empty $Row.ErrorRaw))) { return $false }
    }

    return $true
}

function Get-ExpectedTestType {
    param([string]$Prefix, [hashtable]$Map)
    if (-not $Prefix -or -not $Map) { return $null }
    foreach ($k in $Map.Keys) {
        if ($Prefix -like "$k*" -or $Prefix -eq $k) { return $Map[$k] }
    }
    return $null
}

function Get-RuleSeverity {
    param([hashtable]$Rule, [hashtable]$SectionSeverity)
    if ($Rule -and $Rule.Severity) { return $Rule.Severity }
    if ($Rule -and $Rule.Section -and $SectionSeverity -and $SectionSeverity.ContainsKey($Rule.Section)) {
        return $SectionSeverity[$Rule.Section]
    }
    return 'Info'
}

function Get-RuleTags {
    param([hashtable]$Rule, [hashtable]$SectionTagMap)
    if ($Rule -and $Rule.Tags) { return @($Rule.Tags) }
    if ($Rule -and $Rule.Section -and $SectionTagMap) {
        foreach ($tag in $SectionTagMap.Keys) {
            if ($SectionTagMap[$tag] -eq $Rule.Section) { return @($tag) }
        }
    }
    return @()
}

function New-Info2Row {
    param(
        [pscustomobject]$Row,
        [string]$Title,
        [string]$RuleId,
        [string[]]$Tags,
        [string]$Severity,
        [string]$Reason,
        [string]$SuggestedAction
    )
    $tagList = @()
    if ($Tags) { $tagList = @($Tags | Where-Object { $_ } | Select-Object -Unique) }
    if (-not $Severity) { $Severity = 'Info' }

    return [pscustomobject]@{
        Title           = $Title
        SampleID        = $Row.SampleID
        CartridgeSN     = $Row.CartridgeSN
        TestType        = $Row.TestType
        InstrumentSN    = $Row.InstrumentSN
        ModuleSN        = $Row.ModuleSN
        StartTime       = $Row.StartTime
        Status          = $Row.Status
        TestResult      = $Row.TestResultRaw
        ErrorCode       = $Row.ErrorCode
        MaxPressure     = $Row.MaxPressure
        Error           = (Normalize-Empty $Row.ErrorRaw)
        WorstSeverity   = $Severity
        Tags            = $tagList
        RuleId          = $RuleId
        Reason          = $Reason
        SuggestedAction = $SuggestedAction
        RowKey          = $(New-TestsSummaryRowKey -Row $Row)
        RowNumber       = $Row.RowIndex
    }
}

function New-Info2NoteRow {
    param(
        [string]$Title,
        [string]$RuleId,
        [string[]]$Tags,
        [string]$Severity,
        [string]$Reason,
        [string]$SuggestedAction,
        [string]$Hint = '',
        [int]$Count = 0
    )
    $tagList = @()
    if ($Tags) { $tagList = @($Tags | Where-Object { $_ } | Select-Object -Unique) }
    if (-not $Severity) { $Severity = 'Info' }

    return [pscustomobject]@{
        Title           = $Title
        SampleID        = ''
        CartridgeSN     = ''
        TestType        = ''
        InstrumentSN    = ''
        ModuleSN        = ''
        StartTime       = ''
        Status          = ''
        TestResult      = ''
        ErrorCode       = ''
        MaxPressure     = $null
        Error           = ''
        WorstSeverity   = $Severity
        Tags            = $tagList
        RuleId          = $RuleId
        Reason          = $Reason
        SuggestedAction = $SuggestedAction
        RowKey          = ''
        RowNumber       = $null
        Hint            = $Hint
        Count           = $Count
    }
}

function Get-Info2Report {
    param(
        [Parameter(Mandatory)][object[]]$Rows,
        [Parameter(Mandatory)][pscustomobject]$RuleBank
    )

    $assay = ($Rows | Where-Object { $_.Assay } | Group-Object -Property Assay | Sort-Object Count -Descending | Select-Object -First 1).Name
    $profile = Resolve-AssayProfile -Assay $assay -RuleBank $RuleBank

    $settings = @{}
    if ($RuleBank -and $RuleBank.Defaults) { $settings = Copy-Hashtable -Source $RuleBank.Defaults }
    if ($profile -and $profile.Settings) { $settings = Merge-Settings -Defaults $settings -Overrides $profile.Settings }

    $sectionSeverity = @{}
    if ($RuleBank -and $RuleBank.Defaults -and $RuleBank.Defaults.SectionSeverity) {
        $sectionSeverity = $RuleBank.Defaults.SectionSeverity
    }
    $sectionTagMap = @{}
    if ($RuleBank -and $RuleBank.Defaults -and $RuleBank.Defaults.SectionTagMap) {
        $sectionTagMap = $RuleBank.Defaults.SectionTagMap
    }

    foreach ($row in $Rows) {
        if (-not $row.SampleDerived) {
            $row.SampleDerived = Get-RowSampleDerived -Row $row -Pattern $settings.SampleIdPattern
        }
    }

    $reportRows = New-Object System.Collections.Generic.List[object]

    $enabledRules = @()
    if ($profile -and $profile.EnabledRules) { $enabledRules = @($profile.EnabledRules) }
    if (-not $enabledRules -or $enabledRules.Count -eq 0) { $enabledRules = @($RuleBank.RuleDefinitions.Keys) }

    foreach ($ruleId in $enabledRules) {
        $rule = $RuleBank.RuleDefinitions[$ruleId]
        if (-not $rule) { continue }

        $severity = Get-RuleSeverity -Rule $rule -SectionSeverity $sectionSeverity
        $tags = Get-RuleTags -Rule $rule -SectionTagMap $sectionTagMap
        $reason = if ($rule.Reason) { $rule.Reason } elseif ($rule.RowLabel) { $rule.RowLabel } else { '' }
        $suggested = if ($rule.SuggestedAction) { $rule.SuggestedAction } else { '' }

        foreach ($row in $Rows) {
            if (-not (Test-RuleMatch -Row $row -When $rule.When)) { continue }
            $label = ''
            if ($rule.RowLabel) { $label = $rule.RowLabel }
            elseif ($rule.RowLabelFrom -eq 'ErrorCode') { $label = $row.ErrorCode }
            elseif ($rule.RowLabelFrom -eq 'ErrorCodeOrBlank') { $label = $row.ErrorCode }

            $reportRows.Add((New-Info2Row -Row $row -Title $label -RuleId $ruleId -Tags $tags -Severity $severity -Reason $reason -SuggestedAction $suggested))
        }
    }

    $incorrectBagFlags = @{}
    foreach ($row in $Rows) {
        if (-not $row.SampleID) { continue }
        $parts = $row.SampleDerived
        $bagKey = $null
        if ($parts -and $parts.Success) {
            $bagKey = "$($parts.Prefix)|$($parts.Bag)"
        }

        $invalidMsg = $null
        if (-not $parts -or -not $parts.Success) {
            $invalidMsg = 'Does not match Sample Code or Test Type'
        } else {
            if ($parts.Prefix -notmatch '^(?i)c') { continue }
            if ($parts.IsReplacement) { continue }
            if ($parts.SampleIndex -eq $null) {
                $invalidMsg = 'Does not match Sample Code or Test Type'
            } else {
                $min = [int]$settings.ExpectedSampleRange.Min
                $max = [int]$settings.ExpectedSampleRange.Max
                if ($parts.SampleIndex -lt $min -or $parts.SampleIndex -gt $max) {
                    $invalidMsg = 'Does not match Sample Code or Test Type'
                } else {
                    if ($parts.Suffix -match '\\d') {
                        $invalidMsg = 'Incorrect "+/X", should be: "X"'
                    }
                }
            }
        }

        if ($invalidMsg) {
            if ($bagKey) { $incorrectBagFlags[$bagKey] = $true }
            $reportRows.Add((New-Info2Row -Row $row -Title $invalidMsg -RuleId 'IncorrectSampleId' -Tags @('IncorrectSampleId','Deviation') -Severity 'Warn' -Reason $invalidMsg -SuggestedAction ''))
        }
    }

    foreach ($row in $Rows) {
        $parts = $row.SampleDerived
        if (-not $row.SampleID -or -not $parts -or -not $parts.Success) { continue }
        $expected = Get-ExpectedTestType -Prefix $parts.Prefix -Map $settings.ExpectedTestTypeByPrefix
        if ($expected -and $row.TestType -and $row.TestType -ne $expected) {
            $label = "Incorrect Test Type, should be: $expected"
            $reportRows.Add((New-Info2Row -Row $row -Title $label -RuleId 'IncorrectTestType' -Tags @('IncorrectTestType','Deviation') -Severity 'Warn' -Reason $label -SuggestedAction ''))
        }
    }

    foreach ($grp in ($Rows | Where-Object { $_.SampleID } | Group-Object SampleID | Where-Object { $_.Count -gt 1 })) {
        foreach ($row in $grp.Group) {
            $reportRows.Add((New-Info2Row -Row $row -Title '' -RuleId 'DuplicateSampleId' -Tags @('Duplicate','DuplicateSampleId') -Severity 'Warn' -Reason '' -SuggestedAction ''))
        }
    }

    foreach ($grp in ($Rows | Where-Object { $_.CartridgeSN } | Group-Object CartridgeSN | Where-Object { $_.Count -gt 1 })) {
        foreach ($row in $grp.Group) {
            $reportRows.Add((New-Info2Row -Row $row -Title '' -RuleId 'DuplicateCartridgeSN' -Tags @('Duplicate','DuplicateCartridgeSN') -Severity 'Warn' -Reason '' -SuggestedAction ''))
        }
    }

    $bagSets = @{}
    foreach ($row in $Rows) {
        $parts = $row.SampleDerived
        if (-not $parts -or -not $parts.Success) { continue }
        if ($parts.Prefix -notmatch '^(?i)c') { continue }
        if ($parts.SampleIndex -eq $null) { continue }
        $bagKey = "$($parts.Prefix)|$($parts.Bag)"
        if (-not $bagSets.ContainsKey($bagKey)) {
            $bagSets[$bagKey] = [ordered]@{
                Prefix = $parts.Prefix
                Bag    = $parts.Bag
                Samples = New-Object 'System.Collections.Generic.HashSet[int]'
                HasObsMatch = $false
            }
        }
        [void]$bagSets[$bagKey].Samples.Add($parts.SampleIndex)
        if ($parts.Obs -match '^D(\\d{2})$') {
            if ($matches[1] -eq $parts.Bag) { $bagSets[$bagKey].HasObsMatch = $true }
        }
    }

    foreach ($bagKey in $bagSets.Keys) {
        $bag = $bagSets[$bagKey]
        $min = [int]$settings.ExpectedSampleRange.Min
        $max = [int]$settings.ExpectedSampleRange.Max
        $skip = @()
        if ($settings.ExpectedSampleSkip) { $skip = @($settings.ExpectedSampleSkip) }
        if ($bag.HasObsMatch) { $max = [Math]::Max($max, 20) }
        if ($min -le 0 -or $max -lt $min) { continue }
        for ($i=$min; $i -le $max; $i++) {
            if ($skip -contains "$i") { continue }
            if (-not $bag.Samples.Contains($i)) {
                $hint = if ($incorrectBagFlags.ContainsKey($bagKey)) { 'May be incorrect Sample ID' } else { 'May be a Visual Failure' }
                $title = "Bag $($bag.Bag) missing sample number $i"
                $reportRows.Add((New-Info2NoteRow -Title $title -RuleId 'MissingSample' -Tags @('MissingSample') -Severity 'Warn' -Reason $hint -SuggestedAction '' -Hint $hint))
            }
        }
    }

    $prefixBuckets = @{}
    foreach ($row in $Rows) {
        if (-not $row.SampleID) { continue }
        $parts = $row.SampleDerived
        $prefix = if ($parts -and $parts.Prefix) { $parts.Prefix } else { '' }
        if (-not $prefix) { continue }
        if (-not $prefixBuckets.ContainsKey($prefix)) { $prefixBuckets[$prefix] = 0 }
        $prefixBuckets[$prefix]++
    }
    foreach ($k in ($prefixBuckets.Keys | Sort-Object)) {
        $reportRows.Add((New-Info2NoteRow -Title $k -RuleId 'ControlMaterials' -Tags @('ControlMaterial') -Severity 'Info' -Reason '' -SuggestedAction '' -Count ([int]$prefixBuckets[$k])))
    }

    return [pscustomobject]@{
        Assay = $assay
        Rows  = $reportRows.ToArray()
    }
}
