﻿if (-not $script:InputCache) {
    $script:InputCache = [ordered]@{
        Excel       = @{}
        CsvBundle   = @{}
        SummaryRows = @{}
        Opened      = @{}
        Parsed      = @{}
    }
}

function Reset-InputCache {
    $script:InputCache.Excel.Clear()
    $script:InputCache.CsvBundle.Clear()
    $script:InputCache.SummaryRows.Clear()
    $script:InputCache.Opened.Clear()
    $script:InputCache.Parsed.Clear()
}

function Get-InputOpenCounts {
    return $script:InputCache.Opened
}

function Add-OpenCount {
    param([string]$Path, [string]$Kind)
    if (-not $Path) { return }
    $key = $Path.ToLowerInvariant()
    if (-not $script:InputCache.Opened.ContainsKey($key)) {
        $script:InputCache.Opened[$key] = [ordered]@{ Kind = $Kind; Count = 0 }
    }
    $script:InputCache.Opened[$key].Count = [int]$script:InputCache.Opened[$key].Count + 1
}

# Returns the parse counts for all input files.  Each key is a lowercase
# file path, and the value is the number of times that file has been
# parsed during the current run.  See Add-ParseCount.
function Get-InputParseCounts {
    return $script:InputCache.Parsed
}

# Increments the parse count for the specified file path.  Use this
# inside any function that parses the contents of a file (e.g. CSV or
# Excel) to ensure that each file is parsed exactly once per run.  See
# Get-InputParseCounts to retrieve the counts.
function Add-ParseCount {
    param([string]$Path)
    if (-not $Path) { return }
    $key = $Path.ToLowerInvariant()
    if (-not $script:InputCache.Parsed.ContainsKey($key)) {
        $script:InputCache.Parsed[$key] = 0
    }
    $script:InputCache.Parsed[$key] = [int]$script:InputCache.Parsed[$key] + 1
}

function Get-ExcelPackageCached {
    param(
        [Parameter(Mandatory)][string]$Path,
        [string]$Kind = 'Excel'
    )
    $key = $Path.ToLowerInvariant()
    if ($script:InputCache.Excel.ContainsKey($key)) {
        return $script:InputCache.Excel[$key]
    }
    if (-not (Test-Path -LiteralPath $Path)) { throw "File not found: $Path" }
    Add-OpenCount -Path $Path -Kind $Kind
    Gui-Log ("📂 Öppnar {0}: {1}" -f $Kind, (Split-Path $Path -Leaf)) 'Info'
    $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($Path))
    $script:InputCache.Excel[$key] = $pkg
    return $pkg
}

function Get-TestsSummaryBundleCached {
    param([Parameter(Mandatory)][string]$Path)
    $key = $Path.ToLowerInvariant()
    if ($script:InputCache.CsvBundle.ContainsKey($key)) {
        return $script:InputCache.CsvBundle[$key]
    }
    Add-OpenCount -Path $Path -Kind 'CSV'
    $bundle = Get-TestsSummaryBundle -Path $Path
    $script:InputCache.CsvBundle[$key] = $bundle
    return $bundle
}

function Dispose-InputCache {
    foreach ($pkg in $script:InputCache.Excel.Values) {
        try { $pkg.Dispose() } catch {}
    }
    Reset-InputCache
}

function Convert-ToDoubleOrNull {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return $null }
    $t = ($Text + '').Trim()
    $t = $t -replace ',', '.'
    $v = $null
    if ([double]::TryParse($t, [System.Globalization.NumberStyles]::Any, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$v)) {
        return [double]$v
    }
    return $null
}

function Parse-ErrorCode {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return '' }
    $m = [regex]::Match($Text, '(?i)(?:Error\\s*)?(?<Code>[A-Z]{2}\\d{2,4}|\\d{3,5})')
    if ($m.Success) { return $m.Groups['Code'].Value }
    return ''
}

function Get-TestsSummaryRows {
    param(
        [Parameter(Mandatory)][string]$Path,
        [string]$SampleIdPattern
    )

    return Get-TestsSummaryRowsCached -Path $Path -SampleIdPattern $SampleIdPattern
}

function Get-TestsSummaryRowsCached {
    param(
        [Parameter(Mandatory)][string]$Path,
        [string]$SampleIdPattern
    )

    $key = $Path.ToLowerInvariant()
    if ($script:InputCache.SummaryRows.ContainsKey($key)) {
        $cached = $script:InputCache.SummaryRows[$key]
        if ($SampleIdPattern -and $cached.SampleIdPattern -and ($SampleIdPattern -ne $cached.SampleIdPattern)) {
            Gui-Log ("SampleIdPattern differs for cached Tests Summary: {0}" -f (Split-Path $Path -Leaf)) 'Warn'
        }
        return $cached.Rows
    }

    $rows = Get-TestsSummaryRowsCore -Path $Path -SampleIdPattern $SampleIdPattern
    $script:InputCache.SummaryRows[$key] = [pscustomobject]@{
        SampleIdPattern = $SampleIdPattern
        Rows            = $rows
    }
    return $rows
}

function Get-TestsSummaryRowsCore {
    param(
        [Parameter(Mandatory)][string]$Path,
        [string]$SampleIdPattern
    )

    $ext = [IO.Path]::GetExtension($Path).ToLowerInvariant()
    if ($ext -eq '.csv' -or $ext -eq '.txt') {
        return Get-TestsSummaryRowsFromCsv -Path $Path -SampleIdPattern $SampleIdPattern
    }
    return Get-TestsSummaryRowsFromExcel -Path $Path -SampleIdPattern $SampleIdPattern
}

function Get-TestsSummaryRowsFromCsv {
    param(
        [Parameter(Mandatory)][string]$Path,
        [string]$SampleIdPattern
    )

    # Count this parse of the CSV path
    Add-ParseCount -Path $Path
    $bundle = Get-TestsSummaryBundleCached -Path $Path
    if (-not $bundle -or -not $bundle.Lines) { return [pscustomobject]@{ Path=$Path; Rows=@(); Headers=@(); Meta=@{} } }

    $headers = $bundle.Headers
    $headerIndex = @{}
    for ($i=0; $i -lt $headers.Count; $i++) {
        $norm = Normalize-HeaderName $headers[$i]
        if (-not $headerIndex.ContainsKey($norm)) {
            $headerIndex[$norm] = $i
        }
    }

    $idxSample      = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('sample id','sampleid')
    $idxCartridge   = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('cartridge s/n','cartridge sn','cartridge serial')
    $idxTestType    = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('test type','testtype')
    $idxInstrument  = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('instrument s/n','instrument sn')
    $idxModule      = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('module s/n','module sn')
    $idxStartTime   = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('start time')
    $idxStatus      = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('status')
    $idxResult      = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('test result','result')
    $idxMaxPressure = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('max pressure (psi)','max pressure psi','max pressure')
    $idxError       = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('error','error code','error codes')
    $idxAssay       = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('assay')
    $idxAssayVer    = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('assay version')
    $idxLot         = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('reagent lot id','reagent lot')

    $firstAnalyteIdx = -1
    for ($i=0; $i -lt $headers.Count; $i++) {
        if ((Normalize-HeaderName $headers[$i]) -eq 'analyte name') { $firstAnalyteIdx = $i; break }
    }
    $spcCtIdx = if ($firstAnalyteIdx -ge 0) { $firstAnalyteIdx + 4 } else { -1 }

    $rows = New-Object System.Collections.Generic.List[object]
    $lines = $bundle.Lines
    for ($r = $bundle.DataStartRowIndex; $r -lt $lines.Count; $r++) {
        $ln = $lines[$r]
        if (-not $ln) { continue }
        $cols = Parse-CsvLine -line $ln -delim $bundle.Delimiter
        if (-not $cols -or ($cols -join '').Trim().Length -eq 0) { continue }

        $sampleId = if ($idxSample -ge 0 -and $cols.Count -gt $idxSample) { ($cols[$idxSample] + '').Trim() } else { '' }
        $derived = Parse-SampleIdDerived -SampleId $sampleId -Pattern $SampleIdPattern
        $parts = Convert-SampleIdDerivedToParts -Derived $derived

        $resultRaw = if ($idxResult -ge 0 -and $cols.Count -gt $idxResult) { ($cols[$idxResult] + '').Trim() } else { '' }
        $primary = ''
        if ($resultRaw) { $primary = ($resultRaw -split ';' | Select-Object -First 1).Trim() }

        $spcCt = $null
        if ($spcCtIdx -ge 0 -and $cols.Count -gt $spcCtIdx) {
            $spcCt = Convert-ToDoubleOrNull (($cols[$spcCtIdx] + '').Trim())
        }

        [void]$rows.Add([pscustomobject]@{
            RowIndex         = ($r + 1)
            SampleID         = $sampleId
            CartridgeSN      = if ($idxCartridge -ge 0 -and $cols.Count -gt $idxCartridge) { ($cols[$idxCartridge] + '').Trim() } else { '' }
            TestType         = if ($idxTestType -ge 0 -and $cols.Count -gt $idxTestType) { ($cols[$idxTestType] + '').Trim() } else { '' }
            InstrumentSN     = if ($idxInstrument -ge 0 -and $cols.Count -gt $idxInstrument) { ($cols[$idxInstrument] + '').Trim() } else { '' }
            ModuleSN         = if ($idxModule -ge 0 -and $cols.Count -gt $idxModule) { ($cols[$idxModule] + '').Trim() } else { '' }
            StartTime        = if ($idxStartTime -ge 0 -and $cols.Count -gt $idxStartTime) { ($cols[$idxStartTime] + '').Trim() } else { '' }
            Status           = if ($idxStatus -ge 0 -and $cols.Count -gt $idxStatus) { ($cols[$idxStatus] + '').Trim() } else { '' }
            TestResultRaw    = $resultRaw
            TestResultPrimary= $primary
            MaxPressure      = if ($idxMaxPressure -ge 0 -and $cols.Count -gt $idxMaxPressure) { Convert-ToDoubleOrNull (($cols[$idxMaxPressure] + '').Trim()) } else { $null }
            ErrorRaw         = if ($idxError -ge 0 -and $cols.Count -gt $idxError) { ($cols[$idxError] + '').Trim() } else { '' }
            ErrorCode        = Parse-ErrorCode -Text (if ($idxError -ge 0 -and $cols.Count -gt $idxError) { $cols[$idxError] } else { '' })
            SpcCt            = $spcCt
            Assay            = if ($idxAssay -ge 0 -and $cols.Count -gt $idxAssay) { ($cols[$idxAssay] + '').Trim() } else { '' }
            AssayVersion     = if ($idxAssayVer -ge 0 -and $cols.Count -gt $idxAssayVer) { ($cols[$idxAssayVer] + '').Trim() } else { '' }
            ReagentLotId     = if ($idxLot -ge 0 -and $cols.Count -gt $idxLot) { ($cols[$idxLot] + '').Trim() } else { '' }
            SampleDerived    = $derived
            SampleParts      = $parts
        })
    }

    return [pscustomobject]@{
        Path    = $Path
        Rows    = $rows.ToArray()
        Headers = $headers
        Meta    = @{}
    }
}

function Get-TestsSummaryRowsFromExcel {
    param(
        [Parameter(Mandatory)][string]$Path,
        [string]$SampleIdPattern
    )

    # Count this parse of the Excel tests summary path
    Add-ParseCount -Path $Path
    $pkg = Get-ExcelPackageCached -Path $Path -Kind 'Tests Summary'
    $ws = $pkg.Workbook.Worksheets | Select-Object -First 1
    if (-not $ws -or -not $ws.Dimension) { return [pscustomobject]@{ Path=$Path; Rows=@(); Headers=@(); Meta=@{} } }

    $maxRow = $ws.Dimension.End.Row
    $maxCol = $ws.Dimension.End.Column

    $headerRow = 1
    $delimHit = 0
    for ($r=1; $r -le [Math]::Min(80, $maxRow); $r++) {
        $hits = 0
        for ($c=1; $c -le $maxCol; $c++) {
            $t = ($ws.Cells[$r,$c].Text + '').Trim()
            if (-not $t) { continue }
            $h = Normalize-HeaderName $t
            if ($h -in @('assay','assay version','reagent lot id','sample id','cartridge s/n')) { $hits++ }
        }
        if ($hits -ge 3) { $headerRow = $r; $delimHit = $hits; break }
    }

    $headers = @()
    for ($c=1; $c -le $maxCol; $c++) {
        $headers += ($ws.Cells[$headerRow,$c].Text + '')
    }
    $headerIndex = @{}
    for ($i=0; $i -lt $headers.Count; $i++) {
        $norm = Normalize-HeaderName $headers[$i]
        if (-not $headerIndex.ContainsKey($norm)) { $headerIndex[$norm] = $i }
    }

    $idxSample      = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('sample id','sampleid')
    $idxCartridge   = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('cartridge s/n','cartridge sn','cartridge serial')
    $idxTestType    = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('test type','testtype')
    $idxInstrument  = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('instrument s/n','instrument sn')
    $idxModule      = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('module s/n','module sn')
    $idxStartTime   = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('start time')
    $idxStatus      = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('status')
    $idxResult      = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('test result','result')
    $idxMaxPressure = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('max pressure (psi)','max pressure psi','max pressure')
    $idxError       = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('error','error code','error codes')
    $idxAssay       = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('assay')
    $idxAssayVer    = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('assay version')
    $idxLot         = Get-HeaderIndexValue -HeaderIndex $headerIndex -Keys @('reagent lot id','reagent lot')

    $firstAnalyteIdx = -1
    for ($i=0; $i -lt $headers.Count; $i++) {
        if ((Normalize-HeaderName $headers[$i]) -eq 'analyte name') { $firstAnalyteIdx = $i; break }
    }
    $spcCtIdx = if ($firstAnalyteIdx -ge 0) { $firstAnalyteIdx + 4 } else { -1 }

    $rows = New-Object System.Collections.Generic.List[object]
    $startRow = $headerRow + 1
    for ($r = $startRow; $r -le $maxRow; $r++) {
        $sampleId = if ($idxSample -ge 0) { ($ws.Cells[$r,$idxSample+1].Text + '').Trim() } else { '' }
        if (-not $sampleId) { continue }

        $derived = Parse-SampleIdDerived -SampleId $sampleId -Pattern $SampleIdPattern
        $parts = Convert-SampleIdDerivedToParts -Derived $derived
        $resultRaw = if ($idxResult -ge 0) { ($ws.Cells[$r,$idxResult+1].Text + '').Trim() } else { '' }
        $primary = ''
        if ($resultRaw) { $primary = ($resultRaw -split ';' | Select-Object -First 1).Trim() }

        $spcCt = $null
        if ($spcCtIdx -ge 0) {
            $spcCt = Convert-ToDoubleOrNull (($ws.Cells[$r,$spcCtIdx+1].Text + '').Trim())
        }

        [void]$rows.Add([pscustomobject]@{
            RowIndex          = $r
            SampleID          = $sampleId
            CartridgeSN       = if ($idxCartridge -ge 0) { ($ws.Cells[$r,$idxCartridge+1].Text + '').Trim() } else { '' }
            TestType          = if ($idxTestType -ge 0) { ($ws.Cells[$r,$idxTestType+1].Text + '').Trim() } else { '' }
            InstrumentSN      = if ($idxInstrument -ge 0) { ($ws.Cells[$r,$idxInstrument+1].Text + '').Trim() } else { '' }
            ModuleSN          = if ($idxModule -ge 0) { ($ws.Cells[$r,$idxModule+1].Text + '').Trim() } else { '' }
            StartTime         = if ($idxStartTime -ge 0) { ($ws.Cells[$r,$idxStartTime+1].Text + '').Trim() } else { '' }
            Status            = if ($idxStatus -ge 0) { ($ws.Cells[$r,$idxStatus+1].Text + '').Trim() } else { '' }
            TestResultRaw     = $resultRaw
            TestResultPrimary = $primary
            MaxPressure       = if ($idxMaxPressure -ge 0) { Convert-ToDoubleOrNull (($ws.Cells[$r,$idxMaxPressure+1].Text + '').Trim()) } else { $null }
            ErrorRaw          = if ($idxError -ge 0) { ($ws.Cells[$r,$idxError+1].Text + '').Trim() } else { '' }
            ErrorCode         = Parse-ErrorCode -Text (if ($idxError -ge 0) { $ws.Cells[$r,$idxError+1].Text } else { '' })
            SpcCt             = $spcCt
            Assay             = if ($idxAssay -ge 0) { ($ws.Cells[$r,$idxAssay+1].Text + '').Trim() } else { '' }
            AssayVersion      = if ($idxAssayVer -ge 0) { ($ws.Cells[$r,$idxAssayVer+1].Text + '').Trim() } else { '' }
            ReagentLotId      = if ($idxLot -ge 0) { ($ws.Cells[$r,$idxLot+1].Text + '').Trim() } else { '' }
            SampleDerived     = $derived
            SampleParts       = $parts
        })
    }

    return [pscustomobject]@{
        Path    = $Path
        Rows    = $rows.ToArray()
        Headers = $headers
        Meta    = @{}
    }
}
