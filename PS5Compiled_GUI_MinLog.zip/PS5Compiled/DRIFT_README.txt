DRIFT-paket (compiled RuleBank only)

Detta paket är avsett för körning av kollegor från N:.
RuleBank laddas endast från 'RuleBank\RuleBank.compiled.psd1' (inget CSV-fallback behövs i drift).

Om regler behöver uppdateras:
- använd DEV/QA-paketet med CSV + Build-RuleBank.ps1 för att generera en ny RuleBank.compiled.psd1
- ersätt sedan RuleBank\RuleBank.compiled.psd1 i denna DRIFT-mapp

