param(
    [string]$Root = $PSScriptRoot
)

# Verify that all PowerShell scripts and data files have UTF-8 BOM and CRLF
# line endings only.  Scans recursively for .ps1, .psm1, and .psd1 files
# beneath the specified root.  Prints PASS/FAIL per file and exits with
# non-zero status if any file fails the checks.

$fails = 0
$files = Get-ChildItem -LiteralPath $Root -Recurse -Force |
    Where-Object {
        ($_.Extension -in '.ps1','.psm1','.psd1') -and -not $_.PSIsContainer
    }
foreach ($file in $files) {
    try {
        $bytes = [System.IO.File]::ReadAllBytes($file.FullName)
        $hasBom = $false
        if ($bytes.Length -ge 3) {
            if ($bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
                $hasBom = $true
            }
        }
        $mixedLf = $false
        $prevWasCr = $false
        for ($i = 0; $i -lt $bytes.Length; $i++) {
            $b = $bytes[$i]
            if ($b -eq 0x0A) {
                if (-not $prevWasCr) { $mixedLf = $true; break }
            }
            $prevWasCr = ($b -eq 0x0D)
        }
        $status = 'PASS'
        $reasons = @()
        if (-not $hasBom) { $status = 'FAIL'; $reasons += 'MissingBOM' }
        if ($mixedLf) { $status = 'FAIL'; $reasons += 'MixedLineEndings' }
        if ($status -eq 'PASS') {
            Write-Output ("PASS: {0}" -f $file.FullName)
        } else {
            Write-Output ("FAIL: {0} ({1})" -f $file.FullName, ($reasons -join ','))
            $fails++
        }
    } catch {
        Write-Output ("FAIL: {0} (Exception: {1})" -f $file.FullName, $_.Exception.Message)
        $fails++
    }
}
if ($fails -gt 0) {
    exit 1
} else {
    exit 0
}