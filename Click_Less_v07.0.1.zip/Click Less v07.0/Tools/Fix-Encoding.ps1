﻿#requires -Version 5.1
<#
Fix-Encoding.ps1
- Enforces UTF-8 BOM + CRLF on .ps1/.psm1/.psd1
- Guardrail: if file contains suspicious long base64/cert blocks, DO NOT normalize line endings;
  only ensure UTF-8 BOM. This avoids breaking here-string certificate content.
#>

param(
  [Parameter(Mandatory=$false)]
  [string]$Root = (Split-Path -Parent $MyInvocation.MyCommand.Path),

  [Parameter(Mandatory=$false)]
  [string[]]$Include = @("*.ps1","*.psm1","*.psd1")
)

function Test-HasBase64Block {
  param([string]$Text)
  if ($Text -match "@'[\s\S]{0,200}([A-Za-z0-9+/=]{200,})[\s\S]{0,200}'@") { return $true }
  if ($Text -match '@"[\s\S]{0,200}([A-Za-z0-9+/=]{200,})[\s\S]{0,200}"@') { return $true }
  return $false
}

$utf8Bom = New-Object System.Text.UTF8Encoding($true)

Get-ChildItem -Path $Root -Recurse -File | Where-Object {
  $name = $_.Name
  foreach ($pat in $Include) {
    if ($name -like $pat) { return $true }
  }
  return $false
} | ForEach-Object {
  $path = $_.FullName
  $bytes = [System.IO.File]::ReadAllBytes($path)
  $text = [System.Text.Encoding]::UTF8.GetString($bytes)

  $hasBase64 = Test-HasBase64Block -Text $text

  if (-not $hasBase64) {
    $text = $text -replace "`r`n","`n"
    $text = $text -replace "`r","`n"
    $text = $text -replace "`n","`r`n"
  }

  [System.IO.File]::WriteAllText($path, $text, $utf8Bom)
  Write-Host ("Fixed: {0} (Base64Guard={1})" -f $path, $hasBase64)
}
