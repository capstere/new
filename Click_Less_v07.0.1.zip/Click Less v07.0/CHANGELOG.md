# Changelog

## v07.0.1

- Enforced UTF‑8 with BOM and CRLF line endings across all script and data files.  Added strict
  encoding fixer and verifier scripts under `Tools/` to validate and repair encoding.
- Refactored worksheet handling so the LSP worksheet is opened only once via
  `Get‑ExcelPackageCached`.  Removed duplicate package opens and related disposals.
- Information2 sheet now follows the compact gold layout: eleven sections in a fixed order
  with blank rows between, sorted as specified, and written in bulk without AutoFit.
- Added hidden `TestsSummary_Raw` sheet containing the raw test summary rows and created
  internal hyperlinks from the first column of Information2 back to the raw data rows.
- Implemented open/parse count auditing and added a Definition‑of‑Done footer that logs
  workflow, open‑once status, rule profile, and top timer metrics.
- Added `Tools/Fix‑Encoding‑Strict.ps1` and `Tools/Verify‑Encoding.ps1` to normalize
  encoding and verify compliance.
- Bumped script version to `v07.0.1` in configuration; no changes to GUI workflow or
  business logic.