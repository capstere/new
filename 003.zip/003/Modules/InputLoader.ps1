﻿function Initialize-InputCache {
    if (-not $script:InputCache) {
        $script:InputCache = [ordered]@{
            Excel = @{}
            Csv   = @{}
        }
    }
}

function Get-InputExcelPackage {
    param([Parameter(Mandatory = $true)][string]$Path)

    Initialize-InputCache
    if (-not (Test-Path -LiteralPath $Path)) { throw "Excel-fil saknas: $Path" }

    $key = $Path.ToLowerInvariant()
    $fi = Get-Item -LiteralPath $Path -ErrorAction SilentlyContinue
    $stamp = if ($fi) { $fi.LastWriteTimeUtc.Ticks } else { 0 }
    $cached = $script:InputCache.Excel[$key]

    if ($cached -and $cached.Stamp -eq $stamp -and $cached.Package) {
        return $cached.Package
    }

    if ($cached -and $cached.Package) { try { $cached.Package.Dispose() } catch {} }

    $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($Path))
    $script:InputCache.Excel[$key] = [pscustomobject]@{ Stamp = $stamp; Package = $pkg }
    return $pkg
}

function Get-InputCsvBundle {
    param([Parameter(Mandatory = $true)][string]$Path)

    Initialize-InputCache
    if (-not (Test-Path -LiteralPath $Path)) { throw "CSV saknas: $Path" }

    $key = $Path.ToLowerInvariant()
    $fi = Get-Item -LiteralPath $Path -ErrorAction SilentlyContinue
    $stamp = if ($fi) { $fi.LastWriteTimeUtc.Ticks } else { 0 }
    $cached = $script:InputCache.Csv[$key]

    if ($cached -and $cached.Stamp -eq $stamp -and $cached.Bundle) {
        return $cached.Bundle
    }

    $bundle = Get-TestsSummaryBundle -Path $Path
    $script:InputCache.Csv[$key] = [pscustomobject]@{ Stamp = $stamp; Bundle = $bundle }
    return $bundle
}

function Clear-InputCache {
    Initialize-InputCache
    foreach ($entry in $script:InputCache.Excel.Values) {
        if ($entry -and $entry.Package) { try { $entry.Package.Dispose() } catch {} }
    }
    $script:InputCache.Excel.Clear()
    $script:InputCache.Csv.Clear()
}
