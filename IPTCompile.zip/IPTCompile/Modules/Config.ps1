<# 
Config.ps1 (Smart cleanup + strict diff-patch applied)
- PowerShell 5.1 compatible
- Same logic/behavior as before, with these STRICT patch changes:
  1) Get-EnvNonEmpty uses [Environment]::GetEnvironmentVariable()
  2) Adds Resolve-LocalFirstFile (ScriptRoot\Assets\... first, else network + Resolve-IptPath)
  3) UtrustningListPath & RawDataPath now use Resolve-LocalFirstFile with Assets\... fallback
#>

param(
    [string]$ScriptRoot = (Split-Path -Parent $MyInvocation.MyCommand.Path)
)

# -----------------------------
# Root / path resolve utilities
# -----------------------------
$script:ScriptRoot = $ScriptRoot

# Normalize once (avoid trailing slash differences)
$script:DefaultIptRoot = '\\SE.CEPHEID.PRI\Cepheid Sweden\QC\QC-1\QC-1\IPT'.TrimEnd('\')

function Get-EnvNonEmpty {
    param([Parameter(Mandatory=$true)][string]$Name)
    # PS 5.1 safe: dynamic env var lookup
    try {
        $v = [Environment]::GetEnvironmentVariable($Name)
    } catch {
        $v = $null
    }
    if ([string]::IsNullOrWhiteSpace($v)) { return '' }
    return $v.Trim()
}

# Decide effective IPT root (single Test-Path)
$envIptRaw = Get-EnvNonEmpty -Name 'IPT_ROOT'
$candidate = if ($envIptRaw) { $envIptRaw.TrimEnd('\') } else { '' }

$script:CandidateExists = $false
if ($candidate) {
    try { $script:CandidateExists = (Test-Path -LiteralPath $candidate) } catch { $script:CandidateExists = $false }
}

$script:IPTRoot = if ($candidate -and $script:CandidateExists) { $candidate } else { $script:DefaultIptRoot }

# Expose for debug/logging (same meaning as before)
$global:IPT_ROOT_EFFECTIVE = $script:IPTRoot
$global:IPT_ROOT_SOURCE = if ($envIptRaw) {
    if ($candidate -and $script:CandidateExists) { 'ENV' } else { 'ENV_INVALID_FALLBACK' }
} else {
    'DEFAULT'
}

function Resolve-IptPath {
    param([string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) { return $Path }

    # Stable, wildcard-safe, case-insensitive check
    if ($Path.StartsWith($script:DefaultIptRoot + '\', [System.StringComparison]::OrdinalIgnoreCase) -or
    $Path.Equals($script:DefaultIptRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
        return ($script:IPTRoot + $Path.Substring($script:DefaultIptRoot.Length))
    }
    return $Path
}

function Resolve-IptPathList {
    param([object[]]$Paths)
    if ($null -eq $Paths) { return @() }
    $out = New-Object System.Collections.Generic.List[string]
    foreach ($p in $Paths) {
        if ($null -eq $p) { continue }
        $s = [string]$p
        if ([string]::IsNullOrWhiteSpace($s)) { continue }
        $out.Add((Resolve-IptPath $s))
    }
    return $out.ToArray()
}

# -------------------------------------------------
# Local-first resolver for project-copied assets
# - Tries ScriptRoot\<LocalRelativePath> first
# - Falls back to the provided NetworkPath (and applies Resolve-IptPath)
# -------------------------------------------------
function Resolve-LocalFirstFile {
    param(
        [Parameter(Mandatory=$true)][string]$LocalRelativePath,
        [Parameter(Mandatory=$true)][string]$NetworkPath
    )
    try {
        $local = Join-Path $script:ScriptRoot $LocalRelativePath
        if (Test-Path -LiteralPath $local) { return $local }
    } catch { }
    return (Resolve-IptPath $NetworkPath)
}

# -----------------------------
# Settings (unchanged semantics)
# -----------------------------
$ScriptVersion = "v45.1.0"

# Build roots using DefaultIptRoot, then resolve via ENV override
$RootPaths = @(
    (Join-Path $script:DefaultIptRoot 'Skiftspecifika dokument\PQC analyst\JESPER\Scripts\Tests'),
    (Join-Path $script:DefaultIptRoot '3. IPT - KLART FÖR SAMMANSTÄLLNING'),
    (Join-Path $script:DefaultIptRoot '4. IPT - KLART FÖR GRANSKNING')
)
$RootPaths = Resolve-IptPathList $RootPaths

# Local assets (do NOT need Resolve-IptPath because they are ScriptRoot-based)
$ikonSokvag = Join-Path $ScriptRoot "icon.png"

# Network files (built from DefaultIptRoot, then resolved)
$UtrustningListPath = Resolve-LocalFirstFile `
    -LocalRelativePath 'Assets\Utrustninglista5.0.xlsx' `
    -NetworkPath (Join-Path $script:DefaultIptRoot 'Skiftspecifika dokument\PQC analyst\JESPER\Scripts\Click Less Project\Utrustninglista5.0.xlsx')

$RawDataPath        = Resolve-LocalFirstFile `
    -LocalRelativePath 'Assets\KONTROLLPROVSFIL - Version 2.5.xlsm' `
    -NetworkPath (Join-Path $script:DefaultIptRoot 'KONTROLLPROVSFIL - Version 2.5.xlsm')

$OtherScriptPath = ''  # kept as-is

$Script1Path = Resolve-IptPath (Join-Path $script:DefaultIptRoot 'Skiftspecifika dokument\PQC analyst\JESPER\Kontrollprovsfil 2025\Script Raw Data\Kontrollprovsfil_EPPlus_2025.ps1')
$Script2Path = Resolve-IptPath (Join-Path $script:DefaultIptRoot 'Skiftspecifika dokument\PQC analyst\JESPER\Scripts\Click Less Project\rename-GUI.bat')
$Script3Path = Resolve-IptPath (Join-Path $script:DefaultIptRoot 'Skiftspecifika dokument\PQC analyst\JESPER\Scripts\Click Less Project\rename-GUI.bat')

# SharePoint / PnP settings (unchanged)
$env:PNPPOWERSHELL_UPDATECHECK = "Off"
$global:SP_ClientId   = "INSERT MYSELF"
$global:SP_Tenant     = "danaher.onmicrosoft.com"
$global:SP_CertBase64 = "INSERT MYSELF"
$global:SP_SiteUrl    = "https://danaher.sharepoint.com/sites/CEP-Sweden-Production-Management"

# Central config (unchanged keys/values)
$Config = [ordered]@{
    # Feature flags (safe defaults)
    EnableEquipmentSheet          = $false
    EnableEquipmentScan           = $false
    EnableRuleEngine              = $true
    EnableShadowCompare           = $true
    EnableRuleEngineSummaryLog    = $false
    EnableRuleEngineDebugSheet    = $true
    RuleEngineDebugIncludeAllRows = $false

    # EPPlus AutoFit strategy (performance)
    EpplusAutoFitMode    = 'SMART'
    EpplusAutoFitMaxRows = 500

    # RuleBank
    RuleBankDir = (Join-Path $ScriptRoot 'RuleBank')
    RuleBankRequireCompiled = $true

    # CSV
    CsvStreamingThresholdMB = 25
    CsvPath        = ''
    SealNegPath    = ''
    SealPosPath    = ''
    WorksheetPath  = ''

    # SharePoint config
    SiteUrl      = $global:SP_SiteUrl
    Tenant       = $global:SP_Tenant
    ClientId     = $global:SP_ClientId
    Certificate  = $global:SP_CertBase64

    # EPPlus
    EpplusDllPath = (Join-Path $ScriptRoot 'Modules\EPPlus.dll')
    EpplusVersion = '4.5.3.3'
    AllowNuGetDownload = $false
}

# Expose config globally (back-compat)
try { $global:Config = $Config } catch {}

# GX/INF map (unchanged)
$script:GXINF_Map = @{
    'Infinity-VI'   = '847922'
    'Infinity-VIII' = '803094'
    'GX5'           = '750210,750211,750212,750213'
    'GX6'           = '750246,750247,750248,750249'
    'GX1'           = '709863,709864,709865,709866'
    'GX2'           = '709951,709952,709953,709954'
    'GX3'           = '710084,710085,710086,710087'
    'GX7'           = '750170,750171,750172,750213'
    'Infinity-I'    = '802069'
    'Infinity-III'  = '807363'
    'Infinity-V'    = '839032'
}

$SharePointBatchLinkTemplate = 'https://danaher.sharepoint.com/sites/CEP-Sweden-Production-Management/Lists/Cepheid%20%20Production%20orders/ROBAL.aspx?viewid=6c9e53c9-a377-40c1-a154-13a13866b52b&view=7&q={BatchNumber}'

# -----------------------------
# Log dir selection (unchanged)
# -----------------------------
$netRootForLogs = (Get-EnvNonEmpty -Name 'IPT_NETWORK_ROOT')
if ($netRootForLogs -and (Test-Path -LiteralPath $netRootForLogs)) {
    $DevLogDir = Join-Path $netRootForLogs 'Loggar'
} else {
    $DevLogDir = Join-Path $ScriptRoot 'Loggar'
}
if (-not (Test-Path -LiteralPath $DevLogDir)) {
    New-Item -ItemType Directory -Path $DevLogDir -Force | Out-Null
}

$global:LogPath = Join-Path $DevLogDir ("$($env:USERNAME)_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt")
$global:StructuredLogPath = [System.IO.Path]::ChangeExtension($global:LogPath, '.jsonl')

# -----------------------------
# Config self-test (unchanged)
# -----------------------------
function Test-Config {
    $result = [pscustomobject]@{
        Ok       = $true
        Errors   = New-Object System.Collections.Generic.List[object]
        Warnings = New-Object System.Collections.Generic.List[object]
    }

    try {
        $templatePath = Join-Path $ScriptRoot 'output_template-v4.xlsx'
        if (-not (Test-Path -LiteralPath $templatePath)) {
            $null = $result.Errors.Add("Mallfil saknas: $templatePath")
        }
    } catch {
        $null = $result.Errors.Add("Test-Config (template): $($_.Exception.Message)")
    }

    try {
        if (-not (Test-Path -LiteralPath $UtrustningListPath)) {
            $null = $result.Warnings.Add("Utrustningslista saknas: $UtrustningListPath")
        }
    } catch {
        $null = $result.Warnings.Add("Test-Config (utrustning): $($_.Exception.Message)")
    }

    try {
        if (-not (Test-Path -LiteralPath $RawDataPath)) {
            $null = $result.Warnings.Add("Kontrollprovsfil saknas: $RawDataPath")
        }
    } catch {
        $null = $result.Warnings.Add("Test-Config (rawdata): $($_.Exception.Message)")
    }

    try {
        if (-not (Test-Path -LiteralPath $DevLogDir)) {
            New-Item -ItemType Directory -Path $DevLogDir -Force | Out-Null
        }
        $probe = Join-Path $DevLogDir "write_probe.txt"
        Set-Content -Path $probe -Value 'probe' -Encoding UTF8 -Force
        Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
    } catch {
        $null = $result.Warnings.Add("Kunde inte verifiera skrivning till loggmapp: $($_.Exception.Message)")
    }

    if ($result.Errors.Count -gt 0) { $result.Ok = $false }
    return $result
}