/* ClickLess Offline Analyzer v7 (CSV)
   - ES5 only (no const/let/arrow/template/module/async)
   - Offline XLSX reader: ZIP + raw DEFLATE (inflateRaw)
   - Reads: Seal Test NEG/POS (.xlsx), Worksheet (.xlsx), Test Summary (.csv)
   - Shows results on the page (no downloads).
*/

(function () {
  'use strict';

  // ----------------------------
  // DOM helpers
  // ----------------------------
  function $(id) { return document.getElementById(id); }

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    if (attrs) {
      for (var k in attrs) {
        if (!attrs.hasOwnProperty(k)) continue;
        if (k === 'text') node.textContent = String(attrs[k]);
        else if (k === 'html') node.innerHTML = String(attrs[k]);
        else if (k === 'class') node.className = String(attrs[k]);
        else if (k === 'style') node.setAttribute('style', String(attrs[k]));
        else node.setAttribute(k, String(attrs[k]));
      }
    }
    if (children && children.length) {
      for (var i = 0; i < children.length; i++) node.appendChild(children[i]);
    }
    return node;
  }

  function clearNode(node) { while (node.firstChild) node.removeChild(node.firstChild); }

  function pill(text, kind) {
    var cls = 'pill';
    if (kind === 'ok') cls += ' ok';
    else if (kind === 'bad') cls += ' bad';
    else if (kind === 'warn') cls += ' warn';
    return el('span', { 'class': cls, text: text });
  }

  function setStatus(msg, isError) {
    var s = $('status');
    s.textContent = msg || '';
    s.className = 'small ' + (isError ? 'err' : 'muted');
  }

  // ----------------------------
  // File registry + detection
  // ----------------------------
  var TYPE_OPTIONS = [
    { key: 'auto', label: 'Auto' },
    { key: 'sealNeg', label: 'Seal Test NEG (xlsx)' },
    { key: 'sealPos', label: 'Seal Test POS (xlsx)' },
    { key: 'worksheet', label: 'Worksheet (xlsx)' },
    { key: 'testSummary', label: 'Test Summary (csv/xlsx)' }
  ];

  var files = []; // {file, typeKey, detectedKey}

  function detectTypeByName(name) {
    var n = (name || '').toLowerCase();
    if (n.indexOf('seal test') >= 0 && (n.indexOf('neg') >= 0 || n.indexOf('negative') >= 0)) return 'sealNeg';
    if (n.indexOf('seal test') >= 0 && (n.indexOf('pos') >= 0 || n.indexOf('positive') >= 0)) return 'sealPos';
    if (n.indexOf('worksheet') >= 0) return 'worksheet';
    if (n.indexOf('test summary') >= 0 || n.indexOf('tests summary') >= 0 || n.slice(-4) === '.csv') return 'testSummary';
    if (n.slice(-4) === '.csv') return 'testSummary';
    if (n.slice(-5) === '.xlsx') return 'auto';
    return 'auto';
  }

  // ----------------------------
  // Zip bundle support (Alternative 2)
  // Drop 1 .zip containing the 4 required files.
  // Requires JSZip (loaded via index.html)
  // ----------------------------
  function isZipFile(file) {
    if (!file) return false;
    var n = (file.name || '').toLowerCase();
    if (n.slice(-4) === '.zip') return true;
    var t = (file.type || '').toLowerCase();
    if (t.indexOf('zip') >= 0) return true;
    return false;
  }

  function makeFileLike(data, name, mime) {
    var opts = mime ? { type: mime } : {};
    try {
      return new File([data], name, opts);
    } catch (e) {
      var b = new Blob([data], opts);
      b.name = name;
      return b;
    }
  }

  function readAsArrayBuffer(file) {
    // Prefer modern File/Blob.arrayBuffer, fallback to FileReader
    if (file && typeof file.arrayBuffer === 'function') {
      return file.arrayBuffer();
    }
    return new Promise(function (resolve, reject) {
      try {
        var fr = new FileReader();
        fr.onload = function () { resolve(fr.result); };
        fr.onerror = function () { reject(fr.error || new Error('FileReader error')); };
        fr.readAsArrayBuffer(file);
      } catch (e) {
        reject(e);
      }
    });
  }

  function extractBundleFilesFromZip(zipFile) {
    if (typeof JSZip === 'undefined') {
      return Promise.reject(new Error('JSZip not loaded'));
    }

    return readAsArrayBuffer(zipFile).then(function (buf) {
      return JSZip.loadAsync(buf);
    }).then(function (zip) {
      var picked = { sealNeg: null, sealPos: null, worksheet: null, testSummary: null };

      zip.forEach(function (relPath, entry) {
        if (!entry || entry.dir) return;
        if (relPath.indexOf('__MACOSX/') === 0) return;

        var base = relPath.split('/').pop();
        if (!base) return;
        if (base.indexOf('._') === 0) return;

        var det = detectTypeByName(base);
        if (!picked[det]) {
          picked[det] = { base: base, entry: entry };
        }
      });

      var out = [];
      var tasks = [];

      function pushPicked(key, mime) {
        if (!picked[key]) return;
        tasks.push(
          picked[key].entry.async('arraybuffer').then(function (ab) {
            out.push(makeFileLike(ab, picked[key].base, mime));
          })
        );
      }

      pushPicked('sealNeg', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      pushPicked('sealPos', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      pushPicked('worksheet', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      pushPicked('testSummary', 'text/csv');

      return Promise.all(tasks).then(function () { return out; });
    });
  }


  function typeLabel(key) {
    for (var i = 0; i < TYPE_OPTIONS.length; i++) if (TYPE_OPTIONS[i].key === key) return TYPE_OPTIONS[i].label;
    return key;
  }

  function refreshFileList() {
    var list = $('fileList');
    clearNode(list);

    if (!files.length) {
      list.appendChild(el('div', { 'class': 'small muted', text: 'Inga filer valda.' }));
      $('runBtn').disabled = true;
      return;
    }

    var tbl = el('table');
    var thead = el('thead');
    var trh = el('tr');
    trh.appendChild(el('th', { text: 'Fil' }));
    trh.appendChild(el('th', { text: 'Detekterad typ' }));
    trh.appendChild(el('th', { text: 'Anvand som' }));
    trh.appendChild(el('th', { text: '' }));
    thead.appendChild(trh);
    tbl.appendChild(thead);

    var tbody = el('tbody');
    for (var i = 0; i < files.length; i++) {
      (function (idx) {
        var f = files[idx];
        var tr = el('tr');

        tr.appendChild(el('td', { 'class': 'mono', text: f.file.name }));
        tr.appendChild(el('td', { text: typeLabel(f.detectedKey) }));

        var sel = el('select');
        for (var j = 0; j < TYPE_OPTIONS.length; j++) {
          var opt = el('option', { value: TYPE_OPTIONS[j].key, text: TYPE_OPTIONS[j].label });
          if (TYPE_OPTIONS[j].key === f.typeKey) opt.selected = true;
          sel.appendChild(opt);
        }
        sel.addEventListener('change', function () { files[idx].typeKey = sel.value; validateReady(); });
        tr.appendChild(el('td', null, [sel]));

        var rm = el('button', { 'class': 'btn2', type: 'button', text: 'Ta bort' });
        rm.addEventListener('click', function () { files.splice(idx, 1); refreshFileList(); validateReady(); });
        tr.appendChild(el('td', null, [rm]));

        tbody.appendChild(tr);
      })(i);
    }
    tbl.appendChild(tbody);
    list.appendChild(tbl);

    validateReady();
  }

    function validateReady() {
    var want = { sealNeg: 0, sealPos: 0, worksheet: 0, testSummary: 0 };
    for (var i = 0; i < files.length; i++) {
      var tk = files[i].typeKey;
      if (tk === 'auto') tk = files[i].detectedKey;
      if (want.hasOwnProperty(tk)) want[tk]++;
    }

    // v7: CSV validation is the first milestone — only require Test Summary for now.
    var okCsv = (want.testSummary >= 1);
    $('runBtn').disabled = !okCsv;

    if (!okCsv) {
      setStatus('Välj minst 1 fil: Test Summary (csv).', false);
      return;
    }

    // If other files are missing, we still run CSV-only and show a note.
    var missing = [];
    if (want.sealNeg < 1) missing.push('Seal NEG');
    if (want.sealPos < 1) missing.push('Seal POS');
    if (want.worksheet < 1) missing.push('Worksheet');

    if (missing.length) {
      setStatus('Redo för CSV-validering. (XLSX-delar saknas: ' + missing.join(', ') + ')', false);
    } else {
      setStatus('Redo. Klicka "Kör analys".', false);
    }
  }


  function addFiles(fileList) {
    if (!fileList || !fileList.length) return;

    var incoming = [];
    var tasks = [];

    for (var i = 0; i < fileList.length; i++) {
      var f = fileList[i];
      if (!f) continue;

      if (isZipFile(f)) {
        (function (zipF) {
          setStatus('Reading zip bundle: ' + (zipF.name || 'bundle.zip') + ' ...', false);
          tasks.push(
            extractBundleFilesFromZip(zipF).then(function (extracted) {
              if (extracted && extracted.length) {
                for (var j = 0; j < extracted.length; j++) incoming.push(extracted[j]);
              } else {
                setStatus('Zip did not contain recognizable files: ' + (zipF.name || ''), true);
              }
            }).catch(function (e) {
              var msg = (e && e.message) ? e.message : String(e);
              setStatus('Could not read zip: ' + (zipF.name || '') + ' (' + msg + ')', true);
            })
          );
        })(f);
        continue;
      }

      incoming.push(f);
    }

    Promise.all(tasks).then(function () {
      for (var k = 0; k < incoming.length; k++) {
        var ff = incoming[k];
        var detected = detectTypeByName(ff.name || '');
        files.push({ file: ff, typeKey: 'auto', detectedKey: detected });
      }

      refreshFileList();
      setStatus('', false);
    });
  }

  // ----------------------------
  // CSV parse
  // ----------------------------
    // ----------------------------
  // CSV parse + validation (Test Summary)
  // ----------------------------
  function analyzeTestSummaryTable(headers, rows, extra) {
  extra = extra || {};

  function safeCol(cols, idx) {
    if (idx < 0) return '';
    var v = (idx < cols.length) ? cols[idx] : '';
    if (v === null || typeof v === 'undefined') return '';
    return String(v);
  }

  function parseSampleId(sampleId) {
    sampleId = String(sampleId || '');
    var parts = sampleId.split('_');
    var bag = null;
    var ctrl = '';
    var pos = '';
    if (parts.length >= 2) {
      var bn = parseInt(parts[1], 10);
      if (!isNaN(bn)) bag = bn;
    }
    if (parts.length >= 3) ctrl = String(parts[2] || '');
    if (parts.length >= 4) pos = String(parts[3] || '');
    return { raw: sampleId, prefix: String(parts[0] || ''), bag: bag, ctrl: ctrl, pos: pos };
  }

  function incMap(map, key) { map[key] = (map[key] || 0) + 1; }

  function makeDuplicates(counts) {
    var out = [];
    for (var k in counts) {
      if (!counts.hasOwnProperty(k)) continue;
      if (counts[k] > 1) out.push({ value: k, count: counts[k] });
    }
    out.sort(function (a, b) { return b.count - a.count; });
    return out;
  }

  // --- index lookup
  var idxAssay = findHeader(headers, /^assay$/i);
  var idxAssayVer = findHeader(headers, /^assay version$/i);
  var idxSample = findHeader(headers, /^sample id$/i);
  var idxCart = findHeader(headers, /^cartridge/i);
  var idxLot = findHeader(headers, /reagent lot id/i);
  var idxTestType = findHeader(headers, /^test type$/i);
  var idxTestResult = findHeader(headers, /^test result$/i);
  var idxError = findHeader(headers, /^error$/i);
  var idxUser = findHeader(headers, /^user$/i);

  var countsSample = {};
  var countsCart = {};
  var resultCounts = {};
  var callCounts = { POS: 0, NEG: 0, INDET: 0, UNKNOWN: 0 };
  var majorCounts = { ok: 0, false_negative: 0, false_positive: 0, invalid: 0, expected_unknown: 0 };

  var bagCounts = {};
  var ctrlCounts = {};
  var ctrlPrefixMap = {};
  var invalidRows = [];
  var liteRows = [];
  var majorDeviations = [];

  // For majority-by-testType expected inference
  var majTT = {}; // key -> { POS:x, NEG:y, total:t }
  function ttKey(v) { return String(v || '').trim().toUpperCase(); }
  function incTT(map, tt, call) {
    var k = ttKey(tt);
    if (!k) return;
    if (!map[k]) map[k] = { POS: 0, NEG: 0, total: 0 };
    if (call === 'POS' || call === 'NEG') {
      map[k][call] += 1;
      map[k].total += 1;
    }
  }

  var assay = '';
  var assayVer = '';
  var lot = '';

  for (var i = 0; i < rows.length; i++) {
    var r = rows[i];

    var sAssay = safeCol(r, idxAssay);
    var sAssayVer = safeCol(r, idxAssayVer);
    var sSample = safeCol(r, idxSample);
    var sCart = safeCol(r, idxCart);
    var sLot = safeCol(r, idxLot);
    var sType = safeCol(r, idxTestType);
    var sRes = safeCol(r, idxTestResult);
    var sErr = safeCol(r, idxError);
    var sUser = safeCol(r, idxUser);

    if (!assay && sAssay) assay = sAssay;
    if (!assayVer && sAssayVer) assayVer = sAssayVer;
    if (!lot && sLot) lot = sLot;

    if (sSample) incMap(countsSample, sSample);
    if (sCart) incMap(countsCart, sCart);
    if (sRes) incMap(resultCounts, sRes);

    var sid = parseSampleId(sSample);
    if (sid.bag !== null) incMap(bagCounts, String(sid.bag));

    // Observed call via RuleSheet 01
    var obsCall = RULES.resolveObservedCall(sAssay || assay || '', sRes);
    if (obsCall !== 'POS' && obsCall !== 'NEG' && obsCall !== 'INDET') obsCall = 'UNKNOWN';
    callCounts[obsCall] = (callCounts[obsCall] || 0) + 1;

    // Expected via RuleSheet 02 + TestType fallback
    var expObj = RULES.resolveExpected(sAssay || assay || '', sSample, sType);
    var expected = expObj.expected;
    if (expected !== 'POS' && expected !== 'NEG') expected = 'UNKNOWN';

    // Detected class for existing ctrl logic
    var detClass = 'unknown';
    if (obsCall === 'POS') detClass = 'detected';
    else if (obsCall === 'NEG') detClass = 'not_detected';

    // Invalid?
    var lowRes = String(sRes || '').toLowerCase();
    var isHardInvalid = (lowRes.indexOf('error') >= 0 || lowRes.indexOf('no result') >= 0 || lowRes.indexOf('invalid') >= 0);
    var isInvalid = isHardInvalid || (obsCall === 'INDET' || obsCall === 'UNKNOWN');

    // Error mapping (03)
    var errInfo = RULES.mapError(sErr);
    var errName = errInfo ? (errInfo.name || '') : '';
    var errRetest = errInfo ? (errInfo.retest || '') : '';

    // Markers (05)
    var markers = RULES.getMarkers(sSample);

    // control buckets
    if (!ctrlCounts.hasOwnProperty(sid.ctrl)) ctrlCounts[sid.ctrl] = { detected: 0, not_detected: 0, unknown: 0, total: 0 };
    ctrlCounts[sid.ctrl][detClass] = (ctrlCounts[sid.ctrl][detClass] || 0) + 1;
    ctrlCounts[sid.ctrl].total++;

    // Keep ctrl prefix map
    if (!ctrlPrefixMap.hasOwnProperty(sid.ctrl)) ctrlPrefixMap[sid.ctrl] = {};
    ctrlPrefixMap[sid.ctrl][sid.prefix] = true;

    // Majority expected inference by test type (future-proof)
    incTT(majTT, sType, obsCall);

    var lite = {
      assay: sAssay, assayVer: sAssayVer, lot: sLot,
      sampleId: sSample, cartSn: sCart,
      testType: sType, testResult: sRes,
      error: sErr, errorName: errName, retest: errRetest,
      user: sUser,
      bag: sid.bag, ctrl: sid.ctrl, prefix: sid.prefix, pos: sid.pos,
      markers: markers,
      detectedClass: detClass,
      observedCall: obsCall,
      expected: expected,
      expectedVia: expObj.via || ''
    };
    liteRows.push(lite);

    if (isInvalid) invalidRows.push(lite);
  }

  
  // Parity check (RuleSheet 06): X/+ markers based on lowest numeric Cartridge S/N
  // Rule: expectedMarker = ( (CartSn - baseMinSn) % 2 == 0 ) ? XChar : PlusChar
  var parityReport = { enabled: false, baseSn: null, checked: 0, missingMarker: 0, mismatches: [] };
  if (RULES && RULES.parity && RULES.parity.enabled !== false) {
    var pCfg = RULES.parity;
    var baseSn = null;
    for (var pi = 0; pi < liteRows.length; pi++) {
      var sn0 = parseInt(String(liteRows[pi].cartSn || '').replace(/[^0-9]/g, ''), 10);
      if (!isNaN(sn0)) {
        if (baseSn === null || sn0 < baseSn) baseSn = sn0;
      }
    }
    if (baseSn !== null) {
      parityReport.enabled = true;
      parityReport.baseSn = baseSn;

      for (pi = 0; pi < liteRows.length; pi++) {
        row = liteRows[pi];
        var sn = parseInt(String(row.cartSn || '').replace(/[^0-9]/g, ''), 10);
        if (isNaN(sn)) continue;

        var sidStr = String(row.sampleId || '');
        if (!sidStr) continue;

        var toks = sidStr.split('_');
        var idxTok = (typeof pCfg.tokenIndex === 'number') ? pCfg.tokenIndex : 3;
        var tok = (idxTok >= 0 && idxTok < toks.length) ? String(toks[idxTok] || '') : '';
        if (!tok) continue;

        var last = tok.charAt(tok.length - 1);
        var actual = null;
        if (last === pCfg.xChar || last === pCfg.plusChar) actual = last;

        if (!actual) {
          parityReport.missingMarker += 1;
          continue;
        }

        var exp = (((sn - baseSn) % 2) === 0) ? pCfg.xChar : pCfg.plusChar;
        parityReport.checked += 1;

        if (actual !== exp) {
          parityReport.mismatches.push({
            sampleId: row.sampleId,
            cartSn: row.cartSn,
            testType: row.testType,
            expectedMarker: exp,
            actualMarker: actual,
            delta: String(sn - baseSn)
          });
        }
      }
    }
  }

// Bag range + missing (default behavior: from observed bag span)
  var bagNums = [];
  for (var bk in bagCounts) if (bagCounts.hasOwnProperty(bk)) {
    var bn2 = parseInt(bk, 10);
    if (!isNaN(bn2)) bagNums.push(bn2);
  }
  bagNums.sort(function (a, b) { return a - b; });
  var bagMin = (bagNums.length ? bagNums[0] : null);
  var bagMax = (bagNums.length ? bagNums[bagNums.length - 1] : null);
  var bagMissing = [];
  if (bagMin !== null && bagMax !== null) {
    for (var b = bagMin; b <= bagMax; b++) {
      if (!bagCounts.hasOwnProperty(String(b))) bagMissing.push(b);
    }
  }

  // Control expected behavior = majority (existing logic)
  var ctrlExpected = {};
  for (var ck in ctrlCounts) if (ctrlCounts.hasOwnProperty(ck)) {
    var cc = ctrlCounts[ck];
    var m = 'unknown';
    if (cc.detected > cc.not_detected && cc.detected > cc.unknown) m = 'detected';
    else if (cc.not_detected > cc.detected && cc.not_detected > cc.unknown) m = 'not_detected';
    ctrlExpected[ck] = m;
  }

  // Control deviations list (existing behavior)
  var ctrlDeviations = [];
  for (var j = 0; j < liteRows.length; j++) {
    var row = liteRows[j];
    var expDet = ctrlExpected[row.ctrl] || 'unknown';
    if (expDet === 'unknown') continue;
    if (row.detectedClass === 'unknown') continue;
    if (row.detectedClass !== expDet) {
      ctrlDeviations.push({
        ctrl: row.ctrl,
        expected: expDet,
        detectedClass: row.detectedClass,
        sampleId: row.sampleId,
        bag: row.bag,
        cartSn: row.cartSn,
        testType: row.testType,
        testResult: row.testResult
      });
    }
  }

  // Majority-by-testType expected inference + Major Functional classification
  function inferExpectedByTT(testType) {
    var k = ttKey(testType);
    if (!k || !majTT[k]) return null;
    var d = majTT[k].POS || 0;
    var n = majTT[k].NEG || 0;
    var t = majTT[k].total || 0;
    if (t < 5) return null;
    var mx = Math.max(d, n);
    if (mx / t < 0.80) return null;
    return (d > n) ? 'POS' : 'NEG';
  }

  for (j = 0; j < liteRows.length; j++) {
    row = liteRows[j];

    if (row.expected === 'UNKNOWN') {
      var inf = inferExpectedByTT(row.testType);
      if (inf) {
        row.expected = inf;
        row.expectedVia = 'MajorityTestType';
      }
    }

    // Major Functional
    var maj = 'ok';
    var isObsValid = (row.observedCall === 'POS' || row.observedCall === 'NEG');
    var isExpValid = (row.expected === 'POS' || row.expected === 'NEG');

    if (!isExpValid) {
      maj = 'expected_unknown';
      majorCounts.expected_unknown++;
    } else if (!isObsValid) {
      maj = 'invalid';
      majorCounts.invalid++;
    } else if (row.expected === 'POS' && row.observedCall === 'NEG') {
      maj = 'false_negative';
      majorCounts.false_negative++;
      majorDeviations.push({
        major: 'False Negative',
        expected: row.expected,
        observed: row.observedCall,
        sampleId: row.sampleId,
        bag: row.bag,
        cartSn: row.cartSn,
        testType: row.testType,
        testResult: row.testResult,
        error: row.error,
        user: row.user
      });
    } else if (row.expected === 'NEG' && row.observedCall === 'POS') {
      maj = 'false_positive';
      majorCounts.false_positive++;
      majorDeviations.push({
        major: 'False Positive',
        expected: row.expected,
        observed: row.observedCall,
        sampleId: row.sampleId,
        bag: row.bag,
        cartSn: row.cartSn,
        testType: row.testType,
        testResult: row.testResult,
        error: row.error,
        user: row.user
      });
    } else {
      majorCounts.ok++;
    }

    row.major = maj;
  }

  // Result list (sorted)
  var resultList = [];
  for (var rk in resultCounts) if (resultCounts.hasOwnProperty(rk)) {
    resultList.push({ value: rk, count: resultCounts[rk] });
  }
  resultList.sort(function (a, b) { return b.count - a.count; });

  return {
    ok: true,
    delim: extra.delim || '',
    headerIdx: (typeof extra.headerIdx === 'number' ? extra.headerIdx : -1),
    rowCount: rows.length,
    assay: assay || (extra.assay || ''),
    assayVer: assayVer || (extra.assayVer || ''),
    lot: lot || (extra.lot || ''),
    duplicateSamples: makeDuplicates(countsSample),
    duplicateCarts: makeDuplicates(countsCart),
    results: resultList,
    calls: { counts: callCounts },
    major: { counts: majorCounts, deviations: majorDeviations },
    bag: { min: bagMin, max: bagMax, missing: bagMissing, counts: bagCounts },
    ctrl: { counts: ctrlCounts, expected: ctrlExpected, deviations: ctrlDeviations, prefixes: ctrlPrefixMap },
    parity: parityReport,
    invalid: invalidRows,
    _rows: liteRows
  };
}


function parseCsv(text) {
    text = text || '';
    if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);

    var lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');

    // Guess delimiter from first non-empty line
    var delim = ';';
    for (var i = 0; i < lines.length; i++) {
      if (lines[i] && lines[i].length) {
        var cSemi = countChar(lines[i], ';');
        var cComma = countChar(lines[i], ',');
        delim = (cSemi >= cComma) ? ';' : ',';
        break;
      }
    }

    // Find header row dynamically (same logic as PowerShell: look for core columns)
    var headerIdx = -1;
    for (i = 0; i < lines.length; i++) {
      var l = lines[i];
      if (!l) continue;
      var low = l.toLowerCase();
      if (low.indexOf('assay') >= 0 && low.indexOf('sample') >= 0 && (low.indexOf('cartridge') >= 0 || low.indexOf('s/n') >= 0)) {
        headerIdx = i;
        break;
      }
    }
    if (headerIdx < 0) return { ok: false, error: 'Kunde inte hitta header-rad i CSV.' };

    var headers = splitCsvLine(lines[headerIdx], delim);
    var rows = [];
    for (i = headerIdx + 1; i < lines.length; i++) {
      if (!lines[i]) continue;
      if (/^(\s*;)+\s*$/.test(lines[i]) || /^(\s*,)+\s*$/.test(lines[i])) continue;
      var cols = splitCsvLine(lines[i], delim);
      if (cols.length < 4) continue;
      rows.push(cols);
    }

return analyzeTestSummaryTable(headers, rows, {
  delim: delim,
  headerIdx: headerIdx
});

    return {
      ok: true,
      delim: delim,
      headerIdx: headerIdx,
      rowCount: rows.length,
      assay: assay,
      assayVer: assayVer,
      lot: lot,
      duplicateSamples: makeDuplicates(countsSample),
      duplicateCarts: makeDuplicates(countsCart),
      bag: { min: bagMin, max: bagMax, missing: bagMissing, counts: bagCounts },
      ctrl: { counts: ctrlCounts, expected: ctrlExpected, deviations: ctrlDeviations, prefixes: ctrlPrefixMap },
      invalid: invalidRows,
      // keep some raw for future rules
      _rows: liteRows
    };
  }


  function countChar(s, ch) {
    var n = 0;
    for (var i = 0; i < s.length; i++) if (s.charAt(i) === ch) n++;
    return n;
  }

  function splitCsvLine(line, delim) {
    var out = [];
    var cur = '';
    var inQ = false;
    for (var i = 0; i < line.length; i++) {
      var ch = line.charAt(i);
      if (inQ) {
        if (ch === '"') {
          if (i + 1 < line.length && line.charAt(i + 1) === '"') { cur += '"'; i++; }
          else inQ = false;
        } else {
          cur += ch;
        }
      } else {
        if (ch === '"') inQ = true;
        else if (ch === delim) { out.push(cur); cur = ''; }
        else cur += ch;
      }
    }
    out.push(cur);
    return out;
  }

  function findHeader(headers, regex) {
    for (var i = 0; i < headers.length; i++) {
      var h = (headers[i] || '').toString().trim();
      if (regex.test(h)) return i;
    }
    return -1;
  }


  // ----------------------------
  // Embedded RuleSheets (MASTER) + Rule Engine
  // ----------------------------
  var __RS_01_RESULT_CALL_PATTERNS = "Assay,Call,MatchType,Pattern,Priority,Enabled,Note\nXpert HPV HR,NEG,contains,INVALID,1100,True,Override: HPV uses INVALID as acceptable NEG (align with legacy HTML logic)\nXpert HPV v2 HR,NEG,contains,INVALID,1100,True,Override: HPV uses INVALID as acceptable NEG (align with legacy HTML logic)\nHPV HR AND GENOTYPE RUO ASSAY,NEG,contains,INVALID,1100,True,Override: HPV uses INVALID as acceptable NEG (align with legacy HTML logic)\n*,INDET,contains,INDETERMINATE,950,True,Generic indeterminate\n*,INDET,contains,NO RESULT,950,True,Generic no result\n*,INDET,contains,ABORTED,950,True,Generic aborted\n*,INDET,contains,INCOMPLETE,950,True,Generic incomplete\n*,INDET,contains,INVALID,950,True,Generic invalid\n*,INDET,contains,ERROR,940,True,Generic error\nXpert C.difficile BT,NEG,contains,Toxigenic C.diff NEG;Binary Toxin NEG;027 NEG,300,True,\"From Specification.xlsx sheet \"\"C.DIFF\"\" (Sample Type 0)\"\nXpert C.difficile BT,POS,contains,Toxigenic C.diff POS;Binary Toxin POS;027 PRESUMPTIVE POS,300,True,\"From Specification.xlsx sheet \"\"C.DIFF\"\" (Sample Type 1)\"\nXpert C.diff-Epi,NEG,contains,Toxigenic C.diff NEGATIVE;027 PRESUMPTIVE NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"C.DIFF\"\" (Sample Type 0)\"\nXpert C.diff-Epi,POS,contains,Toxigenic C.diff POSITIVE;027 PRESUMPTIVE POSITIVE,300,True,\"From Specification.xlsx sheet \"\"C.DIFF\"\" (Sample Type 1)\"\nXpert-C. difficile G2,NEG,contains,Toxigenic C.diff NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"C.DIFF\"\" (Sample Type 0)\"\nXpert-C. difficile G2,POS,contains,Toxigenic C.diff POSITIVE,300,True,\"From Specification.xlsx sheet \"\"C.DIFF\"\" (Sample Type 1)\"\nXpert C.difficile G3,NEG,contains,Toxigenic C.diff NEGATIVE;027 PRESUMPTIVE NEG,300,True,\"From Specification.xlsx sheet \"\"C.DIFF\"\" (Sample Type 0)\"\nXpert C.difficile G3,POS,contains,Toxigenic C.diff POSITIVE;027 PRESUMPTIVE POS,300,True,\"From Specification.xlsx sheet \"\"C.DIFF\"\" (Sample Type 1)\"\nXpert C.difficile G3,POS,contains,Toxigenic C.diff POSITIVE;027 PRESUMPTIVE POS,300,True,\"From Specification.xlsx sheet \"\"C.DIFF JP\"\" (Sample Type 2)\"\nXpert C.difficile G3,POS,contains,Toxigenic C.diff POSITIVE;027 PRESUMPTIVE POS,300,True,\"From Specification.xlsx sheet \"\"C.DIFF JP\"\" (Sample Type 3)\"\nXpert_Carba-R,NEG,contains,IMP NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"CARBA\"\" (Sample Type 0)\"\nXpert_Carba-R,POS,contains,IMP DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED,300,True,\"From Specification.xlsx sheet \"\"CARBA\"\" (Sample Type 1)\"\nXpert_Carba-R,POS,contains,IMP DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED,300,True,\"From Specification.xlsx sheet \"\"CARBA\"\" (Sample Type 2)\"\nXpert Carba-R,NEG,contains,IMP1 NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"CARBA\"\" (Sample Type 0)\"\nXpert Carba-R,POS,contains,IMP1 DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED,300,True,\"From Specification.xlsx sheet \"\"CARBA\"\" (Sample Type 1)\"\nXpert Carba-R,POS,contains,IMP1 DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED,300,True,\"From Specification.xlsx sheet \"\"CARBA\"\" (Sample Type 2)\"\nCARBA-R IUO,NEG,contains,IMP1 NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"CARBA\"\" (Sample Type 0)\"\nCARBA-R IUO,POS,contains,IMP1 DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED,300,True,\"From Specification.xlsx sheet \"\"CARBA\"\" (Sample Type 1)\"\nCARBA-R IUO,POS,contains,IMP1 DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED,300,True,\"From Specification.xlsx sheet \"\"CARBA\"\" (Sample Type 2)\"\nCarba-R BEU IUO,NEG,contains,IMP NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"CARBA\"\" (Sample Type 0)\"\nCarba-R BEU IUO,POS,contains,IMP DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED,300,True,\"From Specification.xlsx sheet \"\"CARBA\"\" (Sample Type 1)\"\nCarba-R BEU IUO,POS,contains,IMP DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED,300,True,\"From Specification.xlsx sheet \"\"CARBA\"\" (Sample Type 2)\"\nCARBA-R RUO,NEG,contains,IMP NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"CARBA\"\" (Sample Type 0)\"\nCARBA-R RUO,POS,contains,IMP DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED,300,True,\"From Specification.xlsx sheet \"\"CARBA\"\" (Sample Type 1)\"\nCARBA-R RUO,POS,contains,IMP DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED,300,True,\"From Specification.xlsx sheet \"\"CARBA\"\" (Sample Type 2)\"\nCarba-R BEU RUO,NEG,contains,IMP NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"CARBA\"\" (Sample Type 0)\"\nCarba-R BEU RUO,POS,contains,IMP DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED,300,True,\"From Specification.xlsx sheet \"\"CARBA\"\" (Sample Type 1)\"\nCarba-R BEU RUO,POS,contains,IMP DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED,300,True,\"From Specification.xlsx sheet \"\"CARBA\"\" (Sample Type 2)\"\nXpert Xpress SARS-CoV-2 CE-IVD,NEG,contains,SARS-CoV-2 NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Sars\"\" (Sample Type 0)\"\nXpert Xpress SARS-CoV-2 CE-IVD,POS,contains,SARS-CoV-2 POSITIVE,300,True,\"From Specification.xlsx sheet \"\"Sars\"\" (Sample Type 1)\"\nXpert Xpress SARS-CoV-2,NEG,contains,SARS-CoV-2 NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Sars\"\" (Sample Type 0)\"\nXpert Xpress SARS-CoV-2,POS,contains,SARS-CoV-2 POSITIVE,300,True,\"From Specification.xlsx sheet \"\"Sars\"\" (Sample Type 1)\"\nLCE009 Xpress SARS-CoV-2 plus,NEG,contains,SARS-CoV-2 NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Covid plus\"\" (Sample Type 0)\"\nLCE009 Xpress SARS-CoV-2 plus,POS,contains,SARS-CoV-2 POSITIVE,300,True,\"From Specification.xlsx sheet \"\"Covid plus\"\" (Sample Type 1)\"\nXpress CoV-2 plus RUO,NEG,contains,SARS-CoV-2 NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Covid plus\"\" (Sample Type 0)\"\nXpress CoV-2 plus RUO,POS,contains,SARS-CoV-2 POSITIVE,300,True,\"From Specification.xlsx sheet \"\"Covid plus\"\" (Sample Type 1)\"\nXpress CoV-2 plus IUO,NEG,contains,SARS-CoV-2 NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Covid plus\"\" (Sample Type 0)\"\nXpress CoV-2 plus IUO,POS,contains,SARS-CoV-2 POSITIVE,300,True,\"From Specification.xlsx sheet \"\"Covid plus\"\" (Sample Type 1)\"\nXpert Xpress CoV-2 plus,NEG,contains,SARS-CoV-2 NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Covid plus\"\" (Sample Type 0)\"\nXpert Xpress CoV-2 plus,POS,contains,SARS-CoV-2 POSITIVE,300,True,\"From Specification.xlsx sheet \"\"Covid plus\"\" (Sample Type 1)\"\nXpert Xpress CoV-2 plus IVD,NEG,contains,SARS-CoV-2 NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Covid plus\"\" (Sample Type 0)\"\nXpert Xpress CoV-2 plus IVD,POS,contains,SARS-CoV-2 POSITIVE,300,True,\"From Specification.xlsx sheet \"\"Covid plus\"\" (Sample Type 1)\"\nSARS-CoV-2_Flu_RSV_plus,NEG,contains,SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"FLUVID plus\"\" (Sample Type 0)\"\nSARS-CoV-2_Flu_RSV_plus,POS,contains,SARS-CoV-2 POSITIVE;Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE,300,True,\"From Specification.xlsx sheet \"\"FLUVID plus\"\" (Sample Type 1)\"\nSARS-CoV-2_Flu_RSV plus RUO,NEG,contains,SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"FLUVID plus\"\" (Sample Type 0)\"\nSARS-CoV-2_Flu_RSV plus RUO,POS,contains,SARS-CoV-2 POSITIVE;Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE,300,True,\"From Specification.xlsx sheet \"\"FLUVID plus\"\" (Sample Type 1)\"\nSARS-CoV-2_Flu_RSV plus IUO,NEG,contains,SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"FLUVID plus\"\" (Sample Type 0)\"\nSARS-CoV-2_Flu_RSV plus IUO,POS,contains,SARS-CoV-2 POSITIVE;Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE,300,True,\"From Specification.xlsx sheet \"\"FLUVID plus\"\" (Sample Type 1)\"\nXpress SARS-CoV-2_Flu_RSV plus,NEG,contains,SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"FLUVID plus\"\" (Sample Type 0)\"\nXpress SARS-CoV-2_Flu_RSV plus,POS,contains,SARS-CoV-2 POSITIVE;Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE,300,True,\"From Specification.xlsx sheet \"\"FLUVID plus\"\" (Sample Type 1)\"\nXpress SARS-CoV-2 Flu RSV plus,NEG,contains,SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"FLUVID plus\"\" (Sample Type 0)\"\nXpress SARS-CoV-2 Flu RSV plus,POS,contains,SARS-CoV-2 POSITIVE;Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE,300,True,\"From Specification.xlsx sheet \"\"FLUVID plus\"\" (Sample Type 1)\"\nXpert CT_CE,NEG,contains,CT NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"CTNG\"\" (Sample Type 0)\"\nXpert CT_CE,POS,contains,CT DETECTED,300,True,\"From Specification.xlsx sheet \"\"CTNG\"\" (Sample Type 1)\"\nXpert CT_NG,NEG,contains,CT NOT DETECTED;NG NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"CTNG\"\" (Sample Type 0)\"\nXpert CT_NG,POS,contains,CT DETECTED;NG DETECTED,300,True,\"From Specification.xlsx sheet \"\"CTNG\"\" (Sample Type 1)\"\nXpert Ebola EUA,NEG,contains,Ebola GP NOT DETECTED;Ebola NP NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"EBOLA\"\" (Sample Type 0)\"\nXpert Ebola EUA,POS,contains,Ebola GP DETECTED;Ebola NP DETECTED,300,True,\"From Specification.xlsx sheet \"\"EBOLA\"\" (Sample Type 1)\"\nXpert Ebola EUA,POS,contains,Ebola GP DETECTED;Ebola NP DETECTED,300,True,\"From Specification.xlsx sheet \"\"EBOLA\"\" (Sample Type 2)\"\nXpert Ebola CE-IVD,NEG,contains,Ebola GP NOT DETECTED;Ebola NP NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"EBOLA\"\" (Sample Type 0)\"\nXpert Ebola CE-IVD,POS,contains,Ebola GP DETECTED;Ebola NP DETECTED,300,True,\"From Specification.xlsx sheet \"\"EBOLA\"\" (Sample Type 1)\"\nXpert Ebola CE-IVD,POS,contains,Ebola GP DETECTED;Ebola NP DETECTED,300,True,\"From Specification.xlsx sheet \"\"EBOLA\"\" (Sample Type 2)\"\nEbola RUO,NEG,contains,Ebola GP NOT DETECTED;Ebola NP NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"EBOLA\"\" (Sample Type 0)\"\nEbola RUO,POS,contains,Ebola GP DETECTED;Ebola NP DETECTED,300,True,\"From Specification.xlsx sheet \"\"EBOLA\"\" (Sample Type 1)\"\nEbola RUO,POS,contains,Ebola GP DETECTED;Ebola NP DETECTED,300,True,\"From Specification.xlsx sheet \"\"EBOLA\"\" (Sample Type 2)\"\nXpress GBS IUO,NEG,contains,GBS NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"GBS\"\" (Sample Type 0)\"\nXpress GBS IUO,POS,contains,GBS POSITIVE,300,True,\"From Specification.xlsx sheet \"\"GBS\"\" (Sample Type 1)\"\nXpress GBS RUO,NEG,contains,GBS NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"GBS\"\" (Sample Type 0)\"\nXpress GBS RUO,POS,contains,GBS POSITIVE,300,True,\"From Specification.xlsx sheet \"\"GBS\"\" (Sample Type 1)\"\nXpert Xpress GBS RUO,NEG,contains,GBS NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"GBS\"\" (Sample Type 0)\"\nXpert Xpress GBS RUO,POS,contains,GBS POSITIVE,300,True,\"From Specification.xlsx sheet \"\"GBS\"\" (Sample Type 1)\"\nXpert Xpress GBS,NEG,contains,GBS NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"GBS\"\" (Sample Type 0)\"\nXpert Xpress GBS,POS,contains,GBS POSITIVE,300,True,\"From Specification.xlsx sheet \"\"GBS\"\" (Sample Type 1)\"\nGBS LB RUO,NEG,contains,GBS NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"GBS XC\"\" (Sample Type 0)\"\nGBS LB RUO,POS,contains,GBS POSITIVE,300,True,\"From Specification.xlsx sheet \"\"GBS XC\"\" (Sample Type 1)\"\nGBS LB XC IUO,NEG,contains,GBS NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"GBS XC\"\" (Sample Type 0)\"\nGBS LB XC IUO,POS,contains,GBS POSITIVE,300,True,\"From Specification.xlsx sheet \"\"GBS XC\"\" (Sample Type 1)\"\nXpert GBS LB XC,NEG,contains,GBS NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"GBS XC\"\" (Sample Type 0)\"\nXpert GBS LB XC,POS,contains,GBS POSITIVE,300,True,\"From Specification.xlsx sheet \"\"GBS XC\"\" (Sample Type 1)\"\nGI Panel RUO,NEG,contains,Campylobacter NEGATIVE;Salmonella NEGATIVE;STEC stx1 NEGATIVE;STEC stx2 NEGATIVE;Shigella EIEC NEGATIVE;V. cholerae NEGATIVE;V. parahaemolyticus NEGATIVE;Yersinia NEGATIVE;Cryptosporidium NEGATIVE;Giardia NEGATIVE;Norovirus NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"GI Panel\"\" (Sample Type 0)\"\nGI Panel RUO,POS,contains,Campylobacter POSITIVE;Salmonella POSITIVE;STEC stx1 POSITIVE;STEC stx2 POSITIVE;Shigella EIEC POSITIVE;V. cholerae POSITIVE;V. parahaemolyticus POSITIVE;Yersinia POSITIVE;Cryptosporidium POSITIVE;Giardia POSITIVE;Norovirus POSITIVE,300,True,\"From Specification.xlsx sheet \"\"GI Panel\"\" (Sample Type 1)\"\nGI Panel IUO,NEG,contains,Campylobacter NEGATIVE;Salmonella NEGATIVE;STEC stx1 NEGATIVE;STEC stx2 NEGATIVE;Shigella EIEC NEGATIVE;V. cholerae NEGATIVE;V. parahaemolyticus NEGATIVE;Yersinia NEGATIVE;Cryptosporidium NEGATIVE;Giardia NEGATIVE;Norovirus NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"GI Panel\"\" (Sample Type 0)\"\nGI Panel IUO,POS,contains,Campylobacter POSITIVE;Salmonella POSITIVE;STEC stx1 POSITIVE;STEC stx2 POSITIVE;Shigella EIEC POSITIVE;V. cholerae POSITIVE;V. parahaemolyticus POSITIVE;Yersinia POSITIVE;Cryptosporidium POSITIVE;Giardia POSITIVE;Norovirus POSITIVE,300,True,\"From Specification.xlsx sheet \"\"GI Panel\"\" (Sample Type 1)\"\nXpert GI Panel,NEG,contains,Campylobacter NEGATIVE;Salmonella NEGATIVE;STEC stx1 NEGATIVE;STEC stx2 NEGATIVE;Shigella EIEC NEGATIVE;V. cholerae NEGATIVE;V. parahaemolyticus NEGATIVE;Yersinia NEGATIVE;Cryptosporidium NEGATIVE;Giardia NEGATIVE;Norovirus NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"GI Panel\"\" (Sample Type 0)\"\nXpert GI Panel,POS,contains,Campylobacter POSITIVE;Salmonella POSITIVE;STEC stx1 POSITIVE;STEC stx2 POSITIVE;Shigella EIEC POSITIVE;V. cholerae POSITIVE;V. parahaemolyticus POSITIVE;Yersinia POSITIVE;Cryptosporidium POSITIVE;Giardia POSITIVE;Norovirus POSITIVE,300,True,\"From Specification.xlsx sheet \"\"GI Panel\"\" (Sample Type 1)\"\nXpert GI Panel CE-IVD,NEG,contains,Campylobacter NEGATIVE;Salmonella NEGATIVE;STEC stx1 NEGATIVE;STEC stx2 NEGATIVE;Shigella EIEC NEGATIVE;V. cholerae NEGATIVE;V. parahaemolyticus NEGATIVE;Yersinia NEGATIVE;Cryptosporidium NEGATIVE;Giardia NEGATIVE;Norovirus NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"GI Panel\"\" (Sample Type 0)\"\nXpert GI Panel CE-IVD,POS,contains,Campylobacter POSITIVE;Salmonella POSITIVE;STEC stx1 POSITIVE;STEC stx2 POSITIVE;Shigella EIEC POSITIVE;V. cholerae POSITIVE;V. parahaemolyticus POSITIVE;Yersinia POSITIVE;Cryptosporidium POSITIVE;Giardia POSITIVE;Norovirus POSITIVE,300,True,\"From Specification.xlsx sheet \"\"GI Panel\"\" (Sample Type 1)\"\nXpert HBV Viral Load,NEG,contains,HBV NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"HBV VL\"\" (Sample Type 0)\"\nXpert HBV Viral Load,POS,contains,HBV DETECTED * IU/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HBV VL\"\" (Sample Type 1)\"\nXpert HBV Viral Load,POS,contains,HBV DETECTED * IU/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HBV VL\"\" (Sample Type 2)\"\nXpert HCV VL Fingerstick,NEG,contains,HCV NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"HCV FS\"\" (Sample Type 0)\"\nXpert HCV VL Fingerstick,POS,contains,HCV DETECTED * IU/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HCV FS\"\" (Sample Type 1)\"\nXpert HCV VL Fingerstick,POS,contains,HCV DETECTED * IU/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HCV FS\"\" (Sample Type 2)\"\nHCV VL WB RUO,NEG,contains,HCV NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"HCV FS\"\" (Sample Type 0)\"\nHCV VL WB RUO,POS,contains,HCV DETECTED * IU/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HCV FS\"\" (Sample Type 1)\"\nHCV VL WB RUO,POS,contains,HCV DETECTED * IU/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HCV FS\"\" (Sample Type 2)\"\nHCV IUO,NEG,contains,HCV NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"GX HCV\"\" (Sample Type 0)\"\nHCV IUO,POS,contains,HCV DETECTED,300,True,\"From Specification.xlsx sheet \"\"GX HCV\"\" (Sample Type 1)\"\nXpert HCV PQC,NEG,contains,HCV NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"GX HCV\"\" (Sample Type 0)\"\nXpert HCV PQC,POS,contains,HCV DETECTED,300,True,\"From Specification.xlsx sheet \"\"GX HCV\"\" (Sample Type 1)\"\nXpert_HCV Viral Load,NEG,contains,HCV NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"HCV VL\"\" (Sample Type 0)\"\nXpert_HCV Viral Load,POS,contains,HCV DETECTED * IU/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HCV VL\"\" (Sample Type 1)\"\nXpert_HCV Viral Load,POS,contains,HCV DETECTED * IU/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HCV VL\"\" (Sample Type 2)\"\nHCV Viral Load RUO,NEG,contains,HCV NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"HCV VL\"\" (Sample Type 0)\"\nHCV Viral Load RUO,POS,contains,HCV DETECTED * IU/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HCV VL\"\" (Sample Type 1)\"\nHCV Viral Load RUO,POS,contains,HCV DETECTED * IU/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HCV VL\"\" (Sample Type 2)\"\nXpert_HIV-1 Viral Load,NEG,contains,HIV-1 NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"HIV VL\"\" (Sample Type 0)\"\nXpert_HIV-1 Viral Load,POS,contains,HIV-1 DETECTED * copies/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HIV VL\"\" (Sample Type 1)\"\nXpert_HIV-1 Viral Load,POS,contains,HIV-1 DETECTED * copies/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HIV VL\"\" (Sample Type 2)\"\nHIV-1 Viral Load RUO,NEG,contains,HIV-1 NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"HIV VL\"\" (Sample Type 0)\"\nHIV-1 Viral Load RUO,POS,contains,HIV-1 DETECTED * copies/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HIV VL\"\" (Sample Type 1)\"\nHIV-1 Viral Load RUO,POS,contains,HIV-1 DETECTED * copies/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HIV VL\"\" (Sample Type 2)\"\nHIV-1 Qual XC DBS RUO,NEG,contains,HIV-1 NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"HIV QA XC\"\" (Sample Type 0)\"\nHIV-1 Qual XC DBS RUO,POS,contains,HIV-1 DETECTED,300,True,\"From Specification.xlsx sheet \"\"HIV QA XC\"\" (Sample Type 1)\"\nHIV-1 Qual XC DBS IUO,NEG,contains,HIV-1 NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"HIV QA XC\"\" (Sample Type 0)\"\nHIV-1 Qual XC DBS IUO,POS,contains,HIV-1 DETECTED,300,True,\"From Specification.xlsx sheet \"\"HIV QA XC\"\" (Sample Type 1)\"\nXpert HIV-1 Qual XC PQC,NEG,contains,HIV-1 NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"HIV QA XC\"\" (Sample Type 0)\"\nXpert HIV-1 Qual XC PQC,POS,contains,HIV-1 DETECTED,300,True,\"From Specification.xlsx sheet \"\"HIV QA XC\"\" (Sample Type 1)\"\nXpert HIV-1 Qual XC PQC RUO,NEG,contains,HIV-1 NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"HIV QA XC\"\" (Sample Type 0)\"\nXpert HIV-1 Qual XC PQC RUO,POS,contains,HIV-1 DETECTED,300,True,\"From Specification.xlsx sheet \"\"HIV QA XC\"\" (Sample Type 1)\"\nHIV-1 Viral Load XC IUO,NEG,contains,HIV-1 NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"HIV VL XC\"\" (Sample Type 0)\"\nHIV-1 Viral Load XC IUO,POS,contains,HIV-1 DETECTED * copies/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HIV VL XC\"\" (Sample Type 1)\"\nHIV-1 Viral Load XC IUO,POS,contains,HIV-1 DETECTED * copies/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HIV VL XC\"\" (Sample Type 2)\"\nHIV-1 Viral Load XC RUO,NEG,contains,HIV-1 NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"HIV VL XC\"\" (Sample Type 0)\"\nHIV-1 Viral Load XC RUO,POS,contains,HIV-1 DETECTED * copies/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HIV VL XC\"\" (Sample Type 1)\"\nHIV-1 Viral Load XC RUO,POS,contains,HIV-1 DETECTED * copies/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HIV VL XC\"\" (Sample Type 2)\"\nXpert HIV-1 Viral Load XC,NEG,contains,HIV-1 NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"HIV VL XC\"\" (Sample Type 0)\"\nXpert HIV-1 Viral Load XC,POS,contains,HIV-1 DETECTED * copies/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HIV VL XC\"\" (Sample Type 1)\"\nXpert HIV-1 Viral Load XC,POS,contains,HIV-1 DETECTED * copies/mL (log *.*),300,True,\"From Specification.xlsx sheet \"\"HIV VL XC\"\" (Sample Type 2)\"\nXpert HPV HR,NEG,contains,INVALID,300,True,\"From Specification.xlsx sheet \"\"HPV\"\" (Sample Type 0)\"\nXpert HPV HR,POS,contains,HR HPV POS,300,True,\"From Specification.xlsx sheet \"\"HPV\"\" (Sample Type 1)\"\nXpert HPV HR,POS,contains,HR HPV POS,300,True,\"From Specification.xlsx sheet \"\"HPV\"\" (Sample Type 2)\"\nXpert HPV v2 HR,NEG,contains,INVALID,300,True,\"From Specification.xlsx sheet \"\"HPV\"\" (Sample Type 0)\"\nXpert HPV v2 HR,POS,contains,HR HPV POS,300,True,\"From Specification.xlsx sheet \"\"HPV\"\" (Sample Type 1)\"\nXpert HPV v2 HR,POS,contains,HR HPV POS,300,True,\"From Specification.xlsx sheet \"\"HPV\"\" (Sample Type 2)\"\nHPV HR AND GENOTYPE RUO ASSAY,NEG,contains,INVALID,300,True,\"From Specification.xlsx sheet \"\"HPV\"\" (Sample Type 0)\"\nHPV HR AND GENOTYPE RUO ASSAY,POS,contains,HR HPV POS,300,True,\"From Specification.xlsx sheet \"\"HPV\"\" (Sample Type 1)\"\nHPV HR AND GENOTYPE RUO ASSAY,POS,contains,HR HPV POS,300,True,\"From Specification.xlsx sheet \"\"HPV\"\" (Sample Type 2)\"\nXpert MRSA NxG,NEG,contains,MRSA NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"MRSA NxG\"\" (Sample Type 0)\"\nXpert MRSA NxG,POS,contains,MRSA DETECTED,300,True,\"From Specification.xlsx sheet \"\"MRSA NxG\"\" (Sample Type 1 and 2)\"\nMRSA NxG IUO,NEG,contains,MRSA NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"MRSA NxG\"\" (Sample Type 0)\"\nMRSA NxG IUO,POS,contains,MRSA DETECTED,300,True,\"From Specification.xlsx sheet \"\"MRSA NxG\"\" (Sample Type 1 and 2)\"\nMRSA NxG RUO,NEG,contains,MRSA NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"MRSA NxG\"\" (Sample Type 0)\"\nMRSA NxG RUO,POS,contains,MRSA DETECTED,300,True,\"From Specification.xlsx sheet \"\"MRSA NxG\"\" (Sample Type 1 and 2)\"\nXpert MRSA_SA_BC,NEG,contains,MRSA NEGATIVE;SA NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"MRSA SA\"\" (Sample Type 0)\"\nXpert MRSA_SA_BC,POS,contains,MRSA POSITIVE;SA POSITIVE,300,True,\"From Specification.xlsx sheet \"\"MRSA SA\"\" (Sample Type 1)\"\nXpert MRSA_SA_BC_CE,NEG,contains,MRSA NEGATIVE;SA NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"MRSA SA\"\" (Sample Type 0)\"\nXpert MRSA_SA_BC_CE,POS,contains,MRSA POSITIVE;SA POSITIVE,300,True,\"From Specification.xlsx sheet \"\"MRSA SA\"\" (Sample Type 1)\"\nXpert MRSA-SA BC G3,NEG,contains,MRSA NEGATIVE;SA NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"MRSA SA\"\" (Sample Type 0)\"\nXpert MRSA-SA BC G3,POS,contains,MRSA POSITIVE;SA POSITIVE,300,True,\"From Specification.xlsx sheet \"\"MRSA SA\"\" (Sample Type 1)\"\nXpert MRSA-SA SSTI G3,NEG,contains,MRSA NEGATIVE;SA NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"MRSA SA\"\" (Sample Type 0)\"\nXpert MRSA-SA SSTI G3,POS,contains,MRSA POSITIVE;SA POSITIVE,300,True,\"From Specification.xlsx sheet \"\"MRSA SA\"\" (Sample Type 1)\"\nXpert SA Nasal Complete G3,NEG,contains,MRSA NEGATIVE;SA NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"MRSA SA\"\" (Sample Type 0)\"\nXpert SA Nasal Complete G3,POS,contains,MRSA POSITIVE;SA POSITIVE,300,True,\"From Specification.xlsx sheet \"\"MRSA SA\"\" (Sample Type 1)\"\nMRSA-SA ETA,NEG,contains,MRSA NEGATIVE;SA NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"MRSA SA\"\" (Sample Type 0)\"\nMRSA-SA ETA,POS,contains,MRSA POSITIVE;SA POSITIVE,300,True,\"From Specification.xlsx sheet \"\"MRSA SA\"\" (Sample Type 1)\"\nXpert MTB-RIF Ultra,NEG,contains,MTB NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB U\"\" (Sample Type 0)\"\nXpert MTB-RIF Ultra,POS,contains,MTB DETECTED *;Rif Resistance DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB U\"\" (Sample Type 1)\"\nXpert MTB-RIF Ultra,POS,contains,MTB DETECTED *;Rif Resistance NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB U\"\" (Sample Type 2)\"\nMTB-RIF Ultra v2 RUO,NEG,contains,MTB NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB U\"\" (Sample Type 0)\"\nMTB-RIF Ultra v2 RUO,POS,contains,MTB DETECTED *;Rif Resistance DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB U\"\" (Sample Type 1)\"\nMTB-RIF Ultra v2 RUO,POS,contains,MTB DETECTED *;Rif Resistance NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB U\"\" (Sample Type 2)\"\nXpert MTB-RIF Assay G4,NEG,contains,MTB NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB\"\" (Sample Type 0)\"\nXpert MTB-RIF Assay G4,POS,contains,MTB DETECTED *;Rif Resistance NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB\"\" (Sample Type 1)\"\nXpert MTB-RIF US IVD,NEG,contains,MTB NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB\"\" (Sample Type 0)\"\nXpert MTB-RIF US IVD,POS,contains,MTB DETECTED;Rif Resistance NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB\"\" (Sample Type 1)\"\nXpert MTB-RIF JP IVD,NEG,contains,MTB NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB JP\"\" (Sample Type 0)\"\nXpert MTB-RIF JP IVD,POS,contains,MTB DETECTED;Rif Resistance NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB JP\"\" (Sample Type 1)\"\nXpert MTB-RIF JP IVD,POS,contains,MTB DETECTED;Rif Resistance DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB JP\"\" (Sample Type 2)\"\nXpert MTB-RIF JP IVD,POS,contains,MTB DETECTED;Rif Resistance DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB JP\"\" (Sample Type 3)\"\nXpert MTB-RIF JP IVD,POS,contains,MTB DETECTED;Rif Resistance DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB JP\"\" (Sample Type 4)\"\nXpert MTB-RIF JP IVD,POS,contains,MTB DETECTED;Rif Resistance DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB JP\"\" (Sample Type 5)\"\nXpert MTB-XDR,NEG,contains,MTB NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB XDR\"\" (Sample Type 0)\"\nXpert MTB-XDR,POS,contains,MTB DETECTED;INH Resistance NOT DETECTED;FLQ Resistance NOT DETECTED;AMK Resistance NOT DETECTED;KAN Resistance NOT DETECTED;CAP Resistance NOT DETECTED;ETH Resistance NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB XDR\"\" (Sample Type 1)\"\nXpert MTB-XDR,POS,contains,MTB DETECTED;INH Resistance DETECTED;FLQ Resistance DETECTED;AMK Resistance DETECTED;KAN Resistance DETECTED;CAP Resistance DETECTED;ETH Resistance DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB XDR\"\" (Sample Type 2)\"\nMTB-XDR RUO,NEG,contains,MTB NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB XDR\"\" (Sample Type 0)\"\nMTB-XDR RUO,POS,contains,MTB DETECTED;INH Resistance NOT DETECTED;FLQ Resistance NOT DETECTED;AMK Resistance NOT DETECTED;KAN Resistance NOT DETECTED;CAP Resistance NOT DETECTED;ETH Resistance NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB XDR\"\" (Sample Type 1)\"\nMTB-XDR RUO,POS,contains,MTB DETECTED;INH Resistance DETECTED;FLQ Resistance DETECTED;AMK Resistance DETECTED;KAN Resistance DETECTED;CAP Resistance DETECTED;ETH Resistance DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB XDR\"\" (Sample Type 2)\"\nMTB-XDR IUO,NEG,contains,MTB NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB XDR\"\" (Sample Type 0)\"\nMTB-XDR IUO,POS,contains,MTB DETECTED;INH Resistance NOT DETECTED;FLQ Resistance NOT DETECTED;AMK Resistance NOT DETECTED;KAN Resistance NOT DETECTED;CAP Resistance NOT DETECTED;ETH Resistance NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB XDR\"\" (Sample Type 1)\"\nMTB-XDR IUO,POS,contains,MTB DETECTED;INH Resistance DETECTED;FLQ Resistance DETECTED;AMK Resistance DETECTED;KAN Resistance DETECTED;CAP Resistance DETECTED;ETH Resistance DETECTED,300,True,\"From Specification.xlsx sheet \"\"MTB XDR\"\" (Sample Type 2)\"\nXpert Norovirus,NEG,contains,NORO GI NOT DETECTED;NORO GII NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"NORO\"\" (Sample Type 0)\"\nXpert Norovirus,POS,contains,NORO GI DETECTED;NORO GII DETECTED,300,True,\"From Specification.xlsx sheet \"\"NORO\"\" (Sample Type 1)\"\nXpert Norovirus,POS,contains,NORO GI DETECTED;NORO GII DETECTED,300,True,\"From Specification.xlsx sheet \"\"NORO\"\" (Sample Type 2)\"\nRespiratory Panel IUO,NEG,contains,Adenovirus NEGATIVE;Coronavirus NEGATIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza NEGATIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Type 0)\"\nRespiratory Panel IUO,POS,contains,Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV POSITIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae POSITIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 1)\"\nRespiratory Panel IUO,POS,contains,Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 POSITIVE;Flu A NEGATIVE;Flu B POSITIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis POSITIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 2)\"\nRespiratory Panel IUO,POS,contains,Adenovirus POSITIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV POSITIVE;Parainfluenza POSITIVE;Rhino-Enterovirus POSITIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 3)\"\nRespiratory Panel IUO,POS,contains,Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV POSITIVE;B. parapertussis NEGATIVE;B. pertussis POSITIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae POSITIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 4)\"\nRespiratory Panel RUO,NEG,contains,Adenovirus NEGATIVE;Coronavirus NEGATIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza NEGATIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Type 0)\"\nRespiratory Panel RUO,POS,contains,Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV POSITIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae POSITIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 1)\"\nRespiratory Panel RUO,POS,contains,Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 POSITIVE;Flu A NEGATIVE;Flu B POSITIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis POSITIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 2)\"\nRespiratory Panel RUO,POS,contains,Adenovirus POSITIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV POSITIVE;Parainfluenza POSITIVE;Rhino-Enterovirus POSITIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 3)\"\nRespiratory Panel RUO,POS,contains,Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV POSITIVE;B. parapertussis NEGATIVE;B. pertussis POSITIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae POSITIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 4)\"\nRespiratory panel,NEG,contains,Adenovirus NEGATIVE;Coronavirus NEGATIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza NEGATIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Type 0)\"\nRespiratory panel,POS,contains,Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV POSITIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae POSITIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 1)\"\nRespiratory panel,POS,contains,Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 POSITIVE;Flu A NEGATIVE;Flu B POSITIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis POSITIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 2)\"\nRespiratory panel,POS,contains,Adenovirus POSITIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV POSITIVE;Parainfluenza POSITIVE;Rhino-Enterovirus POSITIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 3)\"\nRespiratory panel,POS,contains,Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV POSITIVE;B. parapertussis NEGATIVE;B. pertussis POSITIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae POSITIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 4)\"\nRespiratory panel CE-IVD,NEG,contains,Adenovirus NEGATIVE;Coronavirus NEGATIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza NEGATIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Type 0)\"\nRespiratory panel CE-IVD,POS,contains,Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV POSITIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae POSITIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 1)\"\nRespiratory panel CE-IVD,POS,contains,Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 POSITIVE;Flu A NEGATIVE;Flu B POSITIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis POSITIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 2)\"\nRespiratory panel CE-IVD,POS,contains,Adenovirus POSITIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV POSITIVE;Parainfluenza POSITIVE;Rhino-Enterovirus POSITIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 3)\"\nRespiratory panel CE-IVD,POS,contains,Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV POSITIVE;B. parapertussis NEGATIVE;B. pertussis POSITIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae POSITIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 4)\"\nRespiratory panel UKCA-IVD,NEG,contains,Adenovirus NEGATIVE;Coronavirus NEGATIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza NEGATIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Type 0)\"\nRespiratory panel UKCA-IVD,POS,contains,Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV POSITIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae POSITIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 1)\"\nRespiratory panel UKCA-IVD,POS,contains,Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 POSITIVE;Flu A NEGATIVE;Flu B POSITIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis POSITIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 2)\"\nRespiratory panel UKCA-IVD,POS,contains,Adenovirus POSITIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A POSITIVE;Flu B NEGATIVE;hMPV POSITIVE;Parainfluenza POSITIVE;Rhino-Enterovirus POSITIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 3)\"\nRespiratory panel UKCA-IVD,POS,contains,Adenovirus NEGATIVE;Coronavirus POSITIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza POSITIVE;Rhino-Enterovirus NEGATIVE;RSV POSITIVE;B. parapertussis NEGATIVE;B. pertussis POSITIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae POSITIVE,300,True,\"From Specification.xlsx sheet \"\"Respiratory Panel\"\" (Sample Mix 4)\"\nXpert Xpress_Strep A,NEG,contains,Strep A NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"STREPA\"\" (Sample Type 0)\"\nXpert Xpress_Strep A,POS,contains,Strep A DETECTED,300,True,\"From Specification.xlsx sheet \"\"STREPA\"\" (Sample Type 1)\"\nXpert Xpress_Strep A,POS,contains,Strep A DETECTED,300,True,\"From Specification.xlsx sheet \"\"STREPA\"\" (Sample Type 2)\"\nXpert Xpress Strep A,NEG,contains,Strep A NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"STREPA\"\" (Sample Type 0)\"\nXpert Xpress Strep A,POS,contains,Strep A DETECTED,300,True,\"From Specification.xlsx sheet \"\"STREPA\"\" (Sample Type 1)\"\nXpert Xpress Strep A,POS,contains,Strep A DETECTED,300,True,\"From Specification.xlsx sheet \"\"STREPA\"\" (Sample Type 2)\"\nTAP Panel RUO,NEG,contains,Ft NOT DETECTED;Ba NOT DETECTED;Yp NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"TAP Panel\"\" (Sample Type 0)\"\nTAP Panel RUO,POS,contains,Ft DETECTED;Ba DETECTED;Yp DETECTED,300,True,\"From Specification.xlsx sheet \"\"TAP Panel\"\" (Sample Type 1)\"\nTAP Panel IUO,NEG,contains,Ft NOT DETECTED;Ba NOT DETECTED;Yp NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"TAP Panel\"\" (Sample Type 0)\"\nTAP Panel IUO,POS,contains,Ft DETECTED;Ba DETECTED;Yp DETECTED,300,True,\"From Specification.xlsx sheet \"\"TAP Panel\"\" (Sample Type 1)\"\nXpert TAP Panel,NEG,contains,Ft NOT DETECTED;Ba NOT DETECTED;Yp NOT DETECTED,300,True,\"From Specification.xlsx sheet \"\"TAP Panel\"\" (Sample Type 0)\"\nXpert TAP Panel,POS,contains,Ft DETECTED;Ba DETECTED;Yp DETECTED,300,True,\"From Specification.xlsx sheet \"\"TAP Panel\"\" (Sample Type 1)\"\nXpert vanA vanB,NEG,contains,vanA NEGATIVE;vanB NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"VAN AB\"\" (Sample Type 0)\"\nXpert vanA vanB,POS,contains,vanA POSITIVE;vanB POSITIVE,300,True,\"From Specification.xlsx sheet \"\"VAN AB\"\" (Sample Type 1)\"\nXP Flu-RSV RUO,NEG,contains,Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"FLU RSV\"\" (Sample Type 0)\"\nXP Flu-RSV RUO,POS,contains,Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE,300,True,\"From Specification.xlsx sheet \"\"FLU RSV\"\" (Sample Type 1 and 2)\"\nXpress Flu IPT_EAT off,NEG,contains,Flu A NEGATIVE;Flu B NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"FLU RSV\"\" (Sample Type 0)\"\nXpress Flu IPT_EAT off,POS,contains,Flu A POSITIVE;Flu B POSITIVE,300,True,\"From Specification.xlsx sheet \"\"FLU RSV\"\" (Sample Type 1 and 2)\"\nXpert Xpress Flu-RSV,NEG,contains,Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE,300,True,\"From Specification.xlsx sheet \"\"FLU RSV\"\" (Sample Type 0)\"\nXpert Xpress Flu-RSV,POS,contains,Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE,300,True,\"From Specification.xlsx sheet \"\"FLU RSV\"\" (Sample Type 1 and 2)\"\n*,POS,regex,(?:^|;)\\s*(?![^;]*NOT\\s+DETECTED)[^;]*\\bDETECTED\\b,130,True,Smart POS: any ';'-segment contains DETECTED but not NOT DETECTED (handles mixed panels)\n*,NEG,regex,\\bNOT\\s+DETECTED\\b,110,True,Smart NEG: phrase NOT DETECTED\n*,POS,contains,POSITIVE,100,True,Generic positive call\n*,NEG,contains,NEGATIVE,95,True,Generic negative call\n*,POS,contains,PRESUMPTIVE,60,True,Generic presumptive call (override per assay if needed)\n";
  var __RS_02_SAMPLE_EXPECTATIONS = "Assay,Expected,SampleIdMatchType,SampleIdPattern,Priority,Enabled,Note\n*,NEG,regex,^[^_]+_\\d+_0_,220,True,Token rule: SampleTypeCode=0 (3rd segment) expected NEG\n*,POS,regex,^[^_]+_\\d+_1_,220,True,Token rule: SampleTypeCode=1 (3rd segment) expected POS\n*,POS,regex,^[^_]+_\\d+_2_,220,True,Token rule: SampleTypeCode=2 (3rd segment) expected POS (PC2/mix)\n*,NEG,contains,_0_,120,True,Fallback: contains _0_ expected NEG\n*,POS,contains,_1_,120,True,Fallback: contains _1_ expected POS\n*,POS,contains,_2_,120,True,Fallback: contains _2_ expected POS\n*,NEG,prefix,NEG_,150,True,Default: Sample ID starting with NEG_ expected NEG\n*,POS,prefix,POS_,150,True,Default: Sample ID starting with POS_ expected POS\n*,POS,suffix,+,100,True,Default: Sample ID ending with + expected POS\n*,NEG,suffix,X,100,True,Default: Sample ID ending with X expected NEG\n";
  var __RS_03_ERROR_CODES = "ErrorCode,Name,GeneratesRetest\n5001,Curve Fit Error,No\n5002,Curve Fit Error,No\n5003,Curve Fit Error,No\n5004,Curve Fit Error,No\n5005,Curve Fit Error,No\n5015,Curve Fit Error,No\n5016,Curve Fit Error,No\n5007,Probe Check Low,No\n5017,Probe Check Low,No\n5019,Probe Check Low,No\n5006,Probe Check High,No\n5018,Probe Check High,No\n2037,CIT,No\n5011,SLD,No\n2008,Pressure Abort,No\n2096,Sample Volume Adequacy,No\n2097,Sample Volume Adequacy,No\n2125,Sample Volume Adequacy,No\n,Max Pressure > 90 PSI,No\n,\"Invalid w/o error (non-HPV, SPC Ct=0)\",No\n####,Delamination + error code,No\n,\"All types of \"\"MTB\"\": RIF Resistance Indeterminate\",No\n####,Other error codes,Yes\n";
  var __RS_04_MISSING_SAMPLES = "BagMin,BagMax,Bag0SampleMin,Bag0SampleMax,OtherBagSampleMin,OtherBagSampleMax,BagIndex_SampleID_SplitIndex,SampleToken_SampleID_SplitIndex,SampleNumberRegex,SampleNumberPad,Notes\n0,10,1,10,1,20,1,3,\\d+,2,Default bag/sample expectation (Bag0=1..10, Bags1-10=1..20)\n";
  var __RS_05_SAMPLEID_MARKERS = "MarkerType,SampleTokenIndex,Marker,Notes\nReplacement,3,A,Sample token contains 'A' -> Replacement\nDelamination,3,D,Sample token contains 'D' -> Delamination\n";
  var __RS_06_PARITY_CONFIG = "SampleTokenIndex,XChar,PlusChar,Notes\n3,X,+,Parity rule for X/+ based on lowest numeric Cartridge S/N\n";

function parseSimpleCsvObjects(text) {
  text = text || '';
  if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
  var lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  // find first non-empty line as header
  var headerLine = null;
  var headerIdx = -1;
  for (var i = 0; i < lines.length; i++) {
    if (lines[i] && lines[i].trim()) { headerLine = lines[i]; headerIdx = i; break; }
  }
  if (headerIdx < 0) return { ok: false, error: 'Empty CSV' };

  // guess delimiter from header
  var delim = ';';
  var cSemi = countChar(headerLine, ';');
  var cComma = countChar(headerLine, ',');
  delim = (cSemi >= cComma) ? ';' : ',';

  var headers = splitCsvLine(headerLine, delim);
  for (i = 0; i < headers.length; i++) headers[i] = (headers[i] || '').trim();

  var out = [];
  for (i = headerIdx + 1; i < lines.length; i++) {
    var l = lines[i];
    if (!l || !l.trim()) continue;
    // skip obvious junk rows
    if (/^(\s*;)+\s*$/.test(l) || /^(\s*,)+\s*$/.test(l)) continue;
    var cols = splitCsvLine(l, delim);
    var obj = {};
    for (var c = 0; c < headers.length; c++) {
      var key = headers[c];
      if (!key) continue;
      obj[key] = (c < cols.length ? cols[c] : '');
    }
    out.push(obj);
  }
  return { ok: true, headers: headers, rows: out };
}

function toBool(v) {
  var s = String(v || '').trim().toLowerCase();
  if (s === 'true' || s === '1' || s === 'yes' || s === 'y') return true;
  if (s === 'false' || s === '0' || s === 'no' || s === 'n') return false;
  return !!s;
}

function toInt(v, def) {
  var n = parseInt(v, 10);
  return isNaN(n) ? (def || 0) : n;
}

function normUpper(v) { return String(v == null ? '' : v).trim().toUpperCase(); }

function assayMatches(ruleAssay, assayName) {
  var ra = String(ruleAssay || '').trim();
  if (!ra || ra === '*') return true;
  return normUpper(ra) === normUpper(assayName);
}

function matchByType(matchType, pattern, value) {
  var mt = String(matchType || '').trim().toLowerCase();
  var v = String(value || '');
  if (mt === 'contains') return v.toLowerCase().indexOf(String(pattern || '').toLowerCase()) >= 0;
  if (mt === 'prefix') return v.toLowerCase().indexOf(String(pattern || '').toLowerCase()) === 0;
  if (mt === 'suffix') {
    var p = String(pattern || '').toLowerCase();
    var vv = v.toLowerCase();
    return vv.slice(Math.max(0, vv.length - p.length)) === p;
  }
  if (mt === 'equals') return normUpper(v) === normUpper(pattern);
  if (mt === 'regex') {
    try {
      var re = new RegExp(String(pattern || ''), 'i');
      return re.test(v);
    } catch (e) { return false; }
  }
  return false;
}

var RULES = (function() {
  var rs01 = null, rs02 = null, rs03 = null, rs05 = null, rs06 = null;
  var resultCallRules = [];
  var expectedRules = [];
  var errorMap = {};
  var sampleMarkers = [];
  var parity = { tokenIndex: 3, xChar: 'X', plusChar: '+', enabled: true };

  function init() {
    // 01: Result call patterns
    rs01 = parseSimpleCsvObjects(__RS_01_RESULT_CALL_PATTERNS);
    if (rs01.ok) {
      for (var i = 0; i < rs01.rows.length; i++) {
        var r = rs01.rows[i];
        if (!toBool(r.Enabled)) continue;
        resultCallRules.push({
          assay: r.Assay,
          call: normUpper(r.Call),
          matchType: r.MatchType,
          pattern: r.Pattern,
          priority: toInt(r.Priority, 0),
          note: r.Note || ''
        });
      }
      resultCallRules.sort(function(a,b){ return b.priority - a.priority; });
    }

    // 02: Sample expectations
    rs02 = parseSimpleCsvObjects(__RS_02_SAMPLE_EXPECTATIONS);
    if (rs02.ok) {
      for (i = 0; i < rs02.rows.length; i++) {
        r = rs02.rows[i];
        if (!toBool(r.Enabled)) continue;
        expectedRules.push({
          assay: r.Assay,
          expected: normUpper(r.Expected),
          matchType: r.SampleIdMatchType,
          pattern: r.SampleIdPattern,
          priority: toInt(r.Priority, 0),
          note: r.Note || ''
        });
      }
      expectedRules.sort(function(a,b){ return b.priority - a.priority; });
    }

    // 03: Error codes map
    rs03 = parseSimpleCsvObjects(__RS_03_ERROR_CODES);
    if (rs03.ok) {
      for (i = 0; i < rs03.rows.length; i++) {
        r = rs03.rows[i];
        var code = String(r.ErrorCode || '').trim();
        if (!code) continue;
        errorMap[code] = { name: r.Name || '', retest: String(r.GeneratesRetest || '').trim() };
      }
    }

    // 05: SampleID markers
    rs05 = parseSimpleCsvObjects(__RS_05_SAMPLEID_MARKERS);
    if (rs05.ok) {
      for (i = 0; i < rs05.rows.length; i++) {
        r = rs05.rows[i];
        sampleMarkers.push({
          markerType: r.MarkerType || '',
          tokenIndex: toInt(r.SampleTokenIndex, 3),
          marker: String(r.Marker || ''),
          notes: r.Notes || ''
        });
      }
    }

    // 06: parity config (optional)
    rs06 = parseSimpleCsvObjects(__RS_06_PARITY_CONFIG);
    if (rs06.ok && rs06.rows.length) {
      r = rs06.rows[0];
      parity.tokenIndex = toInt(r.SampleTokenIndex, 3);
      parity.xChar = String(r.XChar || 'X');
      parity.plusChar = String(r.PlusChar || '+');
    }

    // 04 is unreliable in current upload -> handled by defaults in bag logic
  }

  function resolveObservedCall(assayName, testResult) {
    var tr = String(testResult || '');
    for (var i = 0; i < resultCallRules.length; i++) {
      var rr = resultCallRules[i];
      if (!assayMatches(rr.assay, assayName)) continue;
      if (matchByType(rr.matchType, rr.pattern, tr)) return rr.call;
    }
    return 'UNKNOWN';
  }

  function resolveExpected(assayName, sampleId, testType) {
    // Strong global fallback from Test Type first
    var tt = normUpper(testType);
    if (tt.indexOf('NEGATIVE CONTROL') >= 0) return { expected: 'NEG', via: 'TestType' };
    if (tt.indexOf('POSITIVE CONTROL') >= 0) return { expected: 'POS', via: 'TestType' };

    var sid = String(sampleId || '');
    for (var i = 0; i < expectedRules.length; i++) {
      var er = expectedRules[i];
      if (!assayMatches(er.assay, assayName)) continue;
      if (matchByType(er.matchType, er.pattern, sid)) return { expected: er.expected, via: 'SampleIdRule' };
    }
    return { expected: 'UNKNOWN', via: 'Unknown' };
  }

  function mapError(code) {
    var c = String(code || '').trim();
    if (!c) return null;
    return errorMap[c] || { name: '', retest: '' };
  }

  function getMarkers(sampleId) {
    var sid = String(sampleId || '');
    if (!sid) return [];
    var toks = sid.split('_');
    var out = [];
    for (var i = 0; i < sampleMarkers.length; i++) {
      var m = sampleMarkers[i];
      var idx = m.tokenIndex;
      var tok = (idx >= 0 && idx < toks.length) ? String(toks[idx] || '') : '';
      if (!tok) continue;
      if (tok.indexOf(m.marker) >= 0) out.push(m.markerType);
    }
    return out;
  }

  // init immediately
  init();

  return {
    resolveObservedCall: resolveObservedCall,
    resolveExpected: resolveExpected,
    mapError: mapError,
    getMarkers: getMarkers,
    parity: parity
  };
})();



  function pickDuplicates(map) {
    var out = [];
    for (var k in map) {
      if (!map.hasOwnProperty(k)) continue;
      if (map[k] > 1) out.push({ key: k, count: map[k] });
    }
    out.sort(function (a, b) { return b.count - a.count; });
    return out;
  }

  // ----------------------------
  // ZIP + DEFLATE (raw) for XLSX
  // ----------------------------
  function readU16LE(bytes, off) { return bytes[off] | (bytes[off + 1] << 8); }
  function readU32LE(bytes, off) { return (bytes[off] | (bytes[off + 1] << 8) | (bytes[off + 2] << 16) | (bytes[off + 3] << 24)) >>> 0; }

  function decodeUtf8(bytes) {
    if (window.TextDecoder) return new TextDecoder('utf-8').decode(bytes);
    var s = '';
    for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i] & 0xFF);
    return s;
  }

  function unzipLocal(bytes) {
    var out = {};
    var off = 0;
    while (off + 30 < bytes.length) {
      var sig = readU32LE(bytes, off);
      if (sig !== 0x04034b50) break;

      var flags = readU16LE(bytes, off + 6);
      var method = readU16LE(bytes, off + 8);
      var compSize = readU32LE(bytes, off + 18);
      var uncompSize = readU32LE(bytes, off + 22);
      var nameLen = readU16LE(bytes, off + 26);
      var extraLen = readU16LE(bytes, off + 28);

      var nameBytes = bytes.subarray(off + 30, off + 30 + nameLen);
      var name = decodeUtf8(nameBytes);

      var dataStart = off + 30 + nameLen + extraLen;
      var dataEnd = dataStart + compSize;
      if (dataEnd > bytes.length) break;

      var comp = bytes.subarray(dataStart, dataEnd);
      var data;
      if (method === 0) data = comp;
      else if (method === 8) data = inflateRaw(comp, uncompSize);
      else data = new Uint8Array(0);

      out[name] = data;

      off = dataEnd;
      if (flags & 0x08) break;
    }
    return out;
  }

  function BitReader(bytes) {
    this.bytes = bytes;
    this.pos = 0;
    this.bitbuf = 0;
    this.bitcnt = 0;
  }

  BitReader.prototype.readBits = function (n) {
    while (this.bitcnt < n) {
      if (this.pos >= this.bytes.length) throw new Error('Unexpected EOF in bitstream');
      this.bitbuf |= (this.bytes[this.pos++] << this.bitcnt);
      this.bitcnt += 8;
    }
    var val = this.bitbuf & ((1 << n) - 1);
    this.bitbuf >>>= n;
    this.bitcnt -= n;
    return val;
  };

  BitReader.prototype.alignByte = function () {
    this.bitbuf = 0;
    this.bitcnt = 0;
  };

  function buildHuffman(codeLengths) {
    var maxLen = 0;
    for (var i = 0; i < codeLengths.length; i++) if (codeLengths[i] > maxLen) maxLen = codeLengths[i];

    var blCount = new Array(maxLen + 1);
    for (i = 0; i < blCount.length; i++) blCount[i] = 0;

    for (i = 0; i < codeLengths.length; i++) {
      var len = codeLengths[i];
      if (len > 0) blCount[len]++;
    }

    var nextCode = new Array(maxLen + 1);
    var code = 0;
    blCount[0] = 0;
    for (i = 1; i <= maxLen; i++) {
      code = (code + blCount[i - 1]) << 1;
      nextCode[i] = code;
    }

    var root = {};
    for (var sym = 0; sym < codeLengths.length; sym++) {
      var l = codeLengths[sym];
      if (!l) continue;
      var c = nextCode[l]++;
      var node = root;
      for (var bit = l - 1; bit >= 0; bit--) {
        var b = (c >> bit) & 1;
        if (!node[b]) node[b] = {};
        node = node[b];
      }
      node.sym = sym;
    }
    return root;
  }

  function decodeSym(br, tree) {
    var node = tree;
    while (true) {
      var b = br.readBits(1);
      node = node[b];
      if (!node) throw new Error('Bad Huffman code');
      if (node.sym !== undefined) return node.sym;
    }
  }

  var LEN_BASE = [3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258];
  var LEN_EXTRA= [0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0];
  var DIST_BASE=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577];
  var DIST_EXTRA=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13];

  function fixedLitLenTree() {
    var lengths = new Array(288);
    for (var i = 0; i <= 143; i++) lengths[i] = 8;
    for (i = 144; i <= 255; i++) lengths[i] = 9;
    for (i = 256; i <= 279; i++) lengths[i] = 7;
    for (i = 280; i <= 287; i++) lengths[i] = 8;
    return buildHuffman(lengths);
  }

  function fixedDistTree() {
    var lengths = new Array(32);
    for (var i = 0; i < 32; i++) lengths[i] = 5;
    return buildHuffman(lengths);
  }

  function inflateRaw(compBytes, expectedSize) {
    var br = new BitReader(compBytes);
    var out = [];
    var finalBlock = 0;

    var litTreeFixed = null, distTreeFixed = null;

    while (!finalBlock) {
      finalBlock = br.readBits(1);
      var btype = br.readBits(2);

      if (btype === 0) {
        br.alignByte();
        if (br.pos + 4 > br.bytes.length) throw new Error('Bad stored block');
        var len = br.bytes[br.pos] | (br.bytes[br.pos + 1] << 8);
        var nlen = br.bytes[br.pos + 2] | (br.bytes[br.pos + 3] << 8);
        br.pos += 4;
        if (((len ^ 0xFFFF) & 0xFFFF) !== (nlen & 0xFFFF)) throw new Error('Bad stored block len');
        for (var i = 0; i < len; i++) out.push(br.bytes[br.pos++]);
      } else {
        var litTree, distTree;

        if (btype === 1) {
          if (!litTreeFixed) litTreeFixed = fixedLitLenTree();
          if (!distTreeFixed) distTreeFixed = fixedDistTree();
          litTree = litTreeFixed;
          distTree = distTreeFixed;
        } else if (btype === 2) {
          var HLIT = br.readBits(5) + 257;
          var HDIST = br.readBits(5) + 1;
          var HCLEN = br.readBits(4) + 4;

          var order = [16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];
          var clen = new Array(19);
          for (var z = 0; z < 19; z++) clen[z] = 0;
          for (z = 0; z < HCLEN; z++) clen[order[z]] = br.readBits(3);
          var clenTree = buildHuffman(clen);

          var all = new Array(HLIT + HDIST);
          var idx = 0;
          while (idx < all.length) {
            var sym = decodeSym(br, clenTree);
            if (sym <= 15) {
              all[idx++] = sym;
            } else if (sym === 16) {
              var repeat = br.readBits(2) + 3;
              var prev = idx ? all[idx - 1] : 0;
              while (repeat-- && idx < all.length) all[idx++] = prev;
            } else if (sym === 17) {
              repeat = br.readBits(3) + 3;
              while (repeat-- && idx < all.length) all[idx++] = 0;
            } else if (sym === 18) {
              repeat = br.readBits(7) + 11;
              while (repeat-- && idx < all.length) all[idx++] = 0;
            } else {
              throw new Error('Bad code length symbol');
            }
          }

          var litLens = all.slice(0, HLIT);
          var distLens = all.slice(HLIT);

          litTree = buildHuffman(litLens);
          distTree = buildHuffman(distLens);
        } else {
          throw new Error('Unsupported block type');
        }

        while (true) {
          var s = decodeSym(br, litTree);
          if (s < 256) {
            out.push(s);
          } else if (s === 256) {
            break;
          } else {
            var li = s - 257;
            var length = LEN_BASE[li] + br.readBits(LEN_EXTRA[li]);

            var ds = decodeSym(br, distTree);
            var dist = DIST_BASE[ds] + br.readBits(DIST_EXTRA[ds]);

            var start = out.length - dist;
            if (start < 0) throw new Error('Bad distance');

            for (var k = 0; k < length; k++) out.push(out[start + k]);
          }
        }
      }
    }

    var u8 = new Uint8Array(out.length);
    for (var j = 0; j < out.length; j++) u8[j] = out[j] & 0xFF;

    if (expectedSize && u8.length !== expectedSize) {
      // keep anyway
    }
    return u8;
  }

  // ----------------------------
  // XLSX (OOXML) minimal reader
  // ----------------------------
  function xmlUnescape(s) {
    return (s || '')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'");
  }

  function parseSharedStrings(xml) {
    var out = [];
    var reSi = /<si[\s\S]*?<\/si>/g;
    var m;
    while ((m = reSi.exec(xml)) !== null) {
      var si = m[0];
      var reT = /<t[^>]*>([\s\S]*?)<\/t>/g;
      var mt, s = '';
      while ((mt = reT.exec(si)) !== null) s += xmlUnescape(mt[1]);
      out.push(s);
    }
    return out;
  }

  function colToNum(col) {
    var n = 0;
    for (var i = 0; i < col.length; i++) n = n * 26 + (col.charCodeAt(i) - 64);
    return n;
  }

  function numToCol(n) {
    var s = '';
    while (n > 0) {
      var r = (n - 1) % 26;
      s = String.fromCharCode(65 + r) + s;
      n = Math.floor((n - 1) / 26);
    }
    return s;
  }

  function decodeA1(a1) {
    var m = /^([A-Z]+)(\d+)$/.exec(a1);
    if (!m) return { c: 0, r: 0 };
    return { c: colToNum(m[1]), r: parseInt(m[2], 10) };
  }

  function parseDimension(xml) {
    var m = /<dimension[^>]*ref="([^"]+)"/.exec(xml);
    if (!m) return { s: { c: 1, r: 1 }, e: { c: 26, r: 50 } };
    var ref = m[1];
    var parts = ref.split(':');
    var a = decodeA1(parts[0]);
    var b = parts.length > 1 ? decodeA1(parts[1]) : a;
    return { s: { c: a.c, r: a.r }, e: { c: b.c, r: b.r } };
  }

  function parseSheet(xml, sharedStrings) {
    var cells = {};
    var reCell = /<c\b([^>]*)>([\s\S]*?)<\/c>/g;
    var mc;
    while ((mc = reCell.exec(xml)) !== null) {
      var attrs = mc[1];
      var inner = mc[2];

      var mr = /r="([^"]+)"/.exec(attrs);
      if (!mr) continue;
      var addr = mr[1];

      var mt = /t="([^"]+)"/.exec(attrs);
      var t = mt ? mt[1] : '';

      var vMatch = /<v>([\s\S]*?)<\/v>/.exec(inner);
      var v = vMatch ? vMatch[1] : '';

      if (t === 's') {
        var idx = parseInt(v, 10);
        cells[addr] = (sharedStrings && sharedStrings[idx] !== undefined) ? sharedStrings[idx] : '';
      } else if (t === 'b') {
        cells[addr] = (v === '1') ? 'TRUE' : 'FALSE';
      } else if (t === 'str') {
        cells[addr] = xmlUnescape(v);
      } else if (t === 'inlineStr') {
        var it = /<is>[\s\S]*?<\/is>/.exec(inner);
        if (it) {
          var rt = /<t[^>]*>([\s\S]*?)<\/t>/.exec(it[0]);
          cells[addr] = rt ? xmlUnescape(rt[1]) : '';
        } else {
          cells[addr] = '';
        }
      } else {
        if (v === '') cells[addr] = '';
        else {
          var num = Number(v);
          cells[addr] = (isNaN(num) ? xmlUnescape(v) : num);
        }
      }
    }

    var hf = {};
    var mHF = /<headerFooter[\s\S]*?<\/headerFooter>/.exec(xml);
    if (mHF) {
      var block = mHF[0];
      var mOddH = /<oddHeader>([\s\S]*?)<\/oddHeader>/.exec(block);
      var mOddF = /<oddFooter>([\s\S]*?)<\/oddFooter>/.exec(block);
      hf.oddHeader = mOddH ? xmlUnescape(mOddH[1]) : '';
      hf.oddFooter = mOddF ? xmlUnescape(mOddF[1]) : '';
    }

    return { cells: cells, dim: parseDimension(xml), headerFooter: hf, rawXml: xml };
  }

  function openXlsx(arrayBuffer) {
    var bytes = new Uint8Array(arrayBuffer);
    var fileMap = unzipLocal(bytes);

    var wbBytes = fileMap['xl/workbook.xml'];
    if (!wbBytes || !wbBytes.length) throw new Error('workbook.xml saknas');
    var wbXml = decodeUtf8(wbBytes);

    var relsXml = '';
    if (fileMap['xl/_rels/workbook.xml.rels']) relsXml = decodeUtf8(fileMap['xl/_rels/workbook.xml.rels']);

    var sharedStrings = [];
    if (fileMap['xl/sharedStrings.xml']) sharedStrings = parseSharedStrings(decodeUtf8(fileMap['xl/sharedStrings.xml']));

    var ridToTarget = {};
    relsXml.replace(/<Relationship\b[^>]*Id="([^"]+)"[^>]*Target="([^"]+)"[^>]*\/?>/g, function (_, id, target) {
      ridToTarget[id] = target;
      return '';
    });

    var sheetDefs = [];
    wbXml.replace(/<sheet\b[^>]*name="([^"]+)"[^>]*r:id="([^"]+)"[^>]*\/?>/g, function (_, name, rid) {
      sheetDefs.push({ name: name, rid: rid });
      return '';
    });

    var sheets = [];
    for (var i = 0; i < sheetDefs.length; i++) {
      var target = ridToTarget[sheetDefs[i].rid] || '';
      if (!target) continue;
      target = target.replace(/^\//, '');
      var path = 'xl/' + target;
      var sBytes = fileMap[path];
      if (!sBytes) continue;
      var sXml = decodeUtf8(sBytes);
      var sheet = parseSheet(sXml, sharedStrings);
      sheet.name = sheetDefs[i].name;
      sheets.push(sheet);
    }

    return { sheets: sheets, fileMap: fileMap };
  }

  function getCell(sheet, addr) {
    if (!sheet || !sheet.cells) return '';
    var v = sheet.cells[addr];
    if (v === undefined || v === null) return '';
    return v;
  }

  function getText(sheet, addr) {
    var v = getCell(sheet, addr);
    if (typeof v === 'number') return String(v);
    return (v || '').toString();
  }

  function isDigitStart(s) {
    s = (s || '').toString().trim();
    if (!s) return false;
    var c = s.charAt(0);
    return c >= '0' && c <= '9';
  }

  function trim(s) { return (s || '').toString().replace(/^\s+|\s+$/g, ''); }

  function normalizeSig(s) {
    s = (s || '').toString().trim();
    if (!s) return '';
    s = s.replace(/\./g, '').replace(/\s+/g, ' ').toUpperCase();
    return s;
  }

  function keys(map) {
    var out = [];
    for (var k in map) if (map.hasOwnProperty(k)) out.push(k);
    out.sort();
    return out;
  }

  // ----------------------------
  // Seal Test analysis
  // ----------------------------
  function findHeaderCol(sheet, headerText, headerRow) {
    headerRow = headerRow || 1;
    var dim = sheet.dim || { s: { c: 1, r: 1 }, e: { c: 26, r: 50 } };
    var maxC = dim.e.c || 26;
    var needle = (headerText || '').toLowerCase();
    for (var c = 1; c <= maxC; c++) {
      var addr = numToCol(c) + headerRow;
      var v = (getText(sheet, addr) || '').toLowerCase();
      if (v === needle) return numToCol(c);
    }
    return '';
  }

  function parseCellAddr(addr) {
    var m = /^([A-Z]+)(\d+)$/i.exec(String(addr || '').trim());
    if (!m) return null;
    return { c: colToNum(m[1].toUpperCase()), r: parseInt(m[2], 10) };
  }

  function makeAddr(c, r) {
    if (!c || !r) return '';
    return numToCol(c) + String(r);
  }

  function addrRight(addr, dx) {
    var p = parseCellAddr(addr);
    if (!p) return '';
    return makeAddr(p.c + (dx || 1), p.r);
  }

  function addrDown(addr, dy) {
    var p = parseCellAddr(addr);
    if (!p) return '';
    return makeAddr(p.c, p.r + (dy || 1));
  }

  function findLabelAddr(sheet, re) {
    if (!sheet || !sheet.cells) return '';
    for (var k in sheet.cells) {
      if (!sheet.cells.hasOwnProperty(k)) continue;
      var txt = trim(getText(sheet, k));
      if (txt && re.test(txt)) return k;
    }
    return '';
  }

  function valueNear(sheet, labelRe) {
    var a = findLabelAddr(sheet, labelRe);
    if (!a) return '';

    // Prefer right cell (common for key/value on same row)
    var v = trim(getText(sheet, addrRight(a, 1)));
    if (v && !labelRe.test(v)) return v;

    // Then below (common for key on row, value on next row)
    v = trim(getText(sheet, addrDown(a, 1)));
    if (v && !labelRe.test(v)) return v;

    // Fallback: a bit further away
    v = trim(getText(sheet, addrRight(a, 2)));
    if (v && !labelRe.test(v)) return v;

    v = trim(getText(sheet, addrDown(a, 2)));
    if (v && !labelRe.test(v)) return v;

    return '';
  }

  function readSealHeader(sheet) {
    return {
      ROBAL: valueNear(sheet, /^ROBAL\b/i),
      PartNumber: valueNear(sheet, /^Part\s*Number\b/i),
      BatchNumber: valueNear(sheet, /^Batch\s*Number/i),
      CartridgeLsp: valueNear(sheet, /(Cartridge.*\(LSP\)|Cartridge\s*LSP|Cartridge\s*No\.?\s*\(LSP\)|Cartridge\s*Number)/i),
      PO: valueNear(sheet, /^PO\s*Number\b/i),
      AssayFamily: valueNear(sheet, /^Assay\s*Family\b/i),
      WeightLossSpec: valueNear(sheet, /Weight\s*Loss\s*Spec/i)
    };
  }

  function readSealPeople(sheet) {
    var testers = [];
    var sigs = [];

    var t = trim(valueNear(sheet, /Name\s+of\s+Tester/i));
    if (!t) t = trim(valueNear(sheet, /Inspected\s+by/i));
    if (t) testers.push(t);

    var s = trim(valueNear(sheet, /Print\s+Full\s+Name.*Sign.*Date/i));
    if (s) sigs.push(s);

    return { testers: testers, sigs: sigs };
  }

  function analyzeSealTest(xlsxObj, label) {
    var dataSheets = [];
    for (var i = 0; i < xlsxObj.sheets.length; i++) {
      var sh = xlsxObj.sheets[i];
      if (sh.name === 'Worksheet Instructions') continue;
      if (isDigitStart(getText(sh, 'H3'))) dataSheets.push(sh);
    }

    var header = null;
    if (dataSheets.length) header = readSealHeader(dataSheets[0]);

    var testers = {};
    var signatures = {};
    for (i = 0; i < dataSheets.length; i++) {
      var t = trim(valueNear(dataSheets[i], /Name\s+of\s+Tester/i) || valueNear(dataSheets[i], /Inspected\s+by/i) || getText(dataSheets[i], 'B43'));
      if (t) {
        var parts = t.split(',');
        for (var p = 0; p < parts.length; p++) {
          var s = trim(parts[p]);
          if (s) testers[s] = true;
        }
      }
      var sig = normalizeSig(getText(dataSheets[i], 'B47'));
      if (sig) signatures[sig] = true;
    }

    var viol = [];
    for (i = 0; i < dataSheets.length; i++) {
      var sheet = dataSheets[i];
      var cart = getText(sheet, 'H3');
      var obsCol = findHeaderCol(sheet, 'Observation', 1);
      if (!obsCol) obsCol = 'M';
      for (var r = 3; r <= 45; r++) {
        var avg = getCell(sheet, 'K' + r);
        var status = (getText(sheet, 'L' + r) || '').toUpperCase();
        var avgNum = (typeof avg === 'number') ? avg : Number(avg);
        var bad = false;
        var reason = '';
        if (!isNaN(avgNum) && avgNum <= -3.0) { bad = true; reason = 'MinusValue<=-3'; }
        if (status === 'FAIL') { bad = true; reason = 'FAIL'; }
        if (!bad) continue;

        viol.push({
          source: label,
          sheet: sheet.name,
          cartridge: cart,
          avg: (!isNaN(avgNum) ? avgNum : getText(sheet, 'K' + r)),
          status: status || '',
          reason: reason,
          initial: getText(sheet, 'H' + r),
          final: getText(sheet, 'I' + r),
          observation: getText(sheet, obsCol + r)
        });
      }
    }

    return {
      label: label,
      sheetCount: xlsxObj.sheets.length,
      dataSheetCount: dataSheets.length,
      header: header,
      testers: keys(testers),
      signatures: keys(signatures),
      violations: viol
    };
  }

  // ----------------------------
  // Worksheet analysis (minimal)
  // ----------------------------
  function analyzeWorksheet(xlsxObj) {
    var sheet = null;
    for (var i = 0; i < xlsxObj.sheets.length; i++) {
      if (xlsxObj.sheets[i].name === 'Test Summary') { sheet = xlsxObj.sheets[i]; break; }
    }
    if (!sheet && xlsxObj.sheets.length) sheet = xlsxObj.sheets[0];
    if (!sheet) return { ok: false, error: 'Worksheet: inga sheets hittades' };

    return {
      ok: true,
      sheetName: sheet.name,
      partNumber: getText(sheet, 'B3'),
      cartridgeLsp: getText(sheet, 'B4')
    };
  }

  // ----------------------------
  // Render results
  // ----------------------------
  function escapeHtml(s) {
    s = (s === undefined || s === null) ? '' : String(s);
    return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }

  function renderDupList(title, arr) {
    if (!arr || !arr.length) return el('div', { 'class': 'small muted', text: title + ': inga dubletter.' });
    var wrap = el('div', { 'class': 'small' });
    wrap.appendChild(el('div', { 'class': 'muted', text: title + ': ' + arr.length + ' st.' }));
    var t = el('table');
    var th = el('thead');
    var tr = el('tr');
    tr.appendChild(el('th', { text: 'Value' }));
    tr.appendChild(el('th', { text: 'Count' }));
    th.appendChild(tr);
    t.appendChild(th);

    var tb = el('tbody');
    for (var i = 0; i < Math.min(arr.length, 20); i++) {
      var r = el('tr');
      r.appendChild(el('td', { 'class': 'mono', text: arr[i].key }));
      r.appendChild(el('td', { 'class': 'mono', text: String(arr[i].count) }));
      tb.appendChild(r);
    }
    t.appendChild(tb);
    wrap.appendChild(t);
    return wrap;
  }

    
// ----------------------------
// STF Decision (PASS/FAIL/REVIEW) based on Seal Test NEG/POS
// ----------------------------
function computeSealDecision(sealObj, label) {
  var issues = [];
  if (!sealObj) return { label: label, status: 'MISSING', violationCount: 0, issues: ['Missing file'] };

  var vcount = (sealObj.violations && sealObj.violations.length) ? sealObj.violations.length : 0;

  // Header checks (best effort)
  var hdr = sealObj.header || null;
  if (!hdr) issues.push('Missing header');
  else {
    var required = ['ROBAL','PartNumber','BatchNumber','CartridgeLsp','PO','AssayFamily','WeightLossSpec'];
    for (var i = 0; i < required.length; i++) {
      var k = required[i];
      var val = String(hdr[k] || '').trim();
      if (!val) issues.push('Missing header field: ' + k);
    }
  }

  if (!sealObj.testers || !sealObj.testers.length) issues.push('Missing Name of Tester');
  if (!sealObj.signatures || !sealObj.signatures.length) issues.push('Missing signature');

  if (vcount > 0) issues.push('Violations: ' + String(vcount));

  var status = 'PASS';
  if (vcount > 0) status = 'FAIL';
  else if (issues.length) status = 'REVIEW';

  return { label: label, status: status, violationCount: vcount, issues: issues };
}

function computeStfDecision(sealNeg, sealPos) {
  var neg = computeSealDecision(sealNeg, 'NEG');
  var pos = computeSealDecision(sealPos, 'POS');

  var overall = 'PASS';
  if (neg.status === 'FAIL' || pos.status === 'FAIL') overall = 'FAIL';
  else if (neg.status === 'MISSING' || pos.status === 'MISSING') overall = 'MISSING';
  else if (neg.status === 'REVIEW' || pos.status === 'REVIEW') overall = 'REVIEW';

  return { overall: overall, neg: neg, pos: pos };
}

function renderResults(model) {
    var out = $('results');
    clearNode(out);

    out.appendChild(el('h2', { text: 'Resultat' }));

    if (!model || !model.csv || !model.csv.ok) {
      out.appendChild(el('div', { 'class': 'small err', text: 'Ingen CSV-data att visa.' }));
      return;
    }

    var csv = model.csv;

    // Overall status
    var hasDupSample = (csv.duplicateSamples && csv.duplicateSamples.length);
    var hasDupCart = (csv.duplicateCarts && csv.duplicateCarts.length);
    var hasInvalid = (csv.invalid && csv.invalid.length);
    var hasResultCounts = (csv.results && csv.results.length);
    var hasCtrlDev = (csv.ctrl && csv.ctrl.deviations && csv.ctrl.deviations.length);
    var hasMissingBags = (csv.bag && csv.bag.missing && csv.bag.missing.length);

    var top = el('div', { 'class': 'card' });
    var pills = el('div');
    pills.appendChild(pill('Rows: ' + csv.rowCount, 'ok'));
    if (csv.assay) pills.appendChild(pill('Assay: ' + csv.assay, 'ok'));
    if (csv.assayVer) pills.appendChild(pill('Ver: ' + csv.assayVer, 'ok'));
    if (csv.lot) pills.appendChild(pill('Lot: ' + csv.lot, 'ok'));

    if (hasCtrlDev) pills.appendChild(pill('Control deviations: ' + csv.ctrl.deviations.length, 'bad'));
    else pills.appendChild(pill('Control deviations: 0', 'ok'));

    if (hasInvalid) pills.appendChild(pill('Invalid/NoResult/Error: ' + csv.invalid.length, 'warn'));
    else pills.appendChild(pill('Invalid/NoResult/Error: 0', 'ok'));

    if (hasDupSample) pills.appendChild(pill('Dup SampleID: ' + csv.duplicateSamples.length, 'warn'));
    else pills.appendChild(pill('Dup SampleID: 0', 'ok'));

    if (hasDupCart) pills.appendChild(pill('Dup Cartridge S/N: ' + csv.duplicateCarts.length, 'warn'));
    else pills.appendChild(pill('Dup Cartridge S/N: 0', 'ok'));


    // Parity check summary (RuleSheet 06)
    if (csv.parity && csv.parity.enabled) {
      var pm = (csv.parity.mismatches && csv.parity.mismatches.length) ? csv.parity.mismatches.length : 0;
      if (pm) pills.appendChild(pill('Parity mismatches: ' + pm, 'warn'));
      else pills.appendChild(pill('Parity mismatches: 0', 'ok'));
      if (csv.parity.missingMarker) pills.appendChild(pill('Missing parity marker: ' + csv.parity.missingMarker, 'warn'));
    }
    if (csv.major && csv.major.counts) {
      if (csv.major.counts.false_negative) pills.appendChild(pill('False Negative: ' + csv.major.counts.false_negative, 'bad'));
      else pills.appendChild(pill('False Negative: 0', 'ok'));
      if (csv.major.counts.false_positive) pills.appendChild(pill('False Positive: ' + csv.major.counts.false_positive, 'bad'));
      else pills.appendChild(pill('False Positive: 0', 'ok'));
    }

    if (hasMissingBags) pills.appendChild(pill('Missing bags: ' + csv.bag.missing.length, 'warn'));
    else pills.appendChild(pill('Missing bags: 0', 'ok'));

    if (hasResultCounts) pills.appendChild(pill('Distinct results: ' + csv.results.length, 'ok'));

    if (hasResultCounts) pills.appendChild(pill('Distinct results: ' + csv.results.length, 'ok'));

    top.appendChild(pills);
    top.appendChild(el('div', { 'class': 'small muted', text: 'Delimiter: ' + csv.delim + ' | Header rad: ' + (csv.headerIdx + 1) }));
    out.appendChild(top);

    // ----------------------------
// XLSX sections (Seal Test + Worksheet)
// ----------------------------
var hasSeal = !!(model && (model.sealNeg || model.sealPos));
var hasWs = !!(model && model.worksheet && model.worksheet.ok);

function renderKvTable(obj, keys) {
  var tbl = el('table');
  var thead = el('thead');
  var trh = el('tr');
  trh.appendChild(el('th', { text: 'Field' }));
  trh.appendChild(el('th', { text: 'Value' }));
  thead.appendChild(trh);
  tbl.appendChild(thead);
  var tb = el('tbody');
  for (var i = 0; i < keys.length; i++) {
    var k = keys[i];
    var v = obj ? obj[k] : '';
    if (v === null || typeof v === 'undefined') v = '';
    var tr = el('tr');
    tr.appendChild(el('td', { text: k }));
    tr.appendChild(el('td', { text: String(v) }));
    tb.appendChild(tr);
  }
  tbl.appendChild(tb);
  return tbl;
}

if (hasSeal) {
  var secStf = el('div', { 'class': 'card' });
  secStf.appendChild(el('h3', { text: 'STF Summary (Seal Test NEG/POS)' }));

  // STF decision (PASS/FAIL/REVIEW)
  if (model.stfDecision) {
    var sd = model.stfDecision;
    var line = 'STF Decision: ' + sd.overall + ' (NEG: ' + sd.neg.status + ', POS: ' + sd.pos.status + ')';
    secStf.appendChild(el('div', { 'class': 'small', text: line }));

    function renderIssueList(dec) {
      if (!dec || !dec.issues || !dec.issues.length) return null;
      var box = el('div', { 'class': 'small muted' });
      box.appendChild(el('div', { text: dec.label + ' issues:' }));
      var ul = el('ul');
      for (var ii = 0; ii < dec.issues.length; ii++) {
        ul.appendChild(el('li', { text: dec.issues[ii] }));
      }
      box.appendChild(ul);
      return box;
    }

    var negBox = renderIssueList(sd.neg);
    var posBox = renderIssueList(sd.pos);
    if (negBox) secStf.appendChild(negBox);
    if (posBox) secStf.appendChild(posBox);
  }

  var hKeys = ['ROBAL','PartNumber','BatchNumber','CartridgeLsp','PO','AssayFamily','WeightLossSpec'];
  var hNeg = (model.sealNeg && model.sealNeg.header) ? model.sealNeg.header : null;
  var hPos = (model.sealPos && model.sealPos.header) ? model.sealPos.header : null;

  // pick a primary header to show
  var hMain = hNeg || hPos || {};

  secStf.appendChild(renderKvTable(hMain, hKeys));

  // header mismatch warning (NEG vs POS)
  if (hNeg && hPos) {
    for (var hk = 0; hk < hKeys.length; hk++) {
      var kk = hKeys[hk];
      var a = String(hNeg[kk] || '');
      var b = String(hPos[kk] || '');
      if (a && b && a !== b) {
        secStf.appendChild(el('div', { 'class': 'small warn', text: 'Header mismatch (' + kk + '): NEG=' + a + ' vs POS=' + b }));
      }
    }
  }

  // testers + signatures
  var tMap = {};
  var sMap = {};
  function addAll(map, arr) {
    if (!arr || !arr.length) return;
    for (var ii = 0; ii < arr.length; ii++) map[arr[ii]] = true;
  }
  if (model.sealNeg) { addAll(tMap, model.sealNeg.testers); addAll(sMap, model.sealNeg.signatures); }
  if (model.sealPos) { addAll(tMap, model.sealPos.testers); addAll(sMap, model.sealPos.signatures); }

  var tList = [];
  for (var tk in tMap) if (tMap.hasOwnProperty(tk)) tList.push(tk);
  tList.sort();
  var sList = [];
  for (var sk in sMap) if (sMap.hasOwnProperty(sk)) sList.push(sk);
  sList.sort();

  secStf.appendChild(el('div', { 'class': 'small', text: 'Name of Tester: ' + (tList.length ? tList.join(', ') : '—') }));
  secStf.appendChild(el('div', { 'class': 'small', text: 'Signatures: ' + (sList.length ? sList.join(', ') : '—') }));

  // violations
  var viol = [];
  function addViol(src, arr) {
    if (!arr || !arr.length) return;
    for (var ii = 0; ii < arr.length; ii++) {
      var v = arr[ii];
      viol.push({
        source: src,
        sheet: v.sheet,
        cartridge: v.cartridge,
        avg: v.avg,
        status: v.status,
        reason: v.reason,
        initial: v.initial,
        final: v.final,
        observation: v.observation
      });
    }
  }
  if (model.sealNeg) addViol('NEG', model.sealNeg.violations);
  if (model.sealPos) addViol('POS', model.sealPos.violations);

  secStf.appendChild(el('div', { 'class': 'small muted', text: 'Violations: ' + String(viol.length) }));
  if (viol.length) {
    secStf.appendChild(renderTable(
      ['Source','Sheet','Cartridge','Avg','Status','Reason','Initial','Final','Observation'],
      viol,
      function (r) { return [r.source, r.sheet, r.cartridge, r.avg, r.status, r.reason, r.initial, r.final, r.observation]; }
    ));
  } else {
    secStf.appendChild(el('div', { 'class': 'small muted', text: 'Inga violations hittades i Seal Test-filerna.' }));
  }

  out.appendChild(secStf);
} else if (model._xlsxSelected) {
  out.appendChild(el('div', { 'class': 'small muted', text: 'Tip: Ladda även upp Seal Test Neg.xlsx + Seal Test Pos.xlsx för STF Summary.' }));
}

if (hasWs) {
  var secWs = el('div', { 'class': 'card' });
  secWs.appendChild(el('h3', { text: 'Worksheet (header)' }));
  secWs.appendChild(el('div', { 'class': 'small', text: 'Sheet: ' + (model.worksheet.sheetName || '—') }));
  secWs.appendChild(el('div', { 'class': 'small', text: 'Part Number (B3): ' + (model.worksheet.partNumber || '—') }));
  secWs.appendChild(el('div', { 'class': 'small', text: 'Cartridge (LSP) (B4): ' + (model.worksheet.cartridgeLsp || '—') }));
  out.appendChild(secWs);
} else if (model._xlsxSelected) {
  out.appendChild(el('div', { 'class': 'small muted', text: 'Tip: Ladda upp Worksheet.xlsx för Part Number / Cartridge (LSP).' }));
}

    // Helper: render table
    function renderTable(columns, rows, rowToCells) {
      var tbl = el('table');
      var thead = el('thead');
      var trh = el('tr');
      for (var c = 0; c < columns.length; c++) trh.appendChild(el('th', { text: columns[c] }));
      thead.appendChild(trh);
      tbl.appendChild(thead);

      var tbody = el('tbody');
      for (var r = 0; r < rows.length; r++) {
        var tr = el('tr');
        var cells = rowToCells(rows[r]);
        for (var k = 0; k < cells.length; k++) tr.appendChild(el('td', { text: cells[k] }));
        tbody.appendChild(tr);
      }
      tbl.appendChild(tbody);
      return tbl;
    }

    // Section: duplicates
    var secDup = el('div', { 'class': 'card' });
    secDup.appendChild(el('h3', { text: 'Dubletter' }));

    if (!hasDupSample && !hasDupCart) {
      secDup.appendChild(el('div', { 'class': 'small muted', text: 'Inga dubletter hittades.' }));
    } else {
      if (hasDupSample) {
        secDup.appendChild(el('div', { 'class': 'small', text: 'Sample ID (>' + 1 + '):' }));
        secDup.appendChild(renderTable(['Sample ID', 'Count'], csv.duplicateSamples, function (x) { return [x.value, String(x.count)]; }));
      }
      if (hasDupCart) {
        secDup.appendChild(el('div', { 'class': 'small', text: 'Cartridge S/N (>' + 1 + '):' }));
        secDup.appendChild(renderTable(['Cartridge S/N', 'Count'], csv.duplicateCarts, function (x) { return [x.value, String(x.count)]; }));
      }
    }
    out.appendChild(secDup);

// Section: Parity Check (X/+)
if (csv.parity && csv.parity.enabled) {
  var secPar = el('div', { 'class': 'card' });
  secPar.appendChild(el('h3', { text: 'Parity Check (X/+ markers)' }));

  secPar.appendChild(el('div', { 'class': 'small', text: 'Base (lowest) Cartridge S/N: ' + String(csv.parity.baseSn || '—') }));
  secPar.appendChild(el('div', { 'class': 'small muted', text: 'Checked: ' + String(csv.parity.checked || 0) + ' | Missing marker: ' + String(csv.parity.missingMarker || 0) + ' | Mismatches: ' + String((csv.parity.mismatches && csv.parity.mismatches.length) ? csv.parity.mismatches.length : 0) }));

  if (csv.parity.mismatches && csv.parity.mismatches.length) {
    secPar.appendChild(renderTable(
      ['Sample ID','Cartridge S/N','Test Type','Expected','Actual','Δ from base'],
      csv.parity.mismatches,
      function (r) { return [r.sampleId, r.cartSn, r.testType, r.expectedMarker, r.actualMarker, r.delta]; }
    ));
  } else {
    secPar.appendChild(el('div', { 'class': 'small muted', text: 'Inga parity-mismatches hittades.' }));
  }

  out.appendChild(secPar);
}


// Section: Major Functional (False Pos/Neg)
var secMaj = el('div', { 'class': 'card' });
secMaj.appendChild(el('h3', { text: 'Major Functional' }));
if (!csv.major || !csv.major.counts) {
  secMaj.appendChild(el('div', { 'class': 'small muted', text: 'Ingen Major Functional-data.' }));
} else {
  var mc = csv.major.counts;
  secMaj.appendChild(el('div', { 'class': 'small', text: 'False Negative: ' + String(mc.false_negative || 0) + ' | False Positive: ' + String(mc.false_positive || 0) + ' | Invalid: ' + String(mc.invalid || 0) + ' | Expected Unknown: ' + String(mc.expected_unknown || 0) }));
  if (csv.major.deviations && csv.major.deviations.length) {
    secMaj.appendChild(renderTable(
      ['Major', 'Expected', 'Observed', 'Sample ID', 'Bag', 'Cartridge S/N', 'Test Type', 'Test Result', 'Error', 'User'],
      csv.major.deviations,
      function (r) {
        return [
          r.major,
          r.expected,
          r.observed,
          r.sampleId,
          (r.bag === null ? '' : String(r.bag)),
          r.cartSn,
          r.testType,
          r.testResult,
          r.error,
          r.user
        ];
      }
    ));
  } else {
    secMaj.appendChild(el('div', { 'class': 'small muted', text: 'Inga False Positive/False Negative hittades.' }));
  }
}
out.appendChild(secMaj);

    // Section: invalid results
    var secInv = el('div', { 'class': 'card' });
    secInv.appendChild(el('h3', { text: 'Invalid / No Result / Error' }));
    if (!hasInvalid) {
      secInv.appendChild(el('div', { 'class': 'small muted', text: 'Inga rader med NO RESULT / INVALID / ERROR hittades.' }));
    } else {
      
secInv.appendChild(renderTable(
        ['Sample ID', 'Ctrl', 'Bag', 'Cartridge S/N', 'Test Type', 'Observed', 'Expected', 'Major', 'Test Result', 'Error', 'Error Name', 'Retest', 'User', 'Markers'],
        csv.invalid,
        function (r) {
          return [
            r.sampleId,
            r.ctrl,
            (r.bag === null ? '' : String(r.bag)),
            r.cartSn,
            r.testType,
            r.observedCall,
            r.expected,
            r.major,
            r.testResult,
            r.error,
            r.errorName,
            r.retest,
            r.user,
            (r.markers && r.markers.length ? r.markers.join(', ') : '')
          ];
        }
      ));
    }
    out.appendChild(secInv);

    // Section: result summary
    var secRes = el('div', { 'class': 'card' });
    secRes.appendChild(el('h3', { text: 'Resultatsammanställning' }));
    if (!hasResultCounts) {
      secRes.appendChild(el('div', { 'class': 'small muted', text: 'Inga testresultat att summera.' }));
    } else {
      secRes.appendChild(renderTable(
        ['Test Result', 'Count'],
        csv.results,
        function (r) { return [r.value, String(r.count)]; }
      ));
    }
    out.appendChild(secRes);

    // Section: control expectations + deviations
    var secCtrl = el('div', { 'class': 'card' });
    secCtrl.appendChild(el('h3', { text: 'Kontroll-grupper (majoritet) + avvikelser' }));

    // Summary per ctrl
    var ctrlKeys = [];
    for (var ck in csv.ctrl.counts) if (csv.ctrl.counts.hasOwnProperty(ck)) ctrlKeys.push(ck);
    ctrlKeys.sort(function (a, b) {
      var ai = parseInt(a, 10), bi = parseInt(b, 10);
      if (!isNaN(ai) && !isNaN(bi)) return ai - bi;
      return String(a).localeCompare(String(b));
    });

    var ctrlRows = [];
    for (var ci = 0; ci < ctrlKeys.length; ci++) {
      var key = ctrlKeys[ci];
      var c = csv.ctrl.counts[key];
      var exp = csv.ctrl.expected[key] || 'unknown';
      // prefix summary (top 2)
      var pmap = csv.ctrl.prefixes[key] || {};
      var plist = [];
      for (var pk in pmap) if (pmap.hasOwnProperty(pk)) plist.push({ k: pk, n: pmap[pk] });
      plist.sort(function (a, b) { return b.n - a.n; });
      var ptxt = '';
      for (var pi = 0; pi < plist.length && pi < 2; pi++) {
        ptxt += (ptxt ? ', ' : '') + plist[pi].k + ' (' + plist[pi].n + ')';
      }

      ctrlRows.push({
        ctrl: key,
        expected: exp,
        detected: c.detected || 0,
        notDetected: c.not_detected || 0,
        unknown: c.unknown || 0,
        total: c.total || 0,
        prefixes: ptxt
      });
    }

    secCtrl.appendChild(renderTable(
      ['Ctrl', 'Expected', 'Detected', 'Not detected', 'Unknown', 'Total', 'Top prefixes'],
      ctrlRows,
      function (r) { return [r.ctrl, r.expected, String(r.detected), String(r.notDetected), String(r.unknown), String(r.total), r.prefixes]; }
    ));

    if (!hasCtrlDev) {
      secCtrl.appendChild(el('div', { 'class': 'small muted', text: 'Inga avvikelser mot majoritetsförväntan i kontroll-grupperna.' }));
    } else {
      secCtrl.appendChild(el('div', { 'class': 'small', text: 'Avvikelser (Expected != Observed):' }));
      secCtrl.appendChild(renderTable(
        ['Ctrl', 'Expected', 'Observed', 'Sample ID', 'Bag', 'Cartridge S/N', 'Test Type', 'Test Result'],
        csv.ctrl.deviations,
        function (r) {
          return [
            r.ctrl,
            r.expected,
            r.detectedClass,
            r.sampleId,
            (r.bag === null ? '' : String(r.bag)),
            r.cartSn,
            r.testType,
            r.testResult
          ];
        }
      ));
    }

    out.appendChild(secCtrl);

    // Section: bag coverage
    var secBag = el('div', { 'class': 'card' });
    secBag.appendChild(el('h3', { text: 'Bag coverage' }));
    if (csv.bag.min === null) {
      secBag.appendChild(el('div', { 'class': 'small muted', text: 'Kunde inte tolka bag-nummer från Sample ID.' }));
    } else {
      secBag.appendChild(el('div', { 'class': 'small', text: 'Bag range: ' + csv.bag.min + ' → ' + csv.bag.max }));
      if (hasMissingBags) {
        secBag.appendChild(el('div', { 'class': 'small err', text: 'Missing bags: ' + csv.bag.missing.join(', ') }));
      } else {
        secBag.appendChild(el('div', { 'class': 'small muted', text: 'Inga saknade bag-nummer inom spannet.' }));
      }
    }
    out.appendChild(secBag);

    // Debug footer
    out.appendChild(el('div', { 'class': 'small muted', text: 'Tips: Om något ser fel ut, öppna DevTools (F12) och kolla Console.' }));
  }


  // ----------------------------
  // Read files + run analysis
  // ----------------------------
function readFileAsArrayBuffer(file) {
  return new Promise(function (resolve, reject) {
    var fr = new FileReader();
    fr.onload = function () { resolve(fr.result); };
    fr.onerror = function () { reject(new Error('FileReader error: ' + (file && file.name ? file.name : ''))); };
    fr.readAsArrayBuffer(file);
  });
}

  function readFileAsText(file) {
    return new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onload = function () { resolve(fr.result); };
      fr.onerror = function () { reject(new Error('FileReader error: ' + (file && file.name ? file.name : ''))); };
      fr.readAsText(file);
    });
  }

function normStr(x) {
  if (x === null || x === undefined) return '';
  return String(x).replace(/\u00A0/g, ' ').trim();
}

// XLSX (minimal offline parser) -> { ok:true, headers:[...], rows:[ [..], [..] ], headerIdx:int }
// Uses JSZip + DOMParser (no external XLSX library required).
function parseXlsxGrid(arrayBuffer) {
  if (typeof JSZip === 'undefined') {
    return { ok: false, error: 'JSZip saknas (krävs för att läsa XLSX offline).' };
  }

  function colLettersToIndex(letters) {
    var n = 0;
    for (var i = 0; i < letters.length; i++) {
      var c = letters.charCodeAt(i);
      if (c >= 65 && c <= 90) n = n * 26 + (c - 64);
      else if (c >= 97 && c <= 122) n = n * 26 + (c - 96);
    }
    return n - 1; // 0-based
  }

  function parseCellRef(ref) {
    ref = String(ref || '');
    var m = ref.match(/^([A-Za-z]+)(\d+)$/);
    if (!m) return null;
    return { c: colLettersToIndex(m[1]), r: parseInt(m[2], 10) - 1 };
  }

  function xmlTextToDoc(xmlText) {
    try {
      return (new DOMParser()).parseFromString(xmlText, 'application/xml');
    } catch (e) {
      return null;
    }
  }

  // Helper: pick worksheet xml (prefer sheet1.xml)
  function pickWorksheetPath(zip) {
    if (zip.file('xl/worksheets/sheet1.xml')) return 'xl/worksheets/sheet1.xml';
    // fallback: first worksheet file
    var first = null;
    zip.forEach(function (relPath, entry) {
      if (first) return;
      if (entry && !entry.dir && relPath.indexOf('xl/worksheets/sheet') === 0 && relPath.slice(-4) === '.xml') {
        first = relPath;
      }
    });
    return first;
  }

  return JSZip.loadAsync(arrayBuffer).then(function (zip) {
    var tasks = [];
    var hasShared = !!zip.file('xl/sharedStrings.xml');
    var wsPath = pickWorksheetPath(zip);
    if (!wsPath) throw new Error('XLSX: kunde inte hitta worksheet xml.');

    // Load shared strings (optional)
    var pShared = hasShared
      ? zip.file('xl/sharedStrings.xml').async('string')
      : Promise.resolve('');

    tasks.push(pShared);
    tasks.push(zip.file(wsPath).async('string'));

    return Promise.all(tasks).then(function (res) {
      var sharedXml = res[0];
      var sheetXml = res[1];

      // sharedStrings
      var shared = [];
      if (sharedXml) {
        var sdoc = xmlTextToDoc(sharedXml);
        if (sdoc) {
          var si = sdoc.getElementsByTagName('si');
          for (var i = 0; i < si.length; i++) {
            // concatenate all <t>
            var tnodes = si[i].getElementsByTagName('t');
            var txt = '';
            for (var j = 0; j < tnodes.length; j++) {
              txt += tnodes[j].textContent || '';
            }
            shared.push(normStr(txt));
          }
        }
      }

      // sheet
      var doc = xmlTextToDoc(sheetXml);
      if (!doc) throw new Error('XLSX: kunde inte tolka sheet XML.');

      var cells = doc.getElementsByTagName('c');
      var grid = {}; // r -> { c -> value }
      var maxR = 0, maxC = 0;

      for (var k = 0; k < cells.length; k++) {
        var cEl = cells[k];
        var ref = cEl.getAttribute('r');
        var pos = parseCellRef(ref);
        if (!pos) continue;

        var t = cEl.getAttribute('t') || '';
        var vEl = cEl.getElementsByTagName('v')[0];
        var isEl = cEl.getElementsByTagName('is')[0];
        var val = '';

        if (t === 's') {
          var idx = vEl ? parseInt(vEl.textContent || '0', 10) : 0;
          val = (idx >= 0 && idx < shared.length) ? shared[idx] : '';
        } else if (t === 'inlineStr') {
          // inline string stored in <is><t>
          if (isEl) {
            var t2 = isEl.getElementsByTagName('t');
            var txt2 = '';
            for (var q = 0; q < t2.length; q++) txt2 += t2[q].textContent || '';
            val = normStr(txt2);
          }
        } else {
          // numbers, dates, etc -> read raw
          val = vEl ? normStr(vEl.textContent || '') : '';
        }

        if (!grid[pos.r]) grid[pos.r] = {};
        grid[pos.r][pos.c] = val;
        if (pos.r > maxR) maxR = pos.r;
        if (pos.c > maxC) maxC = pos.c;
      }

      // Build 2D array
      var rows2d = [];
      for (var rr = 0; rr <= maxR; rr++) {
        var rowObj = grid[rr] || {};
        var rowArr = [];
        for (var cc = 0; cc <= maxC; cc++) {
          rowArr.push(normStr(rowObj.hasOwnProperty(cc) ? rowObj[cc] : ''));
        }
        rows2d.push(rowArr);
      }

      // Header detection (same heuristic as CSV)
      var headerIdx = -1;
      for (rr = 0; rr < rows2d.length; rr++) {
        var joined = rows2d[rr].map(function (v) { return normStr(v).toLowerCase(); }).join(' ');
        if (joined.indexOf('assay') >= 0 && joined.indexOf('sample') >= 0 && (joined.indexOf('cartridge') >= 0 || joined.indexOf('s/n') >= 0)) {
          headerIdx = rr;
          break;
        }
      }
      if (headerIdx < 0) throw new Error('Kunde inte hitta header-rad i XLSX.');

      var headers = rows2d[headerIdx].map(normStr);
      var dataRows = [];
      for (rr = headerIdx + 1; rr < rows2d.length; rr++) {
        var r = rows2d[rr];
        if (!r || !r.length) continue;
        var any = false;
        for (cc = 0; cc < r.length; cc++) {
          if (normStr(r[cc])) { any = true; break; }
        }
        if (!any) continue;
        dataRows.push(r.map(normStr));
      }

      return { ok: true, headers: headers, rows: dataRows, headerIdx: headerIdx };
    });
  }).catch(function (e) {
    return { ok: false, error: (e && e.message) ? e.message : String(e) };
  });
}

  function pickByType(typeKey) {
    for (var i = 0; i < files.length; i++) {
      var tk = files[i].typeKey;
      if (tk === 'auto') tk = files[i].detectedKey;
      if (tk === typeKey) return files[i].file;
    }
    return null;
  }

    function runAnalysis() {
    var btn = $('runBtn');
    btn.disabled = true;
    setStatus('Analyserar...', false);

    var fTs = pickByType('testSummary');

    if (!fTs) {
      setStatus('Saknar Test Summary (csv/xlsx).', true);
      validateReady();
      return;
    }

    clearNode($('results'));
    $('results').appendChild(el('div', { 'class': 'small muted', text: 'Läser och analyserar Test Summary...' }));

    var nameLow = (fTs.name || '').toLowerCase();
    var isXlsx = (nameLow.indexOf('.xlsx') >= 0 || nameLow.indexOf('.xls') >= 0);

    var p;
    if (isXlsx) {
      p = readFileAsArrayBuffer(fTs).then(function (buf) {
        return parseXlsxGrid(buf);
      }).then(function (grid) {
        if (!grid.ok) throw new Error(grid.error || 'XLSX-parse misslyckades.');
        return analyzeTestSummaryTable(grid.headers, grid.rows, { delim: '', headerIdx: grid.headerIdx });
      });
    } else {
      p = readFileAsText(fTs).then(function (csvText) {
        var csv = parseCsv(csvText);
        if (!csv || !csv.ok) throw new Error((csv && csv.error) ? csv.error : 'CSV-parse misslyckades.');
        return csv;
      });
    }

    p.then(function (csv) {
      var model = { csv: csv, sealNeg: null, sealPos: null, worksheet: null };

      var fNeg = pickByType('sealNeg');
      var fPos = pickByType('sealPos');
      var fWs = pickByType('worksheet');
      model._xlsxSelected = !!(fNeg || fPos || fWs);

      var tasks = [];

      if (fNeg) {
        tasks.push(
          readFileAsArrayBuffer(fNeg)
            .then(function (buf) { return openXlsx(buf); })
            .then(function (xlsxObj) { model.sealNeg = analyzeSealTest(xlsxObj, 'NEG'); })
        );
      }

      if (fPos) {
        tasks.push(
          readFileAsArrayBuffer(fPos)
            .then(function (buf) { return openXlsx(buf); })
            .then(function (xlsxObj) { model.sealPos = analyzeSealTest(xlsxObj, 'POS'); })
        );
      }

      if (fWs) {
        tasks.push(
          readFileAsArrayBuffer(fWs)
            .then(function (buf) { return openXlsx(buf); })
            .then(function (xlsxObj) { model.worksheet = analyzeWorksheet(xlsxObj); })
        );
      }

      return Promise.all(tasks).then(function () {
                if (model.sealNeg || model.sealPos) { model.stfDecision = computeStfDecision(model.sealNeg, model.sealPos); }
renderResults(model);
        setStatus('OK – analys klar (Test Summary + XLSX).', false);
        validateReady();
      });
    }).catch(function (e) {
      var msg = (e && e.message) ? e.message : String(e);
      setStatus('Fel: ' + msg, true);
      clearNode($('results'));
      $('results').appendChild(el('div', { 'class': 'small err', text: msg }));
      validateReady();
    });
  } // <-- LÄGG TILL DENNA (stänger function runAnalysis)

  // ----------------------------
  // Wire UI
  // ----------------------------
  function init() {
    $('pickBtn').addEventListener('click', function () { $('fileInput').click(); });
    $('fileInput').addEventListener('change', function (ev) {
      if (ev.target && ev.target.files) addFiles(ev.target.files);
      $('fileInput').value = '';
    });

    $('clearBtn').addEventListener('click', function () {
      files = [];
      refreshFileList();
      $('results').textContent = 'Ingen analys kord an.';
      setStatus('', false);
    });

    $('runBtn').addEventListener('click', runAnalysis);

    var drop = $('drop');
    drop.addEventListener('dragover', function (e) { e.preventDefault(); drop.style.borderColor = 'rgba(31,111,235,0.9)'; });
    drop.addEventListener('dragleave', function () { drop.style.borderColor = 'rgba(255,255,255,0.16)'; });
    drop.addEventListener('drop', function (e) {
      e.preventDefault();
      drop.style.borderColor = 'rgba(255,255,255,0.16)';
      if (e.dataTransfer && e.dataTransfer.files) addFiles(e.dataTransfer.files);
    });

    refreshFileList();
  }

  init();

})();


