﻿param(
    [Parameter(Mandatory=$true)]
    [string]$ShortcutName,

    [Parameter(Mandatory=$true)]
    [string]$LauncherPs1,

    [Parameter(Mandatory=$false)]
    [string]$WorkingDir = 'C:\IPTCompile'
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Get-PowerShellExePath {
    return (Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe')
}

$desktop = [Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)
if ([string]::IsNullOrWhiteSpace($desktop)) {
    throw 'Could not resolve DesktopDirectory.'
}

$lnkName = $ShortcutName
if (-not $lnkName.ToLower().EndsWith('.lnk')) { $lnkName = $lnkName + '.lnk' }
$lnkPath = Join-Path $desktop $lnkName

$launcherFull = [System.IO.Path]::GetFullPath($LauncherPs1)
if (-not (Test-Path -LiteralPath $launcherFull)) {
    throw ("Launcher PS1 not found: {0}" -f $launcherFull)
}

$psExe = Get-PowerShellExePath

$wsh = New-Object -ComObject WScript.Shell
$sc = $wsh.CreateShortcut($lnkPath)
$sc.TargetPath = $psExe
$sc.Arguments  = ('-NoProfile -ExecutionPolicy Bypass -File "{0}"' -f $launcherFull)

if (-not [string]::IsNullOrWhiteSpace($WorkingDir)) {
    $sc.WorkingDirectory = $WorkingDir
}

$sc.Description = 'Run IPTCompile via local launcher (fast start)'
$sc.Save()

Write-Host ("Shortcut created/updated: {0}" -f $lnkPath)
exit 0