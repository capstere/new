﻿# requires -Version 5.1
# -----------------------------------------------------------------------------
# Main.ps1 (PowerShell 5.1)
# Patch: stabilare init, snabbare LSP-sökning, bättre resurs-städning
# -----------------------------------------------------------------------------

Set-StrictMode -Version 2.0

#region Imports & Config
if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
    $exe = Join-Path $PSHome 'powershell.exe'
    $scriptPath = if ($PSCommandPath) { $PSCommandPath } else { $MyInvocation.MyCommand.Path }
    Start-Process -FilePath $exe -ArgumentList "-NoProfile -STA -ExecutionPolicy Bypass -File `"$scriptPath`""
    exit
}

Add-Type -AssemblyName System.Windows.Forms
try { [System.Windows.Forms.Application]::EnableVisualStyles() } catch {}
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.ComponentModel
try {
    Add-Type -AssemblyName 'Microsoft.VisualBasic' -ErrorAction SilentlyContinue
} catch {}

$scriptPath = if ($PSCommandPath) { $PSCommandPath } else { $MyInvocation.MyCommand.Path }
$ScriptRootPath = [System.IO.Path]::GetDirectoryName([System.IO.Path]::GetFullPath($scriptPath))
$PSScriptRoot = $ScriptRootPath
try {
    $cwd = (Get-Location).Path
    Write-Host ("[EXEC] Script={0} | ScriptRoot={1} | CWD={2}" -f $scriptPath, $ScriptRootPath, $cwd)
} catch {}
$modulesRoot = Join-Path $ScriptRootPath 'Modules'


# Patch: samlade layoutkonstanter
$Layout = @{ SignatureCell = 'B47' }

. (Join-Path $modulesRoot 'Config.ps1') -ScriptRoot $ScriptRootPath
. (Join-Path $modulesRoot 'Splash.ps1')
. (Join-Path $modulesRoot 'UiStyling.ps1')
. (Join-Path $modulesRoot 'Logging.ps1')

try {
    $netRoot = ($env:IPT_NETWORK_ROOT + '').Trim()
    $iptRoot = ($global:IPT_ROOT_EFFECTIVE + '').Trim()
    $iptSrc  = ($global:IPT_ROOT_SOURCE + '').Trim()
    $logPath = ($global:LogPath + '').Trim()
    $jsonl   = ($global:StructuredLogPath + '').Trim()

    if (-not $netRoot) { $netRoot = '<empty>' }
    if (-not $iptRoot) { $iptRoot = '<empty>' }
    if (-not $iptSrc)  { $iptSrc  = '<empty>' }
    if (-not $logPath) { $logPath = '<empty>' }
    if (-not $jsonl)   { $jsonl   = '<empty>' }

    $msg = "Sanity: IPT_NETWORK_ROOT=$netRoot | IPT_ROOT_EFFECTIVE=$iptRoot | IPT_ROOT_SOURCE=$iptSrc | LogPath=$logPath | StructuredLogPath=$jsonl"
    try { Gui-Log -Text $msg -Severity 'Info' -Category 'SANITY' } catch { Write-Host $msg }
} catch { }

. (Join-Path $modulesRoot 'DataHelpers.ps1')
. (Join-Path $modulesRoot 'SignatureHelpers.ps1')
. (Join-Path $modulesRoot 'RuleEngine.ps1')

$global:SpEnabled = Get-ConfigFlag -Name 'EnableSharePoint' -Default $true -ConfigOverride $Config


$global:StartupReady = $true
$configStatus = $null

try {

    $configStatus = Test-Config
    if ($configStatus) {
        foreach ($err in $configStatus.Errors) { Gui-Log "❌ Konfig-fel: $err" 'Error' }
        foreach ($warn in $configStatus.Warnings) { Gui-Log "⚠️ Konfig-varning: $warn" 'Warn' }
        if (-not $configStatus.Ok) {
            $global:StartupReady = $false
            try { [System.Windows.Forms.MessageBox]::Show("Startkontroll misslyckades. Se logg för detaljer.","Startkontroll") | Out-Null } catch {}
        }
    }
} catch { Gui-Log "❌ Test-Config misslyckades: $($_.Exception.Message)" 'Error'; $global:StartupReady = $false }

$Host.UI.RawUI.WindowTitle = "Startar…"
Show-Splash "Laddar PnP.PowerShell…"
$env:PNPPOWERSHELL_UPDATECHECK = 'Off'  # stäng av update-check tidigt

$global:SpConnected = $false
$global:SpError     = $null

try {
    $null = Get-PackageProvider -Name "NuGet" -ForceBootstrap -ErrorAction SilentlyContinue
} catch {}

if ($global:SpEnabled) {
    try {
        Update-Splash "Laddar..."
        Import-Module PnP.PowerShell -ErrorAction Stop
    } catch {
        try {
            Gui-Log "ℹ️ PowerShell-modulen saknas, installerar modulen..." 'Info'
            Install-Module PnP.PowerShell -MaximumVersion 1.12.0 -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
            Update-Splash "Laddar..."
            Import-Module PnP.PowerShell -ErrorAction Stop
        } catch {
            $global:SpError = "PnP-install/import misslyckades: $($_.Exception.Message)"
        }
    }
} else {
    $global:SpError = 'SharePoint avstängt i Config'
    try { Gui-Log "ℹ️ SharePoint är avstängt i konfigurationen." 'Info' } catch {}
}
try { $null = Ensure-EPPlus -Version '4.5.3.3' } catch { Gui-Log "⚠️ EPPlus-förkontroll misslyckades: $($_.Exception.Message)" 'Warn' }

if ($global:SpEnabled -and -not $global:SpError) {
    try {
        Update-Splash "Ansluter till SharePoint"
        Connect-PnPOnline -Url $global:SP_SiteUrl `
                          -Tenant $global:SP_Tenant `
                          -ClientId $global:SP_ClientId `
                          -CertificateBase64Encoded $global:SP_CertBase64 `
                          -ErrorAction Stop
        $global:SpConnected = $true
    } catch {
        $msg = "Connect-PnPOnline misslyckades: $($_.Exception.Message)"
        Update-Splash $msg
        $global:SpError = $msg
    }
}

#endregion Imports & Config


# ===== GUI CONSTRUCTION & EVENT HANDLERS (Separated för structure) =====
. (Join-Path $PSScriptRoot 'GUI.ps1')
. (Join-Path $PSScriptRoot 'EventHandlers.ps1')


# === Tooltip-inställningar ===
$toolTip = New-Object System.Windows.Forms.ToolTip
$toolTip.AutoPopDelay = 8000
$toolTip.InitialDelay = 500
$toolTip.ReshowDelay  = 500
$toolTip.ShowAlways   = $true
$toolTip.SetToolTip($txtLSP, 'Ange LSP-numret utan "#" och klicka på Sök filer.')
$toolTip.SetToolTip($btnScan, 'Sök efter LSP och lista tillgängliga filer.')
$toolTip.SetToolTip($clbCsv,  'Välj CSV-fil.')
$toolTip.SetToolTip($clbNeg,  'Välj Seal Test Neg-fil.')
$toolTip.SetToolTip($clbPos,  'Välj Seal Test Pos-fil.')
$toolTip.SetToolTip($btnCsvBrowse, 'Bläddra efter en CSV-fil manuellt.')
$toolTip.SetToolTip($btnNegBrowse, 'Bläddra efter Seal Test Neg-fil manuellt.')
$toolTip.SetToolTip($btnPosBrowse, 'Bläddra efter Seal Test Pos-fil manuellt.')
$toolTip.SetToolTip($txtSigner, 'Skriv fullständigt namn, signatur och datum (separerat med kommatecken).')
$toolTip.SetToolTip($chkWriteSign, 'Signatur appliceras på flikar.')
$toolTip.SetToolTip($chkOverwriteSign, 'Dubbelkontroll för att aktivera signering')
$miToggleSign.ToolTipText = 'Visa eller dölj panelen för att lägga till signatur.'
if ($rbSaveInLsp) { $toolTip.SetToolTip($rbSaveInLsp, 'Spara rapporten i mappen för ditt LSP.') }
if ($rbTempOnly) { $toolTip.SetToolTip($rbTempOnly, 'Skapa rapporten temporär utan att spara.') }
$toolTip.SetToolTip($btnBuild, 'Skapa och öppna rapporten baserat på de valda filerna.')
if ($chkSharePointInfo) { $toolTip.SetToolTip($chkSharePointInfo, 'Exportera med SharePoint Info.') }
$txtLSP.add_TextChanged({ Update-BatchLink })

#region Main Run / Orchestration
# =============== SLUT ===============
function Enable-DoubleBuffer {
    $pi = [Windows.Forms.Control].GetProperty('DoubleBuffered',[Reflection.BindingFlags]'NonPublic,Instance')
    foreach($c in @($content,$pLog,$grpPick,$grpSign,$grpSave)) { if ($c) { $pi.SetValue($c,$true,$null) } }
}
try { Set-Theme 'light' } catch {}
Enable-DoubleBuffer
Update-BatchLink
[System.Windows.Forms.Application]::Run($form)

try{ Stop-Transcript | Out-Null }catch{}
#endregion Main Run / Orchestration
